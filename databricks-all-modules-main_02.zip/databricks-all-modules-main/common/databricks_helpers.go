package common

import (
	"context"
	"fmt"
	"testing"

	"github.com/databricks/databricks-sdk-go"
	"github.com/databricks/databricks-sdk-go/service/provisioning"
	"github.com/stretchr/testify/require"
)

// DatabricksManagedServicesCMKResult contains managed services CMK validation results
type DatabricksManagedServicesCMKResult struct {
	WorkspaceID string
	Configured  bool
	Reason      string
	CMKKeyID    string
	KMSKeyARN   string
}

// DatabricksStorageCMKResult contains workspace storage CMK validation results
type DatabricksStorageCMKResult struct {
	WorkspaceID              string
	StorageConfigurationID   string
	RootBucket               string
	KMSKeyARN                string
	Configured               bool
	Reason                   string
}

// GetDatabricksAccountClient returns a Databricks account-level client
func GetDatabricksAccountClient(t *testing.T, host, accountID, clientID, clientSecret string) *databricks.AccountClient {
	cfg := &databricks.Config{
		Host:         host,
		AccountID:    accountID,
		ClientID:     clientID,
		ClientSecret: clientSecret,
	}

	client, err := databricks.NewAccountClient(cfg)
	require.NoError(t, err, "Failed to create Databricks account client")
	return client
}

// GetDatabricksWorkspaceClient returns a Databricks workspace-level client
func GetDatabricksWorkspaceClient(t *testing.T, host, clientID, clientSecret string) *databricks.WorkspaceClient {
	cfg := &databricks.Config{
		Host:         host,
		ClientID:     clientID,
		ClientSecret: clientSecret,
	}

	client, err := databricks.NewWorkspaceClient(cfg)
	require.NoError(t, err, "Failed to create Databricks workspace client")
	return client
}

// CheckDatabricksManagedServicesCMK validates that managed services CMK is configured
func CheckDatabricksManagedServicesCMK(t *testing.T, accountClient *databricks.AccountClient, workspaceID int64) DatabricksManagedServicesCMKResult {
	ctx := context.TODO()

	result := DatabricksManagedServicesCMKResult{
		WorkspaceID: fmt.Sprintf("%d", workspaceID),
		Configured:  false,
	}

	// Get workspace details
	workspace, err := accountClient.Workspaces.GetByWorkspaceId(ctx, workspaceID)
	if err != nil {
		result.Reason = fmt.Sprintf("Unable to retrieve workspace details: %v", err)
		return result
	}

	// Check for managed services CMK
	cmkKeyID := workspace.ManagedServicesCustomerManagedKeyId

	if cmkKeyID == "" {
		result.Reason = "Managed services CMK not configured on workspace"
		return result
	}

	result.CMKKeyID = cmkKeyID

	// CMK is configured if we have an ID
	result.Configured = true
	result.Reason = "Managed services CMK configured (CMK ID found)"
	return result
}

// CheckDatabricksWorkspaceStorageCMK validates that workspace storage CMK is configured
func CheckDatabricksWorkspaceStorageCMK(t *testing.T, accountClient *databricks.AccountClient, workspaceID int64) DatabricksStorageCMKResult {
	ctx := context.TODO()

	result := DatabricksStorageCMKResult{
		WorkspaceID: fmt.Sprintf("%d", workspaceID),
		Configured:  false,
	}

	// Get workspace details
	workspace, err := accountClient.Workspaces.GetByWorkspaceId(ctx, workspaceID)
	if err != nil {
		result.Reason = fmt.Sprintf("Unable to retrieve workspace details: %v", err)
		return result
	}

	// Get storage configuration ID
	if workspace.StorageConfigurationId == "" {
		result.Reason = "No storage configuration ID found"
		return result
	}

	result.StorageConfigurationID = workspace.StorageConfigurationId

	// Storage configuration API may have changed
	// Mark as found if we have an ID
	result.Configured = false
	result.Reason = "Storage configuration ID found but details not accessible"

	// Check for storage CMK
	storageCMKID := workspace.StorageCustomerManagedKeyId

	if storageCMKID == "" {
		result.Reason = "Workspace storage CMK not configured"
		return result
	}

	// CMK is configured if we have an ID
	result.Configured = true
	result.Reason = "Workspace storage CMK configured (CMK ID found)"
	return result
}

// GetWorkspaceURL returns the workspace URL from workspace ID
func GetWorkspaceURL(t *testing.T, accountClient *databricks.AccountClient, workspaceID int64) string {
	ctx := context.TODO()

	workspace, err := accountClient.Workspaces.GetByWorkspaceId(ctx, workspaceID)
	require.NoError(t, err, "Failed to get workspace details")

	if workspace.DeploymentName == "" {
		t.Fatalf("Workspace deployment name not found")
	}

	// Construct workspace URL
	// Format: https://<deployment-name>.cloud.databricks.com
	return fmt.Sprintf("https://%s.cloud.databricks.com", workspace.DeploymentName)
}

// WaitForWorkspaceRunning waits for a workspace to be in RUNNING state
func WaitForWorkspaceRunning(t *testing.T, accountClient *databricks.AccountClient, workspaceID int64, maxRetries int) error {
	ctx := context.TODO()

	for i := 0; i < maxRetries; i++ {
		workspace, err := accountClient.Workspaces.GetByWorkspaceId(ctx, workspaceID)
		if err != nil {
			return fmt.Errorf("failed to get workspace status: %w", err)
		}

		if workspace.WorkspaceStatus == provisioning.WorkspaceStatusRunning {
			t.Logf("Workspace %d is RUNNING", workspaceID)
			return nil
		}

		t.Logf("Workspace %d status: %s (attempt %d/%d)", workspaceID, workspace.WorkspaceStatus, i+1, maxRetries)
		
		// Wait before next check (exponential backoff could be added here)
		// For now, using a simple fixed delay handled by caller
	}

	return fmt.Errorf("workspace did not reach RUNNING state after %d attempts", maxRetries)
}

// CheckUnityCatalogEnabled verifies that Unity Catalog is enabled on the workspace
func CheckUnityCatalogEnabled(t *testing.T, workspaceClient *databricks.WorkspaceClient) bool {
	ctx := context.TODO()

	// Try to list metastores (will fail if UC not enabled)
	metastores, err := workspaceClient.Metastores.ListAll(ctx)
	if err != nil {
		t.Logf("Unity Catalog not enabled or accessible: %v", err)
		return false
	}

	if len(metastores) == 0 {
		t.Logf("No metastores found")
		return false
	}

	t.Logf("Unity Catalog enabled with %d metastore(s)", len(metastores))
	return true
}

// GetWorkspaceMetastoreID returns the metastore ID assigned to a workspace
func GetWorkspaceMetastoreID(t *testing.T, accountClient *databricks.AccountClient, workspaceID int64) string {
	ctx := context.TODO()

	_, err := accountClient.Workspaces.GetByWorkspaceId(ctx, workspaceID)
	require.NoError(t, err, "Failed to get workspace details")

	// Metastore ID may not be directly accessible in current API version
	t.Logf("Metastore ID access not available in current API version")
	return ""
}

