variable "vault_mount" {
  type = string
}

variable "vault_path" {
  type = string
}

variable "client_id" {
  type = string
}

variable "client_secret" {
  type      = string
  sensitive = true
}
