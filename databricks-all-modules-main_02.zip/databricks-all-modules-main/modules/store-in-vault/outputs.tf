output "vault_path" {
  value = "${var.vault_mount}/data/${var.vault_path}"
}
