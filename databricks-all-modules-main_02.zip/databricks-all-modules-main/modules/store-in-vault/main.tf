resource "vault_kv_secret_v2" "this" {
  mount = var.vault_mount
  name  = var.vault_path

  data_json = jsonencode({
    client_id     = var.client_id
    client_secret = var.client_secret
  })
}
