package test

import (
	"testing"

	common "github.com/sandbox45/databricks-all-modules/common"
)

func TestStoreInVaultModule(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("vault")

	config := common.ModuleTestConfig{
		ModuleName:      "store-in-vault",
		TestDescription: "Tests Vault KV v2 secret storage for Databricks OAuth credentials",
		RequiredVars: map[string]interface{}{
			"vault_mount":   "secret",
			"vault_path":    uniqueID,
			"client_id":     "plan-only-client-id",
			"client_secret": "plan-only-client-secret",
		},
		ExpectedOutputs: []string{
			"vault_path",
		},
		SkipDestroy: true,
	}

	common.TestModuleWithConfig(t, config)
}
