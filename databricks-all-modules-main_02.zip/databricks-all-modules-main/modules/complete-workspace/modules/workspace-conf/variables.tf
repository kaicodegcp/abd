# ---------------------------------------------------------------------------
# Settings managed by workspace_setting_v2 (provider >= 1.117.0)
# ---------------------------------------------------------------------------

variable "disable_legacy_access" {
  description = "Disable legacy access (v2: disable_legacy_access). Disables direct Hive Metastore access, Fallback Mode on External Locations, and DBR < 13.3 LTS."
  type        = bool
  default     = true
}

variable "disable_legacy_dbfs" {
  description = "Disable legacy DBFS (v2: disable_legacy_dbfs). Blocks DBFS root/mount access. Takes up to 20 minutes; restart clusters and SQL warehouses after applying."
  type        = bool
  default     = true
}

variable "enable_results_downloading" {
  description = "Allow result downloads from the SQL Editor and AI/BI Dashboards (v2: sql_results_download). Does not affect notebook result downloads; use enable_notebook_results_downloading for that."
  type        = bool
  default     = false
}

variable "enable_notebook_table_clipboard" {
  description = "Allow copying notebook table output to clipboard (v2: enableNotebookTableClipboard)."
  type        = bool
  default     = false
}

variable "enable_export_notebook" {
  description = "Allow users to export notebooks and files (v2: enableExportNotebook)."
  type        = bool
  default     = false
}

variable "aibi_dashboard_embedding_approved_domains" {
  description = "Domains approved to embed AI/BI dashboards when aibi_dashboard_embedding_access_policy is ALLOW_APPROVED_DOMAINS (v2: aibi_dashboard_embedding_approved_domains)."
  type        = list(string)
  default     = []

  validation {
    condition = alltrue([
      for domain in var.aibi_dashboard_embedding_approved_domains :
      length(trimspace(domain)) > 0
    ])
    error_message = "aibi_dashboard_embedding_approved_domains must not contain blank or whitespace-only domains."
  }
}

variable "aibi_dashboard_embedding_access_policy" {
  description = "Domain access policy for embedding AI/BI dashboards (v2: aibi_dashboard_embedding_access_policy)."
  type        = string
  default     = "DENY_ALL_DOMAINS"

  validation {
    condition = contains([
      "ALLOW_ALL_DOMAINS",
      "ALLOW_APPROVED_DOMAINS",
      "DENY_ALL_DOMAINS",
    ], var.aibi_dashboard_embedding_access_policy)
    error_message = "aibi_dashboard_embedding_access_policy must be ALLOW_ALL_DOMAINS, ALLOW_APPROVED_DOMAINS, or DENY_ALL_DOMAINS."
  }
}

variable "restrict_workspace_admins_status" {
  description = "Restrict workspace admin capabilities (v2: restrict_workspace_admins.status). ALLOW_ALL leaves token/job run_as ownership unrestricted for workspace admins; RESTRICT_TOKENS_AND_JOB_RUN_AS limits service principal token creation and job owner/run_as changes."
  type        = string
  default     = "RESTRICT_TOKENS_AND_JOB_RUN_AS"

  validation {
    condition     = contains(["ALLOW_ALL", "RESTRICT_TOKENS_AND_JOB_RUN_AS"], var.restrict_workspace_admins_status)
    error_message = "restrict_workspace_admins_status must be ALLOW_ALL or RESTRICT_TOKENS_AND_JOB_RUN_AS."
  }
}

variable "restrict_workspace_admins_disable_gov_tag_creation" {
  description = "Prevent workspace admins from creating governed tags (v2: restrict_workspace_admins.disable_gov_tag_creation). This setting is independent of restrict_workspace_admins_status."
  type        = bool
  default     = true
}

variable "uc_volumes_download_ui" {
  description = "Allow downloading files from Unity Catalog volumes via the UI (v2: uc_volumes_download_ui)."
  type        = bool
  default     = false
}

# ---------------------------------------------------------------------------
# Settings managed by workspace_conf
# ---------------------------------------------------------------------------

variable "enable_verbose_audit_logs" {
  description = "Emit verbose audit log events (workspace_conf: enableVerboseAuditLogs)."
  type        = bool
  default     = true
}

variable "enable_dbfs_file_browser" {
  description = "Show the DBFS file browser in the UI (workspace_conf: enableDbfsFileBrowser)."
  type        = bool
  default     = false
}

variable "enforce_user_isolation" {
  description = "Enforce user isolation on shared compute (workspace_conf: enforceUserIsolation)."
  type        = bool
  default     = true
}

variable "store_results_in_customer_account" {
  description = "Store interactive notebook results in the customer's cloud account (workspace_conf: storeInteractiveNotebookResultsInCustomerAccount)."
  type        = bool
  default     = true
}

variable "enable_upload_data_uis" {
  description = "Show data upload UIs in the workspace (workspace_conf: enableUploadDataUis)."
  type        = bool
  default     = false
}

variable "enable_ip_access_lists" {
  description = "Enforce IP access list restrictions (workspace_conf: enableIpAccessLists). WARNING: if an allow list exists that excludes the caller, CI/CD runner, or NAT egress IPs, enabling this will cause an operational lockout. Ensure all required IPs are in databricks_ip_access_list resources before enabling."
  type        = bool
  default     = true
}

variable "enable_web_terminal" {
  description = "Enable the web terminal in cluster contexts (workspace_conf: enableWebTerminal)."
  type        = bool
  default     = false
}

variable "max_token_lifetime_days" {
  description = "Maximum personal access token lifetime in days for new tokens (workspace_conf: maxTokenLifetimeDays). Accepts 1-730 to enforce a custom limit, or 0 to remove any custom limit and revert to the Databricks system default of 730 days."
  type        = number
  default     = 90

  validation {
    condition = (
      var.max_token_lifetime_days >= 0 &&
      var.max_token_lifetime_days <= 730 &&
      var.max_token_lifetime_days == floor(var.max_token_lifetime_days)
    )
    error_message = "max_token_lifetime_days must be an integer between 0 and 730."
  }
}

variable "enable_notebook_results_downloading" {
  description = "Allow users to download notebook result output (workspace_conf: enableResultsDownloading). Does not affect SQL Editor or AI/BI Dashboard downloads."
  type        = bool
  default     = false
}

variable "enable_tokens_config" {
  description = "Enable PAT token management for the workspace (workspace_conf: enableTokensConfig). Set to false to disable PAT tokens workspace-wide."
  type        = bool
  default     = false
}

variable "enable_projects_allow_list" {
  description = "Enforce a Git host allow list for Repos (workspace_conf: enableProjectsAllowList). When true, only hosts in projects_allow_list are permitted."
  type        = bool
  default     = false
}

variable "projects_allow_list_permissions" {
  description = "Comma-separated list of Git permission types permitted when enable_projects_allow_list is true (workspace_conf: projectsAllowListPermissions). Omit to leave unset."
  type        = string
  default     = null

  validation {
    condition     = var.projects_allow_list_permissions == null || length(trimspace(var.projects_allow_list_permissions != null ? var.projects_allow_list_permissions : "")) > 0
    error_message = "projects_allow_list_permissions must not be blank when set."
  }
}

variable "projects_allow_list" {
  description = "Comma-separated list of approved Git domains for Repos (workspace_conf: projectsAllowList). Omit to leave unset."
  type        = string
  default     = null

  validation {
    condition     = var.projects_allow_list == null || length(trimspace(var.projects_allow_list != null ? var.projects_allow_list : "")) > 0
    error_message = "projects_allow_list must not be blank when set."
  }
}

variable "enable_project_type_in_workspace" {
  description = "Enable the Project workspace item type (workspace_conf: enableProjectTypeInWorkspace)."
  type        = bool
  default     = false
}

variable "customer_approved_ws_login_expiration_time" {
  description = "Expiration time for Databricks support access to this workspace (v2: customerApprovedWSLoginExpirationTime). Accepted values: a UTC timestamp (YYYY-MM-DDTHH:MM:SSZ, fractional seconds permitted), 'indefinite' to allow access without expiry, or empty string to revoke. Omit (null) to leave the setting unmanaged by this module — the current workspace value is preserved. Once set, continue supplying the desired value on each apply; reverting to null removes Terraform management but does not reset the workspace value."
  type        = string
  default     = "1998-01-01T00:00:00.000Z"
}

variable "additional_workspace_config" {
  description = "Extra key-value pairs merged into the workspace_conf block for settings not yet covered by this module. Must not duplicate keys already managed by this module. Keys and values must be non-blank."
  type        = map(string)
  default     = {}

  validation {
    condition = !anytrue([
      for k in keys(var.additional_workspace_config) : contains([
        "enableVerboseAuditLogs",
        "enableDbfsFileBrowser",
        "enforceUserIsolation",
        "storeInteractiveNotebookResultsInCustomerAccount",
        "enableUploadDataUis",
        "enableIpAccessLists",
        "enableWebTerminal",
        "maxTokenLifetimeDays",
        "enableResultsDownloading",
        "enableTokensConfig",
        "enableProjectsAllowList",
        "projectsAllowListPermissions",
        "projectsAllowList",
        "enableProjectTypeInWorkspace",
        "sql_results_download",
        "enableNotebookTableClipboard",
        "enableExportNotebook",
        "disableLegacyAccess",
        "disable_legacy_access",
        "disableLegacyDbfs",
        "disable_legacy_dbfs",
        "customerApprovedWSLoginExpirationTime",
        "aibi_dashboard_embedding_access_policy",
        "aibi_dashboard_embedding_approved_domains",
        "restrict_workspace_admins",
        "uc_volumes_download_ui",
      ], k)
    ])
    error_message = "additional_workspace_config must not contain keys already managed by this module. Use the dedicated input variables instead."
  }

  validation {
    condition = alltrue([
      for k, v in var.additional_workspace_config :
      length(trimspace(k)) > 0 && length(trimspace(v)) > 0
    ])
    error_message = "additional_workspace_config keys and values must not be blank or whitespace-only."
  }
}
