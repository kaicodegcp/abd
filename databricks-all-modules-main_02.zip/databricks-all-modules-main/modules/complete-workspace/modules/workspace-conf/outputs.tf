# ---------------------------------------------------------------------------
# workspace_conf outputs
# ---------------------------------------------------------------------------

output "workspace_conf_id" {
  description = "ID of the workspace_conf resource."
  value       = databricks_workspace_conf.security_settings.id
}

output "applied_settings" {
  description = "Map of key-value pairs written to workspace_conf. Reflects Terraform-managed state, not fully resolved platform state."
  value       = databricks_workspace_conf.security_settings.custom_config
}

# ---------------------------------------------------------------------------
# workspace_setting_v2 outputs
# ---------------------------------------------------------------------------

output "disable_legacy_access_effective" {
  description = "Effective value for disable_legacy_access. Null if unavailable."
  value       = try(databricks_workspace_setting_v2.disable_legacy_access.effective_boolean_val.value, null)
}

output "disable_legacy_dbfs_effective" {
  description = "Effective value for disable_legacy_dbfs. Null if unavailable."
  value       = try(databricks_workspace_setting_v2.disable_legacy_dbfs.effective_boolean_val.value, null)
}

output "enable_results_downloading_effective" {
  description = "Effective value for sql_results_download (SQL Editor and AI/BI Dashboards). Null if unavailable."
  value       = try(databricks_workspace_setting_v2.enable_results_downloading.effective_boolean_val.value, null)
}

output "enable_notebook_table_clipboard_effective" {
  description = "Effective value for enableNotebookTableClipboard. Null if unavailable."
  value       = try(databricks_workspace_setting_v2.enable_notebook_table_clipboard.effective_boolean_val.value, null)
}

output "enable_export_notebook_effective" {
  description = "Effective value for enableExportNotebook. Null if unavailable."
  value       = try(databricks_workspace_setting_v2.enable_export_notebook.effective_boolean_val.value, null)
}

output "customer_approved_ws_login_expiration_time_effective" {
  description = "Effective value for customerApprovedWSLoginExpirationTime. Null if not set."
  value       = try(databricks_workspace_setting_v2.customer_approved_ws_login_expiration_time[0].effective_string_val.value, null)
}

output "aibi_dashboard_embedding_approved_domains_effective" {
  description = "Effective approved domains for AI/BI dashboard embedding. Null unless the policy is ALLOW_APPROVED_DOMAINS."
  value       = try(databricks_workspace_setting_v2.aibi_dashboard_embedding_approved_domains[0].effective_aibi_dashboard_embedding_approved_domains.approved_domains, null)
}

output "aibi_dashboard_embedding_access_policy_effective" {
  description = "Effective AI/BI dashboard embedding access policy. Null if unavailable."
  value       = try(databricks_workspace_setting_v2.aibi_dashboard_embedding_access_policy.effective_aibi_dashboard_embedding_access_policy.access_policy_type, null)
}

output "restrict_workspace_admins_status" {
  description = "Effective restrict_workspace_admins status. Null if unavailable."
  value       = try(databricks_workspace_setting_v2.restrict_workspace_admins.effective_restrict_workspace_admins.status, null)
}

output "restrict_workspace_admins_disable_gov_tag_creation_effective" {
  description = "Effective governed-tag creation restriction for workspace admins. Null if unavailable."
  value       = try(databricks_workspace_setting_v2.restrict_workspace_admins.effective_restrict_workspace_admins.disable_gov_tag_creation, null)
}

output "uc_volumes_download_ui_effective" {
  description = "Effective value for uc_volumes_download_ui. Null if unavailable."
  value       = try(databricks_workspace_setting_v2.uc_volumes_download_ui.effective_boolean_val.value, null)
}
