# =============================================================================
# Workspace Configuration
# =============================================================================
# Manages workspace-level security settings using workspace_setting_v2 where
# the v2 API is available, and workspace_conf for the remainder.
# =============================================================================

# -----------------------------------------------------------------------------
# Migration note (existing deployments only)
#
# Step-by-step upgrade from the previous module version:
#   1. Pull the updated module code.
#   2. Confirm current workspace setting values before removing state.
#   3. Remove old resource addresses from state (names may differ per composition):
#        terraform state rm 'module.<name>.databricks_disable_legacy_access_setting.access'
#        terraform state rm 'module.<name>.databricks_disable_legacy_dbfs_setting.dbfs'
#   4. Run terraform plan.
#   5. Verify the plan shows no unintended setting changes before proceeding.
#   6. Run terraform apply.
#
# Two keys (enableNotebookTableClipboard, enableExportNotebook) were previously
# in workspace_conf and are now managed by workspace_setting_v2. Dual ownership
# of the same workspace property is not supported — do not deploy a version of
# this module that manages a key in both workspace_conf and workspace_setting_v2
# simultaneously. On the first apply, verify the plan removes these keys from
# the workspace_conf payload and that the corresponding v2 resources preserve
# the intended values.
# -----------------------------------------------------------------------------

resource "databricks_workspace_setting_v2" "disable_legacy_access" {
  name = "disable_legacy_access"
  boolean_val = {
    value = var.disable_legacy_access
  }
}

resource "databricks_workspace_setting_v2" "disable_legacy_dbfs" {
  name = "disable_legacy_dbfs"
  boolean_val = {
    value = var.disable_legacy_dbfs
  }
}

resource "databricks_workspace_setting_v2" "enable_results_downloading" {
  name = "sql_results_download"
  boolean_val = {
    value = var.enable_results_downloading
  }
}

resource "databricks_workspace_setting_v2" "enable_notebook_table_clipboard" {
  name = "enableNotebookTableClipboard"
  boolean_val = {
    value = var.enable_notebook_table_clipboard
  }
}

resource "databricks_workspace_setting_v2" "enable_export_notebook" {
  name = "enableExportNotebook"
  boolean_val = {
    value = var.enable_export_notebook
  }
}

resource "databricks_workspace_setting_v2" "customer_approved_ws_login_expiration_time" {
  count = var.customer_approved_ws_login_expiration_time != null ? 1 : 0
  name  = "customerApprovedWSLoginExpirationTime"
  string_val = {
    value = var.customer_approved_ws_login_expiration_time
  }
}

resource "databricks_workspace_setting_v2" "uc_volumes_download_ui" {
  name = "uc_volumes_download_ui"
  boolean_val = {
    value = var.uc_volumes_download_ui
  }
}

resource "databricks_workspace_setting_v2" "enable_notebook_results_downloading" {
  name = "enableResultsDownloading"
  boolean_val = {
    value = var.enable_notebook_results_downloading
  }
}

resource "databricks_workspace_setting_v2" "aibi_dashboard_embedding_approved_domains" {
  count = var.aibi_dashboard_embedding_access_policy == "ALLOW_APPROVED_DOMAINS" ? 1 : 0

  name = "aibi_dash_embed_ws_apprvd_domains"
  aibi_dashboard_embedding_approved_domains = {
    approved_domains = var.aibi_dashboard_embedding_approved_domains
  }

  depends_on = [databricks_workspace_setting_v2.aibi_dashboard_embedding_access_policy]
}

resource "databricks_workspace_setting_v2" "aibi_dashboard_embedding_access_policy" {
  name = "aibi_dash_embed_ws_acc_policy"
  aibi_dashboard_embedding_access_policy = {
    access_policy_type = var.aibi_dashboard_embedding_access_policy
  }
  effective_aibi_dashboard_embedding_access_policy = {
    access_policy_type = var.aibi_dashboard_embedding_access_policy
  }

  lifecycle {
    precondition {
      condition     = var.aibi_dashboard_embedding_access_policy != "ALLOW_APPROVED_DOMAINS" || length(var.aibi_dashboard_embedding_approved_domains) > 0
      error_message = "aibi_dashboard_embedding_approved_domains must contain at least one domain when aibi_dashboard_embedding_access_policy is ALLOW_APPROVED_DOMAINS."
    }
  }
}

resource "databricks_workspace_setting_v2" "restrict_workspace_admins" {
  name = "restrict_workspace_admins"
  restrict_workspace_admins = {
    status                   = var.restrict_workspace_admins_status
    disable_gov_tag_creation = var.restrict_workspace_admins_disable_gov_tag_creation
  }
  effective_restrict_workspace_admins = {
    status                   = var.restrict_workspace_admins_status
    disable_gov_tag_creation = var.restrict_workspace_admins_disable_gov_tag_creation
  }
}

# -----------------------------------------------------------------------------
# Settings not yet available in workspace_setting_v2
# -----------------------------------------------------------------------------

resource "databricks_workspace_conf" "security_settings" {
  custom_config = merge(
    {
      "enableVerboseAuditLogs"                           = tostring(var.enable_verbose_audit_logs)
      "enableDbfsFileBrowser"                            = tostring(var.enable_dbfs_file_browser)
      "enforceUserIsolation"                             = tostring(var.enforce_user_isolation)
      "storeInteractiveNotebookResultsInCustomerAccount" = tostring(var.store_results_in_customer_account)
      "enableUploadDataUis"                              = tostring(var.enable_upload_data_uis)
      "enableIpAccessLists"                              = tostring(var.enable_ip_access_lists)
      "enableWebTerminal"                                = tostring(var.enable_web_terminal)
      "maxTokenLifetimeDays"                             = tostring(var.max_token_lifetime_days)
      "enableTokensConfig"                               = tostring(var.enable_tokens_config)
      "enableProjectsAllowList"                          = tostring(var.enable_projects_allow_list)
      "enableProjectTypeInWorkspace"                     = tostring(var.enable_project_type_in_workspace)
    },
    var.projects_allow_list_permissions != null ? { "projectsAllowListPermissions" = var.projects_allow_list_permissions } : {},
    var.projects_allow_list != null ? { "projectsAllowList" = var.projects_allow_list } : {},
    var.additional_workspace_config
  )

  lifecycle {
    prevent_destroy = true

    precondition {
      condition     = !var.enable_projects_allow_list || var.projects_allow_list != null
      error_message = "projects_allow_list must be set when enable_projects_allow_list is true."
    }

    precondition {
      condition     = var.projects_allow_list_permissions == null || var.projects_allow_list != null
      error_message = "projects_allow_list must be set when projects_allow_list_permissions is provided."
    }
  }
}
