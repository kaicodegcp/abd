terraform {
  required_version = ">= 1.5"

  required_providers {
    databricks = {
      source  = "databricks/databricks"
      version = ">= 1.117.0, <= 1.128.0"
    }
  }
}
