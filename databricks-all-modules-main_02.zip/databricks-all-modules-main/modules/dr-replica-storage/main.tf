# =============================================================================
# Resilience DR - replica-side storage chain (runs against the SECONDARY workspace)
# =============================================================================
# A replicated catalog's storage root must resolve on the replica metastore.
# This module registers the already-created DR bucket ("<catalog-bucket>-dr",
# created by catalog-creation/complete-workspace dr.tf) in the SECONDARY
# workspace's metastore:
#
#   storage credential -> IAM role (trust uses the credential's external ID,
#   access on "<catalog-bucket>*" both regions + both KMS keys) -> 60s
#   propagation wait -> external location for the DR bucket (+ any extra
#   buckets, e.g. per-schema DR buckets).
#
# The role covers "<catalog-bucket>*" in ONE wildcard, so it reaches the
# primary bucket (needed for cross-region replication reads and failback) and
# every per-schema DR bucket, with no further IAM per schema.
#
# Providers: default aws (IAM is global) and a databricks provider pointing at
# the SECONDARY workspace. Requires the secondary workspace to have a
# metastore assigned.
# =============================================================================

data "aws_caller_identity" "current" {}

locals {
  # "<catalog-bucket>-dr" -> "<catalog-bucket>"
  bucket_base = trimsuffix(var.bucket_name, "-dr")
  role_name   = "${var.bucket_name}-replica"
  role_arn    = "arn:${var.aws_partition}:iam::${data.aws_caller_identity.current.account_id}:role/${local.role_name}"

  all_buckets = merge({ catalog = var.bucket_name }, var.extra_buckets)
}

# Credential first: Databricks generates the external ID the trust policy needs.
resource "databricks_storage_credential" "replica" {
  name = "${var.bucket_name}-replica-credential"

  aws_iam_role {
    role_arn = local.role_arn
  }
  isolation_mode = "ISOLATION_MODE_ISOLATED"
  force_destroy  = var.force_destroy
}

data "databricks_aws_unity_catalog_assume_role_policy" "replica" {
  aws_account_id        = data.aws_caller_identity.current.account_id
  role_name             = local.role_name
  unity_catalog_iam_arn = var.unity_catalog_iam_arn
  external_id           = databricks_storage_credential.replica.aws_iam_role[0].external_id
}

data "aws_iam_policy_document" "replica" {
  statement {
    sid = "ReplicaS3Access"
    actions = [
      "s3:GetObject",
      "s3:PutObject",
      "s3:DeleteObject",
      "s3:ListBucket",
      "s3:GetBucketLocation",
      "s3:GetLifecycleConfiguration",
      "s3:PutLifecycleConfiguration",
    ]
    resources = [
      "arn:${var.aws_partition}:s3:::${local.bucket_base}*",
      "arn:${var.aws_partition}:s3:::${local.bucket_base}*/*",
    ]
  }

  statement {
    sid = "ReplicaKmsAccess"
    actions = [
      "kms:Decrypt",
      "kms:Encrypt",
      "kms:GenerateDataKey",
      "kms:GenerateDataKeyWithoutPlaintext",
      "kms:DescribeKey",
    ]
    resources = var.kms_key_arns
  }

  # Self-assume, as the Databricks-generated UC policy includes.
  statement {
    sid       = "ReplicaSelfAssume"
    actions   = ["sts:AssumeRole"]
    resources = [local.role_arn]
  }
}

resource "aws_iam_role" "replica" {
  name               = local.role_name
  assume_role_policy = data.databricks_aws_unity_catalog_assume_role_policy.replica.json
  tags               = merge(var.tags, { Name = local.role_name })
}

resource "aws_iam_role_policy" "replica" {
  name   = "${local.role_name}-policy"
  role   = aws_iam_role.replica.id
  policy = data.aws_iam_policy_document.replica.json
}

resource "time_sleep" "replica_iam_propagation" {
  depends_on      = [aws_iam_role.replica, aws_iam_role_policy.replica]
  create_duration = "60s"
}

# for_each over a keyed map: the KEYS are plan-known logical names while the
# bucket-name VALUES may be apply-time. Removing one entry destroys only that
# external location instead of shifting the others (the count pitfall).
resource "databricks_external_location" "replica" {
  for_each = local.all_buckets

  name            = "${each.value}-replica-external-location"
  url             = "s3://${each.value}/"
  credential_name = databricks_storage_credential.replica.id
  comment         = "Replica-side external location for DR bucket ${each.value}"
  isolation_mode  = "ISOLATION_MODE_ISOLATED"
  # Managed DR creates replica catalogs/schemas/tables ON these locations
  # (outside Terraform state); without force, destroy fails with "dependent
  # schemas/tables". The underlying data lives in the -dr buckets, which are
  # purged by their own force_destroy.
  force_destroy = var.force_destroy

  depends_on = [time_sleep.replica_iam_propagation]
}

# count -> for_each migration: the main bucket's location moves to its key.
moved {
  from = databricks_external_location.replica[0]
  to   = databricks_external_location.replica["catalog"]
}
