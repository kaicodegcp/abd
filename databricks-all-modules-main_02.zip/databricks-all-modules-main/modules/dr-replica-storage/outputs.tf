output "storage_credential_name" {
  description = "Replica-side storage credential name."
  value       = databricks_storage_credential.replica.id
}

output "iam_role_arn" {
  description = "Replica-side IAM role ARN."
  value       = local.role_arn
}

output "external_location_names" {
  description = "Replica-side external location names (same order as bucket_name + extra_bucket_names)."
  value       = [for loc in databricks_external_location.replica : loc.name]
}
