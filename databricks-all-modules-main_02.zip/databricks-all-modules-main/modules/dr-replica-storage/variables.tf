variable "bucket_name" {
  description = "The DR bucket to register on the secondary metastore, e.g. <catalog-bucket>-dr (catalog-creation / complete-workspace output dr_bucket_name)."
  type        = string
}

# Why a map and why the keys must be plan-known: the external locations use
# for_each over this map, so each entry gets a stable state address
# ("...replica[\"schema1\"]") and removing one entry destroys only that one
# (a count list would shift the indexes of every later entry and churn them).
# for_each requires KEYS known at plan time; that cannot be expressed as a
# variable validation (validations defer on unknown values), but Terraform
# enforces it itself: apply-time keys fail the plan with "Invalid for_each
# argument". Use literal/plan-known keys; VALUES may be apply-time.
variable "extra_buckets" {
  description = "Additional DR buckets to register replica-side, keyed by a PLAN-KNOWN logical name (e.g. the schema name); values are bucket names and may be apply-time. Keys become the external location instance keys, so adding or removing one entry never disturbs the others."
  type        = map(string)
  default     = {}
  nullable    = false # an explicit null would break merge(); null becomes {}
}

variable "kms_key_arns" {
  description = "KMS key ARNs the replica role needs (the DR key, and the primary catalog key for cross-region reads/failback)."
  type        = list(string)

  validation {
    condition     = length(var.kms_key_arns) >= 1
    error_message = "At least one KMS key ARN is required (the DR bucket's key)."
  }
}

variable "unity_catalog_iam_arn" {
  description = "Databricks Unity Catalog master role ARN for the IAM trust policy."
  type        = string
  default     = "arn:aws:iam::414351767826:role/unity-catalog-prod-UCMasterRole-14S5ZJVKOTYTL"
}

variable "aws_partition" {
  description = "AWS partition (aws or aws-us-gov)."
  type        = string
  default     = "aws"
}

variable "tags" {
  description = "Tags for AWS resources."
  type        = map(string)
  default     = {}
}

variable "force_destroy" {
  description = "Force-delete the replica credential and external locations even when Managed-DR-created replica objects (catalogs/schemas/tables) depend on them. Required for clean teardown of a replicating pair."
  type        = bool
  default     = false
}
