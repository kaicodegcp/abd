# =============================================================================
# dr-replica-storage - basic example: register a catalog's DR twin bucket
# (plus per-schema twins) on the SECONDARY workspace's metastore.
# Requires the twin buckets to already exist.
# =============================================================================

terraform {
  required_version = ">= 1.5"
  required_providers {
    databricks = {
      source  = "databricks/databricks"
      version = ">= 1.125.0, < 2.0.0"
    }
    aws = {
      source  = "hashicorp/aws"
      version = ">= 5.0"
    }
    time = {
      source  = "hashicorp/time"
      version = ">= 0.9"
    }
  }
}

provider "aws" {
  region = "us-east-1" # IAM is global
}

provider "databricks" {
  host = "https://dbc-SECONDARY.cloud.databricks.com"
}

module "replica_storage" {
  source = "../.."

  # The catalog twin; drives the credential/role naming and the
  # "<catalog-bucket>*" IAM wildcard that also covers every schema twin.
  bucket_name = "acme-catalog-dr"

  # Keyed by a PLAN-KNOWN logical name; values may be apply-time.
  extra_buckets = {
    schema1 = "acme-catalog-schema1-dr"
  }

  # Keys of the primary bucket and the twin (regional keys, both sides).
  kms_key_arns = [
    "arn:aws:kms:us-east-1:111122223333:key/00000000-0000-0000-0000-000000000001",
    "arn:aws:kms:us-east-2:111122223333:key/00000000-0000-0000-0000-000000000002",
  ]

  force_destroy = true
}
