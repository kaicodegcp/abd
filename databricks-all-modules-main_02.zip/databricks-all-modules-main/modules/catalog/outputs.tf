output "id" {
  description = "The ID of the catalog."
  value       = databricks_catalog.this.id
}

output "name" {
  description = "The name of the catalog."
  value       = databricks_catalog.this.name
}

output "metastore_id" {
  description = "The ID of the metastore the catalog belongs to."
  value       = databricks_catalog.this.metastore_id
}

output "catalog_owner_group" {
  description = "Derived Unity Catalog owner group. The group owns the catalog and receives ALL_PRIVILEGES and MANAGE as defined by the RBAC model."
  value       = local.catalog_owner_group
}
