package test

import (
	"fmt"
	"os"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"

	common "github.com/sandbox45/databricks-all-modules/common"
)

func TestCatalogModuleOwnershipAndGroupName(t *testing.T) {
	t.Parallel()

	uniqueID := common.GenerateUniqueTestID("cat")
	environment := "dev"
	programName := "olympus"
	expectedOwnerGroup := fmt.Sprintf("dbx-%s-%s-catalog-%s-owner-grp", environment, programName, uniqueID)

	opts := &terraform.Options{
		TerraformDir: "../",
		Vars: map[string]interface{}{
			"name":          uniqueID,
			"environment":   environment,
			"program_name":  programName,
			"force_destroy": true,
		},
		PlanFilePath: t.TempDir() + "/plan.tfplan",
	}

	plan := terraform.InitAndPlanAndShowWithStruct(t, opts)

	terraform.AssertPlannedValuesMapKeyExists(t, plan, "databricks_catalog.this")

	catalog := plan.ResourcePlannedValuesMap["databricks_catalog.this"]
	assert.Equal(t, uniqueID, catalog.AttributeValues["name"])
	assert.Equal(t, expectedOwnerGroup, catalog.AttributeValues["owner"])

	terraform.AssertPlannedValuesMapKeyExists(t, plan, "databricks_grant.catalog_owner")
	ownerGrant := plan.ResourcePlannedValuesMap["databricks_grant.catalog_owner"]
	ownerPrivileges := ownerGrant.AttributeValues["privileges"].([]interface{})
	assert.ElementsMatch(t, []interface{}{"ALL_PRIVILEGES", "MANAGE"}, ownerPrivileges)
	assert.Equal(t, expectedOwnerGroup, ownerGrant.AttributeValues["principal"])
}

func TestCatalogModuleUseCatalogGrants(t *testing.T) {
	t.Parallel()

	uniqueID := common.GenerateUniqueTestID("cat-uc")
	schemaReadGroup := "dbx-dev-179392-dms-schema-dms-read-grp"

	opts := &terraform.Options{
		TerraformDir: "../",
		Vars: map[string]interface{}{
			"name":                   uniqueID,
			"environment":            "dev",
			"program_name":           "olympus",
			"force_destroy":          true,
			"use_catalog_principals": []string{schemaReadGroup},
		},
		PlanFilePath: t.TempDir() + "/plan.tfplan",
	}

	plan := terraform.InitAndPlanAndShowWithStruct(t, opts)

	resourceAddr := fmt.Sprintf(`databricks_grant.use_catalog["%s"]`, schemaReadGroup)
	terraform.AssertPlannedValuesMapKeyExists(t, plan, resourceAddr)

	grant := plan.ResourcePlannedValuesMap[resourceAddr]
	privileges := grant.AttributeValues["privileges"].([]interface{})
	assert.Equal(t, 1, len(privileges), "schema groups must receive exactly USE_CATALOG and nothing else")
	assert.Equal(t, "USE_CATALOG", privileges[0])
}

func TestCatalogModuleOwnerGroupConflictFails(t *testing.T) {
	t.Parallel()

	uniqueID := common.GenerateUniqueTestID("cat-conflict")
	environment := "dev"
	programName := "olympus"
	ownerGroup := fmt.Sprintf("dbx-%s-%s-catalog-%s-owner-grp", environment, programName, uniqueID)

	opts := &terraform.Options{
		TerraformDir: "../",
		Vars: map[string]interface{}{
			"name":                   uniqueID,
			"environment":            environment,
			"program_name":           programName,
			"force_destroy":          true,
			"use_catalog_principals": []string{ownerGroup},
		},
	}

	terraform.Init(t, opts)
	_, err := terraform.PlanE(t, opts)
	assert.Error(t, err, "plan should fail when use_catalog_principals contains the derived owner group")
}

func TestCatalogModuleNameValidationFails(t *testing.T) {
	t.Parallel()

	for _, invalidName := range []string{"My Catalog", "UPPERCASE", "has_underscore"} {
		name := invalidName
		t.Run(name, func(t *testing.T) {
			t.Parallel()
			opts := &terraform.Options{
				TerraformDir: "../",
				Vars: map[string]interface{}{
					"name":          name,
					"environment":   "dev",
					"program_name":  "olympus",
					"force_destroy": true,
				},
			}
			_, err := terraform.InitAndPlanE(t, opts)
			assert.Error(t, err, "plan should fail for invalid catalog name: %s", name)
		})
	}
}

// TestCatalogModuleApply requires TEST_CATALOG_NAME to be set to a catalog name whose
// derived owner group (dbx-dev-olympus-catalog-{name}-owner-grp) is pre-provisioned via SCIM.
func TestCatalogModuleApply(t *testing.T) {
	if testing.Short() {
		t.Skip("skipping apply test in short mode")
	}

	catalogName := os.Getenv("TEST_CATALOG_NAME")
	if catalogName == "" {
		t.Skip("TEST_CATALOG_NAME not set — must reference a catalog whose derived owner group is pre-provisioned via SCIM")
	}

	config := common.ModuleTestConfig{
		ModuleName:      "catalog",
		TestDescription: "Apply test for catalog module with UC ownership validation",
		RequiredVars: map[string]interface{}{
			"name":         catalogName,
			"environment":  "dev",
			"program_name": "olympus",
		},
		OptionalVars: map[string]interface{}{
			"force_destroy": true,
		},
		ExpectedOutputs: []string{"id", "name", "metastore_id", "catalog_owner_group"},
	}

	common.TestModuleWithConfig(t, config)
}
