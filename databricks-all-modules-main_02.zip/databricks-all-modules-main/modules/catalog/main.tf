# Groups must exist as SCIM-synced account-level groups before apply.
# Catalog owner group pattern: dbx-{environment}-{program_name}-catalog-{name}-owner-grp
# ISOLATED isolation_mode requires databricks_catalog_workspace_binding — managed outside this module.

locals {
  catalog_owner_group = "dbx-${var.environment}-${var.program_name}-catalog-${var.name}-owner-grp"
}

resource "databricks_catalog" "this" {
  name            = var.name
  comment         = var.comment
  properties      = var.properties
  storage_root    = var.storage_root
  provider_name   = var.provider_name
  share_name      = var.share_name
  connection_name = var.connection_name
  options         = var.options
  owner           = local.catalog_owner_group
  isolation_mode  = var.isolation_mode
  force_destroy   = var.force_destroy
}

resource "databricks_grant" "catalog_owner" {
  catalog    = databricks_catalog.this.name
  principal  = local.catalog_owner_group
  privileges = ["ALL_PRIVILEGES", "MANAGE"]
}

# USE_CATALOG is the only catalog-level privilege granted to schema groups.
# All schema-level access (SELECT, MODIFY, etc.) is managed by modules/schema.
resource "databricks_grant" "use_catalog" {
  for_each = var.use_catalog_principals

  catalog    = databricks_catalog.this.name
  principal  = each.key
  privileges = ["USE_CATALOG"]

  lifecycle {
    precondition {
      condition     = each.key != local.catalog_owner_group
      error_message = "use_catalog_principals must not include the catalog-owner group; catalog-owner access is managed separately via ownership and databricks_grant.catalog_owner."
    }
  }
}
