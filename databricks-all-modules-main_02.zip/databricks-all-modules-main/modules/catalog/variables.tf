variable "name" {
  description = "Name of the catalog. Must not contain periods, spaces, or forward slashes. Unity Catalog stores names as lowercase."
  type        = string

  validation {
    condition     = length(trimspace(var.name)) > 0 && !can(regex("[./\\s]", var.name))
    error_message = "name must not be empty and must not contain periods, forward slashes, or spaces."
  }
}

variable "environment" {
  description = "Deployment environment used in group name construction (dev, uat, prod)."
  type        = string

  validation {
    condition     = contains(["dev", "uat", "prod"], var.environment)
    error_message = "environment must be one of: dev, uat, prod."
  }
}

variable "program_name" {
  description = "Platform program name used in catalog owner group construction. Must be lowercase alphanumeric and hyphens only. Produces: dbx-{environment}-{program_name}-catalog-{name}-owner-grp."
  type        = string

  validation {
    condition     = can(regex("^[a-z0-9][a-z0-9-]*$", var.program_name))
    error_message = "program_name must be lowercase alphanumeric and hyphens only (no spaces, underscores, or uppercase)."
  }
}

variable "comment" {
  description = "Comment/description for the catalog."
  type        = string
  default     = null
}

variable "properties" {
  description = "Catalog properties. Use tags to identify data classification or ABAC policy targets."
  type        = map(string)
  default     = {}
}

variable "storage_root" {
  description = "Storage root location for managed tables."
  type        = string
  default     = null
}

variable "provider_name" {
  description = "Delta Sharing provider name."
  type        = string
  default     = null
}

variable "share_name" {
  description = "Delta Sharing share name."
  type        = string
  default     = null
}

variable "connection_name" {
  description = "Connection name for external catalogs."
  type        = string
  default     = null
}

variable "options" {
  description = "Connection options for external catalogs."
  type        = map(string)
  default     = {}
}

variable "isolation_mode" {
  description = "Isolation mode. ISOLATED (default) restricts catalog to specific workspace bindings managed via databricks_catalog_workspace_binding. OPEN allows all metastore workspaces to see the catalog."
  type        = string
  default     = "ISOLATED"

  validation {
    condition     = contains(["OPEN", "ISOLATED"], var.isolation_mode)
    error_message = "isolation_mode must be OPEN or ISOLATED."
  }
}

variable "force_destroy" {
  description = "Allow Terraform to destroy the catalog even when it contains schemas or tables."
  type        = bool
  default     = false
}

variable "use_catalog_principals" {
  description = "Set of SCIM-synced account-level group names to grant USE_CATALOG on this catalog. Typically the schema-scope groups provisioned by modules/schema (read/write/owner) for each app that uses this catalog. USE_CATALOG is the only catalog-level privilege granted here; all schema-level access is managed separately."
  type        = set(string)
  default     = []

  validation {
    condition = alltrue([
      for p in var.use_catalog_principals : length(trimspace(p)) > 0
    ])
    error_message = "Each use_catalog_principals entry must be a non-empty string."
  }
}
