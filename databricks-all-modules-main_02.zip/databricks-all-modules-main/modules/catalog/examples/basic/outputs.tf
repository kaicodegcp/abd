output "id" {
  description = "The ID of the catalog."
  value       = module.catalog.id
}

output "name" {
  description = "The name of the catalog."
  value       = module.catalog.name
}

output "metastore_id" {
  description = "The ID of the metastore the catalog belongs to."
  value       = module.catalog.metastore_id
}

output "catalog_owner_group" {
  description = "Derived catalog-owner group name."
  value       = module.catalog.catalog_owner_group
}
