provider "databricks" {}

module "catalog" {
  source = "../../"

  name           = var.name
  environment    = var.environment
  program_name   = var.program_name
  comment        = var.comment
  properties     = var.properties
  isolation_mode = var.isolation_mode
  force_destroy  = var.force_destroy

  use_catalog_principals = var.use_catalog_principals
}
