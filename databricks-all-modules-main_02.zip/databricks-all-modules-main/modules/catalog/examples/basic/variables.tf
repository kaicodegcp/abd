variable "name" {
  description = "Name of the catalog."
  type        = string
}

variable "environment" {
  description = "Deployment environment (dev, uat, prod)."
  type        = string
}

variable "program_name" {
  description = "Platform program name used in catalog owner group construction (e.g. olympus)."
  type        = string
}

variable "comment" {
  description = "Comment/description for the catalog."
  type        = string
  default     = null
}

variable "properties" {
  description = "Catalog properties."
  type        = map(string)
  default     = {}
}

variable "isolation_mode" {
  description = "Catalog isolation mode. ISOLATED (default) requires databricks_catalog_workspace_binding."
  type        = string
  default     = "ISOLATED"
}

variable "force_destroy" {
  description = "Allow Terraform to destroy the catalog even when it contains schemas or tables."
  type        = bool
  default     = false
}

variable "use_catalog_principals" {
  description = "Set of group names to grant USE_CATALOG. Typically schema-scope groups from modules/schema."
  type        = set(string)
  default     = []
}
