# =============================================================================
# Complete Databricks Workspace Module (Custom VPC) - SRA-Aligned
# Same as complete-workspace but does NOT create VPC or PrivateLink VPC endpoints.
# Provide vpc_id, private_subnet_ids, vpc_cidr, workspace_security_group_ids, and
# (when using PrivateLink) MWS VPC endpoint IDs. Optional private_access_settings_id
# (same passthrough pattern as complete-workspace-serverless). Optional Unity Catalog
# managed catalog via create_default_catalog and catalog-creation.
# =============================================================================

# Provider requirements are in versions.tf

# =============================================================================
# DATA SOURCES
# =============================================================================

data "aws_caller_identity" "current" {}

data "databricks_aws_assume_role_policy" "this" {
  provider    = databricks.account
  external_id = var.databricks_account_id
}


# =============================================================================
# LOCALS
# =============================================================================

locals {
  prefix = var.workspace_name
  suffix = random_string.suffix.result

  computed_aws_partition = var.databricks_gov_shard != null ? "aws-us-gov" : "aws"

  databricks_aws_account_id = var.databricks_gov_shard == "civilian" ? "044793339203" : (
    var.databricks_gov_shard == "dod" ? "170661010020" : "414351767826"
  )

  databricks_ec2_image_account_id = var.databricks_gov_shard != null ? "044732911619" : "601306020600"



  assume_role_partition = var.databricks_gov_shard == "dod" ? "aws-us-gov-dod" : (
    var.databricks_gov_shard == "civilian" ? "aws-us-gov" : "aws"
  )

  root_bucket_name = module.s3_bucket.s3_bucket_id
}

# =============================================================================
# RANDOM SUFFIX MODULE
# =============================================================================

resource "random_string" "suffix" {
  length  = 6
  special = false
  upper   = false
}

# =============================================================================
# AWS S3 ROOT STORAGE BUCKET
# =============================================================================

module "s3_bucket" {
  source  = "terraform-aws-modules/s3-bucket/aws"
  version = "~> 4.0"

  bucket = "${local.prefix}-root-${local.suffix}"

  force_destroy       = var.force_destroy
  acceleration_status = "Suspended"

  versioning = {
    enabled = var.root_bucket_versioning
  }

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true

  server_side_encryption_configuration = {
    rule = {
      apply_server_side_encryption_by_default = {
        sse_algorithm     = var.enable_cmk ? "aws:kms" : "AES256"
        kms_master_key_id = var.enable_cmk ? var.workspace_storage_kms_key_arn : null
      }
      bucket_key_enabled = var.enable_cmk
    }
  }

  attach_policy = true
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "Grant Databricks Access"
        Effect = "Allow"
        Principal = {
          AWS = "arn:${local.computed_aws_partition}:iam::${local.databricks_aws_account_id}:root"
        }
        Action = [
          "s3:GetObject",
          "s3:GetObjectVersion",
          "s3:ListBucket",
          "s3:GetBucketLocation",
          "s3:PutObject",
          "s3:DeleteObject"
        ]
        Resource = [
          "arn:${local.computed_aws_partition}:s3:::${local.prefix}-root-${local.suffix}/*",
          "arn:${local.computed_aws_partition}:s3:::${local.prefix}-root-${local.suffix}"
        ]
        Condition = {
          StringEquals = {
            "aws:PrincipalTag/DatabricksAccountId" = var.databricks_account_id
          }
        }
      }
    ]
  })

  tags = merge(var.tags, {
    Name    = "Databricks Workspace Storage"
    Purpose = "Databricks Root Storage"
  })
}

# =============================================================================
# DATABRICKS PRIVATELINK REGISTRATION (register caller-provided AWS VPC endpoints)
# =============================================================================

resource "databricks_mws_vpc_endpoint" "backend_rest" {
  provider = databricks.account
  count    = var.enable_private_link ? 1 : 0

  account_id          = var.databricks_account_id
  aws_vpc_endpoint_id = var.rest_api_aws_vpc_endpoint_id
  vpc_endpoint_name   = "${local.prefix}-vpce-backend-${var.vpc_id}"
  region              = var.aws_region
}

resource "databricks_mws_vpc_endpoint" "backend_relay" {
  provider = databricks.account
  count    = var.enable_private_link ? 1 : 0

  account_id          = var.databricks_account_id
  aws_vpc_endpoint_id = var.dataplane_relay_aws_vpc_endpoint_id
  vpc_endpoint_name   = "${local.prefix}-vpce-relay-${var.vpc_id}"
  region              = var.aws_region
}

# =============================================================================
# AWS IAM ROLE MODULE
# =============================================================================

module "iam_assumable_role_databricks" {
  source  = "terraform-aws-modules/iam/aws//modules/iam-assumable-role"
  version = "~> 5.0"

  trusted_role_arns = []

  create_role                     = true
  role_name                       = "${local.prefix}-cross-account-${local.suffix}"
  role_requires_mfa               = false
  create_custom_role_trust_policy = true
  custom_role_trust_policy        = data.databricks_aws_assume_role_policy.this.json

  custom_role_policy_arns = [module.iam_policy_databricks.arn]

  tags = merge(var.tags, { Name = "Databricks Cross-Account Role" })
}

# =============================================================================
# AWS IAM POLICY MODULE (SRA-aligned: GetLaunchTemplateData, GetSpotPlacementScores, AllowEC2Tagging)
# =============================================================================

module "iam_policy_databricks" {
  source  = "terraform-aws-modules/iam/aws//modules/iam-policy"
  version = "~> 5.0"

  name        = "${local.prefix}-databricks-policy-${local.suffix}"
  description = "Databricks cross-account policy with full EC2 and networking permissions"

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "CreateEC2ResourcesWithRequestTag"
        Effect = "Allow"
        Action = [
          "ec2:CreateFleet",
          "ec2:CreateLaunchTemplate",
          "ec2:CreateLaunchTemplateVersion",
          "ec2:CreateVolume",
          "ec2:RequestSpotInstances",
          "ec2:RunInstances"
        ]
        Resource = [
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:volume/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:instance/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:fleet/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:launch-template/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:network-interface/*"
        ]
        Condition = {
          StringEquals = {
            "aws:RequestTag/Vendor" = "Databricks"
          }
        }
      },
      {
        Sid    = "AllowDatabricksTagOnCreate"
        Effect = "Allow"
        Action = ["ec2:CreateTags"]
        Resource = [
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:volume/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:instance/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:launch-template/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:fleet/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:network-interface/*"
        ]
        Condition = {
          StringEquals = {
            "ec2:CreateAction" = [
              "CreateFleet",
              "CreateLaunchTemplate",
              "CreateVolume",
              "RequestSpotInstances",
              "RunInstances"
            ]
            "aws:RequestTag/Vendor" = "Databricks"
          }
        }
      },
      {
        Sid    = "ModifyEC2ResourcesByResourceTags"
        Effect = "Allow"
        Action = [
          "ec2:AssignPrivateIpAddresses",
          "ec2:AssociateIamInstanceProfile",
          "ec2:AttachVolume",
          "ec2:CancelSpotInstanceRequests",
          "ec2:CreateLaunchTemplateVersion",
          "ec2:DetachVolume",
          "ec2:DisassociateIamInstanceProfile",
          "ec2:ModifyFleet",
          "ec2:ModifyLaunchTemplate",
          "ec2:RequestSpotInstances",
          "ec2:CreateFleet",
          "ec2:CreateLaunchTemplate",
          "ec2:CreateVolume",
          "ec2:RunInstances"
        ]
        Resource = [
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:instance/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:volume/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:network-interface/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:launch-template/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:fleet/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:spot-instance-request/*"
        ]
        Condition = {
          StringEquals = {
            "ec2:ResourceTag/Vendor" = "Databricks"
          }
        }
      },
      {
        Sid    = "GetEC2LaunchTemplateDataByTag"
        Effect = "Allow"
        Action = [
          "ec2:GetLaunchTemplateData"
        ]
        Resource = [
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:volume/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:instance/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:fleet/*"
        ]
        Condition = {
          StringEquals = {
            "ec2:ResourceTag/Vendor" = "Databricks"
          }
        }
      },
      {
        Sid    = "DescribeEC2Resources"
        Effect = "Allow"
        Action = [
          "ec2:DescribeAvailabilityZones",
          "ec2:DescribeFleetHistory",
          "ec2:DescribeFleetInstances",
          "ec2:DescribeVpcAttribute",
          "ec2:DescribeFleets",
          "ec2:DescribeIamInstanceProfileAssociations",
          "ec2:DescribeInstanceStatus",
          "ec2:DescribeInstances",
          "ec2:DescribeInternetGateways",
          "ec2:DescribeLaunchTemplates",
          "ec2:DescribeLaunchTemplateVersions",
          "ec2:DescribeNatGateways",
          "ec2:DescribeNetworkAcls",
          "ec2:DescribePrefixLists",
          "ec2:DescribeReservedInstancesOfferings",
          "ec2:DescribeRouteTables",
          "ec2:DescribeSecurityGroups",
          "ec2:DescribeSpotInstanceRequests",
          "ec2:DescribeSpotPriceHistory",
          "ec2:DescribeSubnets",
          "ec2:DescribeVolumes",
          "ec2:DescribeVpcs",
          "ec2:GetSpotPlacementScores"
        ]
        Resource = "*"
      },
      {
        Sid    = "DeleteEC2ResourcesByTag"
        Effect = "Allow"
        Action = [
          "ec2:DeleteFleets",
          "ec2:DeleteLaunchTemplate",
          "ec2:DeleteLaunchTemplateVersions",
          "ec2:DeleteTags",
          "ec2:DeleteVolume",
          "ec2:TerminateInstances"
        ]
        Resource = [
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:instance/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:volume/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:network-interface/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:launch-template/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:fleet/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:spot-instance-request/*"
        ]
        Condition = {
          StringEquals = {
            "ec2:ResourceTag/Vendor" = "Databricks"
          }
        }
      },
      {
        Sid    = "AllowEC2TaggingOnDatabricksResources"
        Effect = "Allow"
        Action = [
          "ec2:CreateTags",
          "ec2:DeleteTags"
        ]
        Resource = [
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:instance/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:volume/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:network-interface/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:launch-template/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:fleet/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:spot-instance-request/*"
        ]
        Condition = {
          StringEquals = {
            "ec2:ResourceTag/Vendor" = "Databricks"
          }
        }
      },
      {
        Sid    = "VpcNonresourceSpecificActions"
        Effect = "Allow"
        Action = [
          "ec2:AuthorizeSecurityGroupEgress",
          "ec2:AuthorizeSecurityGroupIngress",
          "ec2:RevokeSecurityGroupEgress",
          "ec2:RevokeSecurityGroupIngress"
        ]
        Resource = [
          for sg in var.workspace_security_group_ids :
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:security-group/${sg}"
        ]
        Condition = {
          StringEquals = {
            "ec2:vpc" = "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:vpc/${var.vpc_id}"
          }
        }
      },
      {
        Sid    = "RestrictAMIUsageToDatabricksDeny"
        Effect = "Deny"
        Action = [
          "ec2:RunInstances",
          "ec2:CreateFleet",
          "ec2:RequestSpotInstances"
        ]
        Resource = "arn:${local.computed_aws_partition}:ec2:*:*:image/*"
        Condition = {
          StringNotEquals = {
            "ec2:Owner" = local.databricks_ec2_image_account_id
          }
        }
      },
      {
        Sid    = "RestrictAMIUsageToDatabricksAllow"
        Effect = "Allow"
        Action = [
          "ec2:RunInstances",
          "ec2:CreateFleet",
          "ec2:RequestSpotInstances"
        ]
        Resource = "arn:${local.computed_aws_partition}:ec2:*:*:image/*"
        Condition = {
          StringEquals = {
            "ec2:Owner" = local.databricks_ec2_image_account_id
          }
        }
      },
      {
        Sid    = "AllowRunInstancesWithScopedResources"
        Effect = "Allow"
        Action = "ec2:RunInstances"
        Resource = [
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:subnet/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:security-group/*"
        ]
        Condition = {
          StringEqualsIfExists = {
            "ec2:vpc" = "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:vpc/${var.vpc_id}"
          }
        }
      },
      {
        Sid    = "IAMRoleForEC2Spot"
        Effect = "Allow"
        Action = ["iam:CreateServiceLinkedRole"]
        Resource = [
          "arn:${local.computed_aws_partition}:iam::*:role/aws-service-role/spot.amazonaws.com/AWSServiceRoleForEC2Spot"
        ]
        Condition = {
          StringLike = {
            "iam:AWSServiceName" = "spot.amazonaws.com"
          }
        }
      }
    ]
  })

  tags = merge(var.tags, { Name = "Databricks Cross-Account Policy" })
}

# =============================================================================
# DATABRICKS MWS MODULES - ACCOUNT LEVEL
# =============================================================================

resource "time_sleep" "iam_role_propagation" {
  depends_on      = [module.iam_assumable_role_databricks]
  create_duration = "20s"
}

module "mws_credentials" {
  source = "../mws-credentials"
  providers = {
    databricks = databricks.account
  }

  account_id       = var.databricks_account_id
  credentials_name = "${local.prefix}-credentials-${local.suffix}"
  role_arn         = module.iam_assumable_role_databricks.iam_role_arn

  depends_on = [time_sleep.iam_role_propagation]
}

module "mws_storage" {
  source = "../mws-storage-configuration"
  providers = {
    databricks = databricks.account
  }

  account_id                 = var.databricks_account_id
  storage_configuration_name = "${local.prefix}-storage-${local.suffix}"
  bucket_name                = module.s3_bucket.s3_bucket_id
}

module "mws_networks" {
  source = "../mws-networks"
  providers = {
    databricks = databricks.account
  }

  account_id         = var.databricks_account_id
  network_name       = "${local.prefix}-network-${local.suffix}"
  vpc_id             = var.vpc_id
  subnet_ids         = var.private_subnet_ids
  security_group_ids = var.workspace_security_group_ids

  vpc_endpoints = {
    dataplane_relay = var.enable_private_link ? [databricks_mws_vpc_endpoint.backend_relay[0].vpc_endpoint_id] : []
    rest_api        = var.enable_private_link ? [databricks_mws_vpc_endpoint.backend_rest[0].vpc_endpoint_id] : []
  }
}

# Register CMK with Databricks (KMS keys must exist in AWS and allow Databricks principals)
resource "databricks_mws_customer_managed_keys" "managed_services" {
  provider = databricks.account
  count    = var.enable_cmk ? 1 : 0

  account_id = var.databricks_account_id

  aws_key_info {
    key_arn   = var.managed_services_kms_key_arn
    key_alias = var.managed_services_kms_key_alias
  }

  use_cases = ["MANAGED_SERVICES"]

  lifecycle {
    precondition {
      condition     = !var.enable_cmk || (var.managed_services_kms_key_arn != null && var.managed_services_kms_key_alias != null)
      error_message = "When enable_cmk is true, managed_services_kms_key_arn and managed_services_kms_key_alias must be set."
    }
  }
}

resource "databricks_mws_customer_managed_keys" "workspace_storage" {
  provider = databricks.account
  count    = var.enable_cmk ? 1 : 0

  account_id = var.databricks_account_id

  aws_key_info {
    key_arn   = var.workspace_storage_kms_key_arn
    key_alias = var.workspace_storage_kms_key_alias
  }

  use_cases = ["STORAGE"]

  lifecycle {
    precondition {
      condition     = !var.enable_cmk || (var.workspace_storage_kms_key_arn != null && var.workspace_storage_kms_key_alias != null)
      error_message = "When enable_cmk is true, workspace_storage_kms_key_arn and workspace_storage_kms_key_alias must be set."
    }
  }
}

# =============================================================================
# DATABRICKS WORKSPACE (MWS)
# =============================================================================

resource "databricks_mws_workspaces" "this" {
  provider = databricks.account

  account_id               = var.databricks_account_id
  workspace_name           = "${local.prefix}-${local.suffix}"
  aws_region               = var.aws_region
  deployment_name          = var.deployment_name
  credentials_id           = module.mws_credentials.credentials_id
  storage_configuration_id = module.mws_storage.storage_configuration_id
  network_id               = module.mws_networks.network_id

  managed_services_customer_managed_key_id = var.enable_cmk ? databricks_mws_customer_managed_keys.managed_services[0].customer_managed_key_id : null
  storage_customer_managed_key_id          = var.enable_cmk ? databricks_mws_customer_managed_keys.workspace_storage[0].customer_managed_key_id : null

  private_access_settings_id = var.private_access_settings_id

  pricing_tier = var.pricing_tier
  custom_tags  = var.tags

  # NCC: workspace depends on the NCC module so destroy removes the workspace before NCC resources.
  # When count = 0 the module dependency is a no-op.
  depends_on = [
    module.s3_bucket,
    module.network_connectivity_config,
  ]

  lifecycle {
    precondition {
      condition     = !var.enable_cmk || (var.managed_services_kms_key_arn != null && var.workspace_storage_kms_key_arn != null && var.managed_services_kms_key_alias != null && var.workspace_storage_kms_key_alias != null)
      error_message = "When enable_cmk is true, set managed_services_kms_key_arn, workspace_storage_kms_key_arn, managed_services_kms_key_alias, and workspace_storage_kms_key_alias."
    }
  }
}

# =============================================================================
# NCC binding (same pattern as complete-workspace-serverless)
# =============================================================================

module "network_connectivity_config" {
  count = var.enable_network_connectivity_config ? 1 : 0

  source = "../mws-network-connectivity-config"

  providers = {
    databricks = databricks.account
  }

  name   = "${local.prefix}-ncc-${local.suffix}"
  region = var.aws_region

  nlb_vpc_endpoint_service_name = var.ncc_nlb_vpc_endpoint_service_name
  nlb_domain_names              = var.ncc_nlb_domain_names
}

resource "databricks_mws_ncc_binding" "this" {
  provider = databricks.account
  count    = var.enable_network_connectivity_config ? 1 : 0

  network_connectivity_config_id = module.network_connectivity_config[0].network_connectivity_config_id
  workspace_id                   = databricks_mws_workspaces.this.workspace_id

  depends_on = [
    databricks_mws_workspaces.this,
    module.network_connectivity_config,
  ]
}

# =============================================================================
# Unity Catalog: assign workspace to an existing metastore (by name)
# =============================================================================

data "databricks_metastore" "existing" {
  provider = databricks.account

  name = var.existing_metastore_name

  depends_on = [databricks_mws_workspaces.this]
}

resource "databricks_metastore_assignment" "this" {
  provider = databricks.account

  workspace_id = databricks_mws_workspaces.this.workspace_id
  metastore_id = data.databricks_metastore.existing.metastore_id
}

check "default_catalog_storage_kms_inputs" {
  assert {
    condition = !var.create_default_catalog || (
      var.default_catalog_storage_kms_key_arn != null &&
      var.default_catalog_storage_kms_key_alias != null &&
      trimspace(var.default_catalog_storage_kms_key_arn) != "" &&
      trimspace(var.default_catalog_storage_kms_key_alias) != ""
    )
    error_message = "When create_default_catalog is true, set default_catalog_storage_kms_key_arn and default_catalog_storage_kms_key_alias (caller-managed CMK for catalog root storage)."
  }
}

check "default_catalog_file_events_iam" {
  assert {
    condition     = !var.create_default_catalog || var.default_catalog_enable_file_events
    error_message = "When create_default_catalog is true, set default_catalog_enable_file_events = true. With file events disabled, catalog-creation uses an empty inline IAM policy on the UC storage role, which AWS rejects."
  }
}

# =============================================================================
# Optional Unity Catalog managed catalog (S3 + credential + external location + catalog)
# =============================================================================
# NOTE: This legacy SE composition predates the current permission framework and
# no longer provisions schemas through catalog-creation. Schemas and schema-scoped
# privileges must be provisioned separately through modules/schema; catalog-level
# USE_CATALOG access is managed through catalog-creation.permissions.
# =============================================================================

module "default_catalog" {
  count  = var.create_default_catalog ? 1 : 0
  source = "../catalog-creation"

  providers = {
    databricks = databricks.workspace
  }

  workspace_id = databricks_mws_workspaces.this.workspace_id
  name_prefix  = local.prefix

  aws_partition = local.computed_aws_partition

  catalog_storage_kms_key_arn   = var.default_catalog_storage_kms_key_arn
  catalog_storage_kms_key_alias = var.default_catalog_storage_kms_key_alias

  unity_catalog_iam_arn = coalesce(
    var.default_catalog_unity_catalog_iam_arn,
    "arn:aws:iam::414351767826:role/unity-catalog-prod-UCMasterRole-14S5ZJVKOTYTL"
  )

  catalog_owner          = var.default_catalog_owner
  catalog_properties     = var.default_catalog_properties
  catalog_isolation_mode = var.default_catalog_isolation_mode

  permissions                          = var.default_catalog_permissions
  databricks_service_principal_app_ids = var.default_catalog_service_principal_app_ids

  force_destroy = var.force_destroy
  tags          = var.tags

  enable_catalog_file_events                        = var.default_catalog_enable_file_events
  catalog_file_events_sqs_message_retention_seconds = var.default_catalog_file_events_sqs_message_retention_seconds
  catalog_file_events_sqs_kms_key_id                = var.default_catalog_file_events_sqs_kms_key_id
  catalog_file_events_s3_events                     = var.default_catalog_file_events_s3_events
  catalog_file_events_s3_filter_prefix              = var.default_catalog_file_events_s3_filter_prefix
  catalog_file_events_s3_filter_suffix              = var.default_catalog_file_events_s3_filter_suffix

  depends_on = [databricks_metastore_assignment.this]
}

# =============================================================================
# WORKSPACE SECURITY MODULES
# =============================================================================

module "workspace_security" {
  source = "../workspace-conf"
  providers = {
    databricks = databricks.workspace
  }
  count = var.configure_workspace_security ? 1 : 0

  disable_legacy_access                              = true
  disable_legacy_dbfs                                = true
  enable_results_downloading                         = false
  enable_notebook_table_clipboard                    = false
  enable_export_notebook                             = false
  aibi_dashboard_embedding_approved_domains          = []
  aibi_dashboard_embedding_access_policy             = "DENY_ALL_DOMAINS"
  restrict_workspace_admins_status                   = "RESTRICT_TOKENS_AND_JOB_RUN_AS"
  restrict_workspace_admins_disable_gov_tag_creation = true
  enable_verbose_audit_logs                          = true
  enable_dbfs_file_browser                           = false
  enforce_user_isolation                             = true
  store_results_in_customer_account                  = true
  enable_upload_data_uis                             = false
  enable_ip_access_lists                             = true
  enable_web_terminal                                = false
  max_token_lifetime_days                            = 90
  enable_notebook_results_downloading                = false
  enable_tokens_config                               = false
  enable_projects_allow_list                         = false
  projects_allow_list_permissions                    = null
  projects_allow_list                                = null
  enable_project_type_in_workspace                   = false
  customer_approved_ws_login_expiration_time         = "1998-01-01T00:00:00.000Z"
  uc_volumes_download_ui                             = false
  additional_workspace_config                        = {}
}

# =============================================================================
# COMPLIANCE SECURITY PROFILE (CSP) - SRA Gap #5
# =============================================================================

resource "databricks_compliance_security_profile_workspace_setting" "this" {
  provider = databricks.workspace
  count    = var.enable_csp ? 1 : 0

  compliance_security_profile_workspace {
    is_enabled           = true
    compliance_standards = length(coalesce(var.compliance_standards, [])) > 0 ? coalesce(var.compliance_standards, []) : ["HIPAA"]
  }
}

# =============================================================================
# Account Network Policy
# =============================================================================
module "account_network_policy" {
  source = "../account-network-policy"
  count  = var.enable_account_network_policy ? 1 : 0

  providers = {
    databricks = databricks.account
  }

  network_policy_id          = "${substr(local.prefix, 0, 22)}-np-${local.suffix}"
  workspace_id               = databricks_mws_workspaces.this.workspace_id
  existing_network_policy_id = var.existing_network_policy_id

  egress = {
    network_access = {
      restriction_mode              = "RESTRICTED_ACCESS"
      allowed_internet_destinations = var.network_policy_allowed_internet_destinations
      allowed_storage_destinations  = var.network_policy_allowed_storage_destinations
      policy_enforcement = {
        enforcement_mode = "ENFORCED"
      }
    }
  }

  ingress_public_access          = var.network_policy_public_access
  ingress_private_access         = var.network_policy_private_access
  ingress_cross_workspace_access = var.network_policy_cross_workspace_access

  depends_on = [databricks_mws_workspaces.this]
}
