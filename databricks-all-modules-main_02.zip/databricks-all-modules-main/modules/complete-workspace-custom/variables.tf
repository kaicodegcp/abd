# =============================================================================
# Required Variables
# =============================================================================

variable "databricks_account_id" {
  description = "Databricks account ID"
  type        = string
}

variable "workspace_name" {
  description = "Name prefix for the workspace and all resources"
  type        = string
}

variable "existing_metastore_name" {
  description = "Existing Unity Catalog metastore name to assign to the workspace (must already exist in the account)."
  type        = string
}

variable "aws_region" {
  description = "AWS region for deployment"
  type        = string
  default     = "us-west-2"
}

# =============================================================================
# Network Configuration (custom VPC - no VPC or PrivateLink creation by this module)
# =============================================================================

variable "vpc_id" {
  description = "Existing VPC ID where the workspace will be deployed"
  type        = string

  validation {
    condition     = can(regex("^vpc-[a-f0-9]{8,}$", var.vpc_id))
    error_message = "VPC ID must be in format: vpc-xxxxxxxx"
  }
}

variable "private_subnet_ids" {
  description = "List of private subnet IDs for the Databricks workspace (at least 2 in different AZs)"
  type        = list(string)
}

variable "vpc_cidr" {
  description = "CIDR block of the VPC (used for IAM conditions scoping EC2 to this VPC)"
  type        = string
}

variable "workspace_security_group_ids" {
  description = "Security group IDs for Databricks data plane ENIs in the workspace subnets (passed to MWS networks and cross-account IAM)"
  type        = list(string)

  validation {
    condition     = length(var.workspace_security_group_ids) > 0
    error_message = "Provide at least one workspace security group ID."
  }
}

variable "public_subnet_ids" {
  description = "Optional list of public subnet IDs (for output passthrough only)"
  type        = list(string)
  default     = []
}

variable "nat_gateway_ids" {
  description = "Optional list of NAT gateway IDs (for output passthrough only)"
  type        = list(string)
  default     = []
}

# =============================================================================
# PrivateLink Configuration (pass AWS VPC endpoint IDs; module registers them with Databricks)
# =============================================================================

variable "enable_private_link" {
  description = "Use PrivateLink for workspace connectivity; provide AWS VPC endpoint IDs via rest_api_aws_vpc_endpoint_id and dataplane_relay_aws_vpc_endpoint_id"
  type        = bool
  default     = false
}

variable "rest_api_aws_vpc_endpoint_id" {
  description = "AWS VPC endpoint ID for Databricks REST API. Required when enable_private_link = true. Module registers it with Databricks via databricks_mws_vpc_endpoint."
  type        = string
  default     = null
}

variable "dataplane_relay_aws_vpc_endpoint_id" {
  description = "AWS VPC endpoint ID for Databricks SCC dataplane relay. Required when enable_private_link = true. Module registers it with Databricks via databricks_mws_vpc_endpoint."
  type        = string
  default     = null
}

variable "privatelink_security_group_id" {
  description = "Optional PrivateLink security group ID (for output passthrough when using custom PrivateLink)"
  type        = string
  default     = null
}

variable "private_access_settings_id" {
  description = "Optional MWS private access settings ID (from databricks_mws_private_access_settings or the account console). When set, attaches PrivateLink / private connectivity policy to the new workspace."
  type        = string
  default     = null
}

# =============================================================================
# Security Configuration
# =============================================================================

variable "enable_cmk" {
  description = "Register existing KMS keys with Databricks for managed services and workspace storage. When true, set managed_services_kms_key_arn, workspace_storage_kms_key_arn, managed_services_kms_key_alias, and workspace_storage_kms_key_alias."
  type        = bool
  default     = true
}

variable "pricing_tier" {
  description = "Workspace pricing tier (ENTERPRISE required for Unity Catalog)"
  type        = string
  default     = "ENTERPRISE"

  validation {
    condition     = contains(["STANDARD", "PREMIUM", "ENTERPRISE"], var.pricing_tier)
    error_message = "Pricing tier must be STANDARD, PREMIUM, or ENTERPRISE."
  }
}

# =============================================================================
# Workspace Security Configuration
# =============================================================================

variable "configure_workspace_security" {
  description = "Apply workspace security settings (data exfiltration prevention) via workspace-conf"
  type        = bool
  default     = true
}

# =============================================================================
# Additional Configuration
# =============================================================================

variable "tags" {
  description = "Tags to apply to all resources"
  type        = map(string)
  default     = {}
}

variable "force_destroy" {
  description = "Allow force destroy of resources (set to true for testing)"
  type        = bool
  default     = false
}

# =============================================================================
# Deployment Configuration
# =============================================================================

variable "deployment_name" {
  description = "Deployment name for the workspace URL prefix. Must be enabled by a Databricks representative."
  type        = string
  default     = null
  nullable    = true
}

# =============================================================================
# GovCloud Configuration
# =============================================================================

variable "databricks_gov_shard" {
  description = "Databricks GovCloud shard type. Only applicable for us-gov-west-1 region."
  type        = string
  default     = null

  validation {
    condition     = var.databricks_gov_shard == null || can(contains(["civilian", "dod"], var.databricks_gov_shard))
    error_message = "Allowed values: null, civilian, dod."
  }
}

# =============================================================================
# KMS Configuration (keys are created outside this module)
# =============================================================================

variable "managed_services_kms_key_arn" {
  description = "ARN of an existing KMS key for Databricks managed services CMK registration. Required when enable_cmk is true."
  type        = string
  default     = null
}

variable "workspace_storage_kms_key_arn" {
  description = "ARN of an existing KMS key for S3 root-bucket SSE and Databricks STORAGE CMK registration. Required when enable_cmk is true; key policy must allow Databricks control plane and typically the workspace cross-account role for EBS (attach after first apply using cross_account_role_arn output if needed)."
  type        = string
  default     = null
}

variable "managed_services_kms_key_alias" {
  description = "Databricks CMK alias for managed services (aws_key_info.key_alias), e.g. alias/my-managed-services-key. Required when enable_cmk is true."
  type        = string
  default     = null
}

variable "workspace_storage_kms_key_alias" {
  description = "Databricks CMK alias for workspace storage (aws_key_info.key_alias), e.g. alias/my-workspace-storage-key. Required when enable_cmk is true."
  type        = string
  default     = null
}

variable "root_bucket_versioning" {
  description = "Enable versioning on the root storage bucket. SRA recommends disabled."
  type        = bool
  default     = false
}

# =============================================================================
# Network Connectivity Configuration (NCC) — same pattern as complete-workspace-serverless
# =============================================================================

variable "enable_network_connectivity_config" {
  description = "Create an MWS Network Connectivity Config (via mws-network-connectivity-config) and bind it to the workspace for egress / private endpoint rules."
  type        = bool
  default     = false
}

variable "ncc_nlb_vpc_endpoint_service_name" {
  description = "AWS VPC endpoint service name for the NLB private endpoint rule when ncc_nlb_domain_names is non-empty. May be (known after apply). See mws-network-connectivity-config module."
  type        = string
  default     = null
}

variable "ncc_nlb_domain_names" {
  description = "FQDNs for the NCC private endpoint rule; non-empty list creates the rule (service name can resolve at apply time)."
  type        = list(string)
  default     = []
}

# =============================================================================
# Compliance Security Profile
# =============================================================================

variable "enable_csp" {
  description = "Enable Compliance Security Profile on the workspace (SRA recommended for regulated workloads)"
  type        = bool
  default     = false
}

variable "compliance_standards" {
  description = "List of compliance standards for CSP (e.g., HIPAA, PCI_DSS, FEDRAMP_MODERATE)"
  type        = list(string)
  default     = null
  nullable    = true
}

# =============================================================================
# Optional default Unity Catalog (catalog-creation module)
# =============================================================================

variable "create_default_catalog" {
  description = "When true, creates a managed catalog (S3, storage credential, external location, catalog) via catalog-creation after metastore assignment. Requires ENTERPRISE tier, existing metastore, and caller-supplied default_catalog_storage_kms_key_arn / default_catalog_storage_kms_key_alias."
  type        = bool
  default     = false
}

variable "default_catalog_owner" {
  description = "Owner for the default catalog (passed to catalog-creation)."
  type        = string
  default     = "account users"
}

variable "default_catalog_properties" {
  description = "Extra properties for the default catalog."
  type        = map(string)
  default     = {}
}

variable "default_catalog_isolation_mode" {
  description = "Catalog isolation mode: ISOLATED or OPEN."
  type        = string
  default     = "ISOLATED"

  validation {
    condition     = contains(["ISOLATED", "OPEN"], var.default_catalog_isolation_mode)
    error_message = "default_catalog_isolation_mode must be ISOLATED or OPEN."
  }
}

variable "default_catalog_permissions" {
  description = "Catalog-level grants (groups and service principals). Service principal keys must exist in default_catalog_service_principal_app_ids."
  type = object({
    groups             = map(list(string))
    service_principals = map(list(string))
  })
  default = {
    groups             = {}
    service_principals = {}
  }
}

variable "default_catalog_service_principal_app_ids" {
  description = "Map of service principal display name to application ID for catalog/schema grants."
  type        = map(string)
  default     = {}
}

variable "default_catalog_storage_kms_key_arn" {
  description = "When create_default_catalog is true, ARN of the customer-managed KMS key for Unity Catalog catalog root storage. Ignored when create_default_catalog is false."
  type        = string
  default     = null
  nullable    = true
}

variable "default_catalog_storage_kms_key_alias" {
  description = "When create_default_catalog is true, KMS alias in alias/name form (e.g. alias/my-key). Ignored when create_default_catalog is false."
  type        = string
  default     = null
  nullable    = true
}

variable "default_catalog_unity_catalog_iam_arn" {
  description = "Databricks Unity Catalog master IAM role ARN for storage credential trust. Defaults to the commercial UC master role; set for GovCloud or custom deployments."
  type        = string
  default     = null
}

variable "default_catalog_enable_file_events" {
  description = "When true, enables catalog file events (SQS + S3 notifications) per catalog-creation."
  type        = bool
  default     = false
}

variable "default_catalog_file_events_sqs_message_retention_seconds" {
  description = "SQS retention when default_catalog_enable_file_events is true."
  type        = number
  default     = 345600
}

variable "default_catalog_file_events_sqs_kms_key_id" {
  description = "Optional KMS key for SQS when file events are enabled."
  type        = string
  default     = null
}

variable "default_catalog_file_events_s3_events" {
  description = "S3 event types for file-events notifications when default_catalog_enable_file_events is true."
  type        = list(string)
  default     = ["s3:ObjectCreated:*", "s3:ObjectRemoved:*", "s3:LifecycleExpiration:*"]
}

variable "default_catalog_file_events_s3_filter_prefix" {
  type    = string
  default = ""
}

variable "default_catalog_file_events_s3_filter_suffix" {
  type    = string
  default = ""
}

# =============================================================================
# Account Network Policy
# =============================================================================

variable "enable_account_network_policy" {
  description = "Create an account-level network policy (RESTRICTED_ACCESS / ENFORCED) and bind it to the workspace, enforcing default all-deny egress."
  type        = bool
  default     = true
}

variable "existing_network_policy_id" {
  description = "ID of an existing account network policy to reuse. When set, no new policy is created — the existing policy is bound to the workspace directly."
  type        = string
  default     = null
}

variable "network_policy_allowed_internet_destinations" {
  description = "Internet destinations allowed in RESTRICTED_ACCESS mode."
  type = list(object({
    destination               = string
    internet_destination_type = string
  }))
  default = []
}

variable "network_policy_allowed_storage_destinations" {
  description = "Storage destinations allowed in RESTRICTED_ACCESS mode."
  type = list(object({
    bucket_name              = string
    region                   = string
    storage_destination_type = string
  }))
  default = []
}

variable "network_policy_public_access" {
  description = "Context-based ingress policy for public internet traffic. restriction_mode: FULL_ACCESS or RESTRICTED_ACCESS."
  type = object({
    restriction_mode = string
    allow_rules = optional(list(object({
      label = optional(string)
      authentication = optional(object({
        identity_type = optional(string)
        identities = optional(list(object({
          principal_id   = optional(number)
          principal_type = optional(string)
        })), [])
      }))
      destination = optional(object({
        all_destinations = optional(bool)
        workspace_ui     = optional(object({ all_destinations = optional(bool) }))
        workspace_api    = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        apps_runtime     = optional(object({ all_destinations = optional(bool) }))
        lakebase_runtime = optional(object({ all_destinations = optional(bool) }))
        account_api      = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        account_ui       = optional(object({ all_destinations = optional(bool) }))
      }))
      origin = optional(object({
        all_ip_ranges      = optional(bool)
        included_ip_ranges = optional(object({ ip_ranges = optional(list(string), []) }))
        excluded_ip_ranges = optional(object({ ip_ranges = optional(list(string), []) }))
      }))
    })), [])
    deny_rules = optional(list(object({
      label = optional(string)
      authentication = optional(object({
        identity_type = optional(string)
        identities = optional(list(object({
          principal_id   = optional(number)
          principal_type = optional(string)
        })), [])
      }))
      destination = optional(object({
        all_destinations = optional(bool)
        workspace_ui     = optional(object({ all_destinations = optional(bool) }))
        workspace_api    = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        apps_runtime     = optional(object({ all_destinations = optional(bool) }))
        lakebase_runtime = optional(object({ all_destinations = optional(bool) }))
        account_api      = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        account_ui       = optional(object({ all_destinations = optional(bool) }))
      }))
      origin = optional(object({
        all_ip_ranges      = optional(bool)
        included_ip_ranges = optional(object({ ip_ranges = optional(list(string), []) }))
        excluded_ip_ranges = optional(object({ ip_ranges = optional(list(string), []) }))
      }))
    })), [])
  })
  default = {
    restriction_mode = "RESTRICTED_ACCESS"
    allow_rules      = []
    deny_rules       = []
  }
}

variable "network_policy_private_access" {
  description = "Context-based ingress policy for private connectivity (PrivateLink/registered endpoints). restriction_mode: ALLOW_ALL_REGISTERED_ENDPOINTS or RESTRICTED_ACCESS."
  type = object({
    restriction_mode = string
    allow_rules = optional(list(object({
      label = optional(string)
      authentication = optional(object({
        identity_type = optional(string)
        identities = optional(list(object({
          principal_id   = optional(number)
          principal_type = optional(string)
        })), [])
      }))
      destination = optional(object({
        all_destinations = optional(bool)
        workspace_ui     = optional(object({ all_destinations = optional(bool) }))
        workspace_api    = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        apps_runtime     = optional(object({ all_destinations = optional(bool) }))
        lakebase_runtime = optional(object({ all_destinations = optional(bool) }))
        account_api      = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        account_ui       = optional(object({ all_destinations = optional(bool) }))
      }))
      origin = optional(object({
        all_registered_endpoints     = optional(bool)
        all_private_access           = optional(bool)
        azure_workspace_private_link = optional(bool)
        endpoints                    = optional(object({ endpoint_ids = optional(list(string), []) }))
      }))
    })), [])
    deny_rules = optional(list(object({
      label = optional(string)
      authentication = optional(object({
        identity_type = optional(string)
        identities = optional(list(object({
          principal_id   = optional(number)
          principal_type = optional(string)
        })), [])
      }))
      destination = optional(object({
        all_destinations = optional(bool)
        workspace_ui     = optional(object({ all_destinations = optional(bool) }))
        workspace_api    = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        apps_runtime     = optional(object({ all_destinations = optional(bool) }))
        lakebase_runtime = optional(object({ all_destinations = optional(bool) }))
        account_api      = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        account_ui       = optional(object({ all_destinations = optional(bool) }))
      }))
      origin = optional(object({
        all_registered_endpoints     = optional(bool)
        all_private_access           = optional(bool)
        azure_workspace_private_link = optional(bool)
        endpoints                    = optional(object({ endpoint_ids = optional(list(string), []) }))
      }))
    })), [])
  })
  default = {
    restriction_mode = "ALLOW_ALL_REGISTERED_ENDPOINTS"
    allow_rules      = []
    deny_rules       = []
  }
}

variable "network_policy_cross_workspace_access" {
  description = "Context-based ingress policy for cross-workspace traffic within the same account. restriction_mode: FULL_ACCESS or RESTRICTED_ACCESS."
  type = object({
    restriction_mode = string
    allow_rules = optional(list(object({
      label = optional(string)
      authentication = optional(object({
        identity_type = optional(string)
        identities = optional(list(object({
          principal_id   = optional(number)
          principal_type = optional(string)
        })), [])
      }))
      destination = optional(object({
        all_destinations = optional(bool)
        workspace_ui     = optional(object({ all_destinations = optional(bool) }))
        workspace_api    = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        apps_runtime     = optional(object({ all_destinations = optional(bool) }))
        lakebase_runtime = optional(object({ all_destinations = optional(bool) }))
        account_api      = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        account_ui       = optional(object({ all_destinations = optional(bool) }))
      }))
      origin = optional(object({
        all_source_workspaces = optional(bool)
        selected_workspaces   = optional(object({ workspace_ids = optional(list(number), []) }))
      }))
    })), [])
    deny_rules = optional(list(object({
      label = optional(string)
      authentication = optional(object({
        identity_type = optional(string)
        identities = optional(list(object({
          principal_id   = optional(number)
          principal_type = optional(string)
        })), [])
      }))
      destination = optional(object({
        all_destinations = optional(bool)
        workspace_ui     = optional(object({ all_destinations = optional(bool) }))
        workspace_api    = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        apps_runtime     = optional(object({ all_destinations = optional(bool) }))
        lakebase_runtime = optional(object({ all_destinations = optional(bool) }))
        account_api      = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        account_ui       = optional(object({ all_destinations = optional(bool) }))
      }))
      origin = optional(object({
        all_source_workspaces = optional(bool)
        selected_workspaces   = optional(object({ workspace_ids = optional(list(number), []) }))
      }))
    })), [])
  })
  default = null
}


