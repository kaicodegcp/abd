# =============================================================================
# Workspace Outputs
# =============================================================================

output "workspace_id" {
  description = "Databricks workspace ID"
  value       = databricks_mws_workspaces.this.workspace_id
}

output "workspace_url" {
  description = "Databricks workspace URL"
  value       = databricks_mws_workspaces.this.workspace_url
}

output "deployment_name" {
  description = "Workspace deployment name"
  value       = databricks_mws_workspaces.this.deployment_name
}

# =============================================================================
# AWS Infrastructure Outputs (from variables - custom VPC)
# =============================================================================

output "vpc_id" {
  description = "VPC ID"
  value       = var.vpc_id
}

output "private_subnet_ids" {
  description = "Private subnet IDs"
  value       = var.private_subnet_ids
}

output "public_subnet_ids" {
  description = "Public subnet IDs"
  value       = var.public_subnet_ids
}

output "nat_gateway_ids" {
  description = "NAT Gateway IDs"
  value       = var.nat_gateway_ids
}

output "security_group_id" {
  description = "First workspace security group ID (same order as workspace_security_group_ids)"
  value       = var.workspace_security_group_ids[0]
}

output "workspace_security_group_ids" {
  description = "Security group IDs passed in for the workspace data plane"
  value       = var.workspace_security_group_ids
}

output "s3_bucket_name" {
  description = "Workspace storage S3 bucket name"
  value       = module.s3_bucket.s3_bucket_id
}

output "s3_bucket_arn" {
  description = "Workspace storage S3 bucket ARN"
  value       = module.s3_bucket.s3_bucket_arn
}

output "cross_account_role_arn" {
  description = "Cross-account IAM role ARN"
  value       = module.iam_assumable_role_databricks.iam_role_arn
}

# =============================================================================
# Security Outputs
# =============================================================================

output "managed_services_cmk_id" {
  description = "Managed services customer-managed key ID"
  value       = var.enable_cmk ? databricks_mws_customer_managed_keys.managed_services[0].customer_managed_key_id : null
}

output "storage_cmk_id" {
  description = "Storage customer-managed key ID"
  value       = var.enable_cmk ? databricks_mws_customer_managed_keys.workspace_storage[0].customer_managed_key_id : null
}

output "managed_services_kms_key_arn" {
  description = "Managed services KMS key ARN (same as var.managed_services_kms_key_arn when enable_cmk)"
  value       = var.enable_cmk ? var.managed_services_kms_key_arn : null
}

output "storage_kms_key_arn" {
  description = "Workspace storage KMS key ARN (same as var.workspace_storage_kms_key_arn when enable_cmk)"
  value       = var.enable_cmk ? var.workspace_storage_kms_key_arn : null
}

output "managed_services_kms_key_alias" {
  description = "Databricks CMK alias for managed services (var.managed_services_kms_key_alias when enable_cmk)"
  value       = var.enable_cmk ? var.managed_services_kms_key_alias : null
}

output "workspace_storage_kms_key_alias" {
  description = "Databricks CMK alias for workspace storage (var.workspace_storage_kms_key_alias when enable_cmk)"
  value       = var.enable_cmk ? var.workspace_storage_kms_key_alias : null
}

# =============================================================================
# Unity Catalog Outputs
# =============================================================================

output "metastore_id" {
  description = "Unity Catalog metastore ID assigned to the workspace"
  value       = data.databricks_metastore.existing.metastore_id
}

output "default_catalog_id" {
  description = "Unity Catalog catalog ID when create_default_catalog is true"
  value       = var.create_default_catalog ? module.default_catalog[0].catalog_id : null
}

output "default_catalog_name" {
  description = "Unity Catalog catalog name when create_default_catalog is true"
  value       = var.create_default_catalog ? module.default_catalog[0].catalog_name : null
}

output "default_catalog_storage_credential_id" {
  description = "Storage credential ID for the default catalog when create_default_catalog is true"
  value       = var.create_default_catalog ? module.default_catalog[0].storage_credential_id : null
}

output "default_catalog_external_location_name" {
  description = "External location name for the default catalog when create_default_catalog is true"
  value       = var.create_default_catalog ? module.default_catalog[0].external_location_name : null
}

output "default_catalog_s3_bucket_name" {
  description = "S3 bucket for default catalog root storage when create_default_catalog is true"
  value       = var.create_default_catalog ? module.default_catalog[0].s3_bucket_name : null
}

# =============================================================================
# PrivateLink Outputs (passthrough from variables when using custom PrivateLink)
# =============================================================================

output "private_access_settings_id" {
  description = "MWS private access settings ID on the workspace (same as var.private_access_settings_id when set)."
  value       = databricks_mws_workspaces.this.private_access_settings_id
}

output "rest_vpc_endpoint_id" {
  description = "AWS VPC endpoint ID for Databricks REST API"
  value       = var.enable_private_link ? var.rest_api_aws_vpc_endpoint_id : null
}

output "relay_vpc_endpoint_id" {
  description = "AWS VPC endpoint ID for Databricks SCC relay"
  value       = var.enable_private_link ? var.dataplane_relay_aws_vpc_endpoint_id : null
}

output "privatelink_security_group_id" {
  description = "PrivateLink security group ID"
  value       = var.enable_private_link ? var.privatelink_security_group_id : null
}

# =============================================================================
# Network Connectivity Configuration Outputs
# =============================================================================

output "ncc_id" {
  description = "Network Connectivity Configuration ID"
  value       = var.enable_network_connectivity_config ? module.network_connectivity_config[0].network_connectivity_config_id : null
}

output "nlb_private_endpoint_rule_id" {
  description = "ID of the NCC private endpoint rule for the NLB, when ncc_nlb_domain_names is non-empty"
  value       = var.enable_network_connectivity_config ? module.network_connectivity_config[0].nlb_private_endpoint_rule_id : null
}

output "nlb_private_endpoint_connection_state" {
  description = "Connection state of the NLB private endpoint rule (e.g. ESTABLISHED, PENDING)"
  value       = var.enable_network_connectivity_config ? module.network_connectivity_config[0].nlb_private_endpoint_connection_state : null
}

# =============================================================================
# Compliance Security Profile Output
# =============================================================================

output "csp_enabled" {
  description = "Whether Compliance Security Profile is enabled"
  value       = var.enable_csp
}

# =============================================================================
# Summary Output
# =============================================================================

output "workspace_info" {
  description = "Complete workspace information"
  value = {
    workspace_id            = databricks_mws_workspaces.this.workspace_id
    workspace_url           = databricks_mws_workspaces.this.workspace_url
    aws_region              = var.aws_region
    vpc_id                  = var.vpc_id
    s3_bucket               = module.s3_bucket.s3_bucket_id
    cmk_enabled             = var.enable_cmk
    private_link            = var.enable_private_link
    uc_enabled              = true
    ncc_enabled             = var.enable_network_connectivity_config
    csp_enabled             = var.enable_csp
    default_catalog_created = var.create_default_catalog
  }
}

output "account_network_policy_id" {
  description = "Account network policy ID when enable_account_network_policy is true."
  value       = var.enable_account_network_policy ? module.account_network_policy[0].network_policy_id : null
}
