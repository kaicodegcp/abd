package test

import (
	"fmt"
	"testing"

	common "github.com/sandbox45/databricks-all-modules/common"
	"github.com/stretchr/testify/assert"
)

func TestCompleteWorkspaceModule(t *testing.T) {
	defaults := common.GetTestDefaults()

	uniqueID := common.GenerateUniqueTestID("complete-ws")

	// complete-workspace-custom requires vpc_id, private_subnet_ids, vpc_cidr
	subnetIDs := defaults.SubnetIDs
	if subnetIDs == nil {
		subnetIDs = []string{"subnet-placeholder1", "subnet-placeholder2"}
	}
	vpcCIDR := "10.0.0.0/16"

	config := common.ModuleTestConfig{
		ModuleName:      "complete-workspace-custom",
		TestDescription: "Validates complete workspace (custom VPC) module inputs (parameter-only, requires provider aliases for apply)",
		RequiredVars: map[string]interface{}{
			"databricks_account_id":        defaults.AccountID,
			"workspace_name":               uniqueID,
			"existing_metastore_name":      common.GetEnvOrDefault("TEST_EXISTING_METASTORE_NAME", "yankaiz-us-east-1"),
			"vpc_id":                       defaults.VPCID,
			"private_subnet_ids":           subnetIDs,
			"vpc_cidr":                     vpcCIDR,
			"workspace_security_group_ids": []string{defaults.SecurityGroupID},
		},
		OptionalVars: map[string]interface{}{
			"aws_region":                      defaults.AWSRegion,
			"enable_cmk":                      true,
			"configure_workspace_security":    true,
			"force_destroy":                   true,
			"managed_services_kms_key_arn":    "arn:aws:kms:us-east-1:123456789012:key/00000000-0000-0000-0000-000000000001",
			"workspace_storage_kms_key_arn":   "arn:aws:kms:us-east-1:123456789012:key/00000000-0000-0000-0000-000000000002",
			"managed_services_kms_key_alias":  "alias/test-managed-services",
			"workspace_storage_kms_key_alias": "alias/test-workspace-storage",
		},
	}

	opts := common.GetTestTerraformOptions(t, config)

	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})

	t.Run("ValidateOptionalInputs", func(t *testing.T) {
		assert.Equal(t, defaults.AccountID, opts.Vars["databricks_account_id"])
		assert.Equal(t, defaults.AWSRegion, opts.Vars["aws_region"])
		assert.Equal(t, true, opts.Vars["enable_cmk"])
		assert.NotEmpty(t, opts.Vars["existing_metastore_name"])
		t.Log("All optional inputs validated")
	})
}

func TestCompleteWorkspaceModuleMinimal(t *testing.T) {
	defaults := common.GetTestDefaults()

	uniqueID := common.GenerateUniqueTestID("minimal-ws")

	subnetIDs := defaults.SubnetIDs
	if subnetIDs == nil {
		subnetIDs = []string{"subnet-placeholder1", "subnet-placeholder2"}
	}

	config := common.ModuleTestConfig{
		ModuleName:      "complete-workspace-custom",
		TestDescription: "Validates minimal complete workspace (custom VPC) inputs",
		RequiredVars: map[string]interface{}{
			"databricks_account_id":        defaults.AccountID,
			"workspace_name":               uniqueID,
			"existing_metastore_name":      common.GetEnvOrDefault("TEST_EXISTING_METASTORE_NAME", "yankaiz-us-east-1"),
			"vpc_id":                       defaults.VPCID,
			"private_subnet_ids":           subnetIDs,
			"vpc_cidr":                     "10.0.0.0/16",
			"workspace_security_group_ids": []string{defaults.SecurityGroupID},
		},
		OptionalVars: map[string]interface{}{
			"aws_region":    defaults.AWSRegion,
			"enable_cmk":    false,
			"force_destroy": true,
		},
	}

	opts := common.GetTestTerraformOptions(t, config)

	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})

	t.Run("ValidateMinimalConfig", func(t *testing.T) {
		assert.Equal(t, false, opts.Vars["enable_cmk"])
		assert.NotEmpty(t, opts.Vars["existing_metastore_name"])
		t.Log("Minimal configuration validated")
	})
}

func TestMWSCredentialsModule(t *testing.T) {
	defaults := common.GetTestDefaults()

	uniqueID := common.GenerateUniqueTestID("mws-creds")

	config := common.ModuleTestConfig{
		ModuleName:      "mws-credentials",
		ModulePath:      "../../mws-credentials",
		TestDescription: "Tests Databricks MWS credentials module",
		RequiredVars: map[string]interface{}{
			"account_id":       defaults.AccountID,
			"credentials_name": fmt.Sprintf("%s-credentials", uniqueID),
			"role_arn":         defaults.CrossAccountARN,
		},
		ExpectedOutputs: []string{
			"id",
			"credentials_id",
			"credentials_name",
		},
		SkipDestroy: false,
	}

	t.Logf("Testing MWS credentials module: %s", uniqueID)
	common.TestModuleWithConfig(t, config)
}

func TestMWSStorageConfigurationModule(t *testing.T) {
	defaults := common.GetTestDefaults()

	uniqueID := common.GenerateUniqueTestID("mws-storage")

	config := common.ModuleTestConfig{
		ModuleName:      "mws-storage-configuration",
		ModulePath:      "../../mws-storage-configuration",
		TestDescription: "Tests Databricks MWS storage configuration module",
		RequiredVars: map[string]interface{}{
			"account_id":                 defaults.AccountID,
			"storage_configuration_name": fmt.Sprintf("%s-storage-config", uniqueID),
			"bucket_name":                defaults.S3BucketName,
		},
		ExpectedOutputs: []string{
			"id",
			"storage_configuration_id",
			"storage_configuration_name",
		},
		SkipDestroy: false,
	}

	t.Logf("Testing MWS storage configuration module: %s", uniqueID)
	common.TestModuleWithConfig(t, config)
}

func TestMWSNetworksModule(t *testing.T) {
	defaults := common.GetTestDefaults()

	uniqueID := common.GenerateUniqueTestID("mws-network")

	subnetIDs := defaults.SubnetIDs
	if subnetIDs == nil {
		subnetIDs = []string{"subnet-placeholder1", "subnet-placeholder2"}
	}

	config := common.ModuleTestConfig{
		ModuleName:      "mws-networks",
		ModulePath:      "../../mws-networks",
		TestDescription: "Tests Databricks MWS networks module",
		RequiredVars: map[string]interface{}{
			"account_id":         defaults.AccountID,
			"network_name":       fmt.Sprintf("%s-network", uniqueID),
			"vpc_id":             defaults.VPCID,
			"subnet_ids":         subnetIDs,
			"security_group_ids": []string{defaults.SecurityGroupID},
			"vpc_endpoints": map[string]interface{}{
				"dataplane_relay": []string{},
				"rest_api":        []string{},
			},
		},
		ExpectedOutputs: []string{
			"id",
			"network_id",
			"network_name",
			"vpc_id",
		},
		SkipDestroy: false,
	}

	t.Logf("Testing MWS networks module: %s", uniqueID)
	common.TestModuleWithConfig(t, config)
}

func TestWorkspaceConfModule(t *testing.T) {
	config := common.ModuleTestConfig{
		ModuleName:      "workspace-conf",
		ModulePath:      "../../workspace-conf",
		TestDescription: "Tests Databricks workspace security configuration module",
		RequiredVars:    map[string]interface{}{},
		OptionalVars: map[string]interface{}{
			"enable_results_downloading":                         false,
			"enable_notebook_results_downloading":                false,
			"enable_notebook_table_clipboard":                    false,
			"enable_verbose_audit_logs":                          true,
			"enable_dbfs_file_browser":                           false,
			"enable_export_notebook":                             false,
			"aibi_dashboard_embedding_approved_domains":          []string{},
			"aibi_dashboard_embedding_access_policy":             "DENY_ALL_DOMAINS",
			"enforce_user_isolation":                             true,
			"store_results_in_customer_account":                  true,
			"enable_upload_data_uis":                             false,
			"disable_legacy_access":                              true,
			"disable_legacy_dbfs":                                true,
			"restrict_workspace_admins_status":                   "RESTRICT_TOKENS_AND_JOB_RUN_AS",
			"restrict_workspace_admins_disable_gov_tag_creation": true,
			"uc_volumes_download_ui":                             false,
		},
		ExpectedOutputs: []string{
			"workspace_conf_id",
			"applied_settings",
			"disable_legacy_access_effective",
			"disable_legacy_dbfs_effective",
			"enable_results_downloading_effective",
			"enable_notebook_table_clipboard_effective",
			"enable_export_notebook_effective",
			"aibi_dashboard_embedding_approved_domains_effective",
			"aibi_dashboard_embedding_access_policy_effective",
			"restrict_workspace_admins_status",
			"restrict_workspace_admins_disable_gov_tag_creation_effective",
			"uc_volumes_download_ui_effective",
		},
		SkipDestroy: false,
	}

	t.Log("Testing workspace-conf module with SRA security settings")
	common.TestModuleWithConfig(t, config)
}

func TestWorkspaceConfModuleRelaxed(t *testing.T) {
	config := common.ModuleTestConfig{
		ModuleName:      "workspace-conf",
		ModulePath:      "../../workspace-conf",
		TestDescription: "Tests workspace-conf module with relaxed settings for dev environments",
		RequiredVars:    map[string]interface{}{},
		OptionalVars: map[string]interface{}{
			"enable_results_downloading":                         true,
			"enable_notebook_results_downloading":                true,
			"enable_notebook_table_clipboard":                    true,
			"enable_verbose_audit_logs":                          true,
			"enable_dbfs_file_browser":                           true,
			"enable_export_notebook":                             true,
			"aibi_dashboard_embedding_approved_domains":          []string{"https://example.com"},
			"aibi_dashboard_embedding_access_policy":             "ALLOW_APPROVED_DOMAINS",
			"enforce_user_isolation":                             false,
			"store_results_in_customer_account":                  false,
			"enable_upload_data_uis":                             true,
			"disable_legacy_access":                              false,
			"disable_legacy_dbfs":                                false,
			"restrict_workspace_admins_status":                   "ALLOW_ALL",
			"restrict_workspace_admins_disable_gov_tag_creation": false,
			"uc_volumes_download_ui":                             true,
		},
		ExpectedOutputs: []string{
			"workspace_conf_id",
			"applied_settings",
			"disable_legacy_access_effective",
			"disable_legacy_dbfs_effective",
			"enable_results_downloading_effective",
			"enable_notebook_table_clipboard_effective",
			"enable_export_notebook_effective",
			"aibi_dashboard_embedding_approved_domains_effective",
			"aibi_dashboard_embedding_access_policy_effective",
			"restrict_workspace_admins_status",
			"restrict_workspace_admins_disable_gov_tag_creation_effective",
			"uc_volumes_download_ui_effective",
		},
		SkipDestroy: false,
	}

	t.Log("Testing workspace-conf module with relaxed dev settings")
	common.TestModuleWithConfig(t, config)
}
