variable "databricks_account_id" {
  description = "Databricks Account ID"
  type        = string
}

variable "workspace_name" {
  description = "Name for the workspace"
  type        = string
  default     = "example-workspace"
}

variable "name_prefix" {
  description = "Optional short prefix for inbound PrivateLink / dedicated NLB resource names; defaults to workspace_name when null."
  type        = string
  default     = null
}

variable "existing_metastore_name" {
  description = "Existing Unity Catalog metastore name in the account (workspace is assigned to this metastore)"
  type        = string
}

variable "aws_region" {
  description = "AWS Region"
  type        = string
  default     = "us-east-2"
}

# -----------------------------------------------------------------------------
# PrivateLink (set enable_private_link = true and provide AWS VPC endpoint IDs,
# or use the example's built-in endpoint creation when enable_private_link = true)
# -----------------------------------------------------------------------------
variable "enable_private_link" {
  description = "Enable PrivateLink; example creates VPC endpoints and passes IDs to the module when true (default true so all necessary AWS resources are created)"
  type        = bool
  default     = true
}

variable "rest_api_aws_vpc_endpoint_id" {
  description = "AWS VPC endpoint ID for Databricks REST API. Set when using your own endpoints; ignored if enable_private_link and example creates endpoints."
  type        = string
  default     = null
}

variable "dataplane_relay_aws_vpc_endpoint_id" {
  description = "AWS VPC endpoint ID for Databricks SCC dataplane relay. Set when using your own endpoints; ignored if enable_private_link and example creates endpoints."
  type        = string
  default     = null
}

variable "private_access_settings_id" {
  description = "Optional MWS private access settings ID to attach to the workspace. When null, private_access_level is ACCOUNT, enable_private_access_settings is true, and create_inbound_privatelink is false, this example creates ACCOUNT-level PAS via mws-private-access-settings."
  type        = string
  default     = null
}

variable "enable_private_access_settings" {
  description = "When true, create ACCOUNT-level private access settings (mws-private-access-settings) in this example when private_access_settings_id is null, private_access_level is ACCOUNT, and create_inbound_privatelink is false. Independent of enable_private_link. Default false; set true to opt in."
  type        = bool
  default     = false
}

variable "configure_workspace_security" {
  description = "Apply workspace-level security settings (workspace-conf module). Requires Terraform to reach the workspace URL; private/restricted workspaces often need VPN/PrivateLink from the runner—set false for applies from public internet."
  type        = bool
  default     = false
}

variable "private_access_level" {
  description = "ACCOUNT (this example can create PAS when enable_private_access_settings is true) or ENDPOINT (set private_access_settings_id or use create_inbound_privatelink). Used with PrivateLink workspace configuration."
  type        = string
  default     = "ACCOUNT"

  validation {
    condition     = contains(["ACCOUNT", "ENDPOINT"], var.private_access_level)
    error_message = "private_access_level must be ACCOUNT or ENDPOINT."
  }
}

# -----------------------------------------------------------------------------
# NCC (same flags as complete-workspace-serverless root module)
# -----------------------------------------------------------------------------
variable "enable_network_connectivity_config" {
  description = "Create an MWS Network Connectivity Config and bind it to the workspace. Implied true when enable_nlb_private_endpoint is true."
  type        = bool
  default     = true
}

# -----------------------------------------------------------------------------
# Optional: NCC private endpoint rule for AWS Network Load Balancer
# -----------------------------------------------------------------------------
variable "enable_nlb_private_endpoint" {
  description = "Create an internal NLB and VPC endpoint service in this example and pass ncc_nlb_* into the module for the NCC private endpoint rule."
  type        = bool
  default     = true
}

variable "ncc_nlb_vpc_endpoint_service_name" {
  description = "Use an existing AWS VPC endpoint service name for an NLB. Ignored when enable_nlb_private_endpoint is true (example creates the service)."
  type        = string
  default     = null
}

variable "ncc_nlb_domain_names" {
  description = "FQDNs for the NCC private endpoint rule. When enable_nlb_private_endpoint is true, defaults to [\"api.<workspace_name>.internal\"] if empty. When create_internal_nlb_vpc_endpoint is true, defaults to [\"api.<dns-safe-workspace>.internal\"] if empty."
  type        = list(string)
  default     = []
}

# -----------------------------------------------------------------------------
# Dedicated NLB VPC (same pattern as complete-workspace-serverless/examples/basic)
# -----------------------------------------------------------------------------

variable "create_internal_nlb_vpc_endpoint" {
  description = "Create a dedicated VPC, internal NLB, VPC endpoint service, and optional private Route53 zone; pass service name and FQDNs into the module for the NCC private endpoint rule. Mutually exclusive with enable_nlb_private_endpoint."
  type        = bool
  default     = false
}

variable "nlb_vpc_endpoint_service_destroy_wait_duration" {
  description = "Destroy-phase delay after the workspace module is destroyed and before deleting the NLB VPC endpoint service (Databricks releases interface endpoints asynchronously). Only when create_internal_nlb_vpc_endpoint is true."
  type        = string
  default     = "600s"
}

variable "nlb_vpc_cidr" {
  description = "IPv4 CIDR for the dedicated NLB VPC when create_internal_nlb_vpc_endpoint is true."
  type        = string
  default     = "10.48.0.0/16"
}

variable "nlb_vpc_endpoint_allowed_principal_arns" {
  description = "IAM principal ARNs allowed to create interface VPC endpoints to the NLB service. Defaults to the Databricks private connectivity role for aws_region."
  type        = list(string)
  default     = null
}

# -----------------------------------------------------------------------------
# Inbound PrivateLink (Databricks docs steps 1–3)
# https://docs.databricks.com/aws/en/security/network/front-end/front-end-private-connect
# -----------------------------------------------------------------------------

variable "create_inbound_privatelink" {
  description = "Transit VPC + Workspace (REST API) interface endpoint + MWS VPC endpoint registration + PAS (mws-private-access-settings), and pass PAS to the workspace. Leave private_access_settings_id unset. DNS (step 5) remains manual."
  type        = bool
  default     = false
}

variable "inbound_privatelink_vpc_cidr" {
  description = "IPv4 CIDR for the inbound PrivateLink transit VPC when create_inbound_privatelink is true."
  type        = string
  default     = "10.49.0.0/16"
}

variable "inbound_privatelink_workspace_service_name" {
  description = "Override for the AWS endpoint service name (Workspace including REST API). When null, uses the built-in map for aws_region."
  type        = string
  default     = null
}

variable "inbound_privatelink_https_ingress_cidr_blocks" {
  description = "CIDRs allowed to the interface endpoint on TCP 443. When null, defaults to the transit VPC CIDR only."
  type        = list(string)
  default     = null
}

variable "inbound_privatelink_private_access_settings_name" {
  description = "Name for the private access settings object (step 3). When null, defaults to \"<prefix>-<workspace>-pas\"."
  type        = string
  default     = null
}

variable "inbound_privatelink_private_access_level" {
  description = "Private access level for step 3: ENDPOINT restricts to the inbound MWS VPC endpoint registration; ACCOUNT allows any VPC endpoint registered in the Databricks account."
  type        = string
  default     = "ENDPOINT"

  validation {
    condition     = contains(["ACCOUNT", "ENDPOINT"], var.inbound_privatelink_private_access_level)
    error_message = "inbound_privatelink_private_access_level must be ACCOUNT or ENDPOINT."
  }
}

# -----------------------------------------------------------------------------
# Optional default Unity Catalog (example creates CMK in default-catalog-kms.tf)
# -----------------------------------------------------------------------------
variable "create_default_catalog" {
  description = "When true, creates an example catalog-storage CMK and enables the managed default catalog on complete-workspace-custom."
  type        = bool
  default     = false
}

variable "example_default_catalog_kms_cmk_admin_arn" {
  description = "Optional principal for kms:* on the example default-catalog CMK when create_default_catalog is true (defaults to account root)."
  type        = string
  default     = null
}

variable "default_catalog_owner" {
  type    = string
  default = "account users"
}

variable "default_catalog_properties" {
  type    = map(string)
  default = {}
}

variable "default_catalog_isolation_mode" {
  type    = string
  default = "ISOLATED"

  validation {
    condition     = contains(["ISOLATED", "OPEN"], var.default_catalog_isolation_mode)
    error_message = "default_catalog_isolation_mode must be ISOLATED or OPEN."
  }
}

variable "default_catalog_permissions" {
  type = object({
    groups             = map(list(string))
    service_principals = map(list(string))
  })
  default = {
    groups             = {}
    service_principals = {}
  }
}

variable "default_catalog_service_principal_app_ids" {
  type    = map(string)
  default = {}
}

variable "default_catalog_unity_catalog_iam_arn" {
  type    = string
  default = null
}

variable "default_catalog_enable_file_events" {
  description = "When create_default_catalog is true, must be true (module precondition). Default true for convenience."
  type        = bool
  default     = true
}

variable "default_catalog_file_events_sqs_message_retention_seconds" {
  type    = number
  default = 345600
}

variable "default_catalog_file_events_sqs_kms_key_id" {
  type    = string
  default = null
}

variable "default_catalog_file_events_s3_events" {
  type    = list(string)
  default = ["s3:ObjectCreated:*", "s3:ObjectRemoved:*", "s3:LifecycleExpiration:*"]
}

variable "default_catalog_file_events_s3_filter_prefix" {
  type    = string
  default = ""
}

variable "default_catalog_file_events_s3_filter_suffix" {
  type    = string
  default = ""
}

