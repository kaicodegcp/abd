# Example CMK for default Unity Catalog root storage when create_default_catalog is true.
# Key policy uses account-root admin so no workspace_id is required before the CMK exists.

locals {
  example_default_catalog_kms_prefix     = coalesce(var.name_prefix, var.workspace_name)
  example_default_catalog_kms_alias_name = "${local.example_default_catalog_kms_prefix}-default-catalog-${substr(md5(var.workspace_name), 0, 8)}"
}

module "example_default_catalog_storage_kms" {
  count   = var.create_default_catalog ? 1 : 0
  source  = "terraform-aws-modules/kms/aws"
  version = "~> 3.0"

  description = "Example CMK for default Unity Catalog storage (complete-workspace-custom/examples/basic)"
  key_usage   = "ENCRYPT_DECRYPT"

  computed_aliases = {
    "catalog-storage" = {
      name = local.example_default_catalog_kms_alias_name
    }
  }

  key_statements = [
    {
      sid    = "Enable IAM User Permissions"
      effect = "Allow"
      principals = [{
        type        = "AWS"
        identifiers = [coalesce(var.example_default_catalog_kms_cmk_admin_arn, "arn:${data.aws_partition.current.partition}:iam::${data.aws_caller_identity.current.account_id}:root")]
      }]
      actions   = ["kms:*"]
      resources = ["*"]
    }
  ]

  tags = {
    Name        = "${local.example_default_catalog_kms_prefix}-example-default-catalog-cmk"
    Environment = "example"
    ManagedBy   = "Terraform"
  }
}
