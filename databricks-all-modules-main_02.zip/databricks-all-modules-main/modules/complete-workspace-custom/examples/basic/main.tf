# =============================================================================
# Complete Databricks Workspace (Custom VPC) - Example
# =============================================================================
# This example:
#   1. Creates all necessary AWS resources (VPC, and when PrivateLink: SG + VPC endpoints)
#   2. Calls the complete-workspace-custom module with those resources
#
# Provide existing_metastore_name for a Unity Catalog metastore that already exists
# in your Databricks account (the module assigns the workspace to it).
#
# Set enable_private_link = true (default) so the module receives VPC endpoint
# IDs and MWS networks can be created. Set to false only if using your own
# VPC/endpoints and passing rest_api_aws_vpc_endpoint_id and
# dataplane_relay_aws_vpc_endpoint_id.
#
# Private access settings (PAS): the root module only passes optional
# private_access_settings_id (same as complete-workspace-serverless). This example
# can create ACCOUNT-level PAS via mws-private-access-settings when
# enable_private_access_settings is true, private_access_level is ACCOUNT,
# private_access_settings_id is unset, and create_inbound_privatelink is false—
# regardless of enable_private_link. For ENDPOINT, set private_access_settings_id yourself.
# When enable_private_link is true, a PAS source is required (see check.privatelink_requires_private_access_reference).
# configure_workspace_security (default false) controls workspace-level API resources; enable only if the
# runner can reach the workspace control plane.
#
# Optional default UC catalog: set create_default_catalog = true (requires default-catalog-kms.tf CMK + file events on).
# Optional stacks (same pattern as complete-workspace-serverless/examples/basic):
#   - inbound_privatelink.tf — transit VPC, Workspace (REST API) interface endpoint,
#     MWS VPC endpoint registration, PAS (steps 1–3); set create_inbound_privatelink = true
#   - nlb_vpc_endpoint.tf — dedicated VPC, internal NLB, VPC endpoint service, optional
#     private Route53 + destroy wait; set create_internal_nlb_vpc_endpoint = true
# =============================================================================

terraform {
  required_version = ">= 1.5.0"
  required_providers {
    databricks = {
      source  = "databricks/databricks"
      version = ">= 1.117.0, <= 1.128.0"
    }
    aws = {
      source  = "hashicorp/aws"
      version = ">= 5.0"
    }
    time = {
      source  = "hashicorp/time"
      version = ">= 0.9.0"
    }
  }
}

# -----------------------------------------------------------------------------
# Providers
# -----------------------------------------------------------------------------
provider "databricks" {
  alias      = "account"
  host       = "https://accounts.cloud.databricks.com"
  account_id = var.databricks_account_id
}

provider "databricks" {
  alias = "workspace"
  host  = module.complete_workspace_custom.workspace_url
}

provider "aws" {
  region = var.aws_region
}

# =============================================================================
# Part 1: AWS resources (required for the module)
# =============================================================================

# Databricks PrivateLink endpoint service names per region (for example-created endpoints)
locals {
  scc_relay_service = {
    "ap-northeast-1" = "com.amazonaws.vpce.ap-northeast-1.vpce-svc-02aa633bda3edbec0"
    "ap-northeast-2" = "com.amazonaws.vpce.ap-northeast-2.vpce-svc-0dc0e98a5800db5c4"
    "ap-south-1"     = "com.amazonaws.vpce.ap-south-1.vpce-svc-03fd4d9b61414f3de"
    "ap-southeast-1" = "com.amazonaws.vpce.ap-southeast-1.vpce-svc-0557367c6fc1a0c5c"
    "ap-southeast-2" = "com.amazonaws.vpce.ap-southeast-2.vpce-svc-0b4a72e8f825495f6"
    "eu-central-1"   = "com.amazonaws.vpce.eu-central-1.vpce-svc-08e5dfca9572c85c4"
    "eu-west-1"      = "com.amazonaws.vpce.eu-west-1.vpce-svc-09b4eb2bc775f4e8c"
    "eu-west-2"      = "com.amazonaws.vpce.eu-west-2.vpce-svc-05279412bf5353a45"
    "us-east-1"      = "com.amazonaws.vpce.us-east-1.vpce-svc-00018a8c3ff62ffdf"
    "us-east-2"      = "com.amazonaws.vpce.us-east-2.vpce-svc-090a8fab0d73e39a6"
    "us-west-1"      = "com.amazonaws.vpce.us-west-1.vpce-svc-04cb91f9372b792fe"
    "us-west-2"      = "com.amazonaws.vpce.us-west-2.vpce-svc-0158114c0c730c3bb"
  }
  workspace_api_service = {
    "ap-northeast-1" = "com.amazonaws.vpce.ap-northeast-1.vpce-svc-02691fd610d24fd64"
    "ap-northeast-2" = "com.amazonaws.vpce.ap-northeast-2.vpce-svc-0babb9bde64f34d7e"
    "ap-south-1"     = "com.amazonaws.vpce.ap-south-1.vpce-svc-0dbfe5d9ee18d6411"
    "ap-southeast-1" = "com.amazonaws.vpce.ap-southeast-1.vpce-svc-02535b257fc253ff4"
    "ap-southeast-2" = "com.amazonaws.vpce.ap-southeast-2.vpce-svc-0b87155ddd6954974"
    "eu-central-1"   = "com.amazonaws.vpce.eu-central-1.vpce-svc-081f78503812597f7"
    "eu-west-1"      = "com.amazonaws.vpce.eu-west-1.vpce-svc-0da6ebf1461278016"
    "eu-west-2"      = "com.amazonaws.vpce.eu-west-2.vpce-svc-01148c7cdc1d1326c"
    "us-east-1"      = "com.amazonaws.vpce.us-east-1.vpce-svc-09143d1e626de2f04"
    "us-east-2"      = "com.amazonaws.vpce.us-east-2.vpce-svc-041dc2b4d7796b8d3"
    "us-west-1"      = "com.amazonaws.vpce.us-west-1.vpce-svc-09bb6ca26208063f2"
    "us-west-2"      = "com.amazonaws.vpce.us-west-2.vpce-svc-0129f463fcfbc46c5"
  }

  # Ports for example-created workspace SG egress to VPC CIDR (Databricks control plane)
  workspace_sg_egress_ports = [53, 443, 2443, 3306, 5432, 6666, 8443, 8444, 8445, 8446, 8447, 8448, 8449, 8450, 8451]

  # Shared by inbound_privatelink.tf and nlb_vpc_endpoint.tf (optional name_prefix variable)
  dns_safe_workspace      = lower(replace(var.workspace_name, "_", "-"))
  example_resource_prefix = coalesce(var.name_prefix, var.workspace_name)
}

data "aws_prefix_list" "s3" {
  name = "com.amazonaws.${var.aws_region}.s3"
}

# -----------------------------------------------------------------------------
# 1a. VPC (private subnets for workspace; intra subnets for PrivateLink when enabled)
# -----------------------------------------------------------------------------
module "vpc" {
  source  = "terraform-aws-modules/vpc/aws"
  version = "~> 5.0"

  name = "${var.workspace_name}-vpc"
  cidr = "10.0.0.0/16"

  azs             = ["${var.aws_region}a", "${var.aws_region}b"]
  private_subnets = ["10.0.1.0/24", "10.0.2.0/24"]
  public_subnets  = var.enable_private_link ? [] : ["10.0.101.0/24", "10.0.102.0/24"]
  intra_subnets   = var.enable_private_link ? ["10.0.201.0/24", "10.0.202.0/24"] : []

  enable_nat_gateway   = !var.enable_private_link
  single_nat_gateway   = !var.enable_private_link
  create_igw           = !var.enable_private_link
  enable_dns_hostnames = true
  enable_dns_support   = true
}

# -----------------------------------------------------------------------------
# 1a-workspace. Security group for Databricks data plane (pass into complete-workspace-custom)
# -----------------------------------------------------------------------------
module "sg_workspace" {
  source  = "terraform-aws-modules/security-group/aws"
  version = "~> 5.0"

  name   = "${var.workspace_name}-workspace-sg"
  vpc_id = module.vpc.vpc_id

  ingress_with_self = [
    { from_port = 0, to_port = 65535, protocol = "tcp", description = "Databricks internode TCP" },
    { from_port = 0, to_port = 65535, protocol = "udp", description = "Databricks internode UDP" },
  ]

  egress_with_self = [
    { from_port = 0, to_port = 65535, protocol = "tcp", description = "Databricks internode TCP" },
    { from_port = 0, to_port = 65535, protocol = "udp", description = "Databricks internode UDP" },
  ]

  egress_with_cidr_blocks = [for port in local.workspace_sg_egress_ports : {
    from_port   = port
    to_port     = port
    protocol    = "tcp"
    cidr_blocks = module.vpc.vpc_cidr_block
    description = "Databricks control plane ${port}"
  }]

  egress_with_prefix_list_ids = [
    {
      from_port       = 443
      to_port         = 443
      protocol        = "tcp"
      prefix_list_ids = data.aws_prefix_list.s3.id
      description     = "S3 gateway prefix list"
    }
  ]

  tags = {
    Name        = "${var.workspace_name}-workspace-sg"
    Environment = "example"
    ManagedBy   = "Terraform"
  }
}

# -----------------------------------------------------------------------------
# 1b. PrivateLink security group (when we create endpoints in this example)
# -----------------------------------------------------------------------------
module "sg_privatelink" {
  source  = "terraform-aws-modules/security-group/aws"
  version = "~> 5.0"
  count   = var.enable_private_link && var.rest_api_aws_vpc_endpoint_id == null ? 1 : 0

  name   = "${var.workspace_name}-privatelink-sg"
  vpc_id = module.vpc.vpc_id

  ingress_with_cidr_blocks = [
    { from_port = 443, to_port = 443, protocol = "tcp", cidr_blocks = "10.0.0.0/16", description = "REST API" },
    { from_port = 2443, to_port = 2443, protocol = "tcp", cidr_blocks = "10.0.0.0/16", description = "SCC Relay" },
    { from_port = 5432, to_port = 5432, protocol = "tcp", cidr_blocks = "10.0.0.0/16", description = "PostgreSQL" },
    { from_port = 8443, to_port = 8451, protocol = "tcp", cidr_blocks = "10.0.0.0/16", description = "Control plane" },
  ]
}

# -----------------------------------------------------------------------------
# 1c. VPC endpoints for PrivateLink (S3 gateway, STS, Kinesis, Databricks REST + relay)
# -----------------------------------------------------------------------------
module "vpc_endpoints" {
  source  = "terraform-aws-modules/vpc/aws//modules/vpc-endpoints"
  version = "~> 5.0"
  count   = var.enable_private_link && var.rest_api_aws_vpc_endpoint_id == null ? 1 : 0

  vpc_id             = module.vpc.vpc_id
  security_group_ids = [module.sg_privatelink[0].security_group_id]

  endpoints = {
    s3 = {
      service         = "s3"
      service_type    = "Gateway"
      route_table_ids = module.vpc.private_route_table_ids
    }
    sts = {
      service             = "sts"
      private_dns_enabled = true
      subnet_ids          = module.vpc.intra_subnets
    }
    kinesis-streams = {
      service             = "kinesis-streams"
      private_dns_enabled = true
      subnet_ids          = module.vpc.intra_subnets
    }
    backend_rest = {
      service_name        = local.workspace_api_service[var.aws_region]
      private_dns_enabled = true
      subnet_ids          = module.vpc.intra_subnets
    }
    backend_relay = {
      service_name        = local.scc_relay_service[var.aws_region]
      private_dns_enabled = true
      subnet_ids          = module.vpc.intra_subnets
    }
  }
}

# -----------------------------------------------------------------------------
# 1d. Internal NLB and VPC endpoint service (for NCC private endpoint rule)
# -----------------------------------------------------------------------------
# When enable_nlb_private_endpoint is true, creates an internal NLB, exposes it
# via a VPC endpoint service, and passes the service name into the module so
# serverless compute can reach resources behind the NLB via the NCC private
# endpoint rule.
# -----------------------------------------------------------------------------
resource "aws_lb" "nlb" {
  count = var.enable_nlb_private_endpoint ? 1 : 0

  name                             = "${var.workspace_name}-nlb"
  internal                         = true
  load_balancer_type               = "network"
  subnets                          = module.vpc.private_subnets
  ip_address_type                  = "ipv4"
  enable_cross_zone_load_balancing = true

  tags = {
    Name        = "${var.workspace_name}-nlb"
    Environment = "example"
    ManagedBy   = "Terraform"
  }
}

resource "aws_lb_target_group" "nlb" {
  count = var.enable_nlb_private_endpoint ? 1 : 0

  name        = "${var.workspace_name}-nlb-tg"
  port        = 443
  protocol    = "TCP"
  vpc_id      = module.vpc.vpc_id
  target_type = "ip"

  health_check {
    enabled             = true
    healthy_threshold   = 2
    interval            = 30
    protocol            = "TCP"
    unhealthy_threshold = 2
  }

  tags = {
    Name        = "${var.workspace_name}-nlb-tg"
    Environment = "example"
    ManagedBy   = "Terraform"
  }
}

resource "aws_lb_listener" "nlb" {
  count = var.enable_nlb_private_endpoint ? 1 : 0

  load_balancer_arn = aws_lb.nlb[0].arn
  port              = "443"
  protocol          = "TCP"

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.nlb[0].arn
  }
}

resource "aws_vpc_endpoint_service" "nlb" {
  count = var.enable_nlb_private_endpoint ? 1 : 0

  acceptance_required        = false
  network_load_balancer_arns = [aws_lb.nlb[0].arn]
  # Allow Databricks serverless to create a VPC endpoint to this service (private connectivity)
  # https://docs.databricks.com/aws/security/network/serverless-network-security/pl-to-internal-network
  allowed_principals = ["arn:aws:iam::565502421330:role/private-connectivity-role-${var.aws_region}"]

  tags = {
    Name        = "${var.workspace_name}-nlb-vpce-service"
    Environment = "example"
    ManagedBy   = "Terraform"
  }
}

# When we create an NLB (in workspace VPC or dedicated VPC), use its VPC endpoint service name and FQDNs for the NCC rule
locals {
  nlb_endpoint_service_name = try(
    aws_vpc_endpoint_service.ncc_nlb[0].service_name,
    try(aws_vpc_endpoint_service.nlb[0].service_name, var.ncc_nlb_vpc_endpoint_service_name)
  )

  nlb_domain_names_for_rule = var.create_internal_nlb_vpc_endpoint ? (
    length(var.ncc_nlb_domain_names) > 0 ? var.ncc_nlb_domain_names : [format("api.%s.internal", local.dns_safe_workspace)]
    ) : var.enable_nlb_private_endpoint ? (
    length(var.ncc_nlb_domain_names) > 0 ? var.ncc_nlb_domain_names : ["api.${var.workspace_name}.internal"]
  ) : var.ncc_nlb_domain_names

  enable_ncc_for_module = var.enable_network_connectivity_config || var.enable_nlb_private_endpoint || var.create_internal_nlb_vpc_endpoint

  private_access_settings_id_for_workspace = (
    var.create_inbound_privatelink
    ? module.inbound_private_access_settings[0].private_access_settings_id
    : var.private_access_settings_id != null
    ? var.private_access_settings_id
    : (length(module.private_access_settings) > 0 ? module.private_access_settings[0].private_access_settings_id : null)
  )
}

check "private_access_settings_endpoint_requires_id" {
  assert {
    condition = (
      !var.enable_private_link
      || var.private_access_level != "ENDPOINT"
      || var.private_access_settings_id != null
      || var.create_inbound_privatelink
    )
    error_message = "When enable_private_link is true and private_access_level is ENDPOINT, set private_access_settings_id (this example only creates PAS for ACCOUNT), or enable create_inbound_privatelink so PAS is created for inbound PrivateLink."
  }
}

check "privatelink_requires_private_access_reference" {
  assert {
    condition = (
      !var.enable_private_link
      || var.private_access_settings_id != null
      || var.enable_private_access_settings
      || var.create_inbound_privatelink
    )
    error_message = "Databricks requires private_access_settings_id when Private Link is enabled. Set enable_private_access_settings = true (ACCOUNT PAS from this example), set private_access_settings_id, or create_inbound_privatelink = true."
  }
}

check "nlb_private_endpoint_mode_exclusive" {
  assert {
    condition     = !var.enable_nlb_private_endpoint || !var.create_internal_nlb_vpc_endpoint
    error_message = "Use either enable_nlb_private_endpoint (NLB in workspace VPC) or create_internal_nlb_vpc_endpoint (dedicated NLB VPC), not both."
  }
}

module "private_access_settings" {
  source = "../../../mws-private-access-settings"
  count = (
    var.enable_private_access_settings
    && var.private_access_settings_id == null
    && var.private_access_level == "ACCOUNT"
    && !var.create_inbound_privatelink
  ) ? 1 : 0

  providers = {
    databricks = databricks.account
  }

  private_access_settings_name = substr(replace("${var.workspace_name}-pas", "_", "-"), 0, 256)
  region                       = var.aws_region
  private_access_level         = "ACCOUNT"
}

# =============================================================================
# Part 2: complete-workspace-custom module (uses AWS resources above)
# =============================================================================
module "complete_workspace_custom" {
  source = "../../"

  providers = {
    databricks.account   = databricks.account
    databricks.workspace = databricks.workspace
  }

  databricks_account_id   = var.databricks_account_id
  workspace_name          = var.workspace_name
  existing_metastore_name = var.existing_metastore_name
  aws_region              = var.aws_region

  # From Part 1: VPC
  vpc_id             = module.vpc.vpc_id
  private_subnet_ids = module.vpc.private_subnets
  vpc_cidr           = module.vpc.vpc_cidr_block
  public_subnet_ids  = module.vpc.public_subnets
  nat_gateway_ids    = module.vpc.natgw_ids

  workspace_security_group_ids = [module.sg_workspace.security_group_id]

  # PrivateLink: use example-created endpoints or variables
  enable_private_link                 = var.enable_private_link
  rest_api_aws_vpc_endpoint_id        = var.enable_private_link ? (var.rest_api_aws_vpc_endpoint_id != null ? var.rest_api_aws_vpc_endpoint_id : try(module.vpc_endpoints[0].endpoints["backend_rest"].id, null)) : null
  dataplane_relay_aws_vpc_endpoint_id = var.enable_private_link ? (var.dataplane_relay_aws_vpc_endpoint_id != null ? var.dataplane_relay_aws_vpc_endpoint_id : try(module.vpc_endpoints[0].endpoints["backend_relay"].id, null)) : null

  private_access_settings_id = local.private_access_settings_id_for_workspace

  enable_network_connectivity_config = local.enable_ncc_for_module

  ncc_nlb_vpc_endpoint_service_name = local.nlb_endpoint_service_name
  ncc_nlb_domain_names              = local.nlb_domain_names_for_rule

  enable_cmk                   = true
  configure_workspace_security = var.configure_workspace_security

  managed_services_kms_key_arn    = module.example_kms_managed_services.key_arn
  workspace_storage_kms_key_arn   = module.example_kms_workspace_storage.key_arn
  managed_services_kms_key_alias  = "alias/${var.workspace_name}-example-managed-services"
  workspace_storage_kms_key_alias = "alias/${var.workspace_name}-example-workspace-storage"

  create_default_catalog                                    = var.create_default_catalog
  default_catalog_storage_kms_key_arn                       = var.create_default_catalog ? module.example_default_catalog_storage_kms[0].key_arn : null
  default_catalog_storage_kms_key_alias                     = var.create_default_catalog ? "alias/${local.example_default_catalog_kms_alias_name}" : null
  default_catalog_owner                                     = var.default_catalog_owner
  default_catalog_properties                                = var.default_catalog_properties
  default_catalog_isolation_mode                            = var.default_catalog_isolation_mode
  default_catalog_permissions                               = var.default_catalog_permissions
  default_catalog_service_principal_app_ids                 = var.default_catalog_service_principal_app_ids
  default_catalog_unity_catalog_iam_arn                     = var.default_catalog_unity_catalog_iam_arn
  default_catalog_enable_file_events                        = var.default_catalog_enable_file_events
  default_catalog_file_events_sqs_message_retention_seconds = var.default_catalog_file_events_sqs_message_retention_seconds
  default_catalog_file_events_sqs_kms_key_id                = var.default_catalog_file_events_sqs_kms_key_id
  default_catalog_file_events_s3_events                     = var.default_catalog_file_events_s3_events
  default_catalog_file_events_s3_filter_prefix              = var.default_catalog_file_events_s3_filter_prefix
  default_catalog_file_events_s3_filter_suffix              = var.default_catalog_file_events_s3_filter_suffix

  # Account network policy is enabled by default (all-deny egress, restricted public ingress).
  # One network policy is created per workspace by default.
  #
  # Example: allow outbound access to specific internet destinations.
  #
  # network_policy_allowed_internet_destinations = [
  #   {
  #     destination               = "example.com"
  #     internet_destination_type = "DNS_NAME"
  #   }
  # ]
  #
  # Example: customize context-based ingress.
  #
  # network_policy_public_access = {
  #   restriction_mode = "RESTRICTED_ACCESS"
  #   allow_rules = [
  #     {
  #       label  = "corp-vpn"
  #       origin = {
  #         included_ip_ranges = {
  #           ip_ranges = ["203.0.113.0/24"]
  #         }
  #       }
  #     }
  #   ]
  # }
  #
  # network_policy_private_access = {
  #   restriction_mode = "RESTRICTED_ACCESS"
  #   allow_rules = [
  #     {
  #       label  = "prod-endpoint"
  #       origin = {
  #         endpoints = {
  #           endpoint_ids = ["vpce-0abc123"]
  #         }
  #       }
  #     }
  #   ]
  # }

  tags = {
    Environment = "example"
    ManagedBy   = "Terraform"
  }

  depends_on = [
    module.vpc,
    module.sg_workspace,
    module.sg_privatelink,
    module.vpc_endpoints,
    module.private_access_settings,
    module.example_kms_managed_services,
    module.example_kms_workspace_storage,
    module.example_default_catalog_storage_kms,
    module.inbound_private_access_settings,
    databricks_mws_vpc_endpoint.inbound_workspace_api,
    module.nlb_vpc,
    aws_lb.nlb,
    aws_lb.ncc_nlb,
    aws_vpc_endpoint_service.nlb,
    aws_vpc_endpoint_service.ncc_nlb,
    time_sleep.nlb_endpoint_service_destroy_grace,
  ]
}

# =============================================================================
# Outputs
# =============================================================================
output "workspace_url" {
  description = "Databricks workspace URL"
  value       = module.complete_workspace_custom.workspace_url
}

output "workspace_id" {
  description = "Workspace ID"
  value       = module.complete_workspace_custom.workspace_id
}

output "metastore_id" {
  description = "Unity Catalog metastore ID"
  value       = module.complete_workspace_custom.metastore_id
}

output "security_info" {
  description = "Security configuration summary"
  value = {
    cmk_encryption_enabled    = module.complete_workspace_custom.managed_services_cmk_id != null
    unity_catalog_enabled     = module.complete_workspace_custom.metastore_id != null
    security_settings_applied = var.configure_workspace_security
  }
}

output "aws_infrastructure" {
  description = "AWS infrastructure created by the example and used by the module"
  value = {
    vpc_id             = module.complete_workspace_custom.vpc_id
    s3_bucket          = module.complete_workspace_custom.s3_bucket_name
    security_group_id  = module.complete_workspace_custom.security_group_id
    cross_account_role = module.complete_workspace_custom.cross_account_role_arn
  }
}

output "private_link_enabled" {
  description = "Whether PrivateLink is enabled"
  value       = var.enable_private_link
}

output "private_access_settings_id" {
  description = "MWS private access settings ID attached to the workspace (from var.private_access_settings_id or created by this example when enable_private_access_settings is true)."
  value       = module.complete_workspace_custom.private_access_settings_id
}

output "nlb_private_endpoint_rule" {
  description = "NCC private endpoint rule for NLB (when NLB is created or ncc_nlb_vpc_endpoint_service_name and ncc_nlb_domain_names are set)"
  value = local.nlb_endpoint_service_name != null && length(local.nlb_domain_names_for_rule) > 0 ? {
    rule_id          = module.complete_workspace_custom.nlb_private_endpoint_rule_id
    connection_state = module.complete_workspace_custom.nlb_private_endpoint_connection_state
  } : null
}

output "nlb_vpc_endpoint_service_name" {
  description = "VPC endpoint service name for the example-created NLB in the workspace VPC (when enable_nlb_private_endpoint is true)"
  value       = try(aws_vpc_endpoint_service.nlb[0].service_name, null)
}

output "dedicated_nlb_vpc_id" {
  description = "VPC ID for the internal NLB when create_internal_nlb_vpc_endpoint is true (dedicated NLB stack)."
  value       = try(module.nlb_vpc[0].vpc_id, null)
}

output "dedicated_internal_nlb_dns_name" {
  description = "DNS name of the internal NLB in the dedicated NLB VPC when create_internal_nlb_vpc_endpoint is true."
  value       = try(aws_lb.ncc_nlb[0].dns_name, null)
}

output "dedicated_nlb_vpc_endpoint_service_name" {
  description = "AWS VPC endpoint service name for the dedicated NLB stack (NCC rule input) when create_internal_nlb_vpc_endpoint is true."
  value       = try(aws_vpc_endpoint_service.ncc_nlb[0].service_name, null)
}

output "dedicated_nlb_private_dns_fqdns" {
  description = "FQDNs used for the NCC private endpoint rule when the example creates Route53 in the dedicated NLB VPC."
  value       = var.create_internal_nlb_vpc_endpoint ? local.nlb_domain_names_for_rule : []
}

output "inbound_privatelink_private_access_settings_id" {
  description = "PAS ID from mws-private-access-settings when create_inbound_privatelink is true (also passed to the workspace)."
  value       = try(module.inbound_private_access_settings[0].private_access_settings_id, null)
}

output "inbound_privatelink_vpc_id" {
  description = "Transit VPC ID when create_inbound_privatelink is true."
  value       = try(module.inbound_privatelink_vpc[0].vpc_id, null)
}

output "inbound_privatelink_vpc_endpoint_id" {
  description = "AWS interface VPC endpoint ID for Databricks Workspace (REST API) when create_inbound_privatelink is true."
  value       = try(aws_vpc_endpoint.inbound_databricks_workspace[0].id, null)
}

output "inbound_privatelink_mws_vpc_endpoint_id" {
  description = "Databricks MWS VPC endpoint registration ID when create_inbound_privatelink is true."
  value       = try(databricks_mws_vpc_endpoint.inbound_workspace_api[0].vpc_endpoint_id, null)
}
