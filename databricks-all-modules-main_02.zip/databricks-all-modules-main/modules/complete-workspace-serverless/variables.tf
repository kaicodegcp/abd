variable "aws_region" {
  description = "AWS region where the Databricks workspace will be created."
  type        = string
}

variable "databricks_account_id" {
  description = "Databricks account ID."
  type        = string
}

variable "databricks_aws_account_id" {
  description = "Databricks AWS account ID used in S3 bucket policy principal."
  type        = string
}

variable "enable_cmk" {
  description = "Register existing KMS keys with Databricks for managed services and workspace storage. When true, set managed_services_kms_key_arn, workspace_storage_kms_key_arn, managed_services_kms_key_alias, and workspace_storage_kms_key_alias. When false, root bucket uses SSE-S3 (AES256) and the workspace is created without CMK IDs (same pattern as complete-workspace-custom)."
  type        = bool
  default     = true
}

variable "managed_services_kms_key_arn" {
  description = "ARN of the AWS KMS key for Databricks managed services CMK registration. Required when enable_cmk is true."
  type        = string
  default     = null
}

variable "managed_services_kms_key_alias" {
  description = "Databricks CMK alias for managed services (aws_key_info.key_alias), e.g. alias/my-managed-services-key. Required when enable_cmk is true."
  type        = string
  default     = null
}

variable "workspace_storage_kms_key_arn" {
  description = "ARN of the AWS KMS key for workspace root storage (S3 SSE) and STORAGE CMK registration. Required when enable_cmk is true."
  type        = string
  default     = null
}

variable "workspace_storage_kms_key_alias" {
  description = "Databricks CMK alias for workspace storage (aws_key_info.key_alias), e.g. alias/my-workspace-storage-key. Required when enable_cmk is true."
  type        = string
  default     = null
}

variable "name_prefix" {
  description = "Prefix for resource names. Must be at most 29 characters so the derived network_policy_id ('<name_prefix>-np') does not exceed the 32-character API limit."
  type        = string

  validation {
    condition     = length(var.name_prefix) <= 29
    error_message = "name_prefix must be at most 29 characters (derived network_policy_id '<name_prefix>-np' must not exceed 32 characters)."
  }
}

variable "workspace_name" {
  description = "Name for the new Databricks workspace."
  type        = string
}

variable "workspace_root_bucket_name" {
  description = "S3 bucket name used for Databricks workspace root storage configuration."
  type        = string
}

variable "existing_metastore_name" {
  description = "Existing Unity Catalog metastore name to assign to the workspace."
  type        = string
}

variable "private_access_settings_id" {
  description = "Optional MWS private access settings ID (from databricks_mws_private_access_settings or the account console). When set, attaches PrivateLink / private connectivity policy to the new workspace."
  type        = string
  default     = null
}

# =============================================================================
# Deployment configuration
# =============================================================================

variable "deployment_name" {
  description = "Deployment name for the workspace URL prefix. Must be enabled by a Databricks representative."
  type        = string
  default     = null
  nullable    = true
}

variable "force_destroy_buckets" {
  description = "Whether Terraform can delete non-empty S3 buckets on destroy."
  type        = bool
  default     = false
}

variable "enable_network_connectivity_config" {
  description = "Create an MWS Network Connectivity Config (NCC) and bind it to the serverless workspace for egress / private endpoint rules."
  type        = bool
  default     = false
}

variable "enable_account_network_policy" {
  description = "Create an account-level network policy (RESTRICTED_ACCESS / ENFORCED) and bind it to the workspace, enforcing default all-deny egress."
  type        = bool
  default     = true
}

variable "existing_network_policy_id" {
  description = "ID of an existing account network policy to reuse. When set, no new policy is created — the existing policy is bound to the workspace directly."
  type        = string
  default     = null
}

variable "network_policy_allowed_internet_destinations" {
  description = "Internet destinations allowed in RESTRICTED_ACCESS mode."
  type = list(object({
    destination               = string
    internet_destination_type = string
  }))
  default = []
}

variable "network_policy_allowed_storage_destinations" {
  description = "Storage destinations allowed in RESTRICTED_ACCESS mode."
  type = list(object({
    bucket_name              = string
    region                   = string
    storage_destination_type = string
  }))
  default = []
}

variable "network_policy_public_access" {
  description = "Context-based ingress policy for public internet traffic. restriction_mode: FULL_ACCESS or RESTRICTED_ACCESS."
  type = object({
    restriction_mode = string
    allow_rules = optional(list(object({
      label = optional(string)
      authentication = optional(object({
        identity_type = optional(string)
        identities = optional(list(object({
          principal_id   = optional(number)
          principal_type = optional(string)
        })), [])
      }))
      destination = optional(object({
        all_destinations = optional(bool)
        workspace_ui     = optional(object({ all_destinations = optional(bool) }))
        workspace_api    = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        apps_runtime     = optional(object({ all_destinations = optional(bool) }))
        lakebase_runtime = optional(object({ all_destinations = optional(bool) }))
        account_api      = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        account_ui       = optional(object({ all_destinations = optional(bool) }))
      }))
      origin = optional(object({
        all_ip_ranges      = optional(bool)
        included_ip_ranges = optional(object({ ip_ranges = optional(list(string), []) }))
        excluded_ip_ranges = optional(object({ ip_ranges = optional(list(string), []) }))
      }))
    })), [])
    deny_rules = optional(list(object({
      label = optional(string)
      authentication = optional(object({
        identity_type = optional(string)
        identities = optional(list(object({
          principal_id   = optional(number)
          principal_type = optional(string)
        })), [])
      }))
      destination = optional(object({
        all_destinations = optional(bool)
        workspace_ui     = optional(object({ all_destinations = optional(bool) }))
        workspace_api    = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        apps_runtime     = optional(object({ all_destinations = optional(bool) }))
        lakebase_runtime = optional(object({ all_destinations = optional(bool) }))
        account_api      = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        account_ui       = optional(object({ all_destinations = optional(bool) }))
      }))
      origin = optional(object({
        all_ip_ranges      = optional(bool)
        included_ip_ranges = optional(object({ ip_ranges = optional(list(string), []) }))
        excluded_ip_ranges = optional(object({ ip_ranges = optional(list(string), []) }))
      }))
    })), [])
  })
  default = {
    restriction_mode = "RESTRICTED_ACCESS"
    allow_rules      = []
    deny_rules       = []
  }
}

variable "network_policy_private_access" {
  description = "Context-based ingress policy for private connectivity (PrivateLink/registered endpoints). restriction_mode: ALLOW_ALL_REGISTERED_ENDPOINTS or RESTRICTED_ACCESS."
  type = object({
    restriction_mode = string
    allow_rules = optional(list(object({
      label = optional(string)
      authentication = optional(object({
        identity_type = optional(string)
        identities = optional(list(object({
          principal_id   = optional(number)
          principal_type = optional(string)
        })), [])
      }))
      destination = optional(object({
        all_destinations = optional(bool)
        workspace_ui     = optional(object({ all_destinations = optional(bool) }))
        workspace_api    = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        apps_runtime     = optional(object({ all_destinations = optional(bool) }))
        lakebase_runtime = optional(object({ all_destinations = optional(bool) }))
        account_api      = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        account_ui       = optional(object({ all_destinations = optional(bool) }))
      }))
      origin = optional(object({
        all_registered_endpoints     = optional(bool)
        all_private_access           = optional(bool)
        azure_workspace_private_link = optional(bool)
        endpoints                    = optional(object({ endpoint_ids = optional(list(string), []) }))
      }))
    })), [])
    deny_rules = optional(list(object({
      label = optional(string)
      authentication = optional(object({
        identity_type = optional(string)
        identities = optional(list(object({
          principal_id   = optional(number)
          principal_type = optional(string)
        })), [])
      }))
      destination = optional(object({
        all_destinations = optional(bool)
        workspace_ui     = optional(object({ all_destinations = optional(bool) }))
        workspace_api    = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        apps_runtime     = optional(object({ all_destinations = optional(bool) }))
        lakebase_runtime = optional(object({ all_destinations = optional(bool) }))
        account_api      = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        account_ui       = optional(object({ all_destinations = optional(bool) }))
      }))
      origin = optional(object({
        all_registered_endpoints     = optional(bool)
        all_private_access           = optional(bool)
        azure_workspace_private_link = optional(bool)
        endpoints                    = optional(object({ endpoint_ids = optional(list(string), []) }))
      }))
    })), [])
  })
  default = {
    restriction_mode = "ALLOW_ALL_REGISTERED_ENDPOINTS"
    allow_rules      = []
    deny_rules       = []
  }
}

variable "network_policy_cross_workspace_access" {
  description = "Context-based ingress policy for cross-workspace traffic within the same account. restriction_mode: FULL_ACCESS or RESTRICTED_ACCESS."
  type = object({
    restriction_mode = string
    allow_rules = optional(list(object({
      label = optional(string)
      authentication = optional(object({
        identity_type = optional(string)
        identities = optional(list(object({
          principal_id   = optional(number)
          principal_type = optional(string)
        })), [])
      }))
      destination = optional(object({
        all_destinations = optional(bool)
        workspace_ui     = optional(object({ all_destinations = optional(bool) }))
        workspace_api    = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        apps_runtime     = optional(object({ all_destinations = optional(bool) }))
        lakebase_runtime = optional(object({ all_destinations = optional(bool) }))
        account_api      = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        account_ui       = optional(object({ all_destinations = optional(bool) }))
      }))
      origin = optional(object({
        all_source_workspaces = optional(bool)
        selected_workspaces   = optional(object({ workspace_ids = optional(list(number), []) }))
      }))
    })), [])
    deny_rules = optional(list(object({
      label = optional(string)
      authentication = optional(object({
        identity_type = optional(string)
        identities = optional(list(object({
          principal_id   = optional(number)
          principal_type = optional(string)
        })), [])
      }))
      destination = optional(object({
        all_destinations = optional(bool)
        workspace_ui     = optional(object({ all_destinations = optional(bool) }))
        workspace_api    = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        apps_runtime     = optional(object({ all_destinations = optional(bool) }))
        lakebase_runtime = optional(object({ all_destinations = optional(bool) }))
        account_api      = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        account_ui       = optional(object({ all_destinations = optional(bool) }))
      }))
      origin = optional(object({
        all_source_workspaces = optional(bool)
        selected_workspaces   = optional(object({ workspace_ids = optional(list(number), []) }))
      }))
    })), [])
  })
  default = null
}

variable "ncc_nlb_vpc_endpoint_service_name" {
  description = "AWS VPC endpoint service name for the NLB private endpoint rule when ncc_nlb_domain_names is non-empty. May be (known after apply). See mws-network-connectivity-config module."
  type        = string
  default     = null
}

variable "ncc_nlb_domain_names" {
  description = "FQDNs for the NCC private endpoint rule; non-empty list creates the rule (service name can resolve at apply time)."
  type        = list(string)
  default     = []
}

# =============================================================================
# Tags (e.g. default Unity Catalog AWS resources)
# =============================================================================

variable "tags" {
  description = "Tags applied to resources created by optional submodules (e.g. catalog-creation)."
  type        = map(string)
  default     = {}
}

# =============================================================================
# Workspace security (workspace-conf) — same pattern as complete-workspace-custom
# =============================================================================

variable "configure_workspace_security" {
  description = "Apply workspace security settings (data exfiltration prevention) via workspace-conf."
  type        = bool
  default     = true
}

# =============================================================================
# Compliance Security Profile
# =============================================================================

variable "enable_csp" {
  description = "Enable Compliance Security Profile on the workspace (regulated workloads)."
  type        = bool
  default     = false
}

variable "compliance_standards" {
  description = "Compliance standards for CSP (e.g., HIPAA, PCI_DSS, FEDRAMP_MODERATE). When null or empty and enable_csp is true, the module defaults to [\"HIPAA\"] (API requires at least one standard)."
  type        = list(string)
  default     = null
  nullable    = true
}

# =============================================================================
# Optional default Unity Catalog (catalog-creation) — same as complete-workspace-custom
# =============================================================================

variable "create_default_catalog" {
  description = "When true, creates a managed catalog via catalog-creation after metastore assignment. Requires existing_metastore_name and caller-supplied default_catalog_storage_kms_key_arn / default_catalog_storage_kms_key_alias."
  type        = bool
  default     = false
}

variable "default_catalog_owner" {
  description = "Owner for the default catalog (passed to catalog-creation)."
  type        = string
  default     = "account users"
}

variable "default_catalog_properties" {
  description = "Extra properties for the default catalog."
  type        = map(string)
  default     = {}
}

variable "default_catalog_isolation_mode" {
  description = "Catalog isolation mode: ISOLATED or OPEN."
  type        = string
  default     = "ISOLATED"

  validation {
    condition     = contains(["ISOLATED", "OPEN"], var.default_catalog_isolation_mode)
    error_message = "default_catalog_isolation_mode must be ISOLATED or OPEN."
  }
}

variable "default_catalog_permissions" {
  description = "Catalog-level grants (groups and service principals)."
  type = object({
    groups             = map(list(string))
    service_principals = map(list(string))
  })
  default = {
    groups             = {}
    service_principals = {}
  }
}

variable "default_catalog_service_principal_app_ids" {
  description = "Service principal name to application ID map for catalog/schema grants."
  type        = map(string)
  default     = {}
}

variable "default_catalog_storage_kms_key_arn" {
  description = "When create_default_catalog is true, ARN of the customer-managed KMS key for Unity Catalog catalog root storage (S3 SSE-KMS and UC IAM policy). Ignored when create_default_catalog is false."
  type        = string
  default     = null
  nullable    = true
}

variable "default_catalog_storage_kms_key_alias" {
  description = "When create_default_catalog is true, KMS alias for catalog storage in alias/name form (e.g. alias/my-key). Ignored when create_default_catalog is false."
  type        = string
  default     = null
  nullable    = true
}

variable "default_catalog_unity_catalog_iam_arn" {
  description = "Unity Catalog master IAM role for storage credential trust; set for GovCloud or non-default deployments."
  type        = string
  default     = null
}

variable "default_catalog_enable_file_events" {
  description = "Enable catalog file events (SQS + S3 notifications) per catalog-creation."
  type        = bool
  default     = false
}

variable "default_catalog_file_events_sqs_message_retention_seconds" {
  description = "SQS retention when default_catalog_enable_file_events is true."
  type        = number
  default     = 345600
}

variable "default_catalog_file_events_sqs_kms_key_id" {
  description = "Optional KMS key for SQS when file events are enabled."
  type        = string
  default     = null
}

variable "default_catalog_file_events_s3_events" {
  description = "S3 event types for file-events notifications when default_catalog_enable_file_events is true."
  type        = list(string)
  default     = ["s3:ObjectCreated:*", "s3:ObjectRemoved:*", "s3:LifecycleExpiration:*"]
}

variable "default_catalog_file_events_s3_filter_prefix" {
  type    = string
  default = ""
}

variable "default_catalog_file_events_s3_filter_suffix" {
  type    = string
  default = ""
}
