output "workspace_id" {
  description = "Created Databricks workspace ID."
  value       = databricks_mws_workspaces.this.workspace_id
}

output "workspace_url" {
  description = "Created Databricks workspace URL."
  value       = databricks_mws_workspaces.this.workspace_url
}

output "deployment_name" {
  description = "Workspace deployment name URL prefix (same as var.deployment_name when set)."
  value       = databricks_mws_workspaces.this.deployment_name
}

output "private_access_settings_id" {
  description = "MWS private access settings ID on the workspace (same as var.private_access_settings_id when set)."
  value       = databricks_mws_workspaces.this.private_access_settings_id
}

output "storage_configuration_id" {
  description = "Databricks account storage configuration ID."
  value       = databricks_mws_storage_configurations.this.storage_configuration_id
}

output "managed_services_cmk_id" {
  description = "Databricks managed services customer-managed key ID when enable_cmk is true."
  value       = var.enable_cmk ? databricks_mws_customer_managed_keys.managed_services[0].customer_managed_key_id : null
}

output "storage_cmk_id" {
  description = "Databricks storage customer-managed key ID when enable_cmk is true."
  value       = var.enable_cmk ? databricks_mws_customer_managed_keys.storage[0].customer_managed_key_id : null
}

output "managed_services_kms_key_arn" {
  description = "Managed services KMS key ARN (same as var.managed_services_kms_key_arn when enable_cmk)."
  value       = var.enable_cmk ? var.managed_services_kms_key_arn : null
}

output "managed_services_kms_key_alias" {
  description = "Databricks CMK alias for managed services when enable_cmk is true."
  value       = var.enable_cmk ? var.managed_services_kms_key_alias : null
}

output "workspace_storage_kms_key_arn" {
  description = "Workspace storage KMS key ARN (same as var.workspace_storage_kms_key_arn when enable_cmk)."
  value       = var.enable_cmk ? var.workspace_storage_kms_key_arn : null
}

output "workspace_storage_kms_key_alias" {
  description = "Databricks CMK alias for workspace storage when enable_cmk is true."
  value       = var.enable_cmk ? var.workspace_storage_kms_key_alias : null
}

output "cmk_enabled" {
  description = "Whether customer-managed keys are registered and used for the workspace and root bucket SSE."
  value       = var.enable_cmk
}

output "metastore_id" {
  description = "Assigned Unity Catalog metastore ID."
  value       = data.databricks_metastore.existing.metastore_id
}

output "default_catalog_id" {
  description = "Unity Catalog catalog ID when create_default_catalog is true."
  value       = var.create_default_catalog ? module.default_catalog[0].catalog_id : null
}

output "default_catalog_name" {
  description = "Unity Catalog catalog name when create_default_catalog is true."
  value       = var.create_default_catalog ? module.default_catalog[0].catalog_name : null
}

output "default_catalog_storage_credential_id" {
  description = "Storage credential ID for the default catalog when create_default_catalog is true."
  value       = var.create_default_catalog ? module.default_catalog[0].storage_credential_id : null
}

output "default_catalog_external_location_name" {
  description = "External location name for the default catalog when create_default_catalog is true."
  value       = var.create_default_catalog ? module.default_catalog[0].external_location_name : null
}

output "default_catalog_s3_bucket_name" {
  description = "S3 bucket for default catalog root storage when create_default_catalog is true."
  value       = var.create_default_catalog ? module.default_catalog[0].s3_bucket_name : null
}

output "csp_enabled" {
  description = "Whether Compliance Security Profile is enabled."
  value       = var.enable_csp
}

output "network_connectivity_config_id" {
  description = "MWS Network Connectivity Config ID when enable_network_connectivity_config is true."
  value       = length(module.network_connectivity_config) > 0 ? module.network_connectivity_config[0].network_connectivity_config_id : null
}

output "ncc_egress_config" {
  description = "Computed NCC egress rules from Databricks (when NCC is enabled)."
  value       = length(module.network_connectivity_config) > 0 ? module.network_connectivity_config[0].egress_config : null
}

output "ncc_nlb_private_endpoint_rule_id" {
  description = "NLB private endpoint rule ID when NLB variables are set and NCC is enabled."
  value       = length(module.network_connectivity_config) > 0 ? module.network_connectivity_config[0].nlb_private_endpoint_rule_id : null
}

output "account_network_policy_id" {
  description = "Account network policy ID when enable_account_network_policy is true."
  value       = var.enable_account_network_policy ? module.account_network_policy[0].network_policy_id : null
}
