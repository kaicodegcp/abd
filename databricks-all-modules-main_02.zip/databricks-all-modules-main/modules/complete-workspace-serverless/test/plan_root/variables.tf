# Variables passed through to module "../.." for terratest plan-only checks.

variable "aws_region" {
  type = string
}

variable "databricks_account_id" {
  type = string
}

variable "databricks_aws_account_id" {
  type = string
}

variable "name_prefix" {
  type = string
}

variable "workspace_name" {
  type = string
}

variable "workspace_root_bucket_name" {
  type = string
}

variable "existing_metastore_name" {
  type = string
}

variable "workspace_host" {
  type        = string
  description = "Databricks workspace URL for the workspace provider (plan tests use a placeholder)."
  default     = "https://dbc-0000000000000000.cloud.databricks.com"
}

variable "force_destroy_buckets" {
  type    = bool
  default = false
}

variable "private_access_settings_id" {
  type     = string
  nullable = true
  default  = null
}

variable "enable_cmk" {
  type        = bool
  description = "When false, plan tests can omit KMS inputs (matches complete-workspace-serverless enable_cmk)."
  default     = true
}

variable "managed_services_kms_key_arn" {
  type     = string
  nullable = true
  default  = null
}

variable "managed_services_kms_key_alias" {
  type     = string
  nullable = true
  default  = null
}

variable "workspace_storage_kms_key_arn" {
  type     = string
  nullable = true
  default  = null
}

variable "workspace_storage_kms_key_alias" {
  type     = string
  nullable = true
  default  = null
}

variable "enable_network_connectivity_config" {
  type    = bool
  default = false
}

variable "ncc_nlb_vpc_endpoint_service_name" {
  type     = string
  nullable = true
  default  = null
}

variable "ncc_nlb_domain_names" {
  type    = list(string)
  default = []
}
