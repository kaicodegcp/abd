# =============================================================================
# Example variables for complete-workspace-serverless
# Set these in terraform.tfvars (copy from terraform.tfvars.example).
# The module requires aws_region, name_prefix, and existing_metastore_name
# (no defaults in module); this example provides defaults for convenience.
# =============================================================================

variable "databricks_account_id" {
  description = "Databricks account ID."
  type        = string
}

# Client ID and secret for Databricks provider come from env (e.g. source secrets file: DATABRICKS_CLIENT_ID, DATABRICKS_CLIENT_SECRET)

variable "databricks_aws_account_id" {
  description = "Databricks AWS account ID (used in S3 bucket policy principal)."
  type        = string
}

variable "aws_region" {
  description = "AWS region where the workspace and S3 bucket will be created."
  type        = string
  default     = "us-east-1"
}

variable "name_prefix" {
  description = "Prefix for resource names (e.g. MWS storage config, example KMS alias strings)."
  type        = string
  default     = "serverless-ncc-example"
}

variable "workspace_name" {
  description = "Name for the new Databricks serverless workspace."
  type        = string
}

variable "deployment_name" {
  description = "Deployment name for the workspace URL prefix (passed to complete-workspace-serverless). Must be enabled by a Databricks representative when set."
  type        = string
  default     = null
  nullable    = true
}

variable "workspace_root_bucket_name" {
  description = "S3 bucket name for the workspace root storage configuration. Must be globally unique."
  type        = string
}

variable "existing_metastore_name" {
  description = "Existing Unity Catalog metastore name to assign to the workspace."
  type        = string
  default     = "yankaiz-us-east-1"
}

variable "private_access_settings_id" {
  description = "Optional MWS private access settings ID for PrivateLink when create_inbound_privatelink is false. When create_inbound_privatelink is true, leave null (the example creates PAS via mws-private-access-settings)."
  type        = string
  default     = null
}

variable "force_destroy_buckets" {
  description = "Allow Terraform to delete non-empty S3 buckets on destroy (use with caution)."
  type        = bool
  default     = true
}

variable "enable_cmk" {
  description = "When true (default), create example KMS keys and register them with complete-workspace-serverless. When false, root bucket uses SSE-S3 and the module omits CMK registration (no keys created in this example)."
  type        = bool
  default     = true
}

# =============================================================================
# Workspace security (workspace-conf), CSP, optional default UC catalog
# (same inputs as complete-workspace-serverless; see ../../variables.tf)
# =============================================================================

variable "configure_workspace_security" {
  description = "Apply workspace security settings (data exfiltration prevention) via workspace-conf."
  type        = bool
  default     = true
}

variable "enable_csp" {
  description = "Enable Compliance Security Profile on the workspace (regulated workloads)."
  type        = bool
  default     = false
}

variable "compliance_standards" {
  description = "Compliance standards for CSP (e.g., HIPAA, PCI_DSS, FEDRAMP_MODERATE). Null uses provider/workspace defaults."
  type        = list(string)
  default     = null
  nullable    = true
}

variable "create_default_catalog" {
  description = "When true, this example creates a catalog-storage CMK (default-catalog-kms.tf) and the serverless module creates a managed catalog via catalog-creation. Requires existing_metastore_name."
  type        = bool
  default     = false
}

variable "default_catalog_owner" {
  description = "Owner for the default catalog (passed to catalog-creation)."
  type        = string
  default     = "account users"
}

variable "default_catalog_properties" {
  description = "Extra properties for the default catalog."
  type        = map(string)
  default     = {}
}

variable "default_catalog_isolation_mode" {
  description = "Catalog isolation mode: ISOLATED or OPEN."
  type        = string
  default     = "ISOLATED"

  validation {
    condition     = contains(["ISOLATED", "OPEN"], var.default_catalog_isolation_mode)
    error_message = "default_catalog_isolation_mode must be ISOLATED or OPEN."
  }
}

variable "default_catalog_permissions" {
  description = "Catalog-level grants (groups and service principals)."
  type = object({
    groups             = map(list(string))
    service_principals = map(list(string))
  })
  default = {
    groups             = {}
    service_principals = {}
  }
}

variable "default_catalog_service_principal_app_ids" {
  description = "Service principal name to application ID map for catalog/schema grants."
  type        = map(string)
  default     = {}
}

variable "example_default_catalog_kms_cmk_admin_arn" {
  description = "Optional principal for kms:* on the example default-catalog CMK when create_default_catalog is true (defaults to account root)."
  type        = string
  default     = null
}

variable "default_catalog_unity_catalog_iam_arn" {
  description = "Unity Catalog master IAM role for storage credential trust; set for GovCloud or non-default deployments."
  type        = string
  default     = null
}

variable "default_catalog_enable_file_events" {
  description = "Enable catalog file events (SQS + S3 notifications) per catalog-creation. When create_default_catalog is true, keep this true: catalog-creation attaches an inline IAM policy that must be non-empty (see check block in main.tf)."
  type        = bool
  default     = true
}

variable "default_catalog_file_events_sqs_message_retention_seconds" {
  description = "SQS retention when default_catalog_enable_file_events is true."
  type        = number
  default     = 345600
}

variable "default_catalog_file_events_sqs_kms_key_id" {
  description = "Optional KMS key for SQS when file events are enabled."
  type        = string
  default     = null
}

variable "default_catalog_file_events_s3_events" {
  description = "S3 event types for file-events notifications when default_catalog_enable_file_events is true."
  type        = list(string)
  default     = ["s3:ObjectCreated:*", "s3:ObjectRemoved:*", "s3:LifecycleExpiration:*"]
}

variable "default_catalog_file_events_s3_filter_prefix" {
  type    = string
  default = ""
}

variable "default_catalog_file_events_s3_filter_suffix" {
  type    = string
  default = ""
}

variable "enable_network_connectivity_config" {
  description = "Create an MWS Network Connectivity Config and bind it to the serverless workspace. Implied true when create_internal_nlb_vpc_endpoint is true."
  type        = bool
  default     = false
}

variable "create_internal_nlb_vpc_endpoint" {
  description = "Create a dedicated VPC, internal NLB, VPC endpoint service, and private Route53 zone; pass service name and FQDNs into the module for the NCC private endpoint rule."
  type        = bool
  default     = false
}

variable "nlb_vpc_endpoint_service_destroy_wait_duration" {
  description = "Destroy-phase delay (hashicorp/time format, e.g. 600s, 15m) after the serverless module is destroyed and before deleting the NLB VPC endpoint service, so Databricks can release interface endpoint connections. Only applies when create_internal_nlb_vpc_endpoint is true."
  type        = string
  default     = "600s"
}

variable "nlb_vpc_cidr" {
  description = "IPv4 CIDR for the NLB VPC (only used when create_internal_nlb_vpc_endpoint is true)."
  type        = string
  default     = "10.48.0.0/16"
}

variable "nlb_vpc_endpoint_allowed_principal_arns" {
  description = "IAM principal ARNs allowed to create interface VPC endpoints to the NLB service. Defaults to the Databricks private connectivity role for aws_region."
  type        = list(string)
  default     = null
}

variable "ncc_nlb_vpc_endpoint_service_name" {
  description = "Optional VPC endpoint service name when not using create_internal_nlb_vpc_endpoint (use with ncc_nlb_domain_names and enable_network_connectivity_config)."
  type        = string
  default     = null
}

variable "ncc_nlb_domain_names" {
  description = "FQDNs for the NCC private endpoint rule. When create_internal_nlb_vpc_endpoint is true and this is empty, defaults to [\"api.<workspace>.internal\"] (underscores in workspace_name become hyphens)."
  type        = list(string)
  default     = []
}

# -----------------------------------------------------------------------------
# Inbound PrivateLink (Databricks docs steps 1–3)
# https://docs.databricks.com/aws/en/security/network/front-end/front-end-private-connect
# -----------------------------------------------------------------------------

variable "create_inbound_privatelink" {
  description = "When true, runs steps 1–3: transit VPC + Workspace (REST API) interface endpoint + MWS VPC endpoint registration + private access settings (mws-private-access-settings), and passes PAS to the serverless workspace. Do not set private_access_settings_id. DNS (step 5) remains manual."
  type        = bool
  default     = false
}

variable "inbound_privatelink_vpc_cidr" {
  description = "IPv4 CIDR for the inbound PrivateLink transit VPC when create_inbound_privatelink is true."
  type        = string
  default     = "10.49.0.0/16"
}

variable "inbound_privatelink_workspace_service_name" {
  description = "Override for the AWS endpoint service name (Workspace including REST API). When null, uses the built-in map for aws_region; if your region is missing, set this from the Databricks PrivateLink VPC endpoint services table."
  type        = string
  default     = null
}

variable "inbound_privatelink_https_ingress_cidr_blocks" {
  description = "CIDRs allowed to connect to the interface endpoint on TCP 443. When null, defaults to the transit VPC CIDR only; add on-premises or TGW-connected ranges as needed."
  type        = list(string)
  default     = null
}

variable "inbound_privatelink_private_access_settings_name" {
  description = "Name for the private access settings object (step 3). When null, defaults to \"<name_prefix>-<workspace>-pas\"."
  type        = string
  default     = null
}

variable "inbound_privatelink_private_access_level" {
  description = "Private access level for step 3: ENDPOINT restricts to the inbound MWS VPC endpoint registration; ACCOUNT allows any VPC endpoint registered in the Databricks account."
  type        = string
  default     = "ENDPOINT"

  validation {
    condition     = contains(["ACCOUNT", "ENDPOINT"], var.inbound_privatelink_private_access_level)
    error_message = "inbound_privatelink_private_access_level must be ACCOUNT or ENDPOINT."
  }
}
