# =============================================================================
# Complete Databricks Serverless Workspace - Example
# =============================================================================
# This example runs the complete-workspace-serverless module with variables
# supplied via terraform.tfvars (copy terraform.tfvars.example to terraform.tfvars
# and set your Databricks account ID, OAuth credentials, workspace name, and
# S3 bucket name).
#
# The module creates:
#   - S3 bucket for workspace root (SSE with caller-provided KMS, versioning, bucket policy)
#   - MWS storage configuration, customer-managed keys (storage + managed services)
#   - MWS serverless workspace (optional private_access_settings_id for PrivateLink)
#   - Optional dedicated VPC + internal NLB + VPC endpoint service + private
#     Route53 zone when create_internal_nlb_vpc_endpoint is true; values are
#     passed into the module for the NCC private endpoint rule
#   - Optional MWS Network Connectivity Config (NCC) and workspace binding when
#     enable_network_connectivity_config is true or NLB stack is created
#   - Metastore assignment to an existing Unity Catalog metastore
#   - Optional default UC catalog (default-catalog-kms.tf CMK when create_default_catalog), workspace-conf, and CSP
#   - Optional inbound PrivateLink (steps 1–3) when create_inbound_privatelink is true:
#     transit VPC, Workspace API interface endpoint, MWS VPC endpoint registration, PAS module, workspace attachment
#     https://docs.databricks.com/aws/en/security/network/front-end/front-end-private-connect
# =============================================================================

terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 5.0"
    }
    databricks = {
      source  = "databricks/databricks"
      version = ">= 1.117.0, <= 1.128.0"
    }
    time = {
      source  = "hashicorp/time"
      version = ">= 0.9.0"
    }
  }
}

# -----------------------------------------------------------------------------
# Providers
# -----------------------------------------------------------------------------
provider "aws" {
  region = var.aws_region
}

provider "databricks" {
  alias      = "mws"
  host       = "https://accounts.cloud.databricks.com"
  account_id = var.databricks_account_id
}

provider "databricks" {
  alias = "workspace"
  host  = module.complete_workspace_serverless.workspace_url
}

# -----------------------------------------------------------------------------
# Module
# -----------------------------------------------------------------------------
module "complete_workspace_serverless" {
  source = "../.."

  providers = {
    databricks.mws       = databricks.mws
    databricks.workspace = databricks.workspace
  }

  aws_region                 = var.aws_region
  databricks_account_id      = var.databricks_account_id
  databricks_aws_account_id  = var.databricks_aws_account_id
  name_prefix                = var.name_prefix
  workspace_name             = var.workspace_name
  deployment_name            = var.deployment_name
  workspace_root_bucket_name = var.workspace_root_bucket_name
  existing_metastore_name    = var.existing_metastore_name
  private_access_settings_id = (
    var.create_inbound_privatelink
    ? module.inbound_private_access_settings[0].private_access_settings_id
    : var.private_access_settings_id
  )
  force_destroy_buckets = var.force_destroy_buckets

  enable_cmk                      = var.enable_cmk
  managed_services_kms_key_arn    = var.enable_cmk ? module.example_kms_managed_services[0].key_arn : null
  workspace_storage_kms_key_arn   = var.enable_cmk ? module.example_kms_workspace_storage[0].key_arn : null
  managed_services_kms_key_alias  = var.enable_cmk ? "alias/${var.name_prefix}-example-managed-services" : null
  workspace_storage_kms_key_alias = var.enable_cmk ? "alias/${var.name_prefix}-example-workspace-storage" : null

  enable_network_connectivity_config = local.ncc_enabled
  ncc_nlb_vpc_endpoint_service_name  = local.nlb_service_name_for_module
  ncc_nlb_domain_names               = local.nlb_domain_names_for_module

  tags = {
    Environment = "example"
    ManagedBy   = "Terraform"
  }

  configure_workspace_security = var.configure_workspace_security

  # Account network policy is enabled by default (all-deny egress, restricted public ingress).
  # One network policy is created per workspace by default.
  #
  # Example: allow outbound access to specific internet destinations.
  #
  # network_policy_allowed_internet_destinations = [
  #   {
  #     destination               = "example.com"
  #     internet_destination_type = "DNS_NAME"
  #   }
  # ]
  #
  # Example: customize context-based ingress.
  #
  # network_policy_public_access = {
  #   restriction_mode = "RESTRICTED_ACCESS"
  #   allow_rules = [
  #     {
  #       label  = "corp-vpn"
  #       origin = {
  #         included_ip_ranges = {
  #           ip_ranges = ["203.0.113.0/24"]
  #         }
  #       }
  #     }
  #   ]
  # }
  #
  # network_policy_private_access = {
  #   restriction_mode = "RESTRICTED_ACCESS"
  #   allow_rules = [
  #     {
  #       label  = "prod-endpoint"
  #       origin = {
  #         endpoints = {
  #           endpoint_ids = ["vpce-0abc123"]
  #         }
  #       }
  #     }
  #   ]
  # }


  enable_csp           = var.enable_csp
  compliance_standards = var.compliance_standards

  create_default_catalog                                    = var.create_default_catalog
  default_catalog_storage_kms_key_arn                       = var.create_default_catalog ? module.example_default_catalog_storage_kms[0].key_arn : null
  default_catalog_storage_kms_key_alias                     = var.create_default_catalog ? "alias/${local.example_default_catalog_kms_alias_name}" : null
  default_catalog_owner                                     = var.default_catalog_owner
  default_catalog_properties                                = var.default_catalog_properties
  default_catalog_isolation_mode                            = var.default_catalog_isolation_mode
  default_catalog_permissions                               = var.default_catalog_permissions
  default_catalog_service_principal_app_ids                 = var.default_catalog_service_principal_app_ids
  default_catalog_unity_catalog_iam_arn                     = var.default_catalog_unity_catalog_iam_arn
  default_catalog_enable_file_events                        = var.default_catalog_enable_file_events
  default_catalog_file_events_sqs_message_retention_seconds = var.default_catalog_file_events_sqs_message_retention_seconds
  default_catalog_file_events_sqs_kms_key_id                = var.default_catalog_file_events_sqs_kms_key_id
  default_catalog_file_events_s3_events                     = var.default_catalog_file_events_s3_events
  default_catalog_file_events_s3_filter_prefix              = var.default_catalog_file_events_s3_filter_prefix
  default_catalog_file_events_s3_filter_suffix              = var.default_catalog_file_events_s3_filter_suffix

  # Explicit ordering: PAS and NLB / VPC endpoint service must exist before the
  # serverless module (workspace + optional NCC) when those stacks are enabled.
  # time_sleep runs a destroy-phase wait (see nlb_vpc_endpoint.tf) so Databricks
  # can drop interface endpoints before aws_vpc_endpoint_service is deleted.
  # Counted resources/modules with count = 0 are valid here (no-op dependency).
  # KMS ordering when enable_cmk is true is implicit (module inputs reference example_kms_*[0]).
  depends_on = [
    module.inbound_private_access_settings,
    module.nlb_vpc,
    aws_vpc_endpoint_service.ncc_nlb,
    time_sleep.nlb_endpoint_service_destroy_grace,
    module.example_default_catalog_storage_kms,
  ]
}

# -----------------------------------------------------------------------------
# Outputs
# -----------------------------------------------------------------------------
output "workspace_id" {
  description = "Created Databricks serverless workspace ID."
  value       = module.complete_workspace_serverless.workspace_id
}

output "workspace_url" {
  description = "Created Databricks workspace URL."
  value       = module.complete_workspace_serverless.workspace_url
}

output "private_access_settings_id" {
  description = "MWS private access settings ID attached to the workspace (created by this example when create_inbound_privatelink is true, else from var.private_access_settings_id)."
  value       = module.complete_workspace_serverless.private_access_settings_id
}

output "storage_configuration_id" {
  description = "Databricks account storage configuration ID."
  value       = module.complete_workspace_serverless.storage_configuration_id
}

output "managed_services_kms_key_arn" {
  description = "KMS key ARN for managed services CMK (passed through from module)."
  value       = module.complete_workspace_serverless.managed_services_kms_key_arn
}

output "workspace_storage_kms_key_arn" {
  description = "KMS key ARN for workspace storage CMK and S3 SSE (passed through from module)."
  value       = module.complete_workspace_serverless.workspace_storage_kms_key_arn
}

output "metastore_id" {
  description = "Assigned Unity Catalog metastore ID."
  value       = module.complete_workspace_serverless.metastore_id
}

output "network_connectivity_config_id" {
  description = "MWS Network Connectivity Config ID when enable_network_connectivity_config is true."
  value       = module.complete_workspace_serverless.network_connectivity_config_id
}

output "ncc_egress_config" {
  description = "Computed NCC egress rules when NCC is enabled."
  value       = module.complete_workspace_serverless.ncc_egress_config
}

output "ncc_nlb_private_endpoint_rule_id" {
  description = "NLB private endpoint rule ID when NLB variables are set and NCC is enabled."
  value       = module.complete_workspace_serverless.ncc_nlb_private_endpoint_rule_id
}

output "nlb_vpc_id" {
  description = "VPC ID for the internal NLB when create_internal_nlb_vpc_endpoint is true."
  value       = try(module.nlb_vpc[0].vpc_id, null)
}

output "internal_nlb_dns_name" {
  description = "DNS name of the internal NLB when create_internal_nlb_vpc_endpoint is true."
  value       = try(aws_lb.ncc_nlb[0].dns_name, null)
}

output "nlb_vpc_endpoint_service_name" {
  description = "AWS VPC endpoint service name for the NLB (passed to the Databricks NCC rule) when create_internal_nlb_vpc_endpoint is true."
  value       = try(aws_vpc_endpoint_service.ncc_nlb[0].service_name, null)
}

output "nlb_private_dns_fqdns" {
  description = "FQDNs used for the NCC private endpoint rule when the example creates Route53 records."
  value       = var.create_internal_nlb_vpc_endpoint ? local.nlb_domain_names_for_module : []
}

# -----------------------------------------------------------------------------
# Inbound PrivateLink (steps 1–3)
# -----------------------------------------------------------------------------
output "inbound_privatelink_private_access_settings_id" {
  description = "Private access settings ID created by mws-private-access-settings when create_inbound_privatelink is true (also passed to the serverless workspace)."
  value       = try(module.inbound_private_access_settings[0].private_access_settings_id, null)
}

output "inbound_privatelink_vpc_id" {
  description = "Transit VPC ID when create_inbound_privatelink is true."
  value       = try(module.inbound_privatelink_vpc[0].vpc_id, null)
}

output "inbound_privatelink_vpc_endpoint_id" {
  description = "AWS interface VPC endpoint ID for Databricks Workspace (REST API) when create_inbound_privatelink is true."
  value       = try(aws_vpc_endpoint.inbound_databricks_workspace[0].id, null)
}

output "inbound_privatelink_mws_vpc_endpoint_id" {
  description = "Databricks MWS VPC endpoint registration ID when create_inbound_privatelink is true."
  value       = try(databricks_mws_vpc_endpoint.inbound_workspace_api[0].vpc_endpoint_id, null)
}

output "inbound_privatelink_mws_vpc_endpoint_name" {
  description = "Databricks-registered name for the inbound workspace API endpoint."
  value       = try(databricks_mws_vpc_endpoint.inbound_workspace_api[0].vpc_endpoint_name, null)
}
