# =============================================================================
# Internal NLB + AWS VPC endpoint service (for Databricks NCC private endpoint rule)
# =============================================================================
# When create_internal_nlb_vpc_endpoint is true, creates a dedicated VPC, an
# internal network load balancer, exposes it via a VPC endpoint service, and
# (optionally) a Route53 private zone so api.<workspace>.internal resolves to
# the NLB. Values are passed into complete-workspace-serverless as NCC NLB vars.
#
# Databricks must be allowed to create an interface endpoint to your service:
# https://docs.databricks.com/aws/security/network/serverless-network-security/pl-to-internal-network
# =============================================================================

data "aws_availability_zones" "available" {
  state = "available"
}

locals {
  dns_safe_workspace = lower(replace(var.workspace_name, "_", "-"))

  ncc_enabled = var.enable_network_connectivity_config || var.create_internal_nlb_vpc_endpoint

  nlb_allowed_principals = coalesce(
    var.nlb_vpc_endpoint_allowed_principal_arns,
    [format("arn:aws:iam::565502421330:role/private-connectivity-role-%s", var.aws_region)]
  )

  nlb_service_name_for_module = length(aws_vpc_endpoint_service.ncc_nlb) > 0 ? aws_vpc_endpoint_service.ncc_nlb[0].service_name : var.ncc_nlb_vpc_endpoint_service_name

  nlb_domain_names_for_module = var.create_internal_nlb_vpc_endpoint ? (
    length(var.ncc_nlb_domain_names) > 0 ? var.ncc_nlb_domain_names : [format("api.%s.internal", local.dns_safe_workspace)]
  ) : var.ncc_nlb_domain_names
}

module "nlb_vpc" {
  source  = "terraform-aws-modules/vpc/aws"
  version = "~> 5.0"
  count   = var.create_internal_nlb_vpc_endpoint ? 1 : 0

  name = substr(replace("${var.name_prefix}-${local.dns_safe_workspace}-nlb", "_", "-"), 0, 32)
  cidr = var.nlb_vpc_cidr

  azs             = slice(data.aws_availability_zones.available.names, 0, 2)
  private_subnets = [cidrsubnet(var.nlb_vpc_cidr, 8, 1), cidrsubnet(var.nlb_vpc_cidr, 8, 2)]
  public_subnets  = [cidrsubnet(var.nlb_vpc_cidr, 8, 101), cidrsubnet(var.nlb_vpc_cidr, 8, 102)]

  enable_nat_gateway   = true
  single_nat_gateway   = true
  enable_dns_hostnames = true
  enable_dns_support   = true

  tags = {
    Name        = "${var.name_prefix}-nlb-vpc"
    Environment = "example"
    ManagedBy   = "Terraform"
  }
}

resource "aws_lb" "ncc_nlb" {
  count = var.create_internal_nlb_vpc_endpoint ? 1 : 0

  name                             = substr(replace("${var.name_prefix}-${local.dns_safe_workspace}-nl", "_", "-"), 0, 32)
  internal                         = true
  load_balancer_type               = "network"
  subnets                          = module.nlb_vpc[0].private_subnets
  enable_cross_zone_load_balancing = true

  tags = {
    Name        = "${var.name_prefix}-ncc-nlb"
    Environment = "example"
    ManagedBy   = "Terraform"
  }
}

resource "aws_lb_target_group" "ncc_nlb" {
  count = var.create_internal_nlb_vpc_endpoint ? 1 : 0

  name        = substr(replace("${var.name_prefix}-${local.dns_safe_workspace}-tg", "_", "-"), 0, 32)
  port        = 443
  protocol    = "TCP"
  vpc_id      = module.nlb_vpc[0].vpc_id
  target_type = "ip"

  health_check {
    enabled             = true
    healthy_threshold   = 2
    interval            = 30
    protocol            = "TCP"
    unhealthy_threshold = 2
  }

  tags = {
    Name        = "${var.name_prefix}-ncc-nlb-tg"
    Environment = "example"
    ManagedBy   = "Terraform"
  }
}

resource "aws_lb_listener" "ncc_nlb" {
  count = var.create_internal_nlb_vpc_endpoint ? 1 : 0

  load_balancer_arn = aws_lb.ncc_nlb[0].arn
  port              = "443"
  protocol          = "TCP"

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.ncc_nlb[0].arn
  }
}

resource "aws_vpc_endpoint_service" "ncc_nlb" {
  count = var.create_internal_nlb_vpc_endpoint ? 1 : 0

  acceptance_required        = false
  network_load_balancer_arns = [aws_lb.ncc_nlb[0].arn]
  allowed_principals         = local.nlb_allowed_principals

  tags = {
    Name        = "${var.name_prefix}-ncc-nlb-vpce-svc"
    Environment = "example"
    ManagedBy   = "Terraform"
  }
}

# After the serverless module (NCC rule + binding) is destroyed, Databricks
# removes its interface VPC endpoint to this service asynchronously. Terraform
# would otherwise delete aws_vpc_endpoint_service immediately and hit
# ExistingVpcEndpointConnections. This resource sleeps only during destroy, after
# complete_workspace_serverless is gone but before the endpoint service (time_sleep
# depends on the service; the module depends on time_sleep, so destroy order is:
# module -> sleep -> service).
resource "time_sleep" "nlb_endpoint_service_destroy_grace" {
  create_duration  = "0s"
  destroy_duration = var.create_internal_nlb_vpc_endpoint ? var.nlb_vpc_endpoint_service_destroy_wait_duration : "0s"

  depends_on = [aws_vpc_endpoint_service.ncc_nlb]
}

resource "aws_route53_zone" "nlb_private" {
  count = var.create_internal_nlb_vpc_endpoint ? 1 : 0

  name = "${local.dns_safe_workspace}.internal"

  vpc {
    vpc_id = module.nlb_vpc[0].vpc_id
  }

  tags = {
    Name        = "${var.name_prefix}-ncc-nlb-dns"
    Environment = "example"
    ManagedBy   = "Terraform"
  }
}

resource "aws_route53_record" "nlb_api" {
  count = var.create_internal_nlb_vpc_endpoint ? 1 : 0

  zone_id = aws_route53_zone.nlb_private[0].zone_id
  name    = "api"
  type    = "A"

  alias {
    name                   = aws_lb.ncc_nlb[0].dns_name
    zone_id                = aws_lb.ncc_nlb[0].zone_id
    evaluate_target_health = true
  }
}
