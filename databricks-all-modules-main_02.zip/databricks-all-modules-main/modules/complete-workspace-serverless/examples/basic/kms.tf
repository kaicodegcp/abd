data "aws_partition" "current" {}

locals {
  databricks_aws_account_id = "414351767826"
  cmk_admin_arn             = "arn:${data.aws_partition.current.partition}:iam::${data.aws_caller_identity.current.account_id}:root"
}

module "example_kms_managed_services" {
  source  = "terraform-aws-modules/kms/aws"
  version = "~> 3.0"
  count   = var.enable_cmk ? 1 : 0

  description = "Example: Databricks managed services CMK for serverless workspace"
  key_usage   = "ENCRYPT_DECRYPT"

  key_statements = [
    {
      sid    = "Enable IAM User Permissions"
      effect = "Allow"
      principals = [
        {
          type        = "AWS"
          identifiers = [local.cmk_admin_arn]
        }
      ]
      actions   = ["kms:*"]
      resources = ["*"]
    },
    {
      sid    = "Allow Databricks to use KMS key for managed services"
      effect = "Allow"
      principals = [
        {
          type        = "AWS"
          identifiers = ["arn:${data.aws_partition.current.partition}:iam::${local.databricks_aws_account_id}:root"]
        }
      ]
      actions = [
        "kms:Encrypt",
        "kms:Decrypt"
      ]
      resources = ["*"]
      conditions = [
        {
          test     = "StringEquals"
          variable = "aws:PrincipalTag/DatabricksAccountId"
          values   = [var.databricks_account_id]
        }
      ]
    }
  ]

  tags = {
    Name        = "example-serverless-managed-services-cmk"
    Environment = "example"
    ManagedBy   = "Terraform"
  }
}

module "example_kms_workspace_storage" {
  source  = "terraform-aws-modules/kms/aws"
  version = "~> 3.0"
  count   = var.enable_cmk ? 1 : 0

  description = "Example: Databricks workspace root storage CMK for serverless workspace"
  key_usage   = "ENCRYPT_DECRYPT"

  key_statements = [
    {
      sid    = "Enable IAM User Permissions"
      effect = "Allow"
      principals = [
        {
          type        = "AWS"
          identifiers = [local.cmk_admin_arn]
        }
      ]
      actions   = ["kms:*"]
      resources = ["*"]
    },
    {
      sid    = "Allow Databricks to use KMS key for DBFS"
      effect = "Allow"
      principals = [
        {
          type        = "AWS"
          identifiers = ["arn:${data.aws_partition.current.partition}:iam::${local.databricks_aws_account_id}:root"]
        }
      ]
      actions = [
        "kms:Encrypt",
        "kms:Decrypt",
        "kms:ReEncrypt*",
        "kms:GenerateDataKey*",
        "kms:DescribeKey"
      ]
      resources = ["*"]
      conditions = [
        {
          test     = "StringEquals"
          variable = "aws:PrincipalTag/DatabricksAccountId"
          values   = [var.databricks_account_id]
        }
      ]
    }
  ]

  tags = {
    Name        = "example-serverless-workspace-storage-cmk"
    Environment = "example"
    ManagedBy   = "Terraform"
  }
}
