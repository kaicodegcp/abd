terraform {
  required_version = ">= 1.5.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 5.0"
    }
    databricks = {
      source                = "databricks/databricks"
      version               = ">= 1.117.0, <= 1.128.0"
      configuration_aliases = [databricks.mws, databricks.workspace]
    }
  }
}
