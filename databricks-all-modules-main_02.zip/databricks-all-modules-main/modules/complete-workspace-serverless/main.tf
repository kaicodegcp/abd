data "aws_partition" "current" {}

# Root storage bucket (terraform-aws-modules/s3-bucket). SSE-KMS + databricks_mws_customer_managed_keys when
# enable_cmk is true; SSE-S3 (AES256) and no CMK registration when enable_cmk is false (same idea as complete-workspace-custom).
module "s3_bucket" {
  source  = "terraform-aws-modules/s3-bucket/aws"
  version = "~> 4.0"

  bucket = var.workspace_root_bucket_name

  force_destroy       = var.force_destroy_buckets
  acceleration_status = "Suspended"

  versioning = {
    enabled = true
  }

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true

  control_object_ownership = true
  object_ownership         = "BucketOwnerPreferred"

  server_side_encryption_configuration = {
    rule = {
      apply_server_side_encryption_by_default = {
        sse_algorithm     = var.enable_cmk ? "aws:kms" : "AES256"
        kms_master_key_id = var.enable_cmk ? var.workspace_storage_kms_key_arn : null
      }
      bucket_key_enabled = var.enable_cmk
    }
  }

  attach_policy = true
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "GrantDatabricksAccess"
        Effect = "Allow"
        Principal = {
          AWS = "arn:${data.aws_partition.current.partition}:iam::${var.databricks_aws_account_id}:root"
        }
        Action = [
          "s3:GetObject",
          "s3:GetObjectVersion",
          "s3:PutObject",
          "s3:DeleteObject",
          "s3:ListBucket",
          "s3:GetBucketLocation",
        ]
        Resource = [
          "arn:${data.aws_partition.current.partition}:s3:::${var.workspace_root_bucket_name}/*",
          "arn:${data.aws_partition.current.partition}:s3:::${var.workspace_root_bucket_name}",
        ]
        Condition = {
          StringEquals = {
            "aws:PrincipalTag/DatabricksAccountId" = var.databricks_account_id
          }
        }
      },
      {
        Sid    = "PreventDBFSFromAccessingUnityCatalogMetastore"
        Effect = "Deny"
        Principal = {
          AWS = "arn:${data.aws_partition.current.partition}:iam::${var.databricks_aws_account_id}:root"
        }
        Action = [
          "s3:*",
        ]
        Resource = [
          "arn:${data.aws_partition.current.partition}:s3:::${var.workspace_root_bucket_name}/unity-catalog/*",
        ]
      }
    ]
  })

  tags = {
    Name    = "Databricks Workspace Storage"
    Purpose = "Databricks Root Storage"
  }
}

resource "databricks_mws_storage_configurations" "this" {
  provider = databricks.mws

  account_id                 = var.databricks_account_id
  storage_configuration_name = "${var.name_prefix}-mws-storage"
  bucket_name                = module.s3_bucket.s3_bucket_id
}

resource "databricks_mws_customer_managed_keys" "managed_services" {
  provider = databricks.mws
  count    = var.enable_cmk ? 1 : 0

  account_id = var.databricks_account_id
  use_cases  = ["MANAGED_SERVICES"]

  aws_key_info {
    key_arn   = var.managed_services_kms_key_arn
    key_alias = var.managed_services_kms_key_alias
  }

  lifecycle {
    precondition {
      condition     = !var.enable_cmk || (var.managed_services_kms_key_arn != null && var.managed_services_kms_key_alias != null)
      error_message = "When enable_cmk is true, managed_services_kms_key_arn and managed_services_kms_key_alias must be set."
    }
  }
}

resource "databricks_mws_customer_managed_keys" "storage" {
  provider = databricks.mws
  count    = var.enable_cmk ? 1 : 0

  account_id = var.databricks_account_id
  use_cases  = ["STORAGE"]

  aws_key_info {
    key_arn   = var.workspace_storage_kms_key_arn
    key_alias = var.workspace_storage_kms_key_alias
  }

  lifecycle {
    precondition {
      condition     = !var.enable_cmk || (var.workspace_storage_kms_key_arn != null && var.workspace_storage_kms_key_alias != null)
      error_message = "When enable_cmk is true, workspace_storage_kms_key_arn and workspace_storage_kms_key_alias must be set."
    }
  }
}

resource "databricks_mws_workspaces" "this" {
  provider = databricks.mws

  account_id                               = var.databricks_account_id
  workspace_name                           = var.workspace_name
  aws_region                               = var.aws_region
  deployment_name                          = var.deployment_name
  storage_configuration_id                 = databricks_mws_storage_configurations.this.storage_configuration_id
  storage_customer_managed_key_id          = var.enable_cmk ? databricks_mws_customer_managed_keys.storage[0].customer_managed_key_id : null
  managed_services_customer_managed_key_id = var.enable_cmk ? databricks_mws_customer_managed_keys.managed_services[0].customer_managed_key_id : null
  compute_mode                             = "SERVERLESS"
  private_access_settings_id               = var.private_access_settings_id

  # CMK resources are ordered implicitly when enable_cmk is true (workspace references their IDs).
  # NCC: workspace depends on the NCC module so destroy removes the workspace before NCC resources
  # (reverse of create order). When count = 0 the module dependency is a no-op.
  depends_on = [
    module.s3_bucket,
    module.network_connectivity_config,
  ]

  lifecycle {
    precondition {
      condition     = !var.enable_cmk || (var.managed_services_kms_key_arn != null && var.workspace_storage_kms_key_arn != null && var.managed_services_kms_key_alias != null && var.workspace_storage_kms_key_alias != null)
      error_message = "When enable_cmk is true, set managed_services_kms_key_arn, workspace_storage_kms_key_arn, managed_services_kms_key_alias, and workspace_storage_kms_key_alias."
    }
  }
}

# =============================================================================
# Network Connectivity Configuration (optional) — serverless egress / private endpoints
# =============================================================================

module "network_connectivity_config" {
  count = var.enable_network_connectivity_config ? 1 : 0

  source = "../mws-network-connectivity-config"

  providers = {
    databricks = databricks.mws
  }

  name   = "${var.name_prefix}-ncc"
  region = var.aws_region

  nlb_vpc_endpoint_service_name = var.ncc_nlb_vpc_endpoint_service_name
  nlb_domain_names              = var.ncc_nlb_domain_names
}

resource "databricks_mws_ncc_binding" "this" {
  provider = databricks.mws
  count    = var.enable_network_connectivity_config ? 1 : 0

  network_connectivity_config_id = module.network_connectivity_config[0].network_connectivity_config_id
  workspace_id                   = databricks_mws_workspaces.this.workspace_id

  depends_on = [
    databricks_mws_workspaces.this,
    module.network_connectivity_config,
  ]
}

# =============================================================================
# Account Network Policy
# =============================================================================
module "account_network_policy" {
  source = "../account-network-policy"
  count  = var.enable_account_network_policy ? 1 : 0

  providers = {
    databricks = databricks.mws
  }

  network_policy_id          = "${var.name_prefix}-np"
  workspace_id               = databricks_mws_workspaces.this.workspace_id
  existing_network_policy_id = var.existing_network_policy_id

  egress = {
    network_access = {
      restriction_mode              = "RESTRICTED_ACCESS"
      allowed_internet_destinations = var.network_policy_allowed_internet_destinations
      allowed_storage_destinations  = var.network_policy_allowed_storage_destinations
      policy_enforcement = {
        enforcement_mode = "ENFORCED"
      }
    }
  }

  ingress_public_access          = var.network_policy_public_access
  ingress_private_access         = var.network_policy_private_access
  ingress_cross_workspace_access = var.network_policy_cross_workspace_access

  depends_on = [databricks_mws_workspaces.this]
}

data "databricks_metastore" "existing" {
  provider = databricks.mws

  name = var.existing_metastore_name

  depends_on = [databricks_mws_workspaces.this]
}

resource "databricks_metastore_assignment" "this" {
  provider = databricks.mws

  workspace_id = databricks_mws_workspaces.this.workspace_id
  metastore_id = data.databricks_metastore.existing.metastore_id
}

check "default_catalog_storage_kms_inputs" {
  assert {
    condition = !var.create_default_catalog || (
      var.default_catalog_storage_kms_key_arn != null &&
      var.default_catalog_storage_kms_key_alias != null &&
      trimspace(var.default_catalog_storage_kms_key_arn) != "" &&
      trimspace(var.default_catalog_storage_kms_key_alias) != ""
    )
    error_message = "When create_default_catalog is true, set default_catalog_storage_kms_key_arn and default_catalog_storage_kms_key_alias (caller-managed CMK for catalog root storage)."
  }
}

check "default_catalog_file_events_iam" {
  assert {
    condition     = !var.create_default_catalog || var.default_catalog_enable_file_events
    error_message = "When create_default_catalog is true, set default_catalog_enable_file_events = true. With file events disabled, catalog-creation uses an empty inline IAM policy on the UC storage role, which AWS rejects."
  }
}

# =============================================================================
# Optional Unity Catalog managed catalog (catalog-creation) — same as complete-workspace-custom
# =============================================================================
# NOTE: This legacy SE composition predates the current permission framework and
# no longer provisions schemas through catalog-creation. Schemas and schema-scoped
# privileges must be provisioned separately through modules/schema; catalog-level
# USE_CATALOG access is managed through catalog-creation.permissions.
# =============================================================================

module "default_catalog" {
  count  = var.create_default_catalog ? 1 : 0
  source = "../catalog-creation"

  providers = {
    databricks = databricks.workspace
  }

  workspace_id = databricks_mws_workspaces.this.workspace_id
  name_prefix  = var.workspace_name

  aws_partition = data.aws_partition.current.partition

  catalog_storage_kms_key_arn   = var.default_catalog_storage_kms_key_arn
  catalog_storage_kms_key_alias = var.default_catalog_storage_kms_key_alias

  unity_catalog_iam_arn = coalesce(
    var.default_catalog_unity_catalog_iam_arn,
    "arn:aws:iam::414351767826:role/unity-catalog-prod-UCMasterRole-14S5ZJVKOTYTL"
  )

  catalog_owner          = var.default_catalog_owner
  catalog_properties     = var.default_catalog_properties
  catalog_isolation_mode = var.default_catalog_isolation_mode

  permissions                          = var.default_catalog_permissions
  databricks_service_principal_app_ids = var.default_catalog_service_principal_app_ids

  force_destroy = var.force_destroy_buckets
  tags          = var.tags

  enable_catalog_file_events                        = var.default_catalog_enable_file_events
  catalog_file_events_sqs_message_retention_seconds = var.default_catalog_file_events_sqs_message_retention_seconds
  catalog_file_events_sqs_kms_key_id                = var.default_catalog_file_events_sqs_kms_key_id
  catalog_file_events_s3_events                     = var.default_catalog_file_events_s3_events
  catalog_file_events_s3_filter_prefix              = var.default_catalog_file_events_s3_filter_prefix
  catalog_file_events_s3_filter_suffix              = var.default_catalog_file_events_s3_filter_suffix

  depends_on = [databricks_metastore_assignment.this]
}

# =============================================================================
# Workspace security (workspace-conf) — same as complete-workspace-custom
# =============================================================================

module "workspace_security" {
  source = "../workspace-conf"
  providers = {
    databricks = databricks.workspace
  }
  count = var.configure_workspace_security ? 1 : 0

  disable_legacy_access                              = true
  disable_legacy_dbfs                                = true
  enable_results_downloading                         = false
  enable_notebook_table_clipboard                    = false
  enable_export_notebook                             = false
  aibi_dashboard_embedding_approved_domains          = []
  aibi_dashboard_embedding_access_policy             = "DENY_ALL_DOMAINS"
  restrict_workspace_admins_status                   = "RESTRICT_TOKENS_AND_JOB_RUN_AS"
  restrict_workspace_admins_disable_gov_tag_creation = true
  enable_verbose_audit_logs                          = true
  enable_dbfs_file_browser                           = false
  enforce_user_isolation                             = true
  store_results_in_customer_account                  = true
  enable_upload_data_uis                             = false
  enable_ip_access_lists                             = true
  enable_web_terminal                                = false
  max_token_lifetime_days                            = 90
  enable_notebook_results_downloading                = false
  enable_tokens_config                               = false
  enable_projects_allow_list                         = false
  projects_allow_list_permissions                    = null
  projects_allow_list                                = null
  enable_project_type_in_workspace                   = false
  customer_approved_ws_login_expiration_time         = "1998-01-01T00:00:00.000Z"
  uc_volumes_download_ui                             = false
  additional_workspace_config                        = {}
}

# =============================================================================
# Compliance Security Profile (CSP)
# =============================================================================

resource "databricks_compliance_security_profile_workspace_setting" "this" {
  provider = databricks.workspace
  count    = var.enable_csp ? 1 : 0

  compliance_security_profile_workspace {
    is_enabled = true
    # API requires at least one standard when CSP is enabled; default if unset/empty.
    compliance_standards = length(coalesce(var.compliance_standards, [])) > 0 ? coalesce(var.compliance_standards, []) : ["HIPAA"]
  }
}
