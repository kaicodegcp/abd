output "id" {
  description = "Alias for policy_id (consistent with other modules)"
  value       = databricks_budget_policy.this.policy_id
}

output "policy_id" {
  description = "Server-generated budget policy ID"
  value       = databricks_budget_policy.this.policy_id
}

output "policy_name" {
  description = "Budget policy name (same as policy_name input)"
  value       = var.policy_name
}
