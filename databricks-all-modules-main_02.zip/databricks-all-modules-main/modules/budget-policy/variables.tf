variable "policy_name" {
  description = "Budget policy name (unique among active policies; latin1; cannot start with reserved prefixes such as databricks:default-policy)"
  type        = string
}

variable "custom_tags" {
  description = "Tags applied to serverless compute for chargeback (keys cannot be budget-policy-name, budget-policy-id, or budget-policy-resolution-result)"
  type = list(object({
    key   = string
    value = optional(string)
  }))
}

variable "binding_workspace_ids" {
  description = "Optional workspace numeric IDs to scope the policy; omit for account-wide availability"
  type        = list(number)
  default     = null
}
