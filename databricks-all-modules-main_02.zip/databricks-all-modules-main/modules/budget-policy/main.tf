# Serverless budget policy (account-level API).
# Configure the databricks provider with account host + account_id — see:
# https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/budget_policy

resource "databricks_budget_policy" "this" {
  policy_name             = var.policy_name
  custom_tags             = var.custom_tags
  binding_workspace_ids   = var.binding_workspace_ids
}
