# =============================================================================
# Databricks Managed DR - Failover Group
# =============================================================================
# A failover group is the unit of replication: a set of workspaces that mirror
# each other across regions, plus (optionally) the Unity Catalog assets that
# replicate with them.
#
# Terraform owns the TOPOLOGY of the group. It does NOT trigger failover -
# that is an explicit API/console action:
#
#   databricks account disaster-recovery failover-failover-group \
#     accounts/{account_id}/failover-groups/{id} {target_region} FORCED --etag {etag}
#
# Requires the ACCOUNT-level provider (host = accounts.cloud.databricks.com).
#
# Catalogs with ABAC policies, row filters or column masks are not supported
# and will hold up RPO for the whole group. Only include RBAC-only catalogs.
# =============================================================================

locals {
  workspace_set_names = [for ws in var.workspace_sets : ws.name]

  location_mappings = (
    var.unity_catalog_assets == null
    ? []
    : coalesce(var.unity_catalog_assets.location_mappings, [])
  )

  # Mappings that fail to provide a URI for every participating region. A
  # partial mapping is accepted by the API but only surfaces mid-failover,
  # when the uncovered region has nowhere to resolve the location to.
  incomplete_mappings = [
    for m in local.location_mappings : m.name
    if length(setsubtract(
      toset(var.regions),
      toset([for u in m.uri_by_region : u.region])
    )) > 0
  ]

  # Workspace sets that do not carry exactly one workspace per region.
  malformed_sets = [
    for ws in var.workspace_sets : ws.name
    if length(ws.workspace_ids) != length(var.regions)
  ]
}

resource "databricks_disaster_recovery_failover_group" "this" {
  parent            = var.parent
  failover_group_id = var.failover_group_id
  regions           = var.regions

  # Write-only: consumed on create, never returned by the API. After a real
  # failover, effective_primary_region diverges from this value. That is
  # expected. Editing this to "match reality" can force a destroy/recreate of
  # the group and tear down replication for every catalog in it.
  initial_primary_region = var.initial_primary_region

  workspace_sets = var.workspace_sets

  unity_catalog_assets = var.unity_catalog_assets

  lifecycle {
    ignore_changes = [initial_primary_region]

    precondition {
      condition     = contains(var.regions, var.initial_primary_region)
      error_message = "initial_primary_region (${var.initial_primary_region}) must be one of the participating regions: ${join(", ", var.regions)}."
    }

    precondition {
      condition     = length(local.malformed_sets) == 0
      error_message = "Each workspace set must contain exactly one workspace per participating region (${length(var.regions)} expected). Non-conforming sets: ${join(", ", local.malformed_sets)}."
    }

    precondition {
      condition = (
        var.unity_catalog_assets == null ||
        contains(local.workspace_set_names, var.unity_catalog_assets.data_replication_workspace_set)
      )
      error_message = "unity_catalog_assets.data_replication_workspace_set must name one of the declared workspace sets: ${join(", ", local.workspace_set_names)}."
    }

    precondition {
      condition     = length(local.incomplete_mappings) == 0
      error_message = "Every location mapping must provide a URI for all participating regions (${join(", ", var.regions)}). Incomplete mappings: ${join(", ", local.incomplete_mappings)}."
    }
  }
}
