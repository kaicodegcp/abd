output "name" {
  description = "Fully qualified resource name, accounts/{account_id}/failover-groups/{failover_group_id}. This is the NAME argument for the failover CLI/API call."
  value       = databricks_disaster_recovery_failover_group.this.name
}

output "effective_primary_region" {
  description = "The region currently acting as primary. Diverges from initial_primary_region after a failover; this output is the source of truth, not the input variable."
  value       = databricks_disaster_recovery_failover_group.this.effective_primary_region
}

output "state" {
  description = "Replication state of the group, e.g. INITIAL_REPLICATION or ACTIVE."
  value       = databricks_disaster_recovery_failover_group.this.state
}

output "replication_point" {
  description = "The point up to which data has been replicated. Drives measured RPO."
  value       = databricks_disaster_recovery_failover_group.this.replication_point
}

output "etag" {
  description = "Opaque version string for optimistic locking. Required by the failover API call."
  value       = databricks_disaster_recovery_failover_group.this.etag
}

output "create_time" {
  description = "Creation timestamp of the failover group"
  value       = databricks_disaster_recovery_failover_group.this.create_time
}

output "update_time" {
  description = "Last update timestamp of the failover group"
  value       = databricks_disaster_recovery_failover_group.this.update_time
}
