variable "parent" {
  description = "Parent resource for the failover group. Format: accounts/{account_id}."
  type        = string

  validation {
    condition     = can(regex("^accounts/[0-9a-fA-F-]{36}$", var.parent))
    error_message = "parent must be of the form accounts/{account_id}, where account_id is a 36-character UUID."
  }
}

variable "failover_group_id" {
  description = "Client-provided identifier for the failover group. Becomes part of the immutable resource name {parent}/failover-groups/{failover_group_id}; changing it destroys and recreates the group."
  type        = string

  validation {
    condition     = can(regex("^[a-z0-9][a-z0-9-]{1,62}[a-z0-9]$", var.failover_group_id))
    error_message = "failover_group_id must be 3-64 characters, lowercase alphanumeric or hyphen, and must not start or end with a hyphen."
  }
}

variable "regions" {
  description = "All regions participating in this failover group."
  type        = list(string)

  validation {
    condition     = length(var.regions) >= 2
    error_message = "A failover group needs at least two regions."
  }

  validation {
    condition     = length(distinct(var.regions)) == length(var.regions)
    error_message = "regions must not contain duplicates."
  }
}

variable "initial_primary_region" {
  description = "Region that starts as primary. Write-only: consumed on create and never returned by the API. After a failover the live value is reported by the effective_primary_region output; do not edit this to match it."
  type        = string
}

variable "workspace_sets" {
  description = "Workspace sets, each a group of workspaces that replicate to each other. Provide exactly one workspace per participating region."
  type = list(object({
    name                       = string
    workspace_ids              = list(string)
    replicate_workspace_assets = optional(bool)
    stable_url_names           = optional(list(string))
  }))

  validation {
    condition     = length(var.workspace_sets) >= 1
    error_message = "At least one workspace set is required."
  }

  validation {
    condition     = length(distinct([for ws in var.workspace_sets : ws.name])) == length(var.workspace_sets)
    error_message = "workspace_sets[].name must be unique within the group."
  }

  validation {
    condition = alltrue([
      for ws in var.workspace_sets : alltrue([
        for id in ws.workspace_ids : can(regex("^[0-9]+$", id))
      ])
    ])
    error_message = "workspace_ids must be numeric workspace IDs expressed as strings, e.g. [\"1234567890123456\"]."
  }

  validation {
    condition = alltrue([
      for ws in var.workspace_sets :
      length(distinct(ws.workspace_ids)) == length(ws.workspace_ids)
    ])
    error_message = "workspace_ids must not contain duplicates within a workspace set."
  }
}

variable "unity_catalog_assets" {
  description = "Unity Catalog assets to replicate with this group. Omit for workspace-asset-only DR. Catalogs must be RBAC-only: ABAC policies, row filters and column masks are unsupported and hold up RPO for the whole group."
  type = object({
    catalogs                       = list(object({ name = string }))
    data_replication_workspace_set = string
    location_mappings = optional(list(object({
      name = string
      uri_by_region = list(object({
        region = string
        uri    = string
      }))
    })))
  })
  default = null

  validation {
    condition     = var.unity_catalog_assets == null || length(var.unity_catalog_assets.catalogs) <= 10
    error_message = "A failover group supports at most 10 catalogs. Split larger scopes across multiple groups."
  }

  validation {
    condition     = var.unity_catalog_assets == null || length(var.unity_catalog_assets.catalogs) >= 1
    error_message = "unity_catalog_assets requires at least one catalog. Omit the block entirely for workspace-asset-only DR."
  }

  validation {
    condition = var.unity_catalog_assets == null || length(distinct([
      for c in var.unity_catalog_assets.catalogs : c.name
    ])) == length(var.unity_catalog_assets.catalogs)
    error_message = "Catalog names must be unique within a failover group."
  }
}
