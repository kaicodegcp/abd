# =============================================================================
# dr-failover-group - basic example: the raw failover group resource. Most
# roots should use the ../dr wrapper instead; this shows the full shape.
# =============================================================================

terraform {
  required_version = ">= 1.5"
  required_providers {
    databricks = {
      source  = "databricks/databricks"
      version = ">= 1.125.0, < 2.0.0"
    }
  }
}

variable "databricks_account_id" {
  type    = string
  default = "00000000-0000-0000-0000-000000000000"
}

provider "databricks" {
  host       = "https://accounts.cloud.databricks.com"
  account_id = var.databricks_account_id
}

module "failover_group" {
  source = "../.."

  parent            = "accounts/${var.databricks_account_id}"
  failover_group_id = "acme-drg"
  regions           = ["us-east-1", "us-east-2"]

  # Write-only: consumed on create, never edited to match reality afterwards.
  initial_primary_region = "us-east-1"

  workspace_sets = [{
    name                       = "acme-drg-ws"
    workspace_ids              = ["1111111111111111", "2222222222222222"]
    replicate_workspace_assets = true
  }]

  unity_catalog_assets = {
    catalogs                       = [{ name = "acme_catalog" }]
    data_replication_workspace_set = "acme-drg-ws"
    location_mappings = [{
      name = "acme-catalog-location"
      uri_by_region = [
        { region = "us-east-1", uri = "s3://acme-catalog/" },
        { region = "us-east-2", uri = "s3://acme-catalog-dr/" },
      ]
    }]
  }
}
