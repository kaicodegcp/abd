package test

import (
	"fmt"
	"testing"

	common "github.com/sandbox45/databricks-all-modules/common"
)

// These tests are plan-only. The failover group is an account-level resource,
// so DATABRICKS_HOST must point at the ACCOUNT host
// (https://accounts.cloud.databricks.com), not a workspace URL.
//
// No workspaces are required: workspace_ids are opaque strings at plan time,
// so placeholder IDs plan cleanly.

func drRegions() []string {
	return []string{"us-east-1", "us-west-2"}
}

// Workspace-asset-only DR: no Unity Catalog assets in scope.
func TestDRFailoverGroupModule(t *testing.T) {
	defaults := common.GetTestDefaults()

	config := common.ModuleTestConfig{
		ModuleName:      "dr-failover-group",
		TestDescription: "Tests the Managed DR failover group module (workspace assets only)",
		RequiredVars: map[string]interface{}{
			"parent":                 fmt.Sprintf("accounts/%s", defaults.AccountID),
			"failover_group_id":      "plan-only-failover-group",
			"regions":                drRegions(),
			"initial_primary_region": "us-east-1",
			"workspace_sets": []map[string]interface{}{
				{
					"name":                       "plan-only-ws",
					"workspace_ids":              []string{"1234567890123456", "6543210987654321"},
					"replicate_workspace_assets": true,
				},
			},
		},
		ExpectedOutputs: []string{
			"name",
			"effective_primary_region",
			"state",
			"etag",
		},
	}

	common.TestModuleWithConfig(t, config)
}

// Full Tier-1 shape: catalogs plus location mappings covering every region.
func TestDRFailoverGroupModuleWithUnityCatalogAssets(t *testing.T) {
	defaults := common.GetTestDefaults()

	config := common.ModuleTestConfig{
		ModuleName:      "dr-failover-group",
		TestDescription: "Tests the Managed DR failover group module with Unity Catalog assets and location mappings",
		RequiredVars: map[string]interface{}{
			"parent":                 fmt.Sprintf("accounts/%s", defaults.AccountID),
			"failover_group_id":      "plan-only-failover-group-uc",
			"regions":                drRegions(),
			"initial_primary_region": "us-east-1",
			"workspace_sets": []map[string]interface{}{
				{
					"name":                       "plan-only-ws",
					"workspace_ids":              []string{"1234567890123456", "6543210987654321"},
					"replicate_workspace_assets": true,
				},
			},
		},
		OptionalVars: map[string]interface{}{
			"unity_catalog_assets": map[string]interface{}{
				"catalogs": []map[string]interface{}{
					{"name": "plan_only_tier1_catalog"},
				},
				"data_replication_workspace_set": "plan-only-ws",
				"location_mappings": []map[string]interface{}{
					{
						"name": "plan-only-location",
						"uri_by_region": []map[string]interface{}{
							{"region": "us-east-1", "uri": "s3://plan-only-primary/data"},
							{"region": "us-west-2", "uri": "s3://plan-only-secondary/data"},
						},
					},
				},
			},
		},
		ExpectedOutputs: []string{
			"name",
			"effective_primary_region",
			"state",
			"replication_point",
		},
	}

	common.TestModuleWithConfig(t, config)
}
