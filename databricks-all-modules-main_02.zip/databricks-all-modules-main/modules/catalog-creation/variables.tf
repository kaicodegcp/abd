# =============================================================================
# Unity Catalog: Catalog + Schema Creation Module - Variables
# =============================================================================
# Creates S3 bucket (SSE-KMS), IAM role, storage credential, external location,
# and catalog with optional catalog-level grants. Caller provides the catalog
# storage KMS key ARN and alias. Workspace must already have a metastore assigned.
# =============================================================================

variable "workspace_id" {
  description = "Databricks workspace ID (used in naming and catalog comment)"
  type        = string
}

variable "name_prefix" {
  description = "Prefix for resource names (e.g. workspace name). Used to build bucket/role/catalog names as name_prefix-catalog-workspace_id"
  type        = string
}

variable "aws_partition" {
  description = "AWS partition (aws or aws-us-gov)"
  type        = string
  default     = "aws"
}

variable "catalog_storage_kms_key_arn" {
  description = "ARN of the customer-managed KMS key for Unity Catalog root storage (S3 SSE-KMS and Databricks UC IAM policy)."
  type        = string
}

variable "catalog_storage_kms_key_alias" {
  description = "KMS key alias in alias/name form (e.g. alias/my-catalog-key). Exposed on module output for callers; S3 and UC IAM policy use catalog_storage_kms_key_arn."
  type        = string
}

variable "unity_catalog_iam_arn" {
  description = "Databricks Unity Catalog master role ARN for IAM trust policy"
  type        = string
  default     = "arn:aws:iam::414351767826:role/unity-catalog-prod-UCMasterRole-14S5ZJVKOTYTL"
}

variable "catalog_owner" {
  description = "Owner of the catalog"
  type        = string
  default     = "account users"
}

variable "catalog_properties" {
  description = "Properties for the catalog"
  type        = map(string)
  default     = {}
}

variable "catalog_isolation_mode" {
  description = "Catalog isolation mode (ISOLATED or OPEN)"
  type        = string
  default     = "ISOLATED"

  validation {
    condition     = contains(["ISOLATED", "OPEN"], var.catalog_isolation_mode)
    error_message = "Catalog isolation mode must be ISOLATED or OPEN."
  }
}

variable "force_destroy" {
  description = "Allow force destroy of catalog and schema resources"
  type        = bool
  default     = false
}

# =============================================================================
# Unity Catalog file events (optional SQS + S3 notifications)
# =============================================================================
variable "enable_catalog_file_events" {
  description = "When true, creates an SQS queue, S3 bucket notifications for object events, and configures the catalog external location with file_event_queue (customer-provided Amazon SQS) for file-based ingestion (e.g. Auto Loader)"
  type        = bool
  default     = false
}

variable "catalog_file_events_sqs_message_retention_seconds" {
  description = "SQS message retention when enable_catalog_file_events is true (60–1209600)"
  type        = number
  default     = 345600

  validation {
    condition     = var.catalog_file_events_sqs_message_retention_seconds >= 60 && var.catalog_file_events_sqs_message_retention_seconds <= 1209600
    error_message = "catalog_file_events_sqs_message_retention_seconds must be between 60 and 1209600."
  }
}

variable "catalog_file_events_sqs_kms_key_id" {
  description = "Optional KMS key ID, ARN, or alias for SQS encryption when file events are enabled; omit for SSE-SQS. When set, the UC IAM role receives IAM kms:* actions on this key and a KMS grant for Decrypt/GenerateDataKey (required to read encrypted messages)."
  type        = string
  default     = null
}

variable "catalog_file_events_s3_events" {
  description = "S3 event types sent to the file-events queue when enable_catalog_file_events is true"
  type        = list(string)
  default     = ["s3:ObjectCreated:*", "s3:ObjectRemoved:*", "s3:LifecycleExpiration:*"]
}

variable "catalog_file_events_s3_filter_prefix" {
  description = "Optional S3 object key prefix filter for file-events notifications"
  type        = string
  default     = ""
}

variable "catalog_file_events_s3_filter_suffix" {
  description = "Optional S3 object key suffix filter for file-events notifications"
  type        = string
  default     = ""
}

variable "databricks_service_principal_app_ids" {
  description = "Service principal name to application ID map (used for catalog-level permissions)"
  type        = map(string)
  default     = {}
}

variable "permissions" {
  description = "Catalog-level permissions (groups and service principals with list of privileges). Service principal keys must exist in databricks_service_principal_app_ids."
  type = object({
    groups             = map(list(string))
    service_principals = map(list(string))
  })
  default = {
    groups             = {}
    service_principals = {}
  }
}

variable "tags" {
  description = "Tags for AWS resources"
  type        = map(string)
  default     = {}
}
