#!/bin/bash
# Run catalog-creation tests with env vars from the repo secrets file.
# Usage: from repo root: ./modules/catalog-creation/test/run_tests.sh
#        or from this dir: ./run_tests.sh
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../../.." && pwd)"
SECRETS="$REPO_ROOT/secrets"

if [ ! -f "$SECRETS" ]; then
  echo "Secrets file not found: $SECRETS"
  echo "Create it with export statements for DATABRICKS_HOST, DATABRICKS_CLIENT_ID, DATABRICKS_CLIENT_SECRET,"
  echo "DATABRICKS_ACCOUNT_ID (optional), and AWS_* if the tests create AWS resources."
  exit 1
fi

echo "Sourcing secrets from $SECRETS"
# shellcheck source=/dev/null
source "$SECRETS"

export DATABRICKS_WORKSPACE_ID="${DATABRICKS_WORKSPACE_ID:-f49a3f67-7668}"

cd "$SCRIPT_DIR"
go test -v -run 'TestCatalogCreation' -timeout 15m -count=1 .
