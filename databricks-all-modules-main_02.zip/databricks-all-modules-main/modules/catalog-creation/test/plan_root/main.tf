# Terratest fixture: wraps catalog-creation with a sample CMK (kms.tf).
# TerraformDir for Go tests in ../ should be set to this directory (plan_root).

provider "aws" {
  region = var.aws_region
}

provider "databricks" {}

module "catalog" {
  source = "../.."

  workspace_id = var.workspace_id
  name_prefix  = var.name_prefix

  aws_partition = var.aws_partition

  catalog_storage_kms_key_arn   = module.example_catalog_storage_kms.key_arn
  catalog_storage_kms_key_alias = "alias/${local.catalog_kms_alias_name}"

  unity_catalog_iam_arn = var.unity_catalog_iam_arn

  catalog_owner          = var.catalog_owner
  catalog_properties     = var.catalog_properties
  catalog_isolation_mode = var.catalog_isolation_mode
  force_destroy          = var.force_destroy

  permissions                          = var.permissions
  databricks_service_principal_app_ids = var.databricks_service_principal_app_ids

  enable_catalog_file_events                        = var.enable_catalog_file_events
  catalog_file_events_sqs_message_retention_seconds = var.catalog_file_events_sqs_message_retention_seconds
  catalog_file_events_sqs_kms_key_id                = var.catalog_file_events_sqs_kms_key_id
  catalog_file_events_s3_events                     = var.catalog_file_events_s3_events
  catalog_file_events_s3_filter_prefix              = var.catalog_file_events_s3_filter_prefix
  catalog_file_events_s3_filter_suffix              = var.catalog_file_events_s3_filter_suffix

  tags = var.tags

  depends_on = [module.example_catalog_storage_kms]
}
