output "catalog_id" {
  value = module.catalog.catalog_id
}

output "catalog_name" {
  value = module.catalog.catalog_name
}

output "storage_credential_id" {
  value = module.catalog.storage_credential_id
}

output "external_location_name" {
  value = module.catalog.external_location_name
}

output "s3_bucket_name" {
  value = module.catalog.s3_bucket_name
}

output "iam_role_arn" {
  value = module.catalog.iam_role_arn
}

output "kms_key_arn" {
  value = module.catalog.kms_key_arn
}

output "catalog_storage_kms_key_alias" {
  value = module.catalog.catalog_storage_kms_key_alias
}

output "catalog_file_events_sqs_queue_url" {
  value = module.catalog.catalog_file_events_sqs_queue_url
}

output "catalog_file_events_sqs_queue_arn" {
  value = module.catalog.catalog_file_events_sqs_queue_arn
}
