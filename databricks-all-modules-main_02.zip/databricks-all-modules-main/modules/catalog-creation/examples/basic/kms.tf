data "aws_caller_identity" "current" {}

resource "random_string" "kms_suffix" {
  length  = 6
  special = false
  upper   = false
}

locals {
  uc_catalog_role_name   = "${var.name_prefix}-catalog-${var.workspace_id}"
  uc_iam_arn             = "arn:${var.aws_partition}:iam::${data.aws_caller_identity.current.account_id}:role/${local.uc_catalog_role_name}"
  cmk_admin_value        = var.cmk_admin_arn != null ? var.cmk_admin_arn : "arn:${var.aws_partition}:iam::${data.aws_caller_identity.current.account_id}:root"
  catalog_kms_alias_name = "${var.name_prefix}-catalog-storage-${random_string.kms_suffix.result}-key"
}

module "example_catalog_storage_kms" {
  source  = "terraform-aws-modules/kms/aws"
  version = "~> 3.0"

  description = "Example CMK for catalog-creation root storage"
  key_usage   = "ENCRYPT_DECRYPT"

  computed_aliases = {
    "catalog-storage" = {
      name = local.catalog_kms_alias_name
    }
  }

  key_statements = [
    {
      sid    = "Enable IAM User Permissions"
      effect = "Allow"
      principals = [{
        type        = "AWS"
        identifiers = [local.cmk_admin_value]
      }]
      actions   = ["kms:*"]
      resources = ["*"]
    },
    {
      sid    = "Allow IAM Role to use the key"
      effect = "Allow"
      principals = [{
        type        = "AWS"
        identifiers = [local.uc_iam_arn]
      }]
      actions   = ["kms:Decrypt", "kms:Encrypt", "kms:GenerateDataKey*"]
      resources = ["*"]
    }
  ]

  tags = merge(var.tags, { Name = "${var.name_prefix}-example-catalog-storage-cmk" })
}
