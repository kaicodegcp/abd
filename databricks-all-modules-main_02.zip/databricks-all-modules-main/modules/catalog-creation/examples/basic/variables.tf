variable "aws_region" {
  description = "AWS region for KMS and S3."
  type        = string
  default     = "us-east-1"
}

variable "workspace_id" {
  description = "Databricks workspace ID (used in IAM role and S3 bucket naming)."
  type        = string
}

variable "name_prefix" {
  description = "Prefix for catalog-related resource names."
  type        = string
}

variable "aws_partition" {
  description = "AWS partition (aws or aws-us-gov)."
  type        = string
  default     = "aws"
}

variable "cmk_admin_arn" {
  description = "Optional KMS administrator principal; defaults to account root."
  type        = string
  default     = null
}

variable "unity_catalog_iam_arn" {
  description = "Databricks Unity Catalog master role ARN for storage credential trust."
  type        = string
  default     = "arn:aws:iam::414351767826:role/unity-catalog-prod-UCMasterRole-14S5ZJVKOTYTL"
}

variable "catalog_owner" {
  type    = string
  default = "account users"
}

variable "catalog_properties" {
  type    = map(string)
  default = {}
}

variable "catalog_isolation_mode" {
  type    = string
  default = "ISOLATED"
}

variable "force_destroy" {
  type    = bool
  default = false
}

variable "enable_catalog_file_events" {
  type    = bool
  default = false
}

variable "catalog_file_events_sqs_message_retention_seconds" {
  type    = number
  default = 345600
}

variable "catalog_file_events_sqs_kms_key_id" {
  type    = string
  default = null
}

variable "catalog_file_events_s3_events" {
  type    = list(string)
  default = ["s3:ObjectCreated:*", "s3:ObjectRemoved:*", "s3:LifecycleExpiration:*"]
}

variable "catalog_file_events_s3_filter_prefix" {
  type    = string
  default = ""
}

variable "catalog_file_events_s3_filter_suffix" {
  type    = string
  default = ""
}

variable "databricks_service_principal_app_ids" {
  type    = map(string)
  default = {}
}

variable "permissions" {
  type = object({
    groups             = map(list(string))
    service_principals = map(list(string))
  })
  default = {
    groups             = {}
    service_principals = {}
  }
}

variable "tags" {
  type    = map(string)
  default = {}
}
