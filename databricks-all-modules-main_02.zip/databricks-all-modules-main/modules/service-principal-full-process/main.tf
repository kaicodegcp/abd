module "create_sp" {
  source = "../service-principal"

  providers = {
    databricks = databricks
  }

  display_name = var.display_name
}

module "generate_sp_secret" {
  source = "../service-principal-secret"

  providers = {
    databricks = databricks
    time       = time
  }

  service_principal_id = module.create_sp.id
  rotation_days        = var.rotation_days
  lifetime             = var.lifetime
}

module "store_in_vault" {
  source = "../store-in-vault"

  providers = {
    vault = vault
  }

  vault_mount   = var.vault_mount
  vault_path    = var.vault_path
  client_id     = module.create_sp.application_id
  client_secret = module.generate_sp_secret.client_secret
}
