package test

import (
	"testing"

	common "github.com/sandbox45/databricks-all-modules/common"
)

func TestServicePrincipalFullProcessModule(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("sp-full")

	config := common.ModuleTestConfig{
		ModuleName:      "service-principal-full-process",
		TestDescription: "Tests end-to-end service principal creation, secret generation, and Vault storage",
		RequiredVars: map[string]interface{}{
			"display_name":  uniqueID,
			"rotation_days": 90,
			"lifetime":      "23328000s",
			"vault_mount":   "secret",
			"vault_path":    uniqueID,
		},
		ExpectedOutputs: []string{
			"client_id",
			"vault_path",
		},
		SkipDestroy: true,
	}

	common.TestModuleWithConfig(t, config)
}
