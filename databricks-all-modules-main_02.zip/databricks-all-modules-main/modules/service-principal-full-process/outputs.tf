output "client_id" {
  value = module.create_sp.application_id
}

output "vault_path" {
  value = module.store_in_vault.vault_path
}
