variable "display_name" {
  type = string
}

variable "rotation_days" {
  type = number
}

variable "lifetime" {
  type = string
}

variable "vault_mount" {
  type = string
}

variable "vault_path" {
  type = string
}
