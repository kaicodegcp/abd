package test

import (
	"testing"

	common "github.com/sandbox45/databricks-all-modules/common"
)

func TestShareModule(t *testing.T) {
	defaults := common.GetTestDefaults()
	catalogName := defaults.CatalogName

	uniqueID := common.GenerateUniqueTestID("share")
	schemaName := common.GetEnvOrDefault("TEST_SHARE_SCHEMA_NAME", "default")

	config := common.ModuleTestConfig{
		ModuleName:      "share",
		ModulePath:      "..",
		TestDescription: "Tests Databricks Delta Sharing share module (schema share with optional recipients)",
		RequiredVars: map[string]interface{}{
			"share_name":    uniqueID,
			"catalog_name":  catalogName,
			"schema_name":  schemaName,
			"recipients":   []string{},
		},
		ExpectedOutputs: []string{
			"id",
			"name",
		},
	}

	common.TestModuleWithConfig(t, config)
}

func TestShareModuleWithRecipients(t *testing.T) {
	defaults := common.GetTestDefaults()
	catalogName := defaults.CatalogName

	uniqueID := common.GenerateUniqueTestID("share-recipients")
	schemaName := common.GetEnvOrDefault("TEST_SHARE_SCHEMA_NAME", "default")
	// Placeholder recipient name; use TEST_SHARE_RECIPIENTS env (comma-separated) for real run
	recipients := []string{"placeholder-recipient"}

	config := common.ModuleTestConfig{
		ModuleName:      "share",
		ModulePath:      "..",
		TestDescription: "Tests Databricks share module with recipients (grants)",
		RequiredVars: map[string]interface{}{
			"share_name":   uniqueID,
			"catalog_name": catalogName,
			"schema_name":  schemaName,
			"recipients":   recipients,
		},
		ExpectedOutputs: []string{
			"id",
			"name",
		},
	}

	common.TestModuleWithConfig(t, config)
}

func TestShareModuleInputValidation(t *testing.T) {
	defaults := common.GetTestDefaults()
	catalogName := defaults.CatalogName

	uniqueID := common.GenerateUniqueTestID("share-inputs")
	schemaName := common.GetEnvOrDefault("TEST_SHARE_SCHEMA_NAME", "default")

	config := common.ModuleTestConfig{
		ModuleName:      "share",
		ModulePath:      "..",
		TestDescription: "Validates share module required inputs",
		RequiredVars: map[string]interface{}{
			"share_name":   uniqueID,
			"catalog_name": catalogName,
			"schema_name":  schemaName,
			"recipients":   []string{},
		},
	}

	opts := common.GetTestTerraformOptions(t, config)

	t.Run("ValidateRequiredInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})
}
