# Create share on schema
resource "databricks_share" "share" {
  name = var.share_name
  object {
    name                        = "${var.catalog_name}.${var.schema_name}"
    data_object_type            = "SCHEMA"
    history_data_sharing_status = "ENABLED"
  }
}

# Grant access to all recipients
resource "databricks_grant" "grants" {
  for_each = toset(var.recipients)
  share       = databricks_share.share.name
  principal   = each.key
  privileges  = ["SELECT"]
}
