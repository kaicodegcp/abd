terraform {
  required_version = ">= 1.5"

  required_providers {
    databricks = {
      source  = "databricks/databricks"
      version = ">= 1.125.0, < 2.0.0"
    }
    aws = {
      source = "hashicorp/aws"
      # >= 6.0: per-resource `region` places the DR twin bucket and DR KMS key
      # in dr_region without a provider alias, keeping the caller contract to
      # a single aws provider.
      version = ">= 6.0"
    }
    time = {
      source  = "hashicorp/time"
      version = ">= 0.9"
    }
  }
}
