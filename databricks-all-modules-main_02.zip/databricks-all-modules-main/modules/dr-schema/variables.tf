# =============================================================================
# dr-schema - variables
# =============================================================================

# -----------------------------------------------------------------------------
# Identity of the schema (drives every derived name)
# -----------------------------------------------------------------------------

variable "catalog_name" {
  description = "Existing catalog the schema is created in (Ops-managed default catalog). Bucket names derive from it: the catalog bucket name is the catalog name with underscores as hyphens."
  type        = string

  validation {
    condition     = length(trimspace(var.catalog_name)) > 0
    error_message = "catalog_name must not be empty."
  }
}

variable "name" {
  description = "Schema name. Also feeds the bucket, KMS, IAM, credential and external location names."
  type        = string

  validation {
    condition     = length(trimspace(var.name)) > 0
    error_message = "name must not be empty."
  }
}

variable "environment" {
  description = "Deployment environment (dev, uat, prod). Used in resource and persona group names."
  type        = string

  validation {
    condition     = contains(["dev", "uat", "prod"], var.environment)
    error_message = "environment must be one of: dev, uat, prod."
  }
}

variable "app_id" {
  description = "Application identifier (CSI) used in resource and group names, e.g. 179392."
  type        = string

  validation {
    condition     = length(trimspace(var.app_id)) > 0
    error_message = "app_id must not be empty."
  }
}

variable "app_acronym" {
  description = "Application acronym used in resource and group names, e.g. dms."
  type        = string

  validation {
    condition     = length(trimspace(var.app_acronym)) > 0
    error_message = "app_acronym must not be empty."
  }
}

variable "resource_name_suffix" {
  description = "Optional suffix appended to every derived resource name (e.g. a region shorthand like use1), matching the client naming convention. Empty for none."
  type        = string
  default     = ""
}

# -----------------------------------------------------------------------------
# Create-or-pass: S3, KMS, IAM. Default is CREATE everything (domain team
# self-service); pass an existing value to reuse instead.
# -----------------------------------------------------------------------------

variable "create_bucket" {
  description = "Create the schema S3 bucket (and its DR twin when dr_enable). False = bucket_name must point at an existing bucket the team manages elsewhere (its DR twin included)."
  type        = bool
  default     = true
}

variable "bucket_name" {
  description = "Override for the schema bucket name. Null derives \"<catalog-bucket>-<schema>[-suffix]\". Required when create_bucket is false."
  type        = string
  default     = null
}

variable "create_kms_key" {
  description = "Create the schema KMS key (and a DR-region key when dr_enable). False = pass kms_key_arn (and dr_kms_key_arn when dr_enable)."
  type        = bool
  default     = true
}

variable "kms_key_arn" {
  description = "Existing KMS key ARN (primary region) used when create_kms_key is false."
  type        = string
  default     = null
}

variable "dr_kms_key_arn" {
  description = "Existing KMS key ARN in dr_region used when create_kms_key is false and dr_enable is true (KMS keys are regional; the twin bucket needs a key in its own region)."
  type        = string
  default     = null
}

variable "create_iam_role" {
  description = "Create the cross-account Unity Catalog IAM role. False = pass iam_role_arn; the existing role's trust must already allow the UC master role with this account's external ID, and its policy must cover the schema bucket(s) and key(s)."
  type        = bool
  default     = true
}

variable "iam_role_arn" {
  description = "Existing IAM role ARN used when create_iam_role is false."
  type        = string
  default     = null
}

variable "unity_catalog_iam_arn" {
  description = "Databricks Unity Catalog master role ARN for the IAM trust policy."
  type        = string
  default     = "arn:aws:iam::414351767826:role/unity-catalog-prod-UCMasterRole-14S5ZJVKOTYTL"
}

variable "aws_partition" {
  description = "AWS partition."
  type        = string
  default     = "aws"
}

# -----------------------------------------------------------------------------
# Resilience DR: the schema's "-dr" twin bucket in the secondary region.
# Replica-side registration (replica credential/external location on the
# secondary metastore) and the failover-group location mapping stay CENTRAL
# (Ops); this module emits the hand-off outputs for them.
# -----------------------------------------------------------------------------

# Why null and nullable = true: this is a deliberate THREE-state input, and
# null is load-bearing. A plain bool default cannot distinguish "caller chose
# false" from "caller said nothing", and the requirement is exactly that
# distinction: unset (null) resolves by environment (prod = on, otherwise
# off), while an explicit true/false always wins. The resolution lives in
# local.dr_enable in main.tf; everything in the module reads that local, so
# null never reaches a count or precondition. Do NOT set nullable = false
# here: it would coerce null to the default and erase the "not set" state.
variable "dr_enable" {
  description = "Also create the schema's DR twin bucket in dr_region and emit the location-mapping hand-off outputs. Default (null): enabled automatically when environment is prod, disabled otherwise. Set true/false to override either way."
  type        = bool
  default     = null
  nullable    = true
}

variable "dr_region" {
  description = "Secondary AWS region for the DR twin bucket. Required when dr_enable is true."
  type        = string
  default     = null
}

# -----------------------------------------------------------------------------
# Schema pass-through
# -----------------------------------------------------------------------------

variable "comment" {
  description = "Comment/description for the schema."
  type        = string
  default     = null
}

variable "properties" {
  description = "Schema properties."
  type        = map(string)
  default     = {}
}

variable "owner" {
  description = "Schema owner. Defaults to the Terraform identity."
  type        = string
  default     = null
}

variable "additional_schema_grants" {
  description = "Optional map of full group name to schema privileges, granted in addition to the default personas."
  type        = map(list(string))
  default     = {}
}

variable "force_destroy" {
  description = "Force destroy for the credential, external location, schema and created buckets."
  type        = bool
  default     = false
}

variable "skip_validation" {
  description = "Skip Unity Catalog validation on the external location. Escape hatch for the IAM propagation window on freshly created roles (validation has been observed to fail for up to a few hours after role creation even though the IAM is correct)."
  type        = bool
  default     = false
}

variable "tags" {
  description = "Tags applied to created AWS resources."
  type        = map(string)
  default     = {}
}
