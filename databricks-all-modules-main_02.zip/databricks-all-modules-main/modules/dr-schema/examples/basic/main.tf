# =============================================================================
# dr-schema - basic example: one call creates the schema's whole chain
# (credential, KMS, IAM, bucket + DR twin, external location, schema).
# environment = "prod" auto-enables DR (twin bucket + mapping hand-off);
# non-prod defaults DR off, and dr_enable = true/false overrides either way.
# Prerequisite: the three account-level persona groups
# dbx-<env>-<app_id>-<acronym>-schema-<name>-{read,write,owner}-grp.
# =============================================================================

terraform {
  required_version = ">= 1.5"
  required_providers {
    databricks = {
      source  = "databricks/databricks"
      version = ">= 1.125.0, < 2.0.0"
    }
    aws = {
      source  = "hashicorp/aws"
      version = ">= 6.0"
    }
    time = {
      source  = "hashicorp/time"
      version = ">= 0.9"
    }
  }
}

provider "aws" {
  region = "us-east-1"
}

provider "databricks" {
  host = "https://dbc-PRIMARY.cloud.databricks.com"
}

module "domain_schema" {
  source = "../.."

  catalog_name = "acme_catalog_1111111111111111"
  name         = "domainschema"

  environment = "prod" # prod: DR twin + hand-off outputs enabled by default
  app_id      = "179392"
  app_acronym = "dms"

  dr_region = "us-east-2"

  force_destroy = true
}

# Hand-offs for the CENTRAL failover-group owner (Ops):
output "dr_location_mapping" {
  value = module.domain_schema.dr_location_mapping
}

output "dr_bucket_name" {
  value = module.domain_schema.dr_bucket_name
}
