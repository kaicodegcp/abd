# =============================================================================
# dr-schema - one-shot, DR-ready schema for a domain/functional team
# =============================================================================
# Operating model (mirrors the client's schema wrappers, as ONE module):
#   - OPS manage the workspace, the default catalog all schemas go into, and
#     that catalog's own KMS (possibly in a different AWS account). None of
#     that is touched here.
#   - The DOMAIN TEAM calls this module once per schema. By default it creates
#     the whole chain the schema needs, in this order:
#       1. Storage credential (Databricks issues the external ID first)
#       2. KMS key   (create, or pass kms_key_arn / dr_kms_key_arn)
#       3. IAM role  (create, or pass iam_role_arn) - cross-account UC role,
#          trust from the credential's external ID, access scoped to exactly
#          this schema's bucket(s) and key(s)
#       4. S3 bucket (create, or pass bucket_name) + the "-dr" twin bucket in
#          dr_region when dr_enable
#       5. External location on the bucket
#       6. The schema itself (modules/schema: persona grants included; the
#          dbx-<env>-<app_id>-<acronym>-schema-<name>-{read,write,owner}-grp
#          account-level groups must exist)
#
# Naming (client convention, deterministic - no random suffixes):
#   bucket      <catalog-bucket>-<schema>[-suffix]        (+ "-dr" twin)
#   kms alias   <acronym>-<env>-<app_id>-uc-schemakms-<schema>[-suffix]
#   iam role    <acronym>-<env>-<app_id>-uc-schemaiam-<schema>[-suffix]
#   credential  <acronym>-<env>-<app_id>-uc-schemacred-<schema>[-suffix]
#   ext. loc.   <acronym>-<env>-<app_id>-uc-schemaextloc-<schema>[-suffix]
#
# What stays CENTRAL (Ops, failover-group owner) and is NOT done here:
#   - replica credential + replica external locations on the SECONDARY
#     metastore (dr-replica-storage)
#   - the failover group location mapping registration (dr module)
# This module emits `dr_location_mapping` and `dr_bucket_name` as the hand-off.
#
# Providers: one workspace-level databricks provider, one aws provider (the
# DR twin and DR key use per-resource region, no alias needed).
# =============================================================================

data "aws_caller_identity" "current" {}

locals {
  # DR defaults ON for prod, OFF otherwise; an explicit local.dr_enable wins.
  dr_enable = var.dr_enable != null ? var.dr_enable : var.environment == "prod"

  catalog_hyphen = replace(var.catalog_name, "_", "-")
  schema_hyphen  = replace(var.name, "_", "-")
  sfx            = var.resource_name_suffix == "" ? "" : "-${var.resource_name_suffix}"
  base           = "${var.app_acronym}-${var.environment}-${var.app_id}-uc"

  bucket_name    = var.bucket_name != null ? var.bucket_name : "${local.catalog_hyphen}-${local.schema_hyphen}${local.sfx}"
  dr_bucket_name = "${local.bucket_name}-dr"

  kms_alias_name  = "${local.base}-schemakms-${local.schema_hyphen}${local.sfx}"
  role_name       = "${local.base}-schemaiam-${local.schema_hyphen}${local.sfx}"
  credential_name = "${local.base}-schemacred-${local.schema_hyphen}${local.sfx}"
  extloc_name     = "${local.base}-schemaextloc-${local.schema_hyphen}${local.sfx}"

  role_arn = var.create_iam_role ? "arn:${var.aws_partition}:iam::${data.aws_caller_identity.current.account_id}:role/${local.role_name}" : var.iam_role_arn

  kms_key_arn    = var.create_kms_key ? aws_kms_key.this[0].arn : var.kms_key_arn
  dr_kms_key_arn = local.dr_enable ? (var.create_kms_key ? aws_kms_key.dr[0].arn : var.dr_kms_key_arn) : null

  all_bucket_arns = concat(
    [
      "arn:${var.aws_partition}:s3:::${local.bucket_name}",
      "arn:${var.aws_partition}:s3:::${local.bucket_name}/*",
    ],
    local.dr_enable ? [
      "arn:${var.aws_partition}:s3:::${local.dr_bucket_name}",
      "arn:${var.aws_partition}:s3:::${local.dr_bucket_name}/*",
    ] : []
  )

  all_kms_arns = compact([local.kms_key_arn, local.dr_kms_key_arn])
}

# =============================================================================
# 1. Storage credential - FIRST: Databricks generates the external ID the IAM
# trust policy needs. Validation is skipped here because the role may not
# exist yet; the external location below is the validated step.
# =============================================================================

resource "databricks_storage_credential" "this" {
  name = local.credential_name

  aws_iam_role {
    role_arn = local.role_arn
  }

  comment         = "Schema credential for ${var.catalog_name}.${var.name}"
  isolation_mode  = "ISOLATION_MODE_ISOLATED"
  skip_validation = true
  force_destroy   = var.force_destroy

  lifecycle {
    precondition {
      condition     = var.create_iam_role || (var.iam_role_arn != null && var.iam_role_arn != "")
      error_message = "iam_role_arn is required when create_iam_role is false."
    }
    precondition {
      condition     = var.create_bucket || (var.bucket_name != null && var.bucket_name != "")
      error_message = "bucket_name is required when create_bucket is false."
    }
    precondition {
      condition     = var.create_kms_key || (var.kms_key_arn != null && var.kms_key_arn != "")
      error_message = "kms_key_arn is required when create_kms_key is false."
    }
    precondition {
      condition     = !local.dr_enable || (var.dr_region != null && var.dr_region != "")
      error_message = "dr_region is required when dr_enable is true."
    }
    precondition {
      condition     = !local.dr_enable || var.create_kms_key || (var.dr_kms_key_arn != null && var.dr_kms_key_arn != "")
      error_message = "dr_kms_key_arn is required when dr_enable is true and create_kms_key is false (KMS keys are regional)."
    }
  }
}

# =============================================================================
# 2. KMS - schema key (primary region) and, with DR on, its dr_region sibling.
# Default key policy (account root) so access is governed by IAM policies.
# =============================================================================

resource "aws_kms_key" "this" {
  count = var.create_kms_key ? 1 : 0

  description         = "Schema KMS key for ${var.catalog_name}.${var.name}"
  enable_key_rotation = true

  tags = merge(var.tags, { Name = local.kms_alias_name })
}

resource "aws_kms_alias" "this" {
  count = var.create_kms_key ? 1 : 0

  name          = "alias/${local.kms_alias_name}"
  target_key_id = aws_kms_key.this[0].key_id
}

resource "aws_kms_key" "dr" {
  count  = var.create_kms_key && local.dr_enable ? 1 : 0
  region = var.dr_region

  description         = "DR schema KMS key for ${var.catalog_name}.${var.name} (${var.dr_region})"
  enable_key_rotation = true

  tags = merge(var.tags, { Name = "${local.kms_alias_name}-dr" })
}

resource "aws_kms_alias" "dr" {
  count  = var.create_kms_key && local.dr_enable ? 1 : 0
  region = var.dr_region

  name          = "alias/${local.kms_alias_name}-dr"
  target_key_id = aws_kms_key.dr[0].key_id
}

# =============================================================================
# 3. IAM - cross-account Unity Catalog role: trust from the credential's
# external ID, access on exactly this schema's bucket(s) and key(s), plus the
# self-assume statement UC requires.
# =============================================================================

data "databricks_aws_unity_catalog_assume_role_policy" "this" {
  count = var.create_iam_role ? 1 : 0

  aws_account_id        = data.aws_caller_identity.current.account_id
  role_name             = local.role_name
  unity_catalog_iam_arn = var.unity_catalog_iam_arn
  external_id           = databricks_storage_credential.this.aws_iam_role[0].external_id
}

data "aws_iam_policy_document" "this" {
  count = var.create_iam_role ? 1 : 0

  statement {
    sid = "SchemaS3Access"
    actions = [
      "s3:GetObject",
      "s3:PutObject",
      "s3:DeleteObject",
      "s3:ListBucket",
      "s3:GetBucketLocation",
      "s3:GetLifecycleConfiguration",
      "s3:PutLifecycleConfiguration",
    ]
    resources = local.all_bucket_arns
  }

  statement {
    sid = "SchemaKmsAccess"
    actions = [
      "kms:Decrypt",
      "kms:Encrypt",
      "kms:GenerateDataKey",
      "kms:GenerateDataKeyWithoutPlaintext",
      "kms:DescribeKey",
    ]
    resources = local.all_kms_arns
  }

  statement {
    sid       = "SchemaSelfAssume"
    actions   = ["sts:AssumeRole"]
    resources = [local.role_arn]
  }
}

resource "aws_iam_role" "this" {
  count = var.create_iam_role ? 1 : 0

  name               = local.role_name
  assume_role_policy = data.databricks_aws_unity_catalog_assume_role_policy.this[0].json
  tags               = merge(var.tags, { Name = local.role_name })
}

resource "aws_iam_role_policy" "this" {
  count = var.create_iam_role ? 1 : 0

  name   = "${local.role_name}-policy"
  role   = aws_iam_role.this[0].id
  policy = data.aws_iam_policy_document.this[0].json
}

# IAM propagation wait. 60s covers the normal case; a FRESH role has been
# observed to need up to a few hours before Unity Catalog's S3 access sees it
# (STS accepts the role while S3 still denies). If the external location below
# fails AccessDenied with correct IAM, retry later or set skip_validation.
resource "time_sleep" "iam_propagation" {
  count = var.create_iam_role ? 1 : 0

  depends_on      = [aws_iam_role.this, aws_iam_role_policy.this]
  create_duration = "60s"
}

# =============================================================================
# 4. S3 - schema bucket and, with DR on, its "-dr" twin in dr_region.
# =============================================================================

resource "aws_s3_bucket" "this" {
  count = var.create_bucket ? 1 : 0

  bucket        = local.bucket_name
  force_destroy = var.force_destroy

  tags = merge(var.tags, { Name = local.bucket_name })
}

resource "aws_s3_bucket_public_access_block" "this" {
  count = var.create_bucket ? 1 : 0

  bucket                  = aws_s3_bucket.this[0].id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_server_side_encryption_configuration" "this" {
  count = var.create_bucket ? 1 : 0

  bucket = aws_s3_bucket.this[0].id

  rule {
    bucket_key_enabled = true
    apply_server_side_encryption_by_default {
      sse_algorithm     = "aws:kms"
      kms_master_key_id = local.kms_key_arn
    }
  }
}

resource "aws_s3_bucket" "dr" {
  count  = var.create_bucket && local.dr_enable ? 1 : 0
  region = var.dr_region

  bucket        = local.dr_bucket_name
  force_destroy = var.force_destroy

  tags = merge(var.tags, { Name = local.dr_bucket_name })
}

resource "aws_s3_bucket_public_access_block" "dr" {
  count  = var.create_bucket && local.dr_enable ? 1 : 0
  region = var.dr_region

  bucket                  = aws_s3_bucket.dr[0].id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_server_side_encryption_configuration" "dr" {
  count  = var.create_bucket && local.dr_enable ? 1 : 0
  region = var.dr_region

  bucket = aws_s3_bucket.dr[0].id

  rule {
    bucket_key_enabled = true
    apply_server_side_encryption_by_default {
      sse_algorithm     = "aws:kms"
      kms_master_key_id = local.dr_kms_key_arn
    }
  }
}

# =============================================================================
# 5. External location - the schema's managed location, on its own credential.
# =============================================================================

resource "databricks_external_location" "this" {
  name            = local.extloc_name
  url             = "s3://${local.bucket_name}/"
  credential_name = databricks_storage_credential.this.id
  comment         = "Managed location for schema ${var.catalog_name}.${var.name}"
  isolation_mode  = "ISOLATION_MODE_ISOLATED"
  skip_validation = var.skip_validation
  force_destroy   = var.force_destroy

  depends_on = [
    time_sleep.iam_propagation,
    aws_s3_bucket_server_side_encryption_configuration.this,
    aws_s3_bucket_public_access_block.this,
  ]
}

# =============================================================================
# 6. The schema - existing modules/schema (persona grants included).
# =============================================================================

module "schema" {
  source = "../schema"

  catalog_name  = var.catalog_name
  name          = var.name
  comment       = var.comment
  properties    = var.properties
  storage_root  = "s3://${local.bucket_name}/"
  owner         = var.owner
  force_destroy = var.force_destroy

  environment = var.environment
  app_id      = var.app_id
  app_acronym = var.app_acronym

  additional_schema_grants = var.additional_schema_grants

  depends_on = [databricks_external_location.this]
}
