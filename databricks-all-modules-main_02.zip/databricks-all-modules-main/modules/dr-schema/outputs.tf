# =============================================================================
# dr-schema - outputs
# =============================================================================

output "schema_id" {
  description = "ID of the schema."
  value       = module.schema.id
}

output "schema_name" {
  description = "Name of the schema."
  value       = module.schema.name
}

output "schema_full_name" {
  description = "catalog.schema full name."
  value       = module.schema.full_name
}

output "bucket_name" {
  description = "Schema S3 bucket name."
  value       = local.bucket_name
}

output "storage_root" {
  description = "Schema storage root URL."
  value       = "s3://${local.bucket_name}/"
}

output "external_location_name" {
  description = "Name of the schema's external location."
  value       = databricks_external_location.this.id
}

output "storage_credential_name" {
  description = "Name of the schema's storage credential."
  value       = databricks_storage_credential.this.id
}

output "iam_role_arn" {
  description = "Unity Catalog IAM role ARN in use (created or passed)."
  value       = local.role_arn
}

output "kms_key_arn" {
  description = "Primary-region KMS key ARN in use (created or passed)."
  value       = local.kms_key_arn
}

output "dr_kms_key_arn" {
  description = "DR-region KMS key ARN in use, null when dr_enable is false."
  value       = local.dr_kms_key_arn
}

# -----------------------------------------------------------------------------
# DR hand-off for the CENTRAL failover-group owner (Ops):
#   - dr_bucket_name feeds replica-side registration (dr-replica-storage
#     extra_buckets, or its own chain) together with dr_replica_kms_arns
#   - dr_location_mapping feeds the dr module's extra_location_mappings
# -----------------------------------------------------------------------------

output "dr_bucket_name" {
  description = "The schema's DR twin bucket name, null when dr_enable is false."
  value       = local.dr_enable ? local.dr_bucket_name : null
}

output "dr_replica_kms_arns" {
  description = "KMS key ARNs the replica-side role needs for this schema (primary + DR keys), empty when dr_enable is false."
  value       = local.dr_enable ? local.all_kms_arns : []
}

output "dr_location_mapping" {
  description = "Exact-path location mapping entry for the failover group ({name, primary_uri, secondary_uri}), null when dr_enable is false."
  value = local.dr_enable ? {
    name          = "${local.schema_hyphen}${local.sfx}-location"
    primary_uri   = "s3://${local.bucket_name}/"
    secondary_uri = "s3://${local.dr_bucket_name}/"
  } : null
}
