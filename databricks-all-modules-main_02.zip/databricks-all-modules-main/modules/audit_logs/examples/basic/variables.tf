variable "aws_region" {
  description = "AWS region for the audit log S3 bucket and IAM role."
  type        = string
  default     = "us-east-1"
}

variable "databricks_account_id" {
  description = "Databricks account ID (UUID). Used as IAM external ID and for MWS resources."
  type        = string
}

variable "name_prefix" {
  description = "Prefix for resource names (bucket, IAM role, MWS credential and storage names)."
  type        = string
}

variable "aws_partition" {
  description = "AWS partition for Databricks bucket/trust policies (e.g. aws, aws-us-gov). Defaults to current partition."
  type        = string
  default     = null
}

variable "force_destroy" {
  description = "Allow Terraform to destroy the non-empty audit log S3 bucket."
  type        = bool
  default     = false
}

variable "cmk_admin_arn" {
  description = "Optional KMS administrator principal; defaults to the current AWS account root."
  type        = string
  default     = null
}

variable "workspace_ids_filter" {
  description = "Optional list of workspace IDs to scope audit log delivery (see audit_logs module)."
  type        = list(number)
  default     = null
}

variable "tags" {
  description = "Tags applied to the S3 bucket, IAM role, and KMS key."
  type        = map(string)
  default     = {}
}
