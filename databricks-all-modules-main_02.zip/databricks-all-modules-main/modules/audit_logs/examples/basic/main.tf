# Example: audit_logs module with S3 bucket, log-delivery IAM role, and bucket policy
# required for Databricks audit log delivery.
#
# Set variables in a .tfvars file, then run e.g.:
#   terraform plan -var-file=terraform.tfvars.example
# or copy that file to terraform.tfvars, edit, and:
#   terraform plan -var-file=terraform.tfvars
# Export Databricks auth (e.g. DATABRICKS_CLIENT_ID, DATABRICKS_CLIENT_SECRET) for the provider.

provider "aws" {
  region = var.aws_region
}

provider "databricks" {
  alias      = "account"
  host       = "https://accounts.cloud.databricks.com"
  account_id = var.databricks_account_id
}

resource "random_id" "suffix" {
  byte_length = 4
}

data "aws_partition" "current" {}

locals {
  suffix                  = random_id.suffix.hex
  bucket_name             = "${var.name_prefix}-audit-log-delivery-${local.suffix}"
  assume_role_partition   = coalesce(var.aws_partition, data.aws_partition.current.partition)
  audit_log_delivery_tags = merge(var.tags, { Purpose = "Databricks Audit Log Delivery" })
}

data "databricks_aws_assume_role_policy" "log_delivery" {
  provider         = databricks.account
  external_id      = var.databricks_account_id
  for_log_delivery = true
  aws_partition    = local.assume_role_partition
}

module "iam_role_audit_log_delivery" {
  source  = "terraform-aws-modules/iam/aws//modules/iam-assumable-role"
  version = "~> 5.0"

  create_role                     = true
  role_name                       = "${var.name_prefix}-audit-log-delivery-role-${local.suffix}"
  role_description                = "(${var.name_prefix}) Audit log delivery role for Databricks"
  role_requires_mfa               = false
  create_custom_role_trust_policy = true
  custom_role_trust_policy        = data.databricks_aws_assume_role_policy.log_delivery.json
  trusted_role_arns               = []

  tags = merge(local.audit_log_delivery_tags, {
    Name = "${var.name_prefix}-audit-log-delivery-role-${local.suffix}"
  })
}

data "databricks_aws_bucket_policy" "audit_log_delivery" {
  provider         = databricks.account
  full_access_role = module.iam_role_audit_log_delivery.iam_role_arn
  aws_partition    = local.assume_role_partition
  bucket           = local.bucket_name
}

module "s3_audit_log_delivery" {
  source  = "terraform-aws-modules/s3-bucket/aws"
  version = "~> 4.0"

  bucket        = local.bucket_name
  force_destroy = var.force_destroy

  versioning = {
    enabled = false
  }

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true

  server_side_encryption_configuration = {
    rule = {
      apply_server_side_encryption_by_default = {
        sse_algorithm     = "aws:kms"
        kms_master_key_id = module.kms_audit_log_delivery.key_arn
      }
      bucket_key_enabled = true
    }
  }

  attach_policy = true
  policy        = data.databricks_aws_bucket_policy.audit_log_delivery.json

  tags = merge(local.audit_log_delivery_tags, {
    Name = local.bucket_name
  })

  depends_on = [module.kms_audit_log_delivery]
}

resource "time_sleep" "audit_log_role_propagation" {
  depends_on      = [module.iam_role_audit_log_delivery]
  create_duration = "120s"
}

module "audit_logs" {
  source = "../.."
  providers = {
    databricks = databricks.account
  }

  account_id                 = var.databricks_account_id
  credentials_name           = "${var.name_prefix}-audit-log-delivery-credential-${local.suffix}"
  role_arn                   = module.iam_role_audit_log_delivery.iam_role_arn
  storage_configuration_name = "${var.name_prefix}-audit-log-delivery-storage-${local.suffix}"
  bucket_name                = module.s3_audit_log_delivery.s3_bucket_id
  workspace_ids_filter       = var.workspace_ids_filter

  depends_on = [time_sleep.audit_log_role_propagation, module.s3_audit_log_delivery]
}
