output "audit_log_kms_key_arn" {
  description = "KMS CMK ARN used for default bucket encryption (SSE-KMS)."
  value       = module.kms_audit_log_delivery.key_arn
}

output "audit_log_kms_key_alias" {
  description = "KMS key alias for the audit log bucket CMK."
  value       = "alias/${local.audit_log_kms_alias_name}"
}

output "audit_log_s3_bucket_id" {
  description = "S3 bucket receiving Databricks audit logs."
  value       = module.s3_audit_log_delivery.s3_bucket_id
}

output "audit_log_delivery_iam_role_arn" {
  description = "IAM role ARN assumed by Databricks for log delivery."
  value       = module.iam_role_audit_log_delivery.iam_role_arn
}

output "audit_log_delivery_config_id" {
  description = "Databricks MWS audit log delivery configuration ID."
  value       = module.audit_logs.config_id
}

output "mws_credentials_id" {
  description = "MWS storage credentials ID used for audit log delivery."
  value       = module.audit_logs.credentials_id
}

output "mws_storage_configuration_id" {
  description = "MWS storage configuration ID for the audit log bucket."
  value       = module.audit_logs.storage_configuration_id
}
