data "aws_caller_identity" "current" {}

locals {
  audit_log_kms_alias_name = "${var.name_prefix}-audit-log-kms-${local.suffix}"
  cmk_admin_principal      = var.cmk_admin_arn != null ? var.cmk_admin_arn : "arn:${data.aws_partition.current.partition}:iam::${data.aws_caller_identity.current.account_id}:root"
}

module "kms_audit_log_delivery" {
  source  = "terraform-aws-modules/kms/aws"
  version = "~> 3.0"

  description = "CMK for Databricks audit log delivery example bucket"
  key_usage   = "ENCRYPT_DECRYPT"

  computed_aliases = {
    audit_logs = {
      name = local.audit_log_kms_alias_name
    }
  }

  key_statements = [
    {
      sid    = "Enable IAM admin"
      effect = "Allow"
      principals = [{
        type        = "AWS"
        identifiers = [local.cmk_admin_principal]
      }]
      actions   = ["kms:*"]
      resources = ["*"]
    },
    {
      sid    = "Allow audit log delivery IAM role"
      effect = "Allow"
      principals = [{
        type        = "AWS"
        identifiers = [module.iam_role_audit_log_delivery.iam_role_arn]
      }]
      actions = [
        "kms:Encrypt",
        "kms:Decrypt",
        "kms:ReEncrypt*",
        "kms:GenerateDataKey*",
        "kms:DescribeKey",
        "kms:CreateGrant",
      ]
      resources = ["*"]
    },
  ]

  tags = merge(var.tags, {
    Name = "${var.name_prefix}-audit-log-delivery-cmk-${local.suffix}"
  })
}
