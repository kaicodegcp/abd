variable "account_id" {
  description = "Databricks account ID"
  type        = string
}

variable "credentials_name" {
  description = "Name for the MWS credentials used to write audit logs to storage"
  type        = string
}

variable "role_arn" {
  description = "ARN of the IAM role Databricks assumes for audit log delivery"
  type        = string
}

variable "storage_configuration_name" {
  description = "Name for the MWS storage configuration pointing at the audit log bucket"
  type        = string
}

variable "bucket_name" {
  description = "S3 bucket name where audit logs are delivered"
  type        = string
}

variable "delivery_path_prefix" {
  description = "Prefix within the bucket for audit log objects"
  type        = string
  default     = "audit-logs"
}

variable "config_name" {
  description = "Display name for the log delivery configuration"
  type        = string
  default     = "Audit Logs"
}

variable "log_type" {
  description = "Databricks log delivery type (e.g. AUDIT_LOGS)"
  type        = string
  default     = "AUDIT_LOGS"
}

variable "output_format" {
  description = "Output format for delivered logs"
  type        = string
  default     = "JSON"
}

variable "workspace_ids_filter" {
  description = "Optional list of workspace IDs to limit log delivery. When null, logs are delivered for all workspaces (and account-level events where applicable)."
  type        = list(number)
  default     = null
}
