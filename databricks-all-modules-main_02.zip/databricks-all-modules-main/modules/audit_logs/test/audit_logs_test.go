package test

import (
	"testing"

	common "github.com/sandbox45/databricks-all-modules/common"
)

func TestAuditLogsModule(t *testing.T) {
	defaults := common.GetTestDefaults()
	uniqueID := common.GenerateUniqueTestID("audit-logs")

	config := common.ModuleTestConfig{
		ModuleName:      "audit_logs",
		TestDescription: "Tests Databricks audit_logs module (MWS credentials, storage config, log delivery)",
		RequiredVars: map[string]interface{}{
			"account_id":                 defaults.AccountID,
			"credentials_name":           uniqueID + "-cred",
			"role_arn":                   defaults.CrossAccountARN,
			"storage_configuration_name": uniqueID + "-storage",
			"bucket_name":                defaults.S3BucketName,
		},
		ExpectedOutputs: []string{
			"credentials_id",
			"storage_configuration_id",
			"config_id",
		},
		SkipDestroy: true,
	}

	common.TestModuleWithConfig(t, config)
}
