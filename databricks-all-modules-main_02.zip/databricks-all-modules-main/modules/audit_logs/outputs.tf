output "credentials_id" {
  description = "MWS credentials ID for audit log delivery"
  value       = databricks_mws_credentials.audit_log_writer.credentials_id
}

output "storage_configuration_id" {
  description = "MWS storage configuration ID for the audit log bucket"
  value       = databricks_mws_storage_configurations.audit_log_bucket.storage_configuration_id
}

output "config_id" {
  description = "Log delivery configuration ID"
  value       = databricks_mws_log_delivery.audit_logs.config_id
}
