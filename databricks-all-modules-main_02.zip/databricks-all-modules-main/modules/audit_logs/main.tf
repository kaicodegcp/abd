resource "databricks_mws_credentials" "audit_log_writer" {
  credentials_name = var.credentials_name
  role_arn         = var.role_arn
}

resource "databricks_mws_storage_configurations" "audit_log_bucket" {
  account_id                 = var.account_id
  storage_configuration_name = var.storage_configuration_name
  bucket_name                = var.bucket_name
}

resource "databricks_mws_log_delivery" "audit_logs" {
  account_id               = var.account_id
  credentials_id           = databricks_mws_credentials.audit_log_writer.credentials_id
  storage_configuration_id = databricks_mws_storage_configurations.audit_log_bucket.storage_configuration_id
  delivery_path_prefix     = var.delivery_path_prefix
  config_name              = var.config_name
  log_type                 = var.log_type
  output_format            = var.output_format
  workspace_ids_filter     = var.workspace_ids_filter
}
