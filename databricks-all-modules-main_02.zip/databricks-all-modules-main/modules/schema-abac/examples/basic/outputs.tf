output "schema_full_name" {
  value = module.schema_abac.schema_full_name
}

output "abac_enabled" {
  value = module.schema_abac.abac_enabled
}

output "policy_ids" {
  value = module.schema_abac.policy_ids
}

output "tag_assignment_ids" {
  value = module.schema_abac.tag_assignment_ids
}
