provider "databricks" {}

module "schema_abac" {
  source = "../.."

  catalog_name = var.catalog_name
  schema_name  = var.schema_name

  enable_abac              = var.enable_abac
  preserve_tags_on_disable = var.preserve_tags_on_disable
  column_tag_assignments   = var.column_tag_assignments
  table_tag_assignments    = var.table_tag_assignments
  abac_policies            = var.abac_policies
}
