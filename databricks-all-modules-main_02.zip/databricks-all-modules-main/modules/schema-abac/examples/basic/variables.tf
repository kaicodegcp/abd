variable "catalog_name" {
  description = "Existing Unity Catalog catalog the schema lives in."
  type        = string
}

variable "schema_name" {
  description = "Existing schema this module will attach ABAC policies to."
  type        = string
}

variable "enable_abac" {
  description = "Master switch. Set to false for staged rollouts."
  type        = bool
  default     = true
}

variable "preserve_tags_on_disable" {
  description = "When enable_abac = false, keep column tag assignments alive."
  type        = bool
  default     = false
}

variable "column_tag_assignments" {
  description = "Governed-tag assignments to apply to columns."
  type = map(object({
    table     = string
    column    = string
    tag_key   = string
    tag_value = optional(string)
  }))
  default = {}
}

variable "table_tag_assignments" {
  description = "Governed-tag assignments to apply to tables. These are the tags a when_condition reads."
  type = map(object({
    table     = string
    tag_key   = string
    tag_value = optional(string)
  }))
  default = {}
}

variable "abac_policies" {
  description = "Row filter / column mask policies attached at schema scope."
  type = map(object({
    type              = string
    principals        = list(string)
    except_principals = optional(list(string))
    comment           = optional(string)
    when_condition    = optional(string)
    match_columns = optional(list(object({
      condition = string
      alias     = string
    })))
    row_filter = optional(object({
      function_name = string
      using = optional(list(object({
        alias    = optional(string)
        constant = optional(string)
      })))
    }))
    column_mask = optional(object({
      function_name = string
      on_column     = string
      using = optional(list(object({
        alias    = optional(string)
        constant = optional(string)
      })))
    }))
  }))
  default = {}
}
