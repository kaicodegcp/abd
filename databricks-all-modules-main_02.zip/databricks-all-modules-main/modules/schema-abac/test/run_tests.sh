#!/bin/bash
# Run schema-abac plan-only tests with env vars from the repo secrets file.
# Usage: from repo root: ./modules/schema-abac/test/run_tests.sh
#        or from this dir: ./run_tests.sh
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../../.." && pwd)"
SECRETS="$REPO_ROOT/secrets"

if [ -f "$SECRETS" ]; then
  echo "Sourcing secrets from $SECRETS"
  # shellcheck source=/dev/null
  source "$SECRETS"
else
  echo "Note: secrets file not found at $SECRETS"
  echo "Tests need DATABRICKS_HOST, DATABRICKS_CLIENT_ID, DATABRICKS_CLIENT_SECRET in the environment."
fi

cd "$SCRIPT_DIR"
go test -v -run 'TestSchemaAbac' -timeout 10m -count=1 .
