package test

import (
	"fmt"
	"path/filepath"
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	common "github.com/sandbox45/databricks-all-modules/common"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func uniqueSchemaName(prefix string) string {
	return strings.ReplaceAll(common.GenerateUniqueTestID(prefix), "-", "_")
}

func baseVars(uniqueID, catalogName string) map[string]interface{} {
	return map[string]interface{}{
		"catalog_name": catalogName,
		"schema_name":  uniqueID,
	}
}

func planModule(t *testing.T, vars map[string]interface{}) string {
	t.Helper()
	opts := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: filepath.Join(".."),
		Vars:         vars,
		NoColor:      true,
	})
	terraform.Init(t, opts)
	return terraform.Plan(t, opts)
}

func planModuleExpectError(t *testing.T, vars map[string]interface{}) error {
	t.Helper()
	opts := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: filepath.Join(".."),
		Vars:         vars,
		NoColor:      true,
	})
	terraform.Init(t, opts)
	_, err := terraform.PlanE(t, opts)
	return err
}

// A row filter that takes no column arguments needs neither match_columns nor using.
// The alias-checking validations used to raise on the null instead of skipping it,
// which made this shape - filter_deny_all, or a UDF given only constants - impossible
// to express through the module.
func TestSchemaAbacBareRowFilterNeedsNoMatchColumns(t *testing.T) {
	common.SkipIfShortMode(t, "schema-abac bare row filter (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(uniqueSchemaName("sabac_bare"), defaults.CatalogName)
	vars["abac_policies"] = map[string]interface{}{
		"deny_all": map[string]interface{}{
			"type":              "POLICY_TYPE_ROW_FILTER",
			"principals":        []string{"account users"},
			"except_principals": []string{"svc_incident_response"},
			"row_filter": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.filter_deny_all", defaults.CatalogName),
			},
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)
	assert.Contains(t, plan, `databricks_policy_info.this["deny_all"]`, "a row filter with no column arguments must be accepted")
}

// An alias has to come from match_columns, so one with no match_columns at all is a
// typo that must still be caught.
func TestSchemaAbacRowFilterAliasWithoutMatchColumnsRejected(t *testing.T) {
	common.SkipIfShortMode(t, "schema-abac orphan row filter alias rejected (plan fail)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(uniqueSchemaName("sabac_orphan"), defaults.CatalogName)
	vars["abac_policies"] = map[string]interface{}{
		"scoped": map[string]interface{}{
			"type":       "POLICY_TYPE_ROW_FILTER",
			"principals": []string{"preexisting_ro_group"},
			"row_filter": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.has_scoped_attribute", defaults.CatalogName),
				"using":         []map[string]interface{}{{"alias": "orphan"}},
			},
		},
	}

	err := planModuleExpectError(t, vars)
	require.Error(t, err, "plan must fail when a using[].alias has no match_columns to resolve against")
}

// A schema-scoped policy covers every table in the schema. when_condition is the only
// way to narrow it to, say, tables tagged confidential.
func TestSchemaAbacWhenCondition(t *testing.T) {
	common.SkipIfShortMode(t, "schema-abac when_condition (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(uniqueSchemaName("sabac_when"), defaults.CatalogName)
	vars["abac_policies"] = map[string]interface{}{
		"mask_confidential": map[string]interface{}{
			"type":           "POLICY_TYPE_COLUMN_MASK",
			"principals":     []string{"preexisting_ro_group"},
			"when_condition": "has_tag_value('classification', 'confidential')",
			"match_columns": []map[string]interface{}{
				{"condition": "has_tag_value('classification', 'confidential')", "alias": "c"},
			},
			"column_mask": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.mask_value", defaults.CatalogName),
				"on_column":     "c",
			},
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)
	assert.Contains(t, plan, "when_condition", "when_condition must be passed through to the resource")
	assert.Contains(t, plan, "has_tag_value('classification', 'confidential')", "the condition expression must appear in plan")
}

// "" and null are different at the API: an empty condition is not "no condition".
func TestSchemaAbacWhenConditionEmptyRejected(t *testing.T) {
	common.SkipIfShortMode(t, "schema-abac empty when_condition rejected (plan fail)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(uniqueSchemaName("sabac_when_blank"), defaults.CatalogName)
	vars["abac_policies"] = map[string]interface{}{
		"filter_all": map[string]interface{}{
			"type":           "POLICY_TYPE_ROW_FILTER",
			"principals":     []string{"preexisting_ro_group"},
			"when_condition": "   ",
			"row_filter": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.filter_deny_all", defaults.CatalogName),
			},
		},
	}

	err := planModuleExpectError(t, vars)
	require.Error(t, err, "plan must fail when when_condition is blank or whitespace")
}

// when_condition and get_tag_value() read table tags, not column tags.
func TestSchemaAbacTableTagAssignment(t *testing.T) {
	common.SkipIfShortMode(t, "schema-abac table tag assignment (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	schemaName := uniqueSchemaName("sabac_tabletag")
	vars := baseVars(schemaName, defaults.CatalogName)
	vars["table_tag_assignments"] = map[string]interface{}{
		"transactions.classification": map[string]interface{}{
			"table":     "transactions",
			"tag_key":   "classification",
			"tag_value": "confidential",
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)
	assert.Contains(t, plan, `databricks_entity_tag_assignment.table["transactions.classification"]`, "table tag must be planned")
	assert.Contains(t, plan, `"tables"`, "entity_type must be tables, not columns")
	assert.Contains(t, plan, fmt.Sprintf("%s.%s.transactions", defaults.CatalogName, schemaName),
		"entity_name must be the table, with no column segment")
}

func TestSchemaAbacTableTagEmptyTableRejected(t *testing.T) {
	common.SkipIfShortMode(t, "schema-abac empty table tag table rejected (plan fail)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(uniqueSchemaName("sabac_tabletag_blank"), defaults.CatalogName)
	vars["table_tag_assignments"] = map[string]interface{}{
		"bad": map[string]interface{}{"table": "  ", "tag_key": "classification"},
	}

	err := planModuleExpectError(t, vars)
	require.Error(t, err, "plan must fail when a table tag's table is blank")
}

func TestSchemaAbacColumnMaskPolicy(t *testing.T) {
	common.SkipIfShortMode(t, "schema-abac column mask (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(uniqueSchemaName("sabac_mask"), defaults.CatalogName)
	vars["column_tag_assignments"] = map[string]interface{}{
		"transactions.ssn": map[string]interface{}{
			"table":     "transactions",
			"column":    "ssn",
			"tag_key":   "data_classification",
			"tag_value": "restricted",
		},
	}
	vars["abac_policies"] = map[string]interface{}{
		"mask_restricted_columns": map[string]interface{}{
			"type":       "POLICY_TYPE_COLUMN_MASK",
			"principals": []string{"preexisting_ro_group"},
			"match_columns": []map[string]interface{}{
				{"condition": "has_tag_value('data_classification', 'restricted')", "alias": "c"},
			},
			"column_mask": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.mask_redact_full", defaults.CatalogName),
				"on_column":     "c",
			},
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)
	assert.Contains(t, plan, `databricks_entity_tag_assignment.column["transactions.ssn"]`)
	assert.Contains(t, plan, `databricks_policy_info.this["mask_restricted_columns"]`)
	assert.Contains(t, plan, "POLICY_TYPE_COLUMN_MASK")
	assert.Contains(t, plan, `"SCHEMA"`, "on_securable_type must be SCHEMA")
	assert.Contains(t, plan, "preexisting_ro_group")
}

func TestSchemaAbacRowFilterPolicy(t *testing.T) {
	common.SkipIfShortMode(t, "schema-abac row filter (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(uniqueSchemaName("sabac_filter"), defaults.CatalogName)
	vars["column_tag_assignments"] = map[string]interface{}{
		"transactions.region": map[string]interface{}{
			"table":   "transactions",
			"column":  "region",
			"tag_key": "region",
		},
	}
	vars["abac_policies"] = map[string]interface{}{
		"filter_user_region": map[string]interface{}{
			"type":       "POLICY_TYPE_ROW_FILTER",
			"principals": []string{"preexisting_ro_group"},
			"match_columns": []map[string]interface{}{
				{"condition": "has_tag('region')", "alias": "region_col"},
			},
			"row_filter": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.filter_user_region", defaults.CatalogName),
				"using":         []map[string]interface{}{{"alias": "region_col"}},
			},
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)
	assert.Contains(t, plan, `databricks_policy_info.this["filter_user_region"]`)
	assert.Contains(t, plan, "POLICY_TYPE_ROW_FILTER")
	assert.Contains(t, plan, "filter_user_region")
}

func TestSchemaAbacTagAssignmentsOnly(t *testing.T) {
	common.SkipIfShortMode(t, "schema-abac tag assignments only (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(uniqueSchemaName("sabac_tagsonly"), defaults.CatalogName)
	vars["column_tag_assignments"] = map[string]interface{}{
		"transactions.ssn": map[string]interface{}{
			"table":     "transactions",
			"column":    "ssn",
			"tag_key":   "data_classification",
			"tag_value": "restricted",
		},
		"transactions.email": map[string]interface{}{
			"table":     "transactions",
			"column":    "email",
			"tag_key":   "data_classification",
			"tag_value": "confidential",
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)
	assert.Contains(t, plan, `databricks_entity_tag_assignment.column["transactions.ssn"]`)
	assert.Contains(t, plan, `databricks_entity_tag_assignment.column["transactions.email"]`)
	assert.NotContains(t, plan, "databricks_policy_info.this[")
}

func TestSchemaAbacMultiplePolicies(t *testing.T) {
	common.SkipIfShortMode(t, "schema-abac multiple policies (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(uniqueSchemaName("sabac_multi"), defaults.CatalogName)
	vars["abac_policies"] = map[string]interface{}{
		"mask_restricted_columns": map[string]interface{}{
			"type":       "POLICY_TYPE_COLUMN_MASK",
			"principals": []string{"preexisting_ro_group"},
			"match_columns": []map[string]interface{}{
				{"condition": "has_tag_value('data_classification', 'restricted')", "alias": "c"},
			},
			"column_mask": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.mask_redact_full", defaults.CatalogName),
				"on_column":     "c",
			},
		},
		"filter_user_region": map[string]interface{}{
			"type":       "POLICY_TYPE_ROW_FILTER",
			"principals": []string{"preexisting_ro_group"},
			"match_columns": []map[string]interface{}{
				{"condition": "has_tag('region')", "alias": "region_col"},
			},
			"row_filter": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.filter_user_region", defaults.CatalogName),
				"using":         []map[string]interface{}{{"alias": "region_col"}},
			},
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)
	assert.Contains(t, plan, `databricks_policy_info.this["mask_restricted_columns"]`)
	assert.Contains(t, plan, `databricks_policy_info.this["filter_user_region"]`)
}

func TestSchemaAbacExceptPrincipals(t *testing.T) {
	common.SkipIfShortMode(t, "schema-abac except principals (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(uniqueSchemaName("sabac_except"), defaults.CatalogName)
	vars["abac_policies"] = map[string]interface{}{
		"mask_restricted_columns_break_glass": map[string]interface{}{
			"type":              "POLICY_TYPE_COLUMN_MASK",
			"principals":        []string{"preexisting_ro_group"},
			"except_principals": []string{"svc_incident_response"},
			"match_columns": []map[string]interface{}{
				{"condition": "has_tag_value('data_classification', 'restricted')", "alias": "c"},
			},
			"column_mask": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.mask_redact_full", defaults.CatalogName),
				"on_column":     "c",
			},
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)
	assert.Contains(t, plan, "svc_incident_response")
	assert.Contains(t, plan, "POLICY_TYPE_COLUMN_MASK")
}

func TestSchemaAbacDisabled(t *testing.T) {
	common.SkipIfShortMode(t, "schema-abac disabled (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(uniqueSchemaName("sabac_off"), defaults.CatalogName)
	vars["enable_abac"] = false
	vars["column_tag_assignments"] = map[string]interface{}{
		"transactions.ssn": map[string]interface{}{
			"table":     "transactions",
			"column":    "ssn",
			"tag_key":   "data_classification",
			"tag_value": "restricted",
		},
	}
	vars["table_tag_assignments"] = map[string]interface{}{
		"transactions.classification": map[string]interface{}{
			"table":     "transactions",
			"tag_key":   "classification",
			"tag_value": "confidential",
		},
	}
	vars["abac_policies"] = map[string]interface{}{
		"mask_restricted_columns": map[string]interface{}{
			"type":       "POLICY_TYPE_COLUMN_MASK",
			"principals": []string{"preexisting_ro_group"},
			"match_columns": []map[string]interface{}{
				{"condition": "has_tag_value('data_classification', 'restricted')", "alias": "c"},
			},
			"column_mask": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.mask_redact_full", defaults.CatalogName),
				"on_column":     "c",
			},
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)
	assert.NotContains(t, plan, "databricks_entity_tag_assignment.column[", "no column tag assignments when disabled")
	assert.NotContains(t, plan, "databricks_entity_tag_assignment.table[", "no table tag assignments when disabled")
	assert.NotContains(t, plan, "databricks_policy_info.this[", "no policies when disabled")
}

func TestSchemaAbacPreserveTagsOnDisable(t *testing.T) {
	common.SkipIfShortMode(t, "schema-abac preserve tags on disable (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(uniqueSchemaName("sabac_preserve"), defaults.CatalogName)
	vars["enable_abac"] = false
	vars["preserve_tags_on_disable"] = true
	vars["column_tag_assignments"] = map[string]interface{}{
		"transactions.ssn": map[string]interface{}{
			"table":     "transactions",
			"column":    "ssn",
			"tag_key":   "data_classification",
			"tag_value": "restricted",
		},
	}
	vars["table_tag_assignments"] = map[string]interface{}{
		"transactions.classification": map[string]interface{}{
			"table":     "transactions",
			"tag_key":   "classification",
			"tag_value": "confidential",
		},
	}
	vars["abac_policies"] = map[string]interface{}{
		"mask_restricted_columns": map[string]interface{}{
			"type":       "POLICY_TYPE_COLUMN_MASK",
			"principals": []string{"preexisting_ro_group"},
			"match_columns": []map[string]interface{}{
				{"condition": "has_tag_value('data_classification', 'restricted')", "alias": "c"},
			},
			"column_mask": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.mask_redact_full", defaults.CatalogName),
				"on_column":     "c",
			},
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)
	assert.Contains(t, plan, `databricks_entity_tag_assignment.column["transactions.ssn"]`, "column tags must be preserved when preserve_tags_on_disable = true")
	assert.Contains(t, plan, `databricks_entity_tag_assignment.table["transactions.classification"]`, "table tags must be preserved on the same switch as column tags")
	assert.NotContains(t, plan, "databricks_policy_info.this[", "no policies when enable_abac = false")
}
