# =============================================================================
# Schema ABAC
# =============================================================================
# UC ABAC policies at SCHEMA scope. Covers every table in the schema; cannot
# be bypassed by table owners. Composes with modules/schema-rbac (same group
# display names in both modules' principal lists).
# Does NOT create the schema, governed tag vocabulary, UDFs, or groups.
# =============================================================================

locals {
  schema_full_name = "${var.catalog_name}.${var.schema_name}"

  # enable_abac gates policies; preserve_tags_on_disable keeps tags alive when policies are off.
  abac_policies          = var.enable_abac ? var.abac_policies : {}
  column_tag_assignments = (var.enable_abac || var.preserve_tags_on_disable) ? var.column_tag_assignments : {}
  table_tag_assignments  = (var.enable_abac || var.preserve_tags_on_disable) ? var.table_tag_assignments : {}
}

# -----------------------------------------------------------------------------
# Table tag assignments. These are what a policy's when_condition reads, and
# unlike column tags they inherit down from the parent schema and catalog.
# -----------------------------------------------------------------------------
resource "databricks_entity_tag_assignment" "table" {
  for_each = local.table_tag_assignments

  entity_type = "tables"
  entity_name = "${local.schema_full_name}.${each.value.table}"
  tag_key     = each.value.tag_key
  tag_value   = try(each.value.tag_value, null)
}

# -----------------------------------------------------------------------------
# Column tag assignments. Tag keys must already exist at account scope.
# -----------------------------------------------------------------------------
resource "databricks_entity_tag_assignment" "column" {
  for_each = local.column_tag_assignments

  entity_type = "columns"
  entity_name = "${local.schema_full_name}.${each.value.table}.${each.value.column}"
  tag_key     = each.value.tag_key
  tag_value   = try(each.value.tag_value, null)
}

# -----------------------------------------------------------------------------
# ABAC policies at schema scope. Cover every current and future table in the
# schema; cannot be bypassed by table owners.
# -----------------------------------------------------------------------------
resource "databricks_policy_info" "this" {
  for_each = local.abac_policies

  name                  = each.key
  on_securable_type     = "SCHEMA"
  on_securable_fullname = local.schema_full_name
  for_securable_type    = "TABLE"

  policy_type       = each.value.type
  to_principals     = each.value.principals
  except_principals = try(each.value.except_principals, null)
  comment           = each.value.comment != null ? each.value.comment : ""
  when_condition    = try(each.value.when_condition, null)
  match_columns     = try(each.value.match_columns, null)
  row_filter        = try(each.value.row_filter, null)
  column_mask       = try(each.value.column_mask, null)

  # Ordering only, not a guarantee: a tag assignment takes a few minutes to become
  # visible to policy evaluation, so verify with a query rather than assuming the
  # first apply is live. Until it is, the policy does not apply - it fails open.
  depends_on = [
    databricks_entity_tag_assignment.column,
    databricks_entity_tag_assignment.table,
  ]
}
