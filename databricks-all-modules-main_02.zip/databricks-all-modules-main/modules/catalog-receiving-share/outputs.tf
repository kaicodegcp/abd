output "catalog_id" {
  description = "The unique identifier for the receiving catalog"
  value       = databricks_catalog.receiving_catalog.id
}

output "catalog_name" {
  description = "The name of the receiving catalog"
  value       = databricks_catalog.receiving_catalog.name
}
