package test

import (
	"fmt"
	"path/filepath"
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	common "github.com/sandbox45/databricks-all-modules/common"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func uniqueTableName(prefix string) string {
	return strings.ReplaceAll(common.GenerateUniqueTestID(prefix), "-", "_")
}

func baseVars(catalogName, schemaName, tableName string) map[string]interface{} {
	return map[string]interface{}{
		"catalog_name": catalogName,
		"schema_name":  schemaName,
		"table_name":   tableName,
	}
}

func planModule(t *testing.T, vars map[string]interface{}) string {
	t.Helper()
	opts := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: filepath.Join(".."),
		Vars:         vars,
		NoColor:      true,
	})
	terraform.Init(t, opts)
	return terraform.Plan(t, opts)
}

func planModuleExpectError(t *testing.T, vars map[string]interface{}) error {
	t.Helper()
	opts := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: filepath.Join(".."),
		Vars:         vars,
		NoColor:      true,
	})
	terraform.Init(t, opts)
	_, err := terraform.PlanE(t, opts)
	return err
}

// Without when_condition a policy applies to everything in its scope, which is the
// whole point of a tag-driven design at schema and catalog scope.
func TestTableAbacWhenCondition(t *testing.T) {
	common.SkipIfShortMode(t, "table-abac when_condition (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	tableName := uniqueTableName("tabac_when")
	vars := baseVars(defaults.CatalogName, "payments", tableName)
	vars["abac_policies"] = map[string]interface{}{
		"mask_confidential": map[string]interface{}{
			"type":           "POLICY_TYPE_COLUMN_MASK",
			"principals":     []string{"payments_prod_ro"},
			"when_condition": "has_tag_value('classification', 'confidential')",
			"match_columns": []map[string]interface{}{
				{"condition": "has_tag_value('classification', 'confidential')", "alias": "c"},
			},
			"column_mask": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.mask_value", defaults.CatalogName),
				"on_column":     "c",
			},
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, "when_condition", "when_condition must be passed through to the resource")
	assert.Contains(t, plan, "has_tag_value('classification', 'confidential')", "the condition expression must appear in plan")
}

// A row filter that takes no column arguments needs neither match_columns nor using.
// The alias-checking validations used to raise on the null instead of skipping it,
// which made this shape - filter_deny_all, or a UDF given only constants - impossible
// to express through the module.
func TestTableAbacBareRowFilterNeedsNoMatchColumns(t *testing.T) {
	common.SkipIfShortMode(t, "table-abac bare row filter (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(defaults.CatalogName, "payments", uniqueTableName("tabac_bare"))
	vars["abac_policies"] = map[string]interface{}{
		"deny_all": map[string]interface{}{
			"type":              "POLICY_TYPE_ROW_FILTER",
			"principals":        []string{"account users"},
			"except_principals": []string{"svc_incident_response"},
			"row_filter": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.filter_deny_all", defaults.CatalogName),
			},
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)
	assert.Contains(t, plan, `databricks_policy_info.this["deny_all"]`, "a row filter with no column arguments must be accepted")
}

// Constants carry the scope, so there is still nothing for match_columns to alias.
func TestTableAbacConstantsOnlyRowFilterNeedsNoMatchColumns(t *testing.T) {
	common.SkipIfShortMode(t, "table-abac constants-only row filter (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(defaults.CatalogName, "payments", uniqueTableName("tabac_consts"))
	vars["abac_policies"] = map[string]interface{}{
		"scoped": map[string]interface{}{
			"type":       "POLICY_TYPE_ROW_FILTER",
			"principals": []string{"payments_prod_ro"},
			"row_filter": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.has_all_scoped_attributes", defaults.CatalogName),
				"using": []map[string]interface{}{
					{"constant": "dev"}, {"constant": "olympus"}, {"constant": "167969"},
					{"constant": "payments"}, {"constant": "-"}, {"constant": "-"},
				},
			},
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)
	assert.Contains(t, plan, `databricks_policy_info.this["scoped"]`, "a constants-only row filter must be accepted")
}

// An alias has to come from match_columns, so one with no match_columns at all is a
// typo that must still be caught.
func TestTableAbacRowFilterAliasWithoutMatchColumnsRejected(t *testing.T) {
	common.SkipIfShortMode(t, "table-abac orphan row filter alias rejected (plan fail)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(defaults.CatalogName, "payments", uniqueTableName("tabac_orphan"))
	vars["abac_policies"] = map[string]interface{}{
		"scoped": map[string]interface{}{
			"type":       "POLICY_TYPE_ROW_FILTER",
			"principals": []string{"payments_prod_ro"},
			"row_filter": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.has_scoped_attribute", defaults.CatalogName),
				"using":         []map[string]interface{}{{"alias": "orphan"}},
			},
		},
	}

	err := planModuleExpectError(t, vars)
	require.Error(t, err, "plan must fail when a using[].alias has no match_columns to resolve against")
}

func TestTableAbacWhenConditionOmittedStaysNull(t *testing.T) {
	common.SkipIfShortMode(t, "table-abac when_condition omitted (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	tableName := uniqueTableName("tabac_when_null")
	vars := baseVars(defaults.CatalogName, "payments", tableName)
	vars["abac_policies"] = map[string]interface{}{
		"filter_all": map[string]interface{}{
			"type":       "POLICY_TYPE_ROW_FILTER",
			"principals": []string{"payments_prod_ro"},
			"row_filter": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.filter_deny_all", defaults.CatalogName),
			},
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, `databricks_policy_info.this["filter_all"]`, "policy must still be planned without a condition")
}

// "" and null are different at the API: an empty condition is not "no condition".
func TestTableAbacWhenConditionEmptyRejected(t *testing.T) {
	common.SkipIfShortMode(t, "table-abac empty when_condition rejected (plan fail)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(defaults.CatalogName, "payments", uniqueTableName("tabac_when_blank"))
	vars["abac_policies"] = map[string]interface{}{
		"filter_all": map[string]interface{}{
			"type":           "POLICY_TYPE_ROW_FILTER",
			"principals":     []string{"payments_prod_ro"},
			"when_condition": "   ",
			"row_filter": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.filter_deny_all", defaults.CatalogName),
			},
		},
	}

	err := planModuleExpectError(t, vars)
	require.Error(t, err, "plan must fail when when_condition is blank or whitespace")
}

// when_condition and get_tag_value() read table tags, not column tags, so the module
// has to be able to set them.
func TestTableAbacTableTagAssignment(t *testing.T) {
	common.SkipIfShortMode(t, "table-abac table tag assignment (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	tableName := uniqueTableName("tabac_tabletag")
	vars := baseVars(defaults.CatalogName, "payments", tableName)
	vars["table_tag_assignments"] = map[string]interface{}{
		"classification": map[string]interface{}{
			"tag_key":   "classification",
			"tag_value": "confidential",
		},
		"pii": map[string]interface{}{
			"tag_key": "pii",
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, `databricks_entity_tag_assignment.table["classification"]`, "table tag must be planned")
	assert.Contains(t, plan, `databricks_entity_tag_assignment.table["pii"]`, "presence-only table tag must be planned")
	assert.Contains(t, plan, `"tables"`, "entity_type must be tables, not columns")
	assert.Contains(t, plan, fmt.Sprintf("%s.payments.%s", defaults.CatalogName, tableName),
		"entity_name must be the table, with no column segment")
}

func TestTableAbacTableTagEmptyTagKeyRejected(t *testing.T) {
	common.SkipIfShortMode(t, "table-abac empty table tag_key rejected (plan fail)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(defaults.CatalogName, "payments", uniqueTableName("tabac_tabletag_blank"))
	vars["table_tag_assignments"] = map[string]interface{}{
		"bad": map[string]interface{}{"tag_key": "   "},
	}

	err := planModuleExpectError(t, vars)
	require.Error(t, err, "plan must fail when a table tag_key is blank")
}

func TestTableAbacColumnMaskPolicy(t *testing.T) {
	common.SkipIfShortMode(t, "table-abac column mask (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	tableName := uniqueTableName("tabac_mask")
	vars := baseVars(defaults.CatalogName, "payments", tableName)
	vars["column_tag_assignments"] = map[string]interface{}{
		"ssn": map[string]interface{}{
			"column":    "ssn",
			"tag_key":   "data_classification",
			"tag_value": "restricted",
		},
	}
	vars["abac_policies"] = map[string]interface{}{
		"mask_legacy_pii": map[string]interface{}{
			"type":       "POLICY_TYPE_COLUMN_MASK",
			"principals": []string{"payments_prod_ro"},
			"comment":    "Legacy table uses format-preserving mask. Ref: JIRA-5678",
			"match_columns": []map[string]interface{}{
				{"condition": "has_tag_value('data_classification', 'restricted')", "alias": "c"},
			},
			"column_mask": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.mask_format_preserving", defaults.CatalogName),
				"on_column":     "c",
			},
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan, "terraform plan should produce output")

	assert.Contains(t, plan, `databricks_entity_tag_assignment.column["ssn"]`, "column tag must be planned")
	assert.Contains(t, plan, fmt.Sprintf("%s.payments.%s.ssn", defaults.CatalogName, tableName), "fully-qualified entity name must appear in plan")
	assert.Contains(t, plan, `databricks_policy_info.this["mask_legacy_pii"]`, "column mask policy must be planned")
	assert.Contains(t, plan, "POLICY_TYPE_COLUMN_MASK", "policy type must appear in plan")
	assert.Contains(t, plan, "JIRA-5678", "policy comment must appear in plan")
	assert.Contains(t, plan, `"TABLE"`, "on_securable_type must be TABLE")
}

func TestTableAbacRowFilterPolicy(t *testing.T) {
	common.SkipIfShortMode(t, "table-abac row filter (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	tableName := uniqueTableName("tabac_filter")
	vars := baseVars(defaults.CatalogName, "payments", tableName)
	vars["column_tag_assignments"] = map[string]interface{}{
		"region": map[string]interface{}{
			"column":  "region",
			"tag_key": "region",
		},
	}
	vars["abac_policies"] = map[string]interface{}{
		"filter_user_region": map[string]interface{}{
			"type":       "POLICY_TYPE_ROW_FILTER",
			"principals": []string{"payments_prod_ro"},
			"match_columns": []map[string]interface{}{
				{"condition": "has_tag('region')", "alias": "region_col"},
			},
			"row_filter": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.filter_user_region", defaults.CatalogName),
				"using":         []map[string]interface{}{{"alias": "region_col"}},
			},
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, `databricks_entity_tag_assignment.column["region"]`, "presence-only tag must be planned")
	assert.Contains(t, plan, `databricks_policy_info.this["filter_user_region"]`, "row filter policy must be planned")
	assert.Contains(t, plan, "POLICY_TYPE_ROW_FILTER", "policy type must appear in plan")
	assert.Contains(t, plan, fmt.Sprintf("%s.payments.%s.region", defaults.CatalogName, tableName), "fully-qualified entity name must appear in plan")
}

func TestTableAbacMultipleColumnsTagged(t *testing.T) {
	common.SkipIfShortMode(t, "table-abac multiple column tags (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	tableName := uniqueTableName("tabac_multicol")
	vars := baseVars(defaults.CatalogName, "payments", tableName)
	vars["column_tag_assignments"] = map[string]interface{}{
		"ssn": map[string]interface{}{
			"column":    "ssn",
			"tag_key":   "data_classification",
			"tag_value": "restricted",
		},
		"account_number": map[string]interface{}{
			"column":    "account_number",
			"tag_key":   "data_classification",
			"tag_value": "restricted",
		},
		"region": map[string]interface{}{
			"column":  "region",
			"tag_key": "region",
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, `databricks_entity_tag_assignment.column["ssn"]`, "ssn tag must be planned")
	assert.Contains(t, plan, `databricks_entity_tag_assignment.column["account_number"]`, "account_number tag must be planned")
	assert.Contains(t, plan, `databricks_entity_tag_assignment.column["region"]`, "region presence-only tag must be planned")
}

func TestTableAbacExceptPrincipals(t *testing.T) {
	common.SkipIfShortMode(t, "table-abac except principals (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	tableName := uniqueTableName("tabac_except")
	vars := baseVars(defaults.CatalogName, "payments", tableName)
	vars["abac_policies"] = map[string]interface{}{
		"mask_legacy_pii": map[string]interface{}{
			"type":              "POLICY_TYPE_COLUMN_MASK",
			"principals":        []string{"payments_prod_ro"},
			"except_principals": []string{"svc_incident_response"},
			"match_columns": []map[string]interface{}{
				{"condition": "has_tag_value('data_classification', 'restricted')", "alias": "c"},
			},
			"column_mask": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.mask_redact_full", defaults.CatalogName),
				"on_column":     "c",
			},
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, "svc_incident_response", "break-glass principal must appear in plan")
	assert.Contains(t, plan, "payments_prod_ro", "primary principal must appear in plan")
}

func TestTableAbacDisabled(t *testing.T) {
	common.SkipIfShortMode(t, "table-abac disabled (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	tableName := uniqueTableName("tabac_off")
	vars := baseVars(defaults.CatalogName, "payments", tableName)
	vars["enable_abac"] = false
	vars["column_tag_assignments"] = map[string]interface{}{
		"ssn": map[string]interface{}{
			"column":    "ssn",
			"tag_key":   "data_classification",
			"tag_value": "restricted",
		},
	}
	vars["table_tag_assignments"] = map[string]interface{}{
		"classification": map[string]interface{}{
			"tag_key":   "classification",
			"tag_value": "confidential",
		},
	}
	vars["abac_policies"] = map[string]interface{}{
		"mask_legacy_pii": map[string]interface{}{
			"type":       "POLICY_TYPE_COLUMN_MASK",
			"principals": []string{"payments_prod_ro"},
			"match_columns": []map[string]interface{}{
				{"condition": "has_tag_value('data_classification', 'restricted')", "alias": "c"},
			},
			"column_mask": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.mask_redact_full", defaults.CatalogName),
				"on_column":     "c",
			},
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)

	assert.NotContains(t, plan, "databricks_entity_tag_assignment.column[", "no column tag assignments when disabled")
	assert.NotContains(t, plan, "databricks_entity_tag_assignment.table[", "no table tag assignments when disabled")
	assert.NotContains(t, plan, "databricks_policy_info.this[", "no policies when disabled")
}

func TestTableAbacPreserveTagsOnDisable(t *testing.T) {
	common.SkipIfShortMode(t, "table-abac preserve tags on disable (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	tableName := uniqueTableName("tabac_preserve")
	vars := baseVars(defaults.CatalogName, "payments", tableName)
	vars["enable_abac"] = false
	vars["preserve_tags_on_disable"] = true
	vars["column_tag_assignments"] = map[string]interface{}{
		"ssn": map[string]interface{}{
			"column":    "ssn",
			"tag_key":   "data_classification",
			"tag_value": "restricted",
		},
	}
	vars["table_tag_assignments"] = map[string]interface{}{
		"classification": map[string]interface{}{
			"tag_key":   "classification",
			"tag_value": "confidential",
		},
	}
	vars["abac_policies"] = map[string]interface{}{
		"mask_legacy_pii": map[string]interface{}{
			"type":       "POLICY_TYPE_COLUMN_MASK",
			"principals": []string{"payments_prod_ro"},
			"match_columns": []map[string]interface{}{
				{"condition": "has_tag_value('data_classification', 'restricted')", "alias": "c"},
			},
			"column_mask": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.mask_redact_full", defaults.CatalogName),
				"on_column":     "c",
			},
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, `databricks_entity_tag_assignment.column["ssn"]`, "column tags must be preserved when preserve_tags_on_disable = true")
	assert.Contains(t, plan, `databricks_entity_tag_assignment.table["classification"]`, "table tags must be preserved on the same switch as column tags")
	assert.NotContains(t, plan, "databricks_policy_info.this[", "no policies when enable_abac = false")
}
