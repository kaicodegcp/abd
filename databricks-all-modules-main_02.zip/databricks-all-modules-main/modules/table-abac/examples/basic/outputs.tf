output "table_full_name" {
  value = module.table_abac.table_full_name
}

output "abac_enabled" {
  value = module.table_abac.abac_enabled
}

output "policy_ids" {
  value = module.table_abac.policy_ids
}

output "tag_assignment_ids" {
  value = module.table_abac.tag_assignment_ids
}
