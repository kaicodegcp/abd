variable "catalog_name" {
  description = "Name of the parent catalog."
  type        = string
}

variable "schema_name" {
  description = "Name of the parent schema."
  type        = string
}

variable "table_name" {
  description = "Name of the table to attach ABAC policies to."
  type        = string
}

variable "enable_abac" {
  description = "Master switch. Set to false for staged rollout."
  type        = bool
  default     = true
}

variable "preserve_tags_on_disable" {
  description = "When enable_abac = false, keep column tag assignments alive."
  type        = bool
  default     = false
}

variable "column_tag_assignments" {
  description = "Governed-tag assignments for columns on this table."
  type = map(object({
    column    = string
    tag_key   = string
    tag_value = optional(string)
  }))
  default = {}
}

variable "table_tag_assignments" {
  description = "Governed-tag assignments for the table itself. These are the tags a when_condition reads."
  type = map(object({
    tag_key   = string
    tag_value = optional(string)
  }))
  default = {}
}

variable "abac_policies" {
  description = "ABAC policies attached at table scope."
  type = map(object({
    type              = string
    principals        = list(string)
    except_principals = optional(list(string))
    comment           = optional(string)
    when_condition    = optional(string)
    match_columns = optional(list(object({
      condition = string
      alias     = string
    })))
    row_filter = optional(object({
      function_name = string
      using = optional(list(object({
        alias    = optional(string)
        constant = optional(string)
      })))
    }))
    column_mask = optional(object({
      function_name = string
      on_column     = string
      using = optional(list(object({
        alias    = optional(string)
        constant = optional(string)
      })))
    }))
  }))
  default = {}
}
