# =============================================================================
# Table ABAC
# =============================================================================
# UC ABAC policies at TABLE scope. SCOPE CONFLICT WARNING: UC raises
# UC_ABAC_MULTIPLE_ROW_FILTERS or UC_ABAC_MULTIPLE_MASKS if a broader-scoped
# policy of the same type resolves on this table (abac-strategy.md section 11.9).
# Does NOT create the table, schema, governed tag vocabulary, UDFs, or groups.
# =============================================================================

locals {
  table_full_name = "${var.catalog_name}.${var.schema_name}.${var.table_name}"

  # enable_abac gates policies; preserve_tags_on_disable keeps tags alive when policies are off.
  abac_policies          = var.enable_abac ? var.abac_policies : {}
  column_tag_assignments = (var.enable_abac || var.preserve_tags_on_disable) ? var.column_tag_assignments : {}
  table_tag_assignments  = (var.enable_abac || var.preserve_tags_on_disable) ? var.table_tag_assignments : {}
}

# -----------------------------------------------------------------------------
# Table tag assignments. These are what a policy's when_condition reads, and
# unlike column tags they inherit down from the parent schema and catalog.
# -----------------------------------------------------------------------------
resource "databricks_entity_tag_assignment" "table" {
  for_each = local.table_tag_assignments

  entity_type = "tables"
  entity_name = local.table_full_name
  tag_key     = each.value.tag_key
  tag_value   = try(each.value.tag_value, null)
}

# -----------------------------------------------------------------------------
# Column tag assignments. entity_name is <catalog>.<schema>.<table>.<column>.
# Table is known, so only column is required in the input.
# -----------------------------------------------------------------------------
resource "databricks_entity_tag_assignment" "column" {
  for_each = local.column_tag_assignments

  entity_type = "columns"
  entity_name = "${local.table_full_name}.${each.value.column}"
  tag_key     = each.value.tag_key
  tag_value   = try(each.value.tag_value, null)
}

# -----------------------------------------------------------------------------
# ABAC policies at table scope. Apply only to this table; cannot be bypassed
# by the table owner but do not affect other tables in the schema.
# -----------------------------------------------------------------------------
resource "databricks_policy_info" "this" {
  for_each = local.abac_policies

  name                  = each.key
  on_securable_type     = "TABLE"
  on_securable_fullname = local.table_full_name
  for_securable_type    = "TABLE"

  policy_type       = each.value.type
  to_principals     = each.value.principals
  except_principals = try(each.value.except_principals, null)
  comment           = each.value.comment != null ? each.value.comment : ""
  when_condition    = try(each.value.when_condition, null)
  match_columns     = try(each.value.match_columns, null)
  row_filter        = try(each.value.row_filter, null)
  column_mask       = try(each.value.column_mask, null)

  # Ordering only, not a guarantee: a tag assignment takes a few minutes to become
  # visible to policy evaluation, so verify with a query rather than assuming the
  # first apply is live. Until it is, the policy does not apply - it fails open.
  depends_on = [
    databricks_entity_tag_assignment.column,
    databricks_entity_tag_assignment.table,
  ]
}
