# =============================================================================
# Table ABAC - Outputs
# =============================================================================

output "table_full_name" {
  description = "Fully qualified table name (<catalog>.<schema>.<table>) the policies attach to."
  value       = local.table_full_name
}

output "abac_enabled" {
  description = "Whether ABAC enforcement is active for this module instance."
  value       = var.enable_abac
}

output "policy_ids" {
  description = "Map of policy name -> resource ID for audit traceability. Empty when enable_abac = false or abac_policies = {}."
  value       = { for k, p in databricks_policy_info.this : k => p.id }
}

output "tag_assignment_ids" {
  description = "Map of assignment key -> composite resource identifier (<entity_type>|<entity_name>|<tag_key>) for audit traceability. Empty when enable_abac = false or column_tag_assignments = {}."
  value = {
    for k, t in databricks_entity_tag_assignment.column :
    k => "${t.entity_type}|${t.entity_name}|${t.tag_key}"
  }
}

output "table_tag_assignment_ids" {
  description = "Map of assignment key -> composite resource identifier (<entity_type>|<entity_name>|<tag_key>) for the table-level tags a when_condition reads. Kept separate from tag_assignment_ids because the two inputs are keyed independently. Empty when enable_abac = false or table_tag_assignments = {}."
  value = {
    for k, t in databricks_entity_tag_assignment.table :
    k => "${t.entity_type}|${t.entity_name}|${t.tag_key}"
  }
}
