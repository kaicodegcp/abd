package test

import (
	"testing"

	common "github.com/sandbox45/databricks-all-modules/common"
	"github.com/stretchr/testify/assert"
)

func TestNetworkConnectivityConfigModule(t *testing.T) {
	defaults := common.GetTestDefaults()
	uniqueID := common.GenerateUniqueTestID("ncc")

	config := common.ModuleTestConfig{
		ModuleName:      "mws-network-connectivity-config",
		TestDescription: "Tests Databricks Network Connectivity Configuration module (account-level)",
		RequiredVars: map[string]interface{}{
			"name":   uniqueID,
			"region": defaults.AWSRegion,
		},
		ExpectedOutputs: []string{
			"network_connectivity_config_id",
			"id",
			"egress_config",
		},
		SkipDestroy: true,
	}

	common.TestModuleWithConfig(t, config)
}

func TestNetworkConnectivityConfigModuleInputValidation(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("ncc-inputs")

	config := common.ModuleTestConfig{
		ModuleName:      "mws-network-connectivity-config",
		ModulePath:      "..",
		TestDescription: "Validates network connectivity config module required inputs",
		RequiredVars: map[string]interface{}{
			"name":   uniqueID,
			"region": "us-west-2",
		},
	}

	opts := common.GetTestTerraformOptions(t, config)

	t.Run("ValidateRequiredInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})

	t.Run("ValidateInputValues", func(t *testing.T) {
		assert.Equal(t, "us-west-2", opts.Vars["region"])
		assert.Contains(t, opts.Vars["name"], "ncc-inputs")
		t.Log("Network connectivity config inputs validated")
	})
}

func TestNetworkConnectivityConfigModuleMinimal(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("ncc-min")

	config := common.ModuleTestConfig{
		ModuleName:      "mws-network-connectivity-config",
		TestDescription: "Tests NCC module with minimal configuration",
		RequiredVars: map[string]interface{}{
			"name":   uniqueID,
			"region": "us-east-1",
		},
		ExpectedOutputs: []string{
			"network_connectivity_config_id",
			"id",
		},
		SkipDestroy: true,
	}

	common.TestModuleWithConfig(t, config)
}
