output "schema_full_name" {
  description = "Fully qualified schema name (catalog.schema)."
  value       = module.security_udf_pack.schema_full_name
}

output "setup_job_id" {
  description = "Job ID to run after apply to materialize the UDFs in Unity Catalog. Function name outputs are only available after this job completes successfully."
  value       = module.security_udf_pack.setup_job_id
}

output "setup_notebook_path" {
  description = "Workspace path of the UDF setup notebook."
  value       = module.security_udf_pack.setup_notebook_path
}

output "mask_redact_all" {
  description = "Intended fully qualified name of mask_redact_all. The function exists only after the setup job completes successfully."
  value       = module.security_udf_pack.mask_redact_all
}

output "mask_keep_last4" {
  description = "Intended fully qualified name of mask_keep_last4. The function exists only after the setup job completes successfully."
  value       = module.security_udf_pack.mask_keep_last4
}

output "mask_keep_first4" {
  description = "Intended fully qualified name of mask_keep_first4. The function exists only after the setup job completes successfully."
  value       = module.security_udf_pack.mask_keep_first4
}

output "mask_email" {
  description = "Intended fully qualified name of mask_email. The function exists only after the setup job completes successfully."
  value       = module.security_udf_pack.mask_email
}

output "mask_ssn" {
  description = "Intended fully qualified name of mask_ssn. The function exists only after the setup job completes successfully."
  value       = module.security_udf_pack.mask_ssn
}

output "mask_phone" {
  description = "Intended fully qualified name of mask_phone. The function exists only after the setup job completes successfully."
  value       = module.security_udf_pack.mask_phone
}

output "mask_dob" {
  description = "Intended fully qualified name of mask_dob. For STRING-typed DOB columns. The function exists only after the setup job completes successfully."
  value       = module.security_udf_pack.mask_dob
}

output "mask_dob_date" {
  description = "Intended fully qualified name of mask_dob_date. For DATE-typed DOB columns. The function exists only after the setup job completes successfully."
  value       = module.security_udf_pack.mask_dob_date
}

output "mask_name" {
  description = "Intended fully qualified name of mask_name. The function exists only after the setup job completes successfully."
  value       = module.security_udf_pack.mask_name
}

output "rowfilter_deny_all" {
  description = "Intended fully qualified name of rowfilter_deny_all. The function exists only after the setup job completes successfully."
  value       = module.security_udf_pack.rowfilter_deny_all
}

output "rowfilter_attribute" {
  description = "Intended fully qualified name of rowfilter_attribute. The function exists only after the setup job completes successfully."
  value       = module.security_udf_pack.rowfilter_attribute
}

output "rowfilter_attributes_and" {
  description = "Intended fully qualified name of rowfilter_attributes_and. The function exists only after the setup job completes successfully."
  value       = module.security_udf_pack.rowfilter_attributes_and
}

output "rowfilter_dimension" {
  description = "Intended fully qualified name of rowfilter_dimension. The function exists only after the setup job completes successfully."
  value       = module.security_udf_pack.rowfilter_dimension
}

output "rowfilter_hierarchy" {
  description = "Intended fully qualified name of rowfilter_hierarchy. The function exists only after the setup job completes successfully."
  value       = module.security_udf_pack.rowfilter_hierarchy
}

output "mask_any_type" {
  description = "Intended fully qualified name of mask_any_type. The function exists only after the setup job completes successfully."
  value       = module.security_udf_pack.mask_any_type
}

output "mask_by_classification" {
  description = "Intended fully qualified name of mask_by_classification. The function exists only after the setup job completes successfully."
  value       = module.security_udf_pack.mask_by_classification
}

output "mask_unless_entitled" {
  description = "Intended fully qualified name of mask_unless_entitled. The function exists only after the setup job completes successfully."
  value       = module.security_udf_pack.mask_unless_entitled
}

output "grant_ids" {
  description = "Map of principal to grant resource ID."
  value       = module.security_udf_pack.grant_ids
}
