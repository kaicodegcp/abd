variable "catalog_name" {
  description = "Name of the Unity Catalog catalog where the security functions schema will be created."
  type        = string
}

variable "schema_name" {
  description = "Name of the schema to create within the catalog. Defaults to 'security_functions'."
  type        = string
  default     = "security_functions"
}

# Reference values for the abac_scope output only, not bound into the UDF bodies.

variable "sdlc" {
  description = "SDLC value for abac_scope, e.g. dev."
  type        = string
  default     = null
}

variable "workspace_name" {
  description = "Logical workspace (program) name for abac_scope, e.g. olympus."
  type        = string
  default     = null
}

variable "csi" {
  description = "CSI value for abac_scope, e.g. 167969."
  type        = string
  default     = null
}

variable "comment" {
  description = "Optional free-text description attached to the security functions schema."
  type        = string
  default     = "Standard ABAC governance UDFs for column masking and row filtering."
}

variable "force_destroy" {
  description = "If true, allows Terraform to delete the schema even when it contains functions."
  type        = bool
  default     = false
}

variable "owner" {
  description = "Optional schema owner. Defaults to the Terraform identity when not set. Does not affect function ownership; use function_owner_principal for that."
  type        = string
  default     = null
}

variable "notebook_base_path" {
  description = "Workspace folder where the UDF setup notebook is deployed."
  type        = string
  default     = "/security-udf-pack"
}

variable "existing_cluster_id" {
  description = "Optional existing cluster ID for the setup job. When null, the job uses serverless compute; serverless Jobs must be enabled and permitted in the target workspace. Any supplied cluster must support Unity Catalog."
  type        = string
  default     = null
}

variable "run_as_service_principal_application_id" {
  description = "Application (client) ID of the service principal that runs the setup job. Recommended for production."
  type        = string
  default     = null
}

variable "function_owner_principal" {
  description = "Principal (group or service principal) to set as owner of every deployed UDF. For repeated deployments to succeed, the run-as service principal must remain the UDF owner or be a member of this owner group."
  type        = string
  default     = null
}

variable "grants" {
  description = "Schema-level grants for the UDF schema. Principals must already hold USE_CATALOG on the parent catalog. For every principal supplied here, this module must be the sole Terraform owner of that principal's grants on this schema."
  type = list(object({
    principal  = string
    privileges = list(string)
  }))
  default = []
}

variable "udf_pack_version" {
  description = "Version of the UDF pack. Applied as a job tag and printed in the setup notebook output."
  type        = string
  default     = "1.1.0"
}

variable "tags" {
  description = "Tags applied to the setup job for cost tracking and governance."
  type        = map(string)
  default     = {}
}
