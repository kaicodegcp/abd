provider "databricks" {}

module "security_udf_pack" {
  source = "../.."

  catalog_name                            = var.catalog_name
  schema_name                             = var.schema_name
  sdlc                                    = var.sdlc
  workspace_name                          = var.workspace_name
  csi                                     = var.csi
  comment                                 = var.comment
  owner                                   = var.owner
  force_destroy                           = var.force_destroy
  notebook_base_path                      = var.notebook_base_path
  existing_cluster_id                     = var.existing_cluster_id
  run_as_service_principal_application_id = var.run_as_service_principal_application_id
  function_owner_principal                = var.function_owner_principal
  udf_pack_version                        = var.udf_pack_version
  grants                                  = var.grants
  tags                                    = var.tags
}
