package test

import (
	"encoding/base64"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	common "github.com/sandbox45/databricks-all-modules/common"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func notebookSource(t *testing.T, plan string) string {
	t.Helper()

	const marker = `content_base64 = "`
	start := strings.Index(plan, marker)
	require.GreaterOrEqual(t, start, 0, "plan must contain notebook content_base64")

	rest := plan[start+len(marker):]
	end := strings.Index(rest, `"`)
	require.GreaterOrEqual(t, end, 0, "content_base64 value must be terminated")

	decoded, err := base64.StdEncoding.DecodeString(rest[:end])
	require.NoError(t, err, "content_base64 must decode")

	return string(decoded)
}

func uniqueSchemaName(prefix string) string {
	return strings.ReplaceAll(common.GenerateUniqueTestID(prefix), "-", "_")
}

func planPack(t *testing.T, vars map[string]interface{}) string {
	t.Helper()
	opts := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: filepath.Join(".."),
		Vars:         vars,
		NoColor:      true,
	})
	terraform.Init(t, opts)
	return terraform.Plan(t, opts)
}

func planPackExpectError(t *testing.T, vars map[string]interface{}) error {
	t.Helper()
	opts := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: filepath.Join(".."),
		Vars:         vars,
		NoColor:      true,
	})
	terraform.Init(t, opts)
	_, err := terraform.PlanE(t, opts)
	return err
}

func scopeVars() map[string]interface{} {
	return map[string]interface{}{
		"sdlc":           "dev",
		"workspace_name": "olympus",
		"csi":            "167969",
	}
}

func baseVars(catalogName, schemaName string) map[string]interface{} {
	vars := scopeVars()
	vars["catalog_name"] = catalogName
	vars["schema_name"] = schemaName
	return vars
}

func TestUdfPackSchemaAndNotebookAndJob(t *testing.T) {
	common.SkipIfShortMode(t, "udf pack core resources (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	schemaName := uniqueSchemaName("sec_udfs")

	vars := baseVars(defaults.CatalogName, schemaName)

	plan := planPack(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, "databricks_schema.this", "schema must be planned")
	assert.Contains(t, plan, "databricks_notebook.udf_setup", "setup notebook must be planned")
	assert.Contains(t, plan, "databricks_job.udf_setup", "setup job must be planned")
	assert.NotContains(t, plan, "databricks_grant.this", "no grants expected with empty grants list")
}

func TestUdfPackDefaultSchemaName(t *testing.T) {
	common.SkipIfShortMode(t, "udf pack default schema name (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()

	vars := scopeVars()
	vars["catalog_name"] = defaults.CatalogName

	plan := planPack(t, vars)
	require.NotEmpty(t, plan)

	// "security_functions" is also a substring of the notebook and job names, so assert on the notebook.
	assert.Contains(t, notebookSource(t, plan), `schema  = "security_functions"`,
		"default schema name must be security")
}

func TestUdfPackCustomSchemaName(t *testing.T) {
	common.SkipIfShortMode(t, "udf pack custom schema name (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	schemaName := uniqueSchemaName("custom_sec")

	vars := baseVars(defaults.CatalogName, schemaName)

	plan := planPack(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, schemaName, "custom schema name must appear in plan")
}

func TestUdfPackNotebookContainsCatalogAndSchema(t *testing.T) {
	common.SkipIfShortMode(t, "udf pack notebook content baked in (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	schemaName := uniqueSchemaName("sec_nb_content")

	vars := baseVars(defaults.CatalogName, schemaName)

	plan := planPack(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, defaults.CatalogName, "catalog name must be baked into notebook content")
	assert.Contains(t, plan, schemaName, "schema name must be baked into notebook content")
}

func TestUdfPackJobNameIncludesCatalogAndSchema(t *testing.T) {
	common.SkipIfShortMode(t, "udf pack job name includes catalog and schema (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	schemaName := uniqueSchemaName("sec_job_name")

	vars := baseVars(defaults.CatalogName, schemaName)

	plan := planPack(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, "security-udf-pack-"+defaults.CatalogName+"-"+schemaName, "job name must include both catalog and schema name")
}

func TestUdfPackWithGrants(t *testing.T) {
	common.SkipIfShortMode(t, "udf pack with grants (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	schemaName := uniqueSchemaName("sec_grants")

	vars := baseVars(defaults.CatalogName, schemaName)
	vars["grants"] = []map[string]interface{}{
		{"principal": "data-analysts-grp", "privileges": []string{"USE_SCHEMA", "EXECUTE"}},
		{"principal": "data-engineers-grp", "privileges": []string{"USE_SCHEMA", "EXECUTE", "CREATE_FUNCTION"}},
	}

	plan := planPack(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, `databricks_grant.this["data-analysts-grp"]`, "analyst grant must be planned")
	assert.Contains(t, plan, `databricks_grant.this["data-engineers-grp"]`, "engineer grant must be planned")
	assert.Contains(t, plan, "EXECUTE", "EXECUTE privilege must appear in plan")
	assert.Contains(t, plan, "CREATE_FUNCTION", "CREATE_FUNCTION privilege must appear in plan")
}

func TestUdfPackNoGrantsWhenEmpty(t *testing.T) {
	common.SkipIfShortMode(t, "udf pack no grants when list is empty (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	schemaName := uniqueSchemaName("sec_no_grants")

	vars := baseVars(defaults.CatalogName, schemaName)
	vars["grants"] = []map[string]interface{}{}

	plan := planPack(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, "databricks_schema.this", "schema must still be planned")
	assert.NotContains(t, plan, "databricks_grant.this", "no grant resources expected")
}

func TestUdfPackGrantDuplicatePrincipalRejected(t *testing.T) {
	common.SkipIfShortMode(t, "udf pack duplicate principal validation (plan fail)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	schemaName := uniqueSchemaName("sec_dup_principal")

	vars := baseVars(defaults.CatalogName, schemaName)
	vars["grants"] = []map[string]interface{}{
		{"principal": "analysts-grp", "privileges": []string{"EXECUTE"}},
		{"principal": "analysts-grp", "privileges": []string{"USE_SCHEMA"}},
	}

	err := planPackExpectError(t, vars)
	require.Error(t, err, "plan must fail when a principal appears more than once in grants")
}

func TestUdfPackGrantEmptyPrivilegesRejected(t *testing.T) {
	common.SkipIfShortMode(t, "udf pack empty privileges validation (plan fail)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	schemaName := uniqueSchemaName("sec_empty_privs")

	vars := baseVars(defaults.CatalogName, schemaName)
	vars["grants"] = []map[string]interface{}{
		{"principal": "analysts-grp", "privileges": []string{}},
	}

	err := planPackExpectError(t, vars)
	require.Error(t, err, "plan must fail when privileges list is empty")
}

func TestUdfPackNotebookPathIncludesCatalogAndSchema(t *testing.T) {
	common.SkipIfShortMode(t, "udf pack notebook path includes catalog and schema (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	schemaName := uniqueSchemaName("sec_nb_path")

	vars := baseVars(defaults.CatalogName, schemaName)

	plan := planPack(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, defaults.CatalogName+"-"+schemaName+"-udf-pack-setup", "notebook path must include both catalog and schema name")
}

func TestUdfPackCustomNotebookBasePath(t *testing.T) {
	common.SkipIfShortMode(t, "udf pack custom notebook base path (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	schemaName := uniqueSchemaName("sec_nb_base")

	vars := baseVars(defaults.CatalogName, schemaName)
	vars["notebook_base_path"] = "/Repos/data-governance/security-udfs"

	plan := planPack(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, "/Repos/data-governance/security-udfs", "custom notebook base path must appear in plan")
}

func TestUdfPackExistingClusterIdPassedToJob(t *testing.T) {
	common.SkipIfShortMode(t, "udf pack cluster id in job (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	schemaName := uniqueSchemaName("sec_cluster")

	vars := baseVars(defaults.CatalogName, schemaName)
	vars["existing_cluster_id"] = "0531-111422-abc123"

	plan := planPack(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, "0531-111422-abc123", "cluster ID must appear in job plan")
}

// The original pack. These stay defined so a policy already bound to one of them keeps resolving.
var legacyUdfNames = []string{
	"mask_redact_all", "mask_keep_last4", "mask_keep_first4",
	"mask_email", "mask_ssn", "mask_phone", "mask_dob", "mask_dob_date",
	"mask_name", "rowfilter_deny_all",
}

var frameworkUdfNames = []string{
	"rowfilter_attribute", "rowfilter_attributes_and",
	"rowfilter_dimension", "rowfilter_dimensions_and", "rowfilter_hierarchy",
	"mask_any_type", "mask_by_classification", "mask_unless_entitled",
	"mask_partial_unless_entitled",
	"entitled_to_attributes", "entitled_to_dimensions",
}

func TestUdfPackDefinesLegacyAndFrameworkUdfs(t *testing.T) {
	common.SkipIfShortMode(t, "udf pack defines the legacy and framework UDFs (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_all_udfs")))
	require.NotEmpty(t, plan)

	source := notebookSource(t, plan)

	for _, udfName := range legacyUdfNames {
		assert.Contains(t, source, "FUNCTION {fqn}."+udfName+"(",
			"legacy UDF must still be defined: "+udfName)
	}
	for _, udfName := range frameworkUdfNames {
		assert.Contains(t, source, "FUNCTION {fqn}."+udfName+"(",
			"notebook must define UDF: "+udfName)
	}

	defined := regexp.MustCompile(`CREATE OR REPLACE FUNCTION \{fqn\}\.(\w+)\(`).FindAllString(source, -1)
	assert.Len(t, defined, len(legacyUdfNames)+len(frameworkUdfNames),
		"the pack is the legacy UDFs plus the framework UDFs, with nothing dropped")
}

// The module owns only the functions it creates. It must never emit SQL that destroys anything,
// so that deploying it can never remove a function a live policy still binds.
func TestUdfPackEmitsNoDestructiveSql(t *testing.T) {
	common.SkipIfShortMode(t, "udf pack emits no destructive SQL (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_additive")))
	require.NotEmpty(t, plan)

	source := notebookSource(t, plan)

	for _, statement := range []string{"DROP FUNCTION", "DROP TABLE", "DROP SCHEMA", "DROP VIEW"} {
		assert.NotContains(t, source, statement, "the setup notebook must stay additive: "+statement)
	}
}

func TestUdfPackMaxConcurrentRunsIsOne(t *testing.T) {
	common.SkipIfShortMode(t, "udf pack max_concurrent_runs=1 (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	schemaName := uniqueSchemaName("sec_concurrency")

	vars := baseVars(defaults.CatalogName, schemaName)

	plan := planPack(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, "max_concurrent_runs", "job must set max_concurrent_runs")
}

func TestUdfPackRunAsServicePrincipal(t *testing.T) {
	common.SkipIfShortMode(t, "udf pack run_as service principal in job (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	schemaName := uniqueSchemaName("sec_run_as")

	vars := baseVars(defaults.CatalogName, schemaName)
	vars["run_as_service_principal_application_id"] = "00000000-0000-0000-0000-000000000001"

	plan := planPack(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, "00000000-0000-0000-0000-000000000001", "run_as service principal application ID must appear in job plan")
}

func TestUdfPackCatalogNameInvalidRejected(t *testing.T) {
	common.SkipIfShortMode(t, "udf pack invalid catalog_name rejected (plan fail)")
	common.RequireDatabricksEnv(t)

	err := planPackExpectError(t, baseVars("my.catalog", "security_functions"))
	require.Error(t, err, "plan must fail when catalog_name contains a dot")
}

func TestUdfPackSchemaNameInvalidRejected(t *testing.T) {
	common.SkipIfShortMode(t, "udf pack invalid schema_name rejected (plan fail)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()

	err := planPackExpectError(t, baseVars(defaults.CatalogName, "bad schema name"))
	require.Error(t, err, "plan must fail when schema_name contains whitespace")
}

func TestUdfPackGrantBlankPrincipalRejected(t *testing.T) {
	common.SkipIfShortMode(t, "udf pack blank principal validation (plan fail)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	schemaName := uniqueSchemaName("sec_blank_principal")

	vars := baseVars(defaults.CatalogName, schemaName)
	vars["grants"] = []map[string]interface{}{
		{"principal": "   ", "privileges": []string{"EXECUTE"}},
	}

	err := planPackExpectError(t, vars)
	require.Error(t, err, "plan must fail when principal is blank or whitespace")
}

func TestUdfPackGrantInvalidPrivilegeRejected(t *testing.T) {
	common.SkipIfShortMode(t, "udf pack invalid privilege validation (plan fail)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	schemaName := uniqueSchemaName("sec_bad_priv")

	vars := baseVars(defaults.CatalogName, schemaName)
	vars["grants"] = []map[string]interface{}{
		{"principal": "analysts-grp", "privileges": []string{"SELECT"}},
	}

	err := planPackExpectError(t, vars)
	require.Error(t, err, "plan must fail when privilege SELECT is not in the allowed schema-level set")
}

func TestUdfPackVersionInvalidRejected(t *testing.T) {
	common.SkipIfShortMode(t, "udf pack invalid udf_pack_version rejected (plan fail)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	schemaName := uniqueSchemaName("sec_bad_ver")

	vars := baseVars(defaults.CatalogName, schemaName)
	vars["udf_pack_version"] = ""

	err := planPackExpectError(t, vars)
	require.Error(t, err, "plan must fail when udf_pack_version is an empty string")
}

func TestUdfPackGrantDuplicatePrivilegesRejected(t *testing.T) {
	common.SkipIfShortMode(t, "udf pack duplicate privileges validation (plan fail)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	schemaName := uniqueSchemaName("sec_dup_privs")

	vars := baseVars(defaults.CatalogName, schemaName)
	vars["grants"] = []map[string]interface{}{
		{"principal": "analysts-grp", "privileges": []string{"EXECUTE", "EXECUTE"}},
	}

	err := planPackExpectError(t, vars)
	require.Error(t, err, "plan must fail when the same privilege is listed more than once")
}

func TestUdfPackAllPrivilegesCombinationRejected(t *testing.T) {
	common.SkipIfShortMode(t, "udf pack ALL_PRIVILEGES combined with others rejected (plan fail)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	schemaName := uniqueSchemaName("sec_all_privs_combo")

	vars := baseVars(defaults.CatalogName, schemaName)
	vars["grants"] = []map[string]interface{}{
		{"principal": "analysts-grp", "privileges": []string{"ALL_PRIVILEGES", "EXECUTE"}},
	}

	err := planPackExpectError(t, vars)
	require.Error(t, err, "plan must fail when ALL_PRIVILEGES is combined with other privileges")
}

func TestUdfPackForceDestroyEnabled(t *testing.T) {
	common.SkipIfShortMode(t, "udf pack force_destroy=true accepted (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	schemaName := uniqueSchemaName("sec_force_destroy")

	vars := baseVars(defaults.CatalogName, schemaName)
	vars["force_destroy"] = true

	plan := planPack(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, "databricks_schema.this", "schema must be planned when force_destroy is true")
}

func TestUdfPackGrantPaddedPrincipalTrimmed(t *testing.T) {
	common.SkipIfShortMode(t, "udf pack padded principal is trimmed in grants_map (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	schemaName := uniqueSchemaName("sec_trim_principal")

	vars := baseVars(defaults.CatalogName, schemaName)
	vars["grants"] = []map[string]interface{}{
		{"principal": "  analysts-grp  ", "privileges": []string{"EXECUTE"}},
	}

	plan := planPack(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, `databricks_grant.this["analysts-grp"]`, "padded principal must be trimmed to 'analysts-grp' as the map key")
	assert.NotContains(t, plan, `databricks_grant.this["  analysts-grp  "]`, "untrimmed principal must not appear as a map key")
}

func TestUdfPackFunctionOwnerPrincipalInNotebook(t *testing.T) {
	common.SkipIfShortMode(t, "udf pack function_owner_principal baked into notebook (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	schemaName := uniqueSchemaName("sec_owner_principal")

	vars := baseVars(defaults.CatalogName, schemaName)
	vars["function_owner_principal"] = "governance-owner-grp"

	plan := planPack(t, vars)
	require.NotEmpty(t, plan)

	source := notebookSource(t, plan)

	assert.Contains(t, source, "governance-owner-grp", "function_owner_principal must be baked into notebook content")
	assert.Contains(t, source, "ALTER FUNCTION", "ownership transfer statement must appear in notebook content")
	assert.Contains(t, source, "OWNER TO", "OWNER TO clause must appear in notebook content")
}

func TestUdfPackFunctionOwnerPrincipalNullDisablesTransferAtRuntime(t *testing.T) {
	common.SkipIfShortMode(t, "udf pack null function_owner_principal disables transfer at runtime (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	schemaName := uniqueSchemaName("sec_owner_null")

	vars := baseVars(defaults.CatalogName, schemaName)

	plan := planPack(t, vars)
	require.NotEmpty(t, plan)

	source := notebookSource(t, plan)

	// The transfer block stays in the notebook and is skipped at runtime by the Python guard.
	assert.Contains(t, source, `function_owner = ""`, "null principal must produce empty string in notebook")
	assert.Contains(t, source, "if function_owner:", "runtime guard must be present in notebook source")
}

func TestUdfPackFunctionOwnerPrincipalBlankRejected(t *testing.T) {
	common.SkipIfShortMode(t, "blank function_owner_principal rejected (plan fail)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	schemaName := uniqueSchemaName("sec_owner_blank")

	vars := baseVars(defaults.CatalogName, schemaName)
	vars["function_owner_principal"] = "   "

	err := planPackExpectError(t, vars)
	require.Error(t, err, "plan must fail when function_owner_principal is blank")
}

func TestUdfPackScopedAttributePreservesAttributeValue(t *testing.T) {
	common.SkipIfShortMode(t, "sec_value_fidelity")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_value_fidelity")))
	require.NotEmpty(t, plan)

	block := udfBlock(t, plan, "rowfilter_attribute")

	// Folding underscores to hyphens would silently deny: the Day 1 group is internal_pii.
	assert.Contains(t, block, "lower(attribute_value)",
		"the attribute value must be lowercased and otherwise passed through")

	for _, rewrite := range []string{"'_', '-'", "translate(", "regexp_replace("} {
		assert.NotContains(t, block, rewrite,
			"the attribute value must not be rewritten before the group lookup: "+rewrite)
	}
}

// Isolates one function definition, so one UDF cannot satisfy another's assertions.
func udfBlock(t *testing.T, plan, funcName string) string {
	t.Helper()

	source := notebookSource(t, plan)

	anchor := "FUNCTION {fqn}." + funcName + "("
	start := strings.Index(source, anchor)
	require.GreaterOrEqual(t, start, 0, "function definition must appear in notebook: "+funcName)

	rest := source[start:]
	if end := strings.Index(rest, `spark.sql(f"""`); end != -1 {
		return rest[:end]
	}
	return rest
}

func TestUdfPackScopedAttributeSignature(t *testing.T) {
	common.SkipIfShortMode(t, "sec_scoped_attr")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_scoped_attr")))
	require.NotEmpty(t, plan)

	block := udfBlock(t, plan, "rowfilter_attribute")

	for _, param := range []string{
		"sdlc STRING", "workspace STRING", "csi STRING", "attribute_value STRING",
	} {
		assert.Contains(t, block, param, "parameter must be an explicit argument: "+param)
	}
	assert.Contains(t, block, "RETURNS BOOLEAN", "row-filter UDF must return BOOLEAN")

	for _, literal := range []string{"'{sdlc}'", "'{workspace}'", "'{csi}'"} {
		assert.NotContains(t, block, literal,
			"scope must be supplied by the policy, not baked into the body: "+literal)
	}
}

func TestUdfPackScopedAttributeConstructsGroupName(t *testing.T) {
	common.SkipIfShortMode(t, "sec_scoped_grp")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_scoped_grp")))
	require.NotEmpty(t, plan)

	block := udfBlock(t, plan, "rowfilter_attribute")

	for _, part := range []string{
		"concat(", "'dbx-'", "lower(sdlc)", "lower(workspace)", "csi", "'-access'",
	} {
		assert.Contains(t, block, part, "group name must be constructed from: "+part)
	}

	// A table read costs a join per query and disqualifies MERGE on the protected table.
	for _, lookup := range []string{"SELECT", "EXISTS (", "available_attributes", "target_group"} {
		assert.NotContains(t, block, lookup,
			"the body must not read a table: "+lookup)
	}
}

func TestUdfPackScopedAttributeIsAPureExpression(t *testing.T) {
	common.SkipIfShortMode(t, "sec_scoped_pure")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_scoped_pure")))
	require.NotEmpty(t, plan)

	block := udfBlock(t, plan, "rowfilter_attribute")

	assert.NotContains(t, block, "bool_or(", "policy UDF must not aggregate")
	assert.NotContains(t, block, "FROM ", "policy UDF must not scan a table")
	assert.Equal(t, 1, strings.Count(block, "is_account_group_member("),
		"exactly one membership test, on the constructed name")
}

func TestUdfPackScopedAttributeIsNotDeterministic(t *testing.T) {
	common.SkipIfShortMode(t, "rowfilter_attribute must not be DETERMINISTIC (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_scoped_det")))
	require.NotEmpty(t, plan)

	block := udfBlock(t, plan, "rowfilter_attribute")

	assert.NotContains(t, block, "\n  DETERMINISTIC",
		"identity-dependent UDF must not be DETERMINISTIC or Spark may cache across callers")
}

func TestUdfPackScopedAttributeUsesAccountGroupMember(t *testing.T) {
	common.SkipIfShortMode(t, "rowfilter_attribute uses is_account_group_member (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_scoped_acct")))
	require.NotEmpty(t, plan)

	block := udfBlock(t, plan, "rowfilter_attribute")

	assert.Contains(t, block, "is_account_group_member(",
		"ABAC groups are account-level, so is_account_group_member is required")
	assert.NotContains(t, block, "is_member(",
		"is_member resolves workspace-local groups and would silently deny")
}

func TestUdfPackScopedAttributeFailsClosedOnNull(t *testing.T) {
	common.SkipIfShortMode(t, "sec_scoped_null")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_scoped_null")))
	require.NotEmpty(t, plan)

	block := udfBlock(t, plan, "rowfilter_attribute")

	for _, guard := range []string{
		"sdlc IS NULL", "workspace IS NULL", "csi IS NULL", "attribute_value IS NULL",
	} {
		assert.Contains(t, block, guard, "null guard must cover: "+guard)
	}
	assert.Contains(t, block, "THEN false", "null input must deny rather than propagate NULL")
}

func TestUdfPackAllScopedAttributesSignature(t *testing.T) {
	common.SkipIfShortMode(t, "sec_all_attr_sig")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_all_attr_sig")))
	require.NotEmpty(t, plan)

	block := udfBlock(t, plan, "rowfilter_attributes_and")

	for _, param := range []string{
		"sdlc STRING", "workspace STRING", "csi STRING",
		"v1 STRING", "v2 STRING", "v3 STRING",
	} {
		assert.Contains(t, block, param, "parameter must be an explicit argument: "+param)
	}
	assert.Contains(t, block, "RETURNS BOOLEAN", "row-filter UDF must return BOOLEAN")
}

// A policy binds one row filter, so the conjunction has to happen inside the function.
// It must delegate rather than rebuild the name, or the naming rule lives in two places.
func TestUdfPackAllScopedAttributesDelegatesGroupNaming(t *testing.T) {
	common.SkipIfShortMode(t, "sec_all_attr_delegate")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_all_attr_delegate")))
	require.NotEmpty(t, plan)

	block := udfBlock(t, plan, "rowfilter_attributes_and")

	assert.Equal(t, 10, strings.Count(block, "{fqn}.rowfilter_attribute("),
		"one delegated check per attribute slot (v1..v10)")
	assert.NotContains(t, block, "is_account_group_member(",
		"group-name construction belongs to rowfilter_attribute alone")
	assert.NotContains(t, block, "'dbx-'",
		"the prefix must not be duplicated here")
	assert.Equal(t, 9, strings.Count(block, " AND "),
		"the ten slots must be ANDed, not ORed")
}

// '-' opts a slot out. NULL must not, because that is what a missing tag returns and
// deleting a tag has to narrow access rather than widen it.
func TestUdfPackAllScopedAttributesOptOutSentinelIsNotNull(t *testing.T) {
	common.SkipIfShortMode(t, "sec_all_attr_sentinel")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_all_attr_sentinel")))
	require.NotEmpty(t, plan)

	block := udfBlock(t, plan, "rowfilter_attributes_and")

	assert.Equal(t, 9, strings.Count(block, "= '-' OR"),
		"only the nine optional slots (v2..v10) may be opted out")
	assert.NotContains(t, block, "v1 = '-'",
		"the first attribute is mandatory, opting it out would match every row")
	assert.NotContains(t, block, "coalesce(",
		"a null must not be defaulted into the opt-out sentinel")
}

func TestUdfPackAllScopedAttributesFailsClosedOnNull(t *testing.T) {
	common.SkipIfShortMode(t, "sec_all_attr_null")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_all_attr_null")))
	require.NotEmpty(t, plan)

	block := udfBlock(t, plan, "rowfilter_attributes_and")

	for _, guard := range []string{
		"sdlc IS NULL", "workspace IS NULL", "csi IS NULL",
		"v1 IS NULL", "v2 IS NULL", "v3 IS NULL",
	} {
		assert.Contains(t, block, guard, "null guard must cover: "+guard)
	}
	assert.Contains(t, block, "THEN false", "null input must deny rather than propagate NULL")
}

func TestUdfPackAllScopedAttributesIsNotDeterministic(t *testing.T) {
	common.SkipIfShortMode(t, "rowfilter_attributes_and must not be DETERMINISTIC (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_all_attr_det")))
	require.NotEmpty(t, plan)

	block := udfBlock(t, plan, "rowfilter_attributes_and")

	assert.NotContains(t, block, "\n  DETERMINISTIC",
		"identity-dependent UDF must not be DETERMINISTIC or Spark may cache across callers")
}

// Without a dimension segment, a value used by two dimensions resolves to one group, so
// holding either entitlement satisfies both.
func TestUdfPackScopedDimensionAttributeQualifiesTheGroupName(t *testing.T) {
	common.SkipIfShortMode(t, "sec_dim_grp")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_dim_grp")))
	require.NotEmpty(t, plan)

	block := udfBlock(t, plan, "rowfilter_dimension")

	for _, param := range []string{
		"sdlc STRING", "workspace STRING", "csi STRING",
		"dimension STRING", "attribute_value STRING",
	} {
		assert.Contains(t, block, param, "parameter must be an explicit argument: "+param)
	}
	assert.Contains(t, block, "RETURNS BOOLEAN", "row-filter UDF must return BOOLEAN")

	// dbx-dev-olympus-167969-domain-payments-access
	assert.Contains(t, block, "lower(dimension), '-',",
		"the dimension segment must sit between the CSI and the value")
	assert.Contains(t, block, "lower(attribute_value),",
		"the value must still be lowercased and otherwise passed through")
	assert.Equal(t, 1, strings.Count(block, "is_account_group_member("),
		"exactly one membership test, on the qualified name")
}

func TestUdfPackScopedDimensionAttributeFailsClosedOnNull(t *testing.T) {
	common.SkipIfShortMode(t, "sec_dim_null")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_dim_null")))
	require.NotEmpty(t, plan)

	block := udfBlock(t, plan, "rowfilter_dimension")

	for _, guard := range []string{
		"sdlc IS NULL", "workspace IS NULL", "csi IS NULL",
		"dimension IS NULL", "attribute_value IS NULL",
	} {
		assert.Contains(t, block, guard, "null guard must cover: "+guard)
	}
	assert.Contains(t, block, "THEN false", "null input must deny rather than propagate NULL")
	assert.NotContains(t, block, "\n  DETERMINISTIC",
		"identity-dependent UDF must not be DETERMINISTIC or Spark may cache across callers")
}

func TestUdfPackScopedHierarchySignature(t *testing.T) {
	common.SkipIfShortMode(t, "sec_hier_sig")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_hier_sig")))
	require.NotEmpty(t, plan)

	block := udfBlock(t, plan, "rowfilter_hierarchy")

	for _, param := range []string{
		"sdlc STRING", "workspace STRING", "csi STRING", "portfolio STRING", "product STRING",
	} {
		assert.Contains(t, block, param, "Pattern 11 parameter must be an explicit argument: "+param)
	}
	assert.Contains(t, block, "RETURNS BOOLEAN", "row-filter UDF must return BOOLEAN")
}

func TestUdfPackScopedHierarchyChecksProductWithinCsiScope(t *testing.T) {
	common.SkipIfShortMode(t, "sec_hier_product")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_hier_product")))
	require.NotEmpty(t, plan)

	block := udfBlock(t, plan, "rowfilter_hierarchy")

	assert.Contains(t, block, "lower(product)", "the product group must be evaluated")
	assert.NotContains(t, block, "lower(portfolio)",
		"portfolio must not become its own membership test, it is carried by the CSI segment")
	assert.Equal(t, 1, strings.Count(block, "is_account_group_member("),
		"exactly one membership test: the CSI-scoped product group")
}

func TestUdfPackScopedHierarchyIsNotDeterministic(t *testing.T) {
	common.SkipIfShortMode(t, "rowfilter_hierarchy must not be DETERMINISTIC (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_hier_det")))
	require.NotEmpty(t, plan)

	block := udfBlock(t, plan, "rowfilter_hierarchy")

	assert.NotContains(t, block, "\n  DETERMINISTIC",
		"identity-dependent UDF must not be DETERMINISTIC or Spark may cache across callers")
}

func TestUdfPackScopedHierarchyFailsClosedOnNull(t *testing.T) {
	common.SkipIfShortMode(t, "sec_hier_null")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_hier_null")))
	require.NotEmpty(t, plan)

	block := udfBlock(t, plan, "rowfilter_hierarchy")

	for _, guard := range []string{
		"sdlc IS NULL", "workspace IS NULL", "csi IS NULL",
		"portfolio IS NULL", "product IS NULL",
	} {
		assert.Contains(t, block, guard, "null guard must cover: "+guard)
	}
	assert.Contains(t, block, "THEN false", "null input must deny rather than propagate NULL")
}

func TestUdfPackAbacUdfsIncludedInOwnershipTransfer(t *testing.T) {
	common.SkipIfShortMode(t, "ABAC UDFs included in ownership transfer list (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(defaults.CatalogName, uniqueSchemaName("sec_abac_owner"))
	vars["function_owner_principal"] = "governance-owner-grp"

	plan := planPack(t, vars)
	require.NotEmpty(t, plan)

	source := notebookSource(t, plan)

	start := strings.Index(source, "udf_names = [")
	require.GreaterOrEqual(t, start, 0, "udf_names list must appear in notebook source")
	rest := source[start:]
	end := strings.Index(rest, "]")
	require.GreaterOrEqual(t, end, 0, "udf_names list must be terminated")
	list := rest[:end]

	assert.Contains(t, list, `"rowfilter_attribute"`, "rowfilter_attribute must receive the owner transfer")
	assert.Contains(t, list, `"rowfilter_hierarchy"`, "rowfilter_hierarchy must receive the owner transfer")
}

func TestUdfPackConstructedNameMatchesProvisionedGroups(t *testing.T) {
	common.SkipIfShortMode(t, "sec_naming")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_naming")))
	require.NotEmpty(t, plan)

	block := udfBlock(t, plan, "rowfilter_attribute")

	// Reproduces dbx-dev-olympus-167969-internal_pii-access, underscores in the value intact.
	for _, part := range []string{
		"'dbx-',", "lower(sdlc), '-',", "lower(workspace), '-',", "csi, '-',",
		"lower(attribute_value),", "'-access'",
	} {
		assert.Contains(t, block, part, "constructed name must include: "+part)
	}

	assert.NotContains(t, block, "upper(", "group names are lowercase")
}

// udf_names is hand-maintained: a UDF missing from it silently keeps the run-as identity as owner.
func TestUdfPackOwnershipListCoversEveryDefinedUdf(t *testing.T) {
	common.SkipIfShortMode(t, "udf_names covers every defined UDF (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_owner_parity")))
	require.NotEmpty(t, plan)

	source := notebookSource(t, plan)

	defined := regexp.MustCompile(`CREATE OR REPLACE FUNCTION \{fqn\}\.(\w+)\(`).FindAllStringSubmatch(source, -1)
	require.NotEmpty(t, defined, "notebook must define at least one UDF")

	start := strings.Index(source, "udf_names = [")
	require.GreaterOrEqual(t, start, 0, "udf_names list must appear in notebook source")
	rest := source[start:]
	end := strings.Index(rest, "]")
	require.GreaterOrEqual(t, end, 0, "udf_names list must be terminated")
	listed := regexp.MustCompile(`"(\w+)"`).FindAllStringSubmatch(rest[:end], -1)

	inList := make(map[string]bool, len(listed))
	for _, m := range listed {
		inList[m[1]] = true
	}

	for _, m := range defined {
		assert.True(t, inList[m[1]],
			"UDF is defined but missing from udf_names, so it would not receive the owner transfer: "+m[1])
	}
	assert.Len(t, listed, len(defined),
		"udf_names must list exactly the UDFs the notebook defines")
}

func TestUdfPackMaskValueSignature(t *testing.T) {
	common.SkipIfShortMode(t, "sec_maskval_sig")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_maskval_sig")))
	require.NotEmpty(t, plan)

	block := udfBlock(t, plan, "mask_any_type")

	assert.Contains(t, block, "mask_any_type(v VARIANT)",
		"one function must cover the supported column types")
	assert.Contains(t, block, "RETURNS VARIANT",
		"a STRING return fails the policy cast on non-string columns")

	for _, param := range []string{"pii_type STRING", "masking_rule STRING"} {
		assert.NotContains(t, block, param,
			"governed-vocabulary masking is out of scope: "+param)
	}
	assert.NotContains(t, block, "rowfilter_attribute(",
		"mask_any_type must not resolve an entitlement")
}

func TestUdfPackMaskValueIsDeterministic(t *testing.T) {
	common.SkipIfShortMode(t, "sec_maskval_det")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_maskval_det")))
	require.NotEmpty(t, plan)

	block := udfBlock(t, plan, "mask_any_type")

	assert.Contains(t, block, "DETERMINISTIC",
		"a pure value transform should be DETERMINISTIC so Spark can fold it")
	assert.Contains(t, block, "try_cast('****' AS VARIANT)",
		"strings still redact to ****")

	assert.Contains(t, block, "WHEN v IS NULL THEN NULL",
		"schema_of_variant(NULL) is NULL, so NULL must be caught before the ELSE")
	assert.Contains(t, block, "ELSE NULL",
		"BINARY and ARRAY reject a numeric catch-all")

	// One dispatch on the type name, so a row pays for a single schema_of_variant call.
	assert.Contains(t, block, "ELSE CASE schema_of_variant(v)",
		"types must be dispatched once, not re-tested per branch")
	assert.Contains(t, block, "WHEN 'BIGINT' THEN try_cast(0 AS VARIANT)",
		"schema_of_variant reports every integer width as BIGINT")
	// A throwing cast blocks the optimizer from folding or reordering the branch.
	assert.NotContains(t, block, "::VARIANT",
		"sentinels must be built with try_cast, not the throwing :: form")
	// TIMESTAMP_NTZ reports under its own name, not as TIMESTAMP, so without this
	// branch a zone-less timestamp column masks to NULL instead of the epoch.
	assert.Contains(t, block, "WHEN 'TIMESTAMP_NTZ' THEN",
		"TIMESTAMP_NTZ needs its own branch or it falls through to NULL")
	assert.Contains(t, block, "startswith(schema_of_variant(v), 'DECIMAL')",
		"schema_of_variant returns DECIMAL(p,s), so DECIMAL needs a prefix test")
	assert.NotContains(t, block, "RLIKE",
		"a per-row regex over the type name is what the dispatch replaced")
	assert.Equal(t, 2, strings.Count(block, "schema_of_variant("),
		"one dispatch plus the DECIMAL prefix test")
}

func TestUdfPackMaskByClassificationSignature(t *testing.T) {
	common.SkipIfShortMode(t, "sec_maskcls_sig")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_maskcls_sig")))
	require.NotEmpty(t, plan)

	block := udfBlock(t, plan, "mask_by_classification")

	assert.Contains(t, block, "mask_by_classification(",
		"the classification must be an argument so one function serves every column")
	for _, param := range []string{"v VARIANT", "classification STRING"} {
		assert.Contains(t, block, param, "parameter must be an explicit argument: "+param)
	}
	assert.Contains(t, block, "RETURNS VARIANT",
		"a STRING return fails the policy cast on non-string columns")
	assert.Contains(t, block, "DETERMINISTIC",
		"a pure value transform should be DETERMINISTIC so Spark can fold it")
	assert.NotContains(t, block, "is_account_group_member(",
		"this one branches on the tag only; entitlement belongs to mask_unless_entitled")
}

// The published example for this shape ends on the column, which reveals anything
// outside the vocabulary. Every path that is not an explicit allow must mask.
func TestUdfPackMaskByClassificationFailsClosed(t *testing.T) {
	common.SkipIfShortMode(t, "sec_maskcls_closed")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_maskcls_closed")))
	require.NotEmpty(t, plan)

	block := udfBlock(t, plan, "mask_by_classification")

	assert.Contains(t, block, "WHEN classification IS NULL THEN {fqn}.mask_any_type(v)",
		"an untagged column reads as NULL and must mask")
	assert.Contains(t, block, "ELSE {fqn}.mask_any_type(v)",
		"the fallthrough must mask, so an unrecognised value cannot reveal")
	assert.NotContains(t, block, "ELSE v",
		"the fallthrough must not be the raw column")
	assert.Contains(t, block, "lower(classification) IN ('public', 'internal')",
		"only the explicit passthrough vocabulary reveals, matched case-insensitively")
	assert.Equal(t, 2, strings.Count(block, "{fqn}.mask_any_type(v)"),
		"both the null path and the fallthrough delegate the sentinel to mask_any_type")
}

func TestUdfPackMaskUnlessScopedSignature(t *testing.T) {
	common.SkipIfShortMode(t, "sec_maskscope_sig")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_maskscope_sig")))
	require.NotEmpty(t, plan)

	block := udfBlock(t, plan, "mask_unless_entitled")

	for _, param := range []string{
		"v VARIANT", "sdlc STRING", "workspace STRING", "csi STRING", "classification STRING",
	} {
		assert.Contains(t, block, param, "parameter must be an explicit argument: "+param)
	}
	assert.Contains(t, block, "RETURNS VARIANT",
		"a STRING return fails the policy cast on non-string columns")
}

// to_principals and except_principals cap at 20 across both, and the group inventory is
// far larger, so the exemption has to be resolved inside the mask.
func TestUdfPackMaskUnlessScopedResolvesEntitlementItself(t *testing.T) {
	common.SkipIfShortMode(t, "sec_maskscope_entitle")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_maskscope_entitle")))
	require.NotEmpty(t, plan)

	block := udfBlock(t, plan, "mask_unless_entitled")

	assert.Equal(t, 1, strings.Count(block, "is_account_group_member("),
		"exactly one membership test, on the scoped classification group")
	assert.NotContains(t, block, "is_member(",
		"is_member resolves workspace-local groups and would silently mask")
	for _, part := range []string{
		"'dbx-',", "lower(sdlc), '-',", "lower(workspace), '-',", "csi, '-',",
		"lower(classification),", "'-access'",
	} {
		assert.Contains(t, block, part, "group name must be constructed from: "+part)
	}
	assert.NotContains(t, block, "\n  DETERMINISTIC",
		"identity-dependent UDF must not be DETERMINISTIC or Spark may cache across callers")
}

func TestUdfPackMaskUnlessScopedFailsClosed(t *testing.T) {
	common.SkipIfShortMode(t, "sec_maskscope_closed")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	plan := planPack(t, baseVars(defaults.CatalogName, uniqueSchemaName("sec_maskscope_closed")))
	require.NotEmpty(t, plan)

	block := udfBlock(t, plan, "mask_unless_entitled")

	for _, guard := range []string{
		"sdlc IS NULL", "workspace IS NULL", "csi IS NULL", "classification IS NULL",
	} {
		assert.Contains(t, block, guard, "null guard must cover: "+guard)
	}
	assert.Contains(t, block, "ELSE {fqn}.mask_any_type(v)",
		"a caller without the group must get the sentinel, not the column")
	assert.Equal(t, 2, strings.Count(block, "{fqn}.mask_any_type(v)"),
		"the null path and the unentitled fallthrough both mask; only the group check reveals")
}

// Every function the pack deploys is part of the module's public surface. Keeping a
// function but dropping its output still breaks any caller that references it, which is
// how the ten legacy outputs went missing once already.
func TestUdfPackExposesAnOutputForEveryUdf(t *testing.T) {
	paths := []string{
		filepath.Join("..", "outputs.tf"),
		filepath.Join("..", "examples", "basic", "outputs.tf"),
	}
	names := append(append([]string{}, legacyUdfNames...), frameworkUdfNames...)

	for _, path := range paths {
		raw, err := os.ReadFile(path)
		require.NoError(t, err, "must be able to read "+path)

		for _, udfName := range names {
			assert.Contains(t, string(raw), `output "`+udfName+`"`,
				path+" must expose an output for "+udfName)
		}
	}
}
