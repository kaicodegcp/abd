variable "catalog_name" {
  description = "Name of the Unity Catalog catalog where the security functions schema will be created."
  type        = string

  validation {
    condition     = can(regex("^[A-Za-z][A-Za-z0-9_]*$", var.catalog_name))
    error_message = "catalog_name must start with a letter and contain only letters, numbers, and underscores."
  }
}

variable "schema_name" {
  description = "Schema for governance UDFs. Defaults to 'security_functions'."
  type        = string
  default     = "security_functions"

  # Leading digit allowed for CSI-named schemas such as 200100.
  validation {
    condition     = can(regex("^[A-Za-z0-9][A-Za-z0-9_]*$", var.schema_name))
    error_message = "schema_name must start with a letter or digit and contain only letters, numbers, and underscores."
  }
}

variable "comment" {
  description = "Free-text description for the schema."
  type        = string
  default     = "Standard ABAC governance UDFs for column masking and row filtering."
}

# Published via the abac_scope output only. Leave null for a deployment shared across CSIs.

variable "sdlc" {
  description = "SDLC value for abac_scope, e.g. dev."
  type        = string
  default     = null

  validation {
    condition     = var.sdlc == null || can(regex("^[a-z0-9][a-z0-9-]*$", var.sdlc))
    error_message = "sdlc must be lowercase alphanumeric with hyphens, e.g. dev."
  }
}

variable "workspace_name" {
  description = "Logical workspace (program) name for abac_scope, e.g. olympus. Not the physical workspace name."
  type        = string
  default     = null

  validation {
    condition     = var.workspace_name == null || can(regex("^[a-z0-9][a-z0-9-]*$", var.workspace_name))
    error_message = "workspace_name must be lowercase alphanumeric with hyphens, e.g. olympus."
  }
}

variable "csi" {
  description = "CSI value for abac_scope, e.g. 167969. Always literal: 000000 means CSI 000000."
  type        = string
  default     = null

  validation {
    condition     = var.csi == null || can(regex("^[0-9]{5,6}$", var.csi))
    error_message = "csi must be a 5-digit or 6-digit CSI identifier, e.g. 167969."
  }
}

variable "force_destroy" {
  description = "If true, allows Terraform to delete the schema even when it contains functions. Set to true in dev/test; keep false in production."
  type        = bool
  default     = false
}

variable "owner" {
  description = "Schema owner. Defaults to the Terraform caller identity. Does not affect function ownership; use function_owner_principal for that."
  type        = string
  default     = null
}

variable "notebook_base_path" {
  description = "Workspace folder for the setup notebook. Notebook path is '<base>/<catalog>-<schema>-udf-pack-setup'."
  type        = string
  default     = "/security-udf-pack"
}

variable "existing_cluster_id" {
  description = "Cluster ID for the setup job. When null, the task runs on serverless compute, which must be enabled in the workspace. Any cluster supplied must support Unity Catalog."
  type        = string
  default     = null
}

variable "run_as_service_principal_application_id" {
  description = "Application (client) ID of the service principal that runs the setup job (GUID, not a display name). Recommended for production."
  type        = string
  default     = null

  validation {
    condition = var.run_as_service_principal_application_id == null || can(
      regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$",
        var.run_as_service_principal_application_id
      )
    )
    error_message = "run_as_service_principal_application_id must be a GUID (xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx), not a display name."
  }
}

variable "function_owner_principal" {
  description = "Principal to own every deployed UDF, applied via ALTER FUNCTION after creation. The run-as service principal must remain the owner or be a member of this group, or redeployment fails. Null keeps ownership on the run-as identity."
  type        = string
  default     = null

  validation {
    condition     = var.function_owner_principal == null || length(trimspace(var.function_owner_principal != null ? var.function_owner_principal : "")) > 0
    error_message = "function_owner_principal must not be blank when set."
  }

  validation {
    condition     = var.function_owner_principal == null || !can(regex("`", var.function_owner_principal))
    error_message = "function_owner_principal must not contain backtick characters."
  }
}

variable "udf_pack_version" {
  description = "Version of the UDF pack. Applied as a job tag and printed in the setup notebook output."
  type        = string
  default     = "1.4.0"

  validation {
    condition     = can(regex("^[0-9]+\\.[0-9]+\\.[0-9]+(?:[-+][A-Za-z0-9.-]+)?$", var.udf_pack_version))
    error_message = "udf_pack_version must use semantic version format, such as 1.0.0 or 1.1.0-beta.1."
  }
}

variable "tags" {
  description = "Tags applied to the setup job."
  type        = map(string)
  default     = {}
}

variable "grants" {
  description = "Schema-level grants for the UDF schema. Principals must already hold USE_CATALOG on the parent catalog. For each principal listed, this module is the sole Terraform owner of that principal's grants on this schema."
  type = list(object({
    principal  = string
    privileges = list(string)
  }))
  default = []

  validation {
    condition     = length(var.grants) == length(distinct([for g in var.grants : trimspace(g.principal)]))
    error_message = "Each principal must appear at most once in var.grants (comparison is whitespace-insensitive)."
  }

  validation {
    condition     = alltrue([for g in var.grants : length(trimspace(g.principal)) > 0])
    error_message = "Each grant entry must have a non-empty principal."
  }

  validation {
    condition     = alltrue([for g in var.grants : length(g.privileges) > 0])
    error_message = "Each grant entry must specify at least one privilege."
  }

  validation {
    condition = alltrue([
      for g in var.grants : alltrue([
        for p in g.privileges : contains(["USE_SCHEMA", "EXECUTE", "CREATE_FUNCTION", "ALL_PRIVILEGES"], p)
      ])
    ])
    error_message = "Valid schema-level privileges are: USE_SCHEMA, EXECUTE, CREATE_FUNCTION, ALL_PRIVILEGES."
  }

  validation {
    condition     = alltrue([for g in var.grants : length(g.privileges) == length(distinct(g.privileges))])
    error_message = "Each grant entry must not contain duplicate privileges."
  }

  validation {
    condition = alltrue([
      for g in var.grants :
      contains(g.privileges, "ALL_PRIVILEGES") ? length(g.privileges) == 1 : true
    ])
    error_message = "ALL_PRIVILEGES cannot be combined with other privileges."
  }
}
