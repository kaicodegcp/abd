output "schema_name" {
  description = "Name of the security functions schema."
  value       = databricks_schema.this.name
}

output "schema_full_name" {
  description = "Fully qualified schema name (catalog.schema)."
  value       = local.schema_fqn
}

output "setup_job_id" {
  description = "Job ID of the UDF setup job. Function name outputs are only available after this job completes successfully."
  value       = databricks_job.udf_setup.id
}

output "setup_notebook_path" {
  description = "Workspace path of the UDF setup notebook."
  value       = databricks_notebook.udf_setup.path
}

output "mask_redact_all" {
  description = "Intended fully qualified name of mask_redact_all. The function exists only after the setup job completes successfully."
  value       = "${local.schema_fqn}.mask_redact_all"
}

output "mask_keep_last4" {
  description = "Intended fully qualified name of mask_keep_last4. The function exists only after the setup job completes successfully."
  value       = "${local.schema_fqn}.mask_keep_last4"
}

output "mask_email" {
  description = "Intended fully qualified name of mask_email. The function exists only after the setup job completes successfully."
  value       = "${local.schema_fqn}.mask_email"
}

output "rowfilter_deny_all" {
  description = "Intended fully qualified name of rowfilter_deny_all. The function exists only after the setup job completes successfully."
  value       = "${local.schema_fqn}.rowfilter_deny_all"
}

output "mask_ssn" {
  description = "Intended fully qualified name of mask_ssn. The function exists only after the setup job completes successfully."
  value       = "${local.schema_fqn}.mask_ssn"
}

output "mask_phone" {
  description = "Intended fully qualified name of mask_phone. The function exists only after the setup job completes successfully."
  value       = "${local.schema_fqn}.mask_phone"
}

output "mask_dob" {
  description = "Intended fully qualified name of mask_dob. For STRING-typed DOB columns. The function exists only after the setup job completes successfully."
  value       = "${local.schema_fqn}.mask_dob"
}

output "mask_dob_date" {
  description = "Intended fully qualified name of mask_dob_date. For DATE-typed DOB columns. The function exists only after the setup job completes successfully."
  value       = "${local.schema_fqn}.mask_dob_date"
}

output "mask_name" {
  description = "Intended fully qualified name of mask_name. The function exists only after the setup job completes successfully."
  value       = "${local.schema_fqn}.mask_name"
}

output "mask_keep_first4" {
  description = "Intended fully qualified name of mask_keep_first4. The function exists only after the setup job completes successfully."
  value       = "${local.schema_fqn}.mask_keep_first4"
}

output "rowfilter_attribute" {
  description = "Fully qualified name of rowfilter_attribute."
  value       = "${local.schema_fqn}.rowfilter_attribute"
}

output "rowfilter_dimension" {
  description = "Fully qualified name of rowfilter_dimension. Only bind a policy to this once groups carry a dimension segment, otherwise it denies every row."
  value       = "${local.schema_fqn}.rowfilter_dimension"
}

output "rowfilter_hierarchy" {
  description = "Fully qualified name of rowfilter_hierarchy."
  value       = "${local.schema_fqn}.rowfilter_hierarchy"
}

output "mask_any_type" {
  description = "Fully qualified name of mask_any_type."
  value       = "${local.schema_fqn}.mask_any_type"
}

output "mask_by_classification" {
  description = "Fully qualified name of mask_by_classification. Column mask that reveals PUBLIC and INTERNAL and masks everything else, including untagged columns."
  value       = "${local.schema_fqn}.mask_by_classification"
}

output "mask_unless_entitled" {
  description = "Fully qualified name of mask_unless_entitled. Column mask that resolves the caller's entitlement itself, for when the 20-principal cap on to_principals and except_principals is too small."
  value       = "${local.schema_fqn}.mask_unless_entitled"
}

output "mask_partial_unless_entitled" {
  description = "Fully qualified name of mask_partial_unless_entitled. Entitlement-gated STRING mask that reveals the raw value to members of the classification's group and shows everyone else a PARTIAL (via style: email/ssn/phone/name/dob/first4/last4/redact), not a blank."
  value       = "${local.schema_fqn}.mask_partial_unless_entitled"
}

output "rowfilter_attributes_and" {
  description = "Fully qualified name of rowfilter_attributes_and. The standard row filter: ANDs up to ten scoped attribute checks and binds via SET ROW FILTER over scalar columns, with no MATCH COLUMNS 3-condition cap. v1 required; pass '-' for unused slots."
  value       = "${local.schema_fqn}.rowfilter_attributes_and"
}

output "rowfilter_dimensions_and" {
  description = "Fully qualified name of rowfilter_dimensions_and. Collision-safe wide row filter over up to ten (dimension, value) pairs; binds via SET ROW FILTER. Requires groups that carry a dimension segment. Pass '-' for both members of an unused pair."
  value       = "${local.schema_fqn}.rowfilter_dimensions_and"
}

output "entitled_to_attributes" {
  description = "Fully qualified name of entitled_to_attributes. Array-input conjunction with no length cap. Scalar helper for WHERE, masks, or an ARRAY column; it cannot bind as a row filter over separate columns (use rowfilter_attributes_and there)."
  value       = "${local.schema_fqn}.entitled_to_attributes"
}

output "entitled_to_dimensions" {
  description = "Fully qualified name of entitled_to_dimensions. Array-input, dimension-qualified conjunction over zipped (dimension, value) pairs, uncapped. Scalar helper; not bindable as a row filter over separate columns (use rowfilter_dimensions_and there)."
  value       = "${local.schema_fqn}.entitled_to_dimensions"
}

output "abac_scope" {
  description = "Reference sdlc/workspace/csi values a policy should pass to the scoped UDFs. Null entries mean this deployment is shared across scopes."
  value = {
    sdlc      = var.sdlc
    workspace = var.workspace_name
    csi       = var.csi
  }
}

output "grant_ids" {
  description = "Principal to grant resource ID for each schema-level grant managed by this module."
  value       = { for k, g in databricks_grant.this : k => g.id }
}
