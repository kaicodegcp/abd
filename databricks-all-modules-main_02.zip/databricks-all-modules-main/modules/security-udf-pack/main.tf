locals {
  schema_fqn    = "${var.catalog_name}.${var.schema_name}"
  notebook_path = "${var.notebook_base_path}/${var.catalog_name}-${var.schema_name}-udf-pack-setup"
  grants_map = {
    for g in var.grants :
    trimspace(g.principal) => {
      privileges = g.privileges
    }
  }

  notebook_content = <<-PYTHON
    # Managed by Terraform. Re-run after apply to refresh functions.
    #
    # Examples, not a standard. Whatever a function does not take as an argument is
    # fixed for every caller, so a value that varies by team belongs in the signature.

    catalog = "${var.catalog_name}"
    schema  = "${var.schema_name}"
    fqn     = f"{catalog}.{schema}"

    # mask_redact_all - replaces the value with a fixed token.
    # Expects:       STRING. NULL returns NULL.
    # Configurable:  nothing. The '****' token is a literal.
    # Not supported: any other token, or preserving length.
    spark.sql(f"""
      CREATE OR REPLACE FUNCTION {fqn}.mask_redact_all(value STRING)
      RETURNS STRING
      LANGUAGE SQL
      DETERMINISTIC
      COMMENT 'UDF pack ${var.udf_pack_version}. Redacts the input value to ****. Preserves NULL.'
      RETURN CASE
        WHEN value IS NULL THEN NULL
        ELSE '****'
      END
    """)

    # mask_keep_last4 - keeps the trailing 4 characters.
    # Expects:       STRING, NULL returns NULL. 4 characters or fewer masks fully.
    # Configurable:  nothing. The count and the '*' fill are literals.
    # Not supported: a different width. That needs a function of its own.
    spark.sql(f"""
      CREATE OR REPLACE FUNCTION {fqn}.mask_keep_last4(value STRING)
      RETURNS STRING
      LANGUAGE SQL
      DETERMINISTIC
      COMMENT 'UDF pack ${var.udf_pack_version}. Last 4 characters visible. Example: 4111222233334444 to ************4444.'
      RETURN CASE
        WHEN value IS NULL THEN NULL
        WHEN length(value) <= 4 THEN repeat('*', length(value))
        ELSE concat(repeat('*', length(value) - 4), right(value, 4))
      END
    """)

    # mask_email - keeps the first character of the local part and the domain.
    # Expects:       STRING, NULL returns NULL. One address, not validated; no '@'
    #                masks fully.
    # Configurable:  nothing.
    # Not supported: masking the domain, multiple addresses, or display-name form.
    spark.sql(f"""
      CREATE OR REPLACE FUNCTION {fqn}.mask_email(email STRING)
      RETURNS STRING
      LANGUAGE SQL
      DETERMINISTIC
      COMMENT 'UDF pack ${var.udf_pack_version}. Email local part masked. Example: user@domain.com to u***@domain.com, a@domain.com to *@domain.com.'
      RETURN CASE
        WHEN email IS NULL THEN NULL
        WHEN instr(email, '@') <= 1 THEN repeat('*', length(email))
        WHEN instr(email, '@') = 2
          THEN concat('*', substring(email, 2))
        ELSE concat(
          left(email, 1),
          repeat('*', instr(email, '@') - 2),
          substring(email, instr(email, '@'))
        )
      END
    """)

    # rowfilter_deny_all - row filter that hides every row.
    # Expects:       no arguments.
    # Configurable:  nothing. Exemptions come from the policy's except_principals.
    # Not supported: conditional visibility. Use rowfilter_attribute.
    spark.sql(f"""
      CREATE OR REPLACE FUNCTION {fqn}.rowfilter_deny_all()
      RETURNS BOOLEAN
      LANGUAGE SQL
      DETERMINISTIC
      COMMENT 'UDF pack ${var.udf_pack_version}. Row filter. Always returns false. Pair with except_principals in the ABAC policy.'
      RETURN false
    """)

    # mask_ssn - keeps the last 4 digits of a US SSN.
    # Expects:       STRING, NULL returns NULL. Non-digits are stripped first.
    # Configurable:  nothing.
    # Not supported: non-US identifiers. Output is rewritten to ***-**-NNNN.
    spark.sql(f"""
      CREATE OR REPLACE FUNCTION {fqn}.mask_ssn(ssn STRING)
      RETURNS STRING
      LANGUAGE SQL
      DETERMINISTIC
      COMMENT 'UDF pack ${var.udf_pack_version}. SSN: last 4 digits visible. Example: 123-45-6789 to ***-**-6789.'
      RETURN CASE
        WHEN ssn IS NULL THEN NULL
        WHEN length(regexp_replace(ssn, '[^0-9]', '')) >= 4
          THEN concat('***-**-', right(regexp_replace(ssn, '[^0-9]', ''), 4))
        ELSE repeat('*', length(ssn))
      END
    """)

    # mask_phone - keeps the last 4 digits of a phone number.
    # Expects:       STRING, NULL returns NULL. Non-digits are stripped first.
    # Configurable:  nothing.
    # Not supported: preserving the input format. Every result becomes ***-***-NNNN,
    #                so an international number loses its country code.
    spark.sql(f"""
      CREATE OR REPLACE FUNCTION {fqn}.mask_phone(phone STRING)
      RETURNS STRING
      LANGUAGE SQL
      DETERMINISTIC
      COMMENT 'UDF pack ${var.udf_pack_version}. Phone: last 4 digits visible. Example: (212) 555-1234 to ***-***-1234.'
      RETURN CASE
        WHEN phone IS NULL THEN NULL
        WHEN length(regexp_replace(phone, '[^0-9]', '')) >= 4
          THEN concat('***-***-', right(regexp_replace(phone, '[^0-9]', ''), 4))
        ELSE repeat('*', length(phone))
      END
    """)

    # mask_dob - keeps the year of a date held as text.
    # Expects:       STRING, NULL returns NULL. YYYY-MM-DD or YYYY/MM/DD; anything
    #                else masks fully, so a DD-MM-YYYY column loses its year too.
    # Configurable:  nothing.
    # Not supported: other layouts, or DATE columns. Use mask_dob_date.
    spark.sql(f"""
      CREATE OR REPLACE FUNCTION {fqn}.mask_dob(dob STRING)
      RETURNS STRING
      LANGUAGE SQL
      DETERMINISTIC
      COMMENT 'UDF pack ${var.udf_pack_version}. DOB string: year visible. Example: 1990-03-15 to 1990-**-**.'
      RETURN CASE
        WHEN dob IS NULL THEN NULL
        WHEN dob rlike '^[0-9]{{4}}[-/][0-9]{{2}}[-/][0-9]{{2}}$'
          THEN concat(left(dob, 4), '-**-**')
        ELSE repeat('*', length(dob))
      END
    """)

    # mask_name - keeps the first character of each word.
    # Expects:       STRING, NULL returns NULL. Words split on a single space; an
    #                all-whitespace value is returned unchanged.
    # Configurable:  nothing.
    # Not supported: hyphenated or comma-separated names, which count as one word. A
    #                one-character word is returned in full, so initials stay readable.
    spark.sql(f"""
      CREATE OR REPLACE FUNCTION {fqn}.mask_name(name STRING)
      RETURNS STRING
      LANGUAGE SQL
      DETERMINISTIC
      COMMENT 'UDF pack ${var.udf_pack_version}. Full name: first character per word visible. Example: John Smith to J*** S****.'
      RETURN CASE
        WHEN name IS NULL THEN NULL
        WHEN length(trim(name)) = 0 THEN name
        ELSE array_join(
          transform(
            split(trim(name), ' '),
            w -> CASE
                   WHEN length(w) <= 1 THEN w
                   ELSE concat(left(w, 1), repeat('*', length(w) - 1))
                 END
          ),
          ' '
        )
      END
    """)

    # mask_keep_first4 - keeps the leading 4 characters.
    # Expects:       STRING, NULL returns NULL. 4 characters or fewer masks fully.
    # Configurable:  nothing. The count and the '*' fill are literals.
    # Not supported: a different width, or keeping the tail instead of the head.
    spark.sql(f"""
      CREATE OR REPLACE FUNCTION {fqn}.mask_keep_first4(value STRING)
      RETURNS STRING
      LANGUAGE SQL
      DETERMINISTIC
      COMMENT 'UDF pack ${var.udf_pack_version}. First 4 characters visible. Example: 4111222233334444 to 4111************.'
      RETURN CASE
        WHEN value IS NULL THEN NULL
        WHEN length(value) <= 4 THEN repeat('*', length(value))
        ELSE concat(left(value, 4), repeat('*', length(value) - 4))
      END
    """)

    # mask_dob_date - keeps the year of a DATE column.
    # Expects:       DATE, NULL returns NULL. Returns DATE, so no cast is needed.
    # Configurable:  nothing. The result is always 1 January.
    # Not supported: keeping the month, or TIMESTAMP columns.
    spark.sql(f"""
      CREATE OR REPLACE FUNCTION {fqn}.mask_dob_date(dob DATE)
      RETURNS DATE
      LANGUAGE SQL
      DETERMINISTIC
      COMMENT 'UDF pack ${var.udf_pack_version}. DOB date: returns first day of birth year. Example: 1990-03-15 to 1990-01-01. For STRING columns use mask_dob.'
      RETURN CASE
        WHEN dob IS NULL THEN NULL
        ELSE make_date(year(dob), 1, 1)
      END
    """)

    # rowfilter_attribute - row filter for Appendix D Patterns 1-10 and 12.
    # Expects:       sdlc, workspace and csi as policy constants, attribute_value from
    #                the row. Tests dbx-<sdlc>-<workspace>-<csi>-<value>-access.
    #                Any null argument denies.
    # Configurable:  all four arguments, so one function covers every attribute that
    #                follows the group naming standard.
    # Not supported: group names outside that standard, or more than one attribute.
    #
    # Null guard: concat with a null yields null, and is_account_group_member(null) is not a documented deny.
    spark.sql(f"""
      CREATE OR REPLACE FUNCTION {fqn}.rowfilter_attribute(
        sdlc STRING,
        workspace STRING,
        csi STRING,
        attribute_value STRING
      )
      RETURNS BOOLEAN
      COMMENT 'UDF pack ${var.udf_pack_version}. Row filter for Appendix D Patterns 1-10 and 12. True when the caller is in dbx-<sdlc>-<workspace>-<csi>-<attribute_value>-access. Denies on null.'
      RETURN CASE
        WHEN sdlc IS NULL OR workspace IS NULL OR csi IS NULL OR attribute_value IS NULL
          THEN false
        ELSE is_account_group_member(
          concat(
            'dbx-',
            lower(sdlc), '-',
            lower(workspace), '-',
            csi, '-',
            lower(attribute_value),
            '-access'
          )
        )
      END
    """)

    # rowfilter_dimension - collision-safe variant of rowfilter_attribute.
    # Expects:       the three scope constants, the dimension name, and the value.
    #                Tests dbx-<sdlc>-<workspace>-<csi>-<dimension>-<value>-access.
    # Configurable:  all five arguments.
    # Not supported: nothing beyond rowfilter_attribute. This exists because a name
    #                built from the value alone collapses values that appear in more
    #                than one dimension: PAYMENTS is both a domain and a team, and
    #                OPERATIONS is both a domain and a cost centre, so a holder of one
    #                entitlement silently satisfies the other.
    #
    # INERT until the naming decision lands. The 504-group Day-1 inventory carries no
    # dimension segment, so a policy wired to this today denies everything. It is
    # deployed ready rather than in use: see ABAC_OPEN_QUESTIONS.md question 1.
    spark.sql(f"""
      CREATE OR REPLACE FUNCTION {fqn}.rowfilter_dimension(
        sdlc STRING,
        workspace STRING,
        csi STRING,
        dimension STRING,
        attribute_value STRING
      )
      RETURNS BOOLEAN
      COMMENT 'UDF pack ${var.udf_pack_version}. Row filter. True when the caller is in dbx-<sdlc>-<workspace>-<csi>-<dimension>-<attribute_value>-access. Qualifying by dimension stops values shared between dimensions resolving to one group. Requires groups provisioned with the dimension segment. Denies on null.'
      RETURN CASE
        WHEN sdlc IS NULL OR workspace IS NULL OR csi IS NULL
          OR dimension IS NULL OR attribute_value IS NULL
          THEN false
        ELSE is_account_group_member(
          concat(
            'dbx-',
            lower(sdlc), '-',
            lower(workspace), '-',
            csi, '-',
            lower(dimension), '-',
            lower(attribute_value),
            '-access'
          )
        )
      END
    """)

    # rowfilter_hierarchy - row filter for Appendix D Pattern 11.
    # Expects:       the three scope constants, plus portfolio and product from the
    #                row. Only product forms the name; portfolio rides the CSI
    #                segment. Any null argument denies.
    # Configurable:  all five arguments; the two-level shape is fixed.
    # Not supported: a third level, or testing portfolio as its own group. Portfolio is
    #                reserved: it stays in the signature so a null in it still denies,
    #                but it never reaches the group name. That makes a caller entitled
    #                to a product visible across every portfolio containing it. If
    #                portfolio-level groups get provisioned, express Pattern 11 as
    #                rowfilter_attributes_and(sdlc, workspace, csi, portfolio,
    #                product, '-') and retire this function.
    spark.sql(f"""
      CREATE OR REPLACE FUNCTION {fqn}.rowfilter_hierarchy(
        sdlc STRING,
        workspace STRING,
        csi STRING,
        portfolio STRING,
        product STRING
      )
      RETURNS BOOLEAN
      COMMENT 'UDF pack ${var.udf_pack_version}. Row filter for Appendix D Pattern 11. True when the caller is in dbx-<sdlc>-<workspace>-<csi>-<product>-access. Portfolio is carried by the CSI segment, not checked as its own group. Denies on null.'
      RETURN CASE
        WHEN sdlc IS NULL OR workspace IS NULL OR csi IS NULL
          OR portfolio IS NULL OR product IS NULL
          THEN false
        ELSE is_account_group_member(
          concat(
            'dbx-',
            lower(sdlc), '-',
            lower(workspace), '-',
            csi, '-',
            lower(product),
            '-access'
          )
        )
      END
    """)

    # mask_any_type - column mask for Appendix D Patterns 9, 10 and 12.
    # Expects:       any column as VARIANT, NULL returns NULL. Returns VARIANT, which
    #                the policy casts back to the column type; a STRING return fails
    #                that cast on anything else, which is why this one is not typed.
    # Configurable:  nothing. Each type has a fixed sentinel, chosen only to be a
    #                legal value of that type rather than to carry meaning.
    # Not supported: partial, hashed or conditional masking. BINARY and ARRAY mask to
    #                NULL. MAP, STRUCT and INTERVAL cannot cast to VARIANT, so a policy
    #                targeting one fails the query. Narrow MATCH COLUMNS to exclude them;
    #                try_cast below cannot prevent it, because the failing cast is the
    #                policy converting this function's VARIANT return back to the
    #                column type, which happens outside the function body.
    spark.sql(f"""
      CREATE OR REPLACE FUNCTION {fqn}.mask_any_type(v VARIANT)
      RETURNS VARIANT
      LANGUAGE SQL
      DETERMINISTIC
      COMMENT 'UDF pack ${var.udf_pack_version}. Column mask for Appendix D Patterns 9, 10 and 12. VARIANT so one function covers the supported column types: an ABAC policy casts the result back to the column type, and a STRING mask fails that cast on any non-string column. BINARY and ARRAY mask to NULL. MAP, STRUCT and INTERVAL cannot cast to VARIANT, so do not target them.'
      RETURN CASE
        WHEN v IS NULL THEN NULL
        ELSE CASE schema_of_variant(v)
          WHEN 'STRING' THEN try_cast('****' AS VARIANT)
          WHEN 'BIGINT' THEN try_cast(0 AS VARIANT)
          WHEN 'DOUBLE' THEN try_cast(0 AS VARIANT)
          WHEN 'FLOAT' THEN try_cast(0 AS VARIANT)
          WHEN 'DATE' THEN try_cast(DATE'1970-01-01' AS VARIANT)
          WHEN 'TIMESTAMP' THEN try_cast(TIMESTAMP'1970-01-01 00:00:00' AS VARIANT)
          WHEN 'TIMESTAMP_NTZ' THEN try_cast(TIMESTAMP_NTZ'1970-01-01 00:00:00' AS VARIANT)
          WHEN 'BOOLEAN' THEN try_cast(false AS VARIANT)
          ELSE CASE WHEN startswith(schema_of_variant(v), 'DECIMAL')
            THEN try_cast(0 AS VARIANT) ELSE NULL END
        END
      END
    """)

    # mask_by_classification - column mask that branches on the classification tag.
    # Expects:       any column as VARIANT plus the classification value, which the
    #                policy supplies from a constant or a tag. NULL classification
    #                masks, so an untagged column never leaks.
    # Configurable:  the passthrough vocabulary in the IN list.
    # Not supported: per-principal behaviour. Use mask_unless_entitled for that.
    #
    # The Databricks example for this shape ends 'ELSE col', which fails open on any
    # value not in the list. This ends on the mask instead.
    spark.sql(f"""
      CREATE OR REPLACE FUNCTION {fqn}.mask_by_classification(
        v VARIANT,
        classification STRING
      )
      RETURNS VARIANT
      LANGUAGE SQL
      DETERMINISTIC
      COMMENT 'UDF pack ${var.udf_pack_version}. Column mask. Returns the value for PUBLIC and INTERNAL, otherwise the mask_any_type sentinel. A null classification masks, so an untagged column does not leak.'
      RETURN CASE
        WHEN v IS NULL THEN NULL
        WHEN classification IS NULL THEN {fqn}.mask_any_type(v)
        WHEN lower(classification) IN ('public', 'internal') THEN v
        ELSE {fqn}.mask_any_type(v)
      END
    """)

    # mask_unless_entitled - column mask that resolves its own entitlement.
    # Expects:       the column as VARIANT, the three scope constants, and the
    #                classification. Reveals the value when the caller holds the
    #                matching scoped group, masks otherwise.
    # Configurable:  all five arguments.
    # Not supported: partial masking, or a vocabulary branch. Compose with
    #                mask_by_classification if both are needed.
    #
    # Entitlement normally belongs in the policy's TO/EXCEPT clauses, but those cap at
    # 20 principals across both and the group inventory is far larger, so the check has
    # to move into the function. Every argument is constant for the query, so the
    # identity lookup resolves once at analysis time rather than per row.
    spark.sql(f"""
      CREATE OR REPLACE FUNCTION {fqn}.mask_unless_entitled(
        v VARIANT,
        sdlc STRING,
        workspace STRING,
        csi STRING,
        classification STRING
      )
      RETURNS VARIANT
      COMMENT 'UDF pack ${var.udf_pack_version}. Column mask. Returns the value when the caller is in dbx-<sdlc>-<workspace>-<csi>-<classification>-access, otherwise the mask_any_type sentinel. Masks on null. Use when the 20-principal cap on TO and EXCEPT makes an enumerated exemption list unworkable.'
      RETURN CASE
        WHEN v IS NULL THEN NULL
        WHEN sdlc IS NULL OR workspace IS NULL OR csi IS NULL OR classification IS NULL
          THEN {fqn}.mask_any_type(v)
        WHEN is_account_group_member(
          concat(
            'dbx-',
            lower(sdlc), '-',
            lower(workspace), '-',
            csi, '-',
            lower(classification),
            '-access'
          )
        ) THEN v
        ELSE {fqn}.mask_any_type(v)
      END
    """)

    # mask_partial_unless_entitled - entitlement-gated mask that falls back to a PARTIAL,
    # not a blank. The membership-aware counterpart of the format masks.
    # Expects:       the value (STRING), the three scope constants, the classification, and
    #                a style. Reveals the raw value to a member of
    #                dbx-<sdlc>-<workspace>-<csi>-<classification>-access; everyone else sees
    #                the partial named by `style`, so a support user still sees ***-**-6789
    #                rather than ****.
    # Configurable:  all arguments. `style` is one of email, ssn, phone, name, dob, first4,
    #                last4, redact (composes the matching format mask). Unknown or null style
    #                fails safe to a full redact.
    # Not supported: non-STRING columns. This returns STRING (so a revealed string is not
    #                JSON-quoted, unlike the VARIANT mask_unless_entitled); for other column
    #                types use mask_unless_entitled, which reveals-or-blanks any type.
    #
    # Masks on null scope/classification (fails closed to the partial, never reveals).
    spark.sql(f"""
      CREATE OR REPLACE FUNCTION {fqn}.mask_partial_unless_entitled(
        v STRING,
        sdlc STRING,
        workspace STRING,
        csi STRING,
        classification STRING,
        style STRING
      )
      RETURNS STRING
      COMMENT 'UDF pack ${var.udf_pack_version}. Column mask for STRING columns. Reveals the raw value to a member of dbx-<sdlc>-<workspace>-<csi>-<classification>-access; everyone else gets the partial named by style (email, ssn, phone, name, dob, first4, last4, redact), not a blank. Unknown/null style or null scope fails safe to a full redact. Returns STRING so a revealed value is not JSON-quoted; for non-string columns use mask_unless_entitled.'
      RETURN CASE
        WHEN v IS NULL THEN NULL
        WHEN sdlc IS NOT NULL AND workspace IS NOT NULL AND csi IS NOT NULL
          AND classification IS NOT NULL
          AND is_account_group_member(
            concat(
              'dbx-',
              lower(sdlc), '-',
              lower(workspace), '-',
              csi, '-',
              lower(classification),
              '-access'
            )
          ) THEN v
        ELSE CASE lower(coalesce(style, 'redact'))
          WHEN 'email'  THEN {fqn}.mask_email(v)
          WHEN 'ssn'    THEN {fqn}.mask_ssn(v)
          WHEN 'phone'  THEN {fqn}.mask_phone(v)
          WHEN 'name'   THEN {fqn}.mask_name(v)
          WHEN 'dob'    THEN {fqn}.mask_dob(v)
          WHEN 'first4' THEN {fqn}.mask_keep_first4(v)
          WHEN 'last4'  THEN {fqn}.mask_keep_last4(v)
          WHEN 'redact' THEN {fqn}.mask_redact_all(v)
          ELSE {fqn}.mask_redact_all(v)
        END
      END
    """)

    # rowfilter_attributes_and - the standard row filter: AND up to TEN attribute checks.
    # Expects:       the three scope constants plus up to TEN attribute values. v1 is
    #                required; v2..v10 accept the literal '-' to mean "this slot is
    #                unused" (so a 1-, 2- or 3-attribute pattern just fills the rest with '-').
    #                Binds directly as a SET ROW FILTER because every parameter is scalar:
    #                ON ('dev','ws','csi', country, domain, team, '-', ...).
    # Configurable:  all arguments; no app-specific values are baked in.
    # Not supported: an array parameter. SET ROW FILTER's ON clause takes only bare
    #                columns and scalar literals, so array(...) cannot be passed there —
    #                which is why this is fixed-arity. More than ten attributes needs a
    #                wider sibling. For non-row-filter callers use entitled_to_attributes.
    #
    # A single composed row filter has no MATCH COLUMNS 3-condition cap, so this covers
    # every AND-pattern (Pattern 10 needs seven). Null in any slot denies, so a missing tag
    # never widens access; '-' is the only "unused" marker.
    spark.sql(f"""
      CREATE OR REPLACE FUNCTION {fqn}.rowfilter_attributes_and(
        sdlc STRING, workspace STRING, csi STRING,
        v1 STRING, v2 STRING, v3 STRING, v4 STRING, v5 STRING,
        v6 STRING, v7 STRING, v8 STRING, v9 STRING, v10 STRING
      )
      RETURNS BOOLEAN
      COMMENT 'UDF pack ${var.udf_pack_version}. Standard row filter. Conjunction of up to TEN scoped attribute checks; binds via SET ROW FILTER over scalar columns. v1 required; pass the literal ''-'' for any of v2..v10 to leave that slot out (a single-attribute filter fills v2..v10 with ''-''). Denies on null so a missing tag never widens access. No MATCH COLUMNS 3-condition cap.'
      RETURN CASE
        WHEN sdlc IS NULL OR workspace IS NULL OR csi IS NULL OR v1 IS NULL THEN false
        WHEN v2 IS NULL OR v3 IS NULL OR v4 IS NULL OR v5 IS NULL OR v6 IS NULL
          OR v7 IS NULL OR v8 IS NULL OR v9 IS NULL OR v10 IS NULL THEN false
        ELSE {fqn}.rowfilter_attribute(sdlc, workspace, csi, v1)
         AND (v2  = '-' OR {fqn}.rowfilter_attribute(sdlc, workspace, csi, v2))
         AND (v3  = '-' OR {fqn}.rowfilter_attribute(sdlc, workspace, csi, v3))
         AND (v4  = '-' OR {fqn}.rowfilter_attribute(sdlc, workspace, csi, v4))
         AND (v5  = '-' OR {fqn}.rowfilter_attribute(sdlc, workspace, csi, v5))
         AND (v6  = '-' OR {fqn}.rowfilter_attribute(sdlc, workspace, csi, v6))
         AND (v7  = '-' OR {fqn}.rowfilter_attribute(sdlc, workspace, csi, v7))
         AND (v8  = '-' OR {fqn}.rowfilter_attribute(sdlc, workspace, csi, v8))
         AND (v9  = '-' OR {fqn}.rowfilter_attribute(sdlc, workspace, csi, v9))
         AND (v10 = '-' OR {fqn}.rowfilter_attribute(sdlc, workspace, csi, v10))
      END
    """)

    # rowfilter_dimensions_and - collision-safe wide row filter.
    # Expects:       the three scope constants, then up to TEN (dimension, value) PAIRS.
    #                The first pair is required; for an unused pair pass '-' for BOTH its
    #                dimension and its value. Binds directly as a SET ROW FILTER:
    #                ON ('dev','ws','csi', 'country', country, 'domain', domain, '-','-', ...).
    # Configurable:  all arguments. Qualifying by dimension stops values shared across
    #                dimensions resolving to the same group (see rowfilter_dimension).
    # Not supported: an array parameter (same ON-clause limitation), or more than ten
    #                pairs. For non-row-filter callers use entitled_to_dimensions.
    #
    # INERT until groups carry a dimension segment, exactly like rowfilter_dimension.
    spark.sql(f"""
      CREATE OR REPLACE FUNCTION {fqn}.rowfilter_dimensions_and(
        sdlc STRING, workspace STRING, csi STRING,
        d1 STRING, v1 STRING, d2 STRING, v2 STRING, d3 STRING, v3 STRING,
        d4 STRING, v4 STRING, d5 STRING, v5 STRING, d6 STRING, v6 STRING,
        d7 STRING, v7 STRING, d8 STRING, v8 STRING, d9 STRING, v9 STRING,
        d10 STRING, v10 STRING
      )
      RETURNS BOOLEAN
      COMMENT 'UDF pack ${var.udf_pack_version}. Row filter. Conjunction of up to TEN dimension-qualified attribute checks; binds via SET ROW FILTER over scalar columns. First pair required; pass ''-'' for BOTH the dimension and value of an unused pair. Denies on null. Requires groups provisioned with the dimension segment.'
      RETURN CASE
        WHEN sdlc IS NULL OR workspace IS NULL OR csi IS NULL OR d1 IS NULL OR v1 IS NULL THEN false
        WHEN d2 IS NULL OR v2 IS NULL OR d3 IS NULL OR v3 IS NULL OR d4 IS NULL OR v4 IS NULL
          OR d5 IS NULL OR v5 IS NULL OR d6 IS NULL OR v6 IS NULL OR d7 IS NULL OR v7 IS NULL
          OR d8 IS NULL OR v8 IS NULL OR d9 IS NULL OR v9 IS NULL OR d10 IS NULL OR v10 IS NULL THEN false
        ELSE {fqn}.rowfilter_dimension(sdlc, workspace, csi, d1, v1)
         AND (v2  = '-' OR {fqn}.rowfilter_dimension(sdlc, workspace, csi, d2,  v2))
         AND (v3  = '-' OR {fqn}.rowfilter_dimension(sdlc, workspace, csi, d3,  v3))
         AND (v4  = '-' OR {fqn}.rowfilter_dimension(sdlc, workspace, csi, d4,  v4))
         AND (v5  = '-' OR {fqn}.rowfilter_dimension(sdlc, workspace, csi, d5,  v5))
         AND (v6  = '-' OR {fqn}.rowfilter_dimension(sdlc, workspace, csi, d6,  v6))
         AND (v7  = '-' OR {fqn}.rowfilter_dimension(sdlc, workspace, csi, d7,  v7))
         AND (v8  = '-' OR {fqn}.rowfilter_dimension(sdlc, workspace, csi, d8,  v8))
         AND (v9  = '-' OR {fqn}.rowfilter_dimension(sdlc, workspace, csi, d9,  v9))
         AND (v10 = '-' OR {fqn}.rowfilter_dimension(sdlc, workspace, csi, d10, v10))
      END
    """)

    # entitled_to_attributes - array-input conjunction (NOT a row filter).
    # Expects:       the three scope constants plus an ARRAY<STRING> of attribute values.
    #                ANDs a scoped check over every element, with no length cap.
    # Configurable:  all arguments.
    # Not supported: binding directly as a SET ROW FILTER over separate columns — the ON
    #                clause cannot build an array from columns. It DOES bind when the table
    #                has a real ARRAY<STRING> column (ON (...,'-', attrs_col)). Otherwise use
    #                it in WHERE, in a mask, or from a wrapper; for a wide row filter over
    #                one-column-per-dimension tables use rowfilter_attributes_and.
    #
    # Empty or null array denies; a null element denies (a missing tag never widens access).
    spark.sql(f"""
      CREATE OR REPLACE FUNCTION {fqn}.entitled_to_attributes(
        sdlc STRING, workspace STRING, csi STRING, attribute_values ARRAY<STRING>
      )
      RETURNS BOOLEAN
      COMMENT 'UDF pack ${var.udf_pack_version}. Conjunction of a scoped attribute check over every element of attribute_values, uncapped. Empty or null array denies, as does a null element. Scalar helper: cannot bind as a row filter over separate columns (bind rowfilter_attributes_and there), but works in WHERE, masks, or over a real ARRAY column.'
      RETURN CASE
        WHEN sdlc IS NULL OR workspace IS NULL OR csi IS NULL OR attribute_values IS NULL THEN false
        WHEN cardinality(attribute_values) = 0 THEN false
        ELSE forall(attribute_values, av -> av IS NOT NULL AND is_account_group_member(
          concat('dbx-', lower(sdlc), '-', lower(workspace), '-', csi, '-', lower(av), '-access')))
      END
    """)

    # entitled_to_dimensions - array-input, dimension-qualified (NOT a row filter).
    # Expects:       the three scope constants plus two parallel arrays: dimensions and
    #                attribute_values, checked as zipped (dimension, value) pairs. Uncapped.
    # Configurable:  all arguments.
    # Not supported: binding as a SET ROW FILTER over separate columns (same reason as
    #                entitled_to_attributes). Use rowfilter_dimensions_and
    #                for that. Arrays of unequal length deny.
    #
    # Empty or null array, length mismatch, or a null element all deny.
    spark.sql(f"""
      CREATE OR REPLACE FUNCTION {fqn}.entitled_to_dimensions(
        sdlc STRING, workspace STRING, csi STRING,
        dimensions ARRAY<STRING>, attribute_values ARRAY<STRING>
      )
      RETURNS BOOLEAN
      COMMENT 'UDF pack ${var.udf_pack_version}. Dimension-qualified conjunction over zipped (dimension, value) pairs, uncapped. Empty/null arrays, unequal lengths, or a null element all deny. Scalar helper: cannot bind as a row filter over separate columns (use rowfilter_dimensions_and there). Requires groups provisioned with the dimension segment.'
      RETURN CASE
        WHEN sdlc IS NULL OR workspace IS NULL OR csi IS NULL
          OR dimensions IS NULL OR attribute_values IS NULL THEN false
        WHEN cardinality(dimensions) = 0
          OR cardinality(dimensions) != cardinality(attribute_values) THEN false
        ELSE forall(
          zip_with(dimensions, attribute_values, (d, av) ->
            d IS NOT NULL AND av IS NOT NULL AND is_account_group_member(
              concat('dbx-', lower(sdlc), '-', lower(workspace), '-', csi, '-',
                     lower(d), '-', lower(av), '-access'))),
          x -> x)
      END
    """)

    udf_names = [
        "mask_redact_all", "mask_keep_last4", "mask_email",
        "rowfilter_deny_all", "mask_ssn", "mask_phone", "mask_dob",
        "mask_name", "mask_keep_first4", "mask_dob_date",
        "rowfilter_attribute", "rowfilter_attributes_and",
        "rowfilter_dimension", "rowfilter_dimensions_and", "rowfilter_hierarchy",
        "mask_any_type", "mask_by_classification", "mask_unless_entitled",
        "mask_partial_unless_entitled",
        "entitled_to_attributes", "entitled_to_dimensions",
    ]

    function_owner = "${var.function_owner_principal != null ? var.function_owner_principal : ""}"
    if function_owner:
        escaped_owner = function_owner.replace("`", "``")
        for fn in udf_names:
            try:
                spark.sql(f"ALTER FUNCTION {fqn}.{fn} OWNER TO `{escaped_owner}`")
            except Exception as e:
                raise RuntimeError(f"Failed to transfer ownership of {fqn}.{fn}: {e}") from e
        print(f"Ownership of {len(udf_names)} UDFs transferred to: {function_owner}")

    print(f"UDF Pack ${var.udf_pack_version}: {len(udf_names)} UDFs deployed to {fqn}.")
  PYTHON
}

resource "databricks_schema" "this" {
  catalog_name  = var.catalog_name
  name          = var.schema_name
  comment       = var.comment
  owner         = var.owner
  force_destroy = var.force_destroy
}

resource "databricks_notebook" "udf_setup" {
  path           = local.notebook_path
  language       = "PYTHON"
  content_base64 = base64encode(local.notebook_content)

  depends_on = [databricks_schema.this]
}

resource "databricks_job" "udf_setup" {
  name                = "security-udf-pack-${var.catalog_name}-${var.schema_name}"
  tags                = merge(var.tags, { udf_pack_version = var.udf_pack_version })
  max_concurrent_runs = 1

  dynamic "run_as" {
    for_each = var.run_as_service_principal_application_id != null ? [1] : []
    content {
      service_principal_name = var.run_as_service_principal_application_id
    }
  }

  task {
    task_key            = "create-udfs"
    existing_cluster_id = var.existing_cluster_id

    notebook_task {
      notebook_path = databricks_notebook.udf_setup.path
    }
  }

}

resource "databricks_grant" "this" {
  for_each = local.grants_map

  schema     = local.schema_fqn
  principal  = each.key
  privileges = each.value.privileges

  depends_on = [databricks_schema.this]
}
