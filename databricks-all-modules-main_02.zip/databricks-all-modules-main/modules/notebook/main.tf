resource "databricks_notebook" "this" {
  path     = var.path
  language = var.language
  format   = var.format

  content_base64 = var.content_base64
  source         = var.notebook_source

  lifecycle {
    precondition {
      condition = (
        (var.content_base64 != null && length(var.content_base64) > 0) ? 1 : 0
        ) + (
        (var.notebook_source != null && length(trimspace(var.notebook_source)) > 0) ? 1 : 0
      ) == 1
      error_message = "Exactly one non-empty value among content_base64 and notebook_source must be provided."
    }
  }
}

# ACLs cover CI/CD-deployed notebooks only.
# Groups follow: dbx-{environment}-{app_id}-{app_acronym}-{role}-grp
locals {
  analyst_group  = "dbx-${var.environment}-${var.app_id}-${var.app_acronym}-analyst-grp"
  engineer_group = "dbx-${var.environment}-${var.app_id}-${var.app_acronym}-engineer-grp"
  deployer_group = "dbx-${var.environment}-${var.app_id}-${var.app_acronym}-deployer-grp"
  support_group  = "dbx-${var.environment}-${var.app_id}-${var.app_acronym}-support-grp"

  analyst_notebook_permission  = var.environment == "dev" ? "CAN_RUN" : "CAN_READ"
  engineer_notebook_permission = var.environment == "dev" ? "CAN_EDIT" : "CAN_READ"

  group_acls = [
    { group_name = local.analyst_group, user_name = null, service_principal_name = null, permission_level = local.analyst_notebook_permission },
    { group_name = local.engineer_group, user_name = null, service_principal_name = null, permission_level = local.engineer_notebook_permission },
    { group_name = local.deployer_group, user_name = null, service_principal_name = null, permission_level = "CAN_EDIT" },
    { group_name = local.support_group, user_name = null, service_principal_name = null, permission_level = "CAN_RUN" },
  ]
  all_acls = concat(local.group_acls, var.access_controls)

  standard_groups = toset([local.analyst_group, local.engineer_group, local.deployer_group, local.support_group])
  acl_overlap = setintersection(
    toset([for acl in var.access_controls : trimspace(acl.group_name) if acl.group_name != null && length(trimspace(acl.group_name)) > 0]),
    local.standard_groups
  )

  custom_principals = [
    for acl in var.access_controls :
    acl.group_name != null ? "group:${trimspace(acl.group_name)}" :
    acl.user_name != null ? "user:${trimspace(acl.user_name)}" :
    "sp:${trimspace(acl.service_principal_name)}"
  ]
}

resource "databricks_permissions" "notebook" {
  notebook_path = databricks_notebook.this.path

  lifecycle {
    precondition {
      condition     = length(local.acl_overlap) == 0
      error_message = "Group(s) [${join(", ", local.acl_overlap)}] appear in both the standard set and access_controls. The Databricks API rejects duplicate principals."
    }
    precondition {
      condition     = length(local.custom_principals) == length(toset(local.custom_principals))
      error_message = "access_controls contains duplicate principals. Each group, user, or service principal may appear only once."
    }
  }

  dynamic "access_control" {
    for_each = local.all_acls
    content {
      group_name             = access_control.value.group_name
      user_name              = access_control.value.user_name
      service_principal_name = access_control.value.service_principal_name
      permission_level       = access_control.value.permission_level
    }
  }
}
