variable "path" {
  description = "The path to the notebook in the Databricks workspace (e.g. /Shared/my-notebook)."
  type        = string

  validation {
    condition     = length(trimspace(var.path)) > 0
    error_message = "path must not be empty."
  }
}

variable "language" {
  description = "The language of the notebook (PYTHON, SCALA, SQL, or R)"
  type        = string

  validation {
    condition     = contains(["PYTHON", "SCALA", "SQL", "R"], var.language)
    error_message = "language must be one of: PYTHON, SCALA, SQL, R."
  }
}

variable "format" {
  description = "The format of the notebook (SOURCE, HTML, JUPYTER, or DBC)"
  type        = string
  default     = "SOURCE"

  validation {
    condition     = contains(["SOURCE", "HTML", "JUPYTER", "DBC"], var.format)
    error_message = "format must be one of: SOURCE, HTML, JUPYTER, DBC."
  }
}

variable "content_base64" {
  description = "The base64-encoded content of the notebook"
  type        = string
  default     = null
}

variable "notebook_source" {
  description = "Path to the notebook file on the local filesystem"
  type        = string
  default     = null
}


variable "app_acronym" {
  description = "CSI application acronym used in group name construction (e.g. dms)."
  type        = string

  validation {
    condition     = length(trimspace(var.app_acronym)) > 0
    error_message = "app_acronym must not be empty."
  }
}

variable "environment" {
  description = "Deployment environment used in group name construction (e.g. dev, uat, prod)."
  type        = string

  validation {
    condition     = contains(["dev", "uat", "prod"], var.environment)
    error_message = "environment must be one of: dev, uat, prod."
  }
}

variable "app_id" {
  description = "Application identifier / CSI used in group name construction (e.g. 179392)."
  type        = string

  validation {
    condition     = length(trimspace(var.app_id)) > 0
    error_message = "app_id must not be empty."
  }
}

variable "access_controls" {
  description = "Additional user or service principal ACL entries. Exactly one of group_name, user_name, or service_principal_name must be set per entry."
  type = list(object({
    group_name             = optional(string)
    user_name              = optional(string)
    service_principal_name = optional(string)
    permission_level       = string
  }))
  default = []

  validation {
    condition = alltrue([
      for acl in var.access_controls :
      length([for v in [acl.group_name, acl.user_name, acl.service_principal_name] : v if v != null && length(trimspace(v)) > 0]) == 1
    ])
    error_message = "Each access_controls entry must specify exactly one non-empty value among group_name, user_name, or service_principal_name."
  }

  validation {
    condition = alltrue([
      for acl in var.access_controls :
      contains(["CAN_READ", "CAN_RUN", "CAN_EDIT", "CAN_MANAGE"], acl.permission_level)
    ])
    error_message = "permission_level must be one of: CAN_READ, CAN_RUN, CAN_EDIT, CAN_MANAGE. Note: CAN_VIEW is not valid for notebook objects — use CAN_READ instead."
  }
}
