# Example: notebook — creates a CI/CD-deployed notebook with embedded permissions.
# Copy terraform.tfvars.example to terraform.tfvars; auth via env (DATABRICKS_HOST/CLIENT_ID/CLIENT_SECRET).
# ACLs apply to CI/CD-deployed notebooks only — user-created notebooks are unaffected.

provider "databricks" {}

module "notebook" {
  source = "../.."

  path           = var.path
  language       = var.language
  content_base64 = var.content_base64

  app_acronym = var.app_acronym
  environment = var.environment
  app_id      = var.app_id
}
