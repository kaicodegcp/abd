output "notebook_path" {
  description = "The created notebook path."
  value       = module.notebook.path
}

output "notebook_url" {
  description = "URL to the created notebook."
  value       = module.notebook.url
}
