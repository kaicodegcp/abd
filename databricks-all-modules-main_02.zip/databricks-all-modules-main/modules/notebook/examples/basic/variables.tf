variable "path" {
  description = "Workspace path for the notebook (e.g. /Shared/cts/179392/etl)."
  type        = string
}

variable "language" {
  description = "Notebook language (PYTHON, SCALA, SQL, R)."
  type        = string
  default     = "PYTHON"
}

variable "content_base64" {
  description = "Base64-encoded notebook content."
  type        = string
  default     = null
}

variable "app_acronym" {
  description = "CSI application acronym used in group name construction (e.g. dms)."
  type        = string
}

variable "environment" {
  description = "Deployment environment (dev, uat, prod)."
  type        = string
}

variable "app_id" {
  description = "Application identifier used in group name construction."
  type        = string
}
