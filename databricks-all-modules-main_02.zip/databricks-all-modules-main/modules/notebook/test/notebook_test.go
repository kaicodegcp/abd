package test

import (
	"encoding/base64"
	"path/filepath"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	common "github.com/sandbox45/databricks-all-modules/common"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func planNotebookModule(t *testing.T, vars map[string]interface{}) string {
	t.Helper()
	common.SkipIfShortMode(t, "notebook module (plan)")
	common.RequireDatabricksEnv(t)

	opts := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: filepath.Join(".."),
		Vars:         vars,
		NoColor:      true,
	})
	terraform.Init(t, opts)
	plan := terraform.Plan(t, opts)
	require.NotEmpty(t, plan, "terraform plan should produce output")
	return plan
}

// In prod, analysts and engineers get CAN_READ only; also asserts exact group-name derivation.
func TestNotebookModuleProdPermissions(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("notebook-prod")

	notebookContent := base64.StdEncoding.EncodeToString([]byte("# Databricks notebook source\nprint(\"prod\")\n"))

	plan := planNotebookModule(t, map[string]interface{}{
		"path":           "/" + uniqueID + "-ci-cd/notebook",
		"language":       "PYTHON",
		"content_base64": notebookContent,
		"app_acronym":    "dms",
		"environment":    "prod",
		"app_id":         "179392",
	})

	assert.Contains(t, plan, "dbx-prod-179392-dms-analyst-grp")
	assert.Contains(t, plan, "dbx-prod-179392-dms-engineer-grp")
	assert.Contains(t, plan, "dbx-prod-179392-dms-deployer-grp")
	assert.Contains(t, plan, "dbx-prod-179392-dms-support-grp")
	assert.Contains(t, plan, "CAN_READ")
}

func TestNotebookModule(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("notebook")

	notebookContent := base64.StdEncoding.EncodeToString([]byte("# Databricks notebook source\nprint(\"Hello from terratest!\")\n"))

	config := common.ModuleTestConfig{
		ModuleName:      "notebook",
		TestDescription: "Tests Databricks notebook module",
		RequiredVars: map[string]interface{}{
			"path":           "/" + uniqueID + "-ci-cd/notebook",
			"language":       "PYTHON",
			"content_base64": notebookContent,
			"app_acronym":    "dms",
			"environment":    "dev",
			"app_id":         "179392",
		},
		OptionalVars: map[string]interface{}{
			"format": "SOURCE",
		},
		ExpectedOutputs: []string{
			"id",
			"path",
			"permissions_id",
		},
	}

	common.TestModuleWithConfig(t, config)
}

func TestNotebookModuleSQLLanguage(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("notebook-sql")

	notebookContent := base64.StdEncoding.EncodeToString([]byte("-- Databricks notebook source\nSELECT \"Hello from SQL terratest!\"\n"))

	config := common.ModuleTestConfig{
		ModuleName:      "notebook",
		TestDescription: "Tests Databricks notebook module with SQL language",
		RequiredVars: map[string]interface{}{
			"path":           "/" + uniqueID + "-ci-cd/notebook",
			"language":       "SQL",
			"content_base64": notebookContent,
			"app_acronym":    "dms",
			"environment":    "dev",
			"app_id":         "179392",
		},
		ExpectedOutputs: []string{
			"id",
			"path",
			"permissions_id",
		},
	}

	common.TestModuleWithConfig(t, config)
}
