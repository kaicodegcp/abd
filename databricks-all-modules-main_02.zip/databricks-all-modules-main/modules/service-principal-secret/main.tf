resource "time_rotating" "this" {
  rotation_days = var.rotation_days
}

resource "databricks_service_principal_secret" "this" {
  service_principal_id = var.service_principal_id
  lifetime             = var.lifetime
  time_rotating        = time_rotating.this.rfc3339

  lifecycle {
    create_before_destroy = true
  }
}
