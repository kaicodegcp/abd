variable "service_principal_id" {
  type = string
}

variable "rotation_days" {
  type    = number
  default = 90
}

variable "lifetime" {
  type    = string
  default = "23328000s" # 270 days
}
