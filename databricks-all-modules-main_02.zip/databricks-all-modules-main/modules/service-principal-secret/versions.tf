terraform {
  required_providers {
    databricks = {
      source = "databricks/databricks"
    }

    time = {
      source = "hashicorp/time"
    }
  }
}
