output "client_secret" {
  value     = databricks_service_principal_secret.this.secret
  sensitive = true
}
