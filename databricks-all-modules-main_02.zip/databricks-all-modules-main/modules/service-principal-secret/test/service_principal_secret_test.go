package test

import (
	"testing"

	common "github.com/sandbox45/databricks-all-modules/common"
)

func TestServicePrincipalSecretModule(t *testing.T) {
	config := common.ModuleTestConfig{
		ModuleName:      "service-principal-secret",
		TestDescription: "Tests Databricks service principal secret module",
		RequiredVars: map[string]interface{}{
			"service_principal_id": "00000000-0000-0000-0000-000000000001",
		},
		OptionalVars: map[string]interface{}{
			"rotation_days": 90,
			"lifetime":      "23328000s",
		},
		ExpectedOutputs: []string{
			"client_secret",
		},
		SkipDestroy: true,
	}

	common.TestModuleWithConfig(t, config)
}
