package test

import (
	"fmt"
	"path/filepath"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	common "github.com/sandbox45/databricks-all-modules/common"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func baseVars(catalogName string) map[string]interface{} {
	return map[string]interface{}{
		"catalog_name": catalogName,
	}
}

func planModule(t *testing.T, vars map[string]interface{}) string {
	t.Helper()
	opts := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: filepath.Join(".."),
		Vars:         vars,
		NoColor:      true,
	})
	terraform.Init(t, opts)
	return terraform.Plan(t, opts)
}

func planModuleExpectError(t *testing.T, vars map[string]interface{}) error {
	t.Helper()
	opts := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: filepath.Join(".."),
		Vars:         vars,
		NoColor:      true,
	})
	terraform.Init(t, opts)
	_, err := terraform.PlanE(t, opts)
	return err
}

// A row filter that takes no column arguments needs neither match_columns nor using.
// The alias-checking validations used to raise on the null instead of skipping it,
// which made this shape - filter_deny_all, or a UDF given only constants - impossible
// to express through the module.
func TestCatalogAbacBareRowFilterNeedsNoMatchColumns(t *testing.T) {
	common.SkipIfShortMode(t, "catalog-abac bare row filter (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(defaults.CatalogName)
	vars["abac_policies"] = map[string]interface{}{
		"deny_all": map[string]interface{}{
			"type":              "POLICY_TYPE_ROW_FILTER",
			"principals":        []string{"account users"},
			"except_principals": []string{"svc_audit_platform"},
			"row_filter": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.filter_deny_all", defaults.CatalogName),
			},
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)
	assert.Contains(t, plan, `databricks_policy_info.this["deny_all"]`, "a row filter with no column arguments must be accepted")
}

// An alias has to come from match_columns, so one with no match_columns at all is a
// typo that must still be caught.
func TestCatalogAbacRowFilterAliasWithoutMatchColumnsRejected(t *testing.T) {
	common.SkipIfShortMode(t, "catalog-abac orphan row filter alias rejected (plan fail)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(defaults.CatalogName)
	vars["abac_policies"] = map[string]interface{}{
		"scoped": map[string]interface{}{
			"type":       "POLICY_TYPE_ROW_FILTER",
			"principals": []string{"account users"},
			"row_filter": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.has_scoped_attribute", defaults.CatalogName),
				"using":         []map[string]interface{}{{"alias": "orphan"}},
			},
		},
	}

	err := planModuleExpectError(t, vars)
	require.Error(t, err, "plan must fail when a using[].alias has no match_columns to resolve against")
}

// A catalog-scoped policy covers every table in every schema. when_condition is the
// only way to narrow it to, say, tables tagged confidential.
func TestCatalogAbacWhenCondition(t *testing.T) {
	common.SkipIfShortMode(t, "catalog-abac when_condition (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(defaults.CatalogName)
	vars["abac_policies"] = map[string]interface{}{
		"mask_confidential": map[string]interface{}{
			"type":           "POLICY_TYPE_COLUMN_MASK",
			"principals":     []string{"account users"},
			"when_condition": "has_tag_value('classification', 'confidential')",
			"match_columns": []map[string]interface{}{
				{"condition": "has_tag_value('classification', 'confidential')", "alias": "c"},
			},
			"column_mask": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.mask_value", defaults.CatalogName),
				"on_column":     "c",
			},
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, "when_condition", "when_condition must be passed through to the resource")
	assert.Contains(t, plan, "has_tag_value('classification', 'confidential')", "the condition expression must appear in plan")
}

// "" and null are different at the API: an empty condition is not "no condition".
func TestCatalogAbacWhenConditionEmptyRejected(t *testing.T) {
	common.SkipIfShortMode(t, "catalog-abac empty when_condition rejected (plan fail)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(defaults.CatalogName)
	vars["abac_policies"] = map[string]interface{}{
		"filter_all": map[string]interface{}{
			"type":           "POLICY_TYPE_ROW_FILTER",
			"principals":     []string{"account users"},
			"when_condition": "   ",
			"row_filter": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.filter_deny_all", defaults.CatalogName),
			},
		},
	}

	err := planModuleExpectError(t, vars)
	require.Error(t, err, "plan must fail when when_condition is blank or whitespace")
}

// when_condition and get_tag_value() read table tags, not column tags.
func TestCatalogAbacTableTagAssignment(t *testing.T) {
	common.SkipIfShortMode(t, "catalog-abac table tag assignment (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(defaults.CatalogName)
	vars["table_tag_assignments"] = map[string]interface{}{
		"payments.transactions.classification": map[string]interface{}{
			"schema":    "payments",
			"table":     "transactions",
			"tag_key":   "classification",
			"tag_value": "confidential",
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, `databricks_entity_tag_assignment.table["payments.transactions.classification"]`, "table tag must be planned")
	assert.Contains(t, plan, `"tables"`, "entity_type must be tables, not columns")
	assert.Contains(t, plan, fmt.Sprintf("%s.payments.transactions", defaults.CatalogName),
		"entity_name must be the table, with no column segment")
}

func TestCatalogAbacTableTagEmptySchemaRejected(t *testing.T) {
	common.SkipIfShortMode(t, "catalog-abac empty table tag schema rejected (plan fail)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(defaults.CatalogName)
	vars["table_tag_assignments"] = map[string]interface{}{
		"bad": map[string]interface{}{"schema": " ", "table": "transactions", "tag_key": "classification"},
	}

	err := planModuleExpectError(t, vars)
	require.Error(t, err, "plan must fail when a table tag's schema is blank")
}

func TestCatalogAbacColumnMaskPolicy(t *testing.T) {
	common.SkipIfShortMode(t, "catalog-abac column mask (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(defaults.CatalogName)
	vars["column_tag_assignments"] = map[string]interface{}{
		"payments.transactions.ssn": map[string]interface{}{
			"schema":    "payments",
			"table":     "transactions",
			"column":    "ssn",
			"tag_key":   "data_classification",
			"tag_value": "restricted",
		},
	}
	vars["abac_policies"] = map[string]interface{}{
		"mask_ssn_enterprise": map[string]interface{}{
			"type":       "POLICY_TYPE_COLUMN_MASK",
			"principals": []string{"account users"},
			"match_columns": []map[string]interface{}{
				{"condition": "has_tag_value('data_classification', 'restricted')", "alias": "c"},
			},
			"column_mask": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.mask_ssn", defaults.CatalogName),
				"on_column":     "c",
			},
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan, "terraform plan should produce output")

	assert.Contains(t, plan, `databricks_entity_tag_assignment.column["payments.transactions.ssn"]`, "tag assignment must be planned")
	assert.Contains(t, plan, `databricks_policy_info.this["mask_ssn_enterprise"]`, "column mask policy must be planned")
	assert.Contains(t, plan, "POLICY_TYPE_COLUMN_MASK", "policy type must appear in plan")
	assert.Contains(t, plan, "account users", "principal must appear in plan")
	assert.Contains(t, plan, `"CATALOG"`, "on_securable_type must be CATALOG")
}

func TestCatalogAbacRowFilterPolicy(t *testing.T) {
	common.SkipIfShortMode(t, "catalog-abac row filter (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(defaults.CatalogName)
	vars["column_tag_assignments"] = map[string]interface{}{
		"hr.employees.region": map[string]interface{}{
			"schema":  "hr",
			"table":   "employees",
			"column":  "region",
			"tag_key": "region",
		},
	}
	vars["abac_policies"] = map[string]interface{}{
		"filter_region_enterprise": map[string]interface{}{
			"type":       "POLICY_TYPE_ROW_FILTER",
			"principals": []string{"account users"},
			"match_columns": []map[string]interface{}{
				{"condition": "has_tag('region')", "alias": "region_col"},
			},
			"row_filter": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.filter_user_region", defaults.CatalogName),
				"using":         []map[string]interface{}{{"alias": "region_col"}},
			},
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, `databricks_entity_tag_assignment.column["hr.employees.region"]`, "presence-only tag must be planned")
	assert.Contains(t, plan, `databricks_policy_info.this["filter_region_enterprise"]`, "row filter policy must be planned")
	assert.Contains(t, plan, "POLICY_TYPE_ROW_FILTER", "policy type must appear in plan")
}

func TestCatalogAbacMultipleSchemas(t *testing.T) {
	common.SkipIfShortMode(t, "catalog-abac multi-schema tags (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(defaults.CatalogName)
	vars["column_tag_assignments"] = map[string]interface{}{
		"payments.transactions.ssn": map[string]interface{}{
			"schema":    "payments",
			"table":     "transactions",
			"column":    "ssn",
			"tag_key":   "data_classification",
			"tag_value": "restricted",
		},
		"hr.employees.national_id": map[string]interface{}{
			"schema":    "hr",
			"table":     "employees",
			"column":    "national_id",
			"tag_key":   "data_classification",
			"tag_value": "restricted",
		},
		"trading.orders.customer_id": map[string]interface{}{
			"schema":    "trading",
			"table":     "orders",
			"column":    "customer_id",
			"tag_key":   "data_classification",
			"tag_value": "restricted",
		},
	}
	vars["abac_policies"] = map[string]interface{}{
		"mask_ssn_enterprise": map[string]interface{}{
			"type":       "POLICY_TYPE_COLUMN_MASK",
			"principals": []string{"account users"},
			"match_columns": []map[string]interface{}{
				{"condition": "has_tag_value('data_classification', 'restricted')", "alias": "c"},
			},
			"column_mask": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.mask_ssn", defaults.CatalogName),
				"on_column":     "c",
			},
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, `databricks_entity_tag_assignment.column["payments.transactions.ssn"]`, "payments tag must be planned")
	assert.Contains(t, plan, `databricks_entity_tag_assignment.column["hr.employees.national_id"]`, "hr tag must be planned")
	assert.Contains(t, plan, `databricks_entity_tag_assignment.column["trading.orders.customer_id"]`, "trading tag must be planned")
	assert.Contains(t, plan, `databricks_policy_info.this["mask_ssn_enterprise"]`, "single catalog policy must cover all schemas")
}

func TestCatalogAbacExceptPrincipals(t *testing.T) {
	common.SkipIfShortMode(t, "catalog-abac except principals (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(defaults.CatalogName)
	vars["abac_policies"] = map[string]interface{}{
		"mask_ssn_enterprise": map[string]interface{}{
			"type":              "POLICY_TYPE_COLUMN_MASK",
			"principals":        []string{"account users"},
			"except_principals": []string{"svc_audit_platform", "grp_data_governance_admins"},
			"comment":           "Enterprise SSN masking. Ref: SEC-001",
			"match_columns": []map[string]interface{}{
				{"condition": "has_tag_value('data_classification', 'restricted')", "alias": "c"},
			},
			"column_mask": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.mask_ssn", defaults.CatalogName),
				"on_column":     "c",
			},
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, "svc_audit_platform", "break-glass principal must appear in plan")
	assert.Contains(t, plan, "grp_data_governance_admins", "governance exemption must appear in plan")
	assert.Contains(t, plan, "SEC-001", "policy comment must appear in plan")
}

func TestCatalogAbacDisabled(t *testing.T) {
	common.SkipIfShortMode(t, "catalog-abac disabled (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(defaults.CatalogName)
	vars["enable_abac"] = false
	vars["column_tag_assignments"] = map[string]interface{}{
		"payments.transactions.ssn": map[string]interface{}{
			"schema":    "payments",
			"table":     "transactions",
			"column":    "ssn",
			"tag_key":   "data_classification",
			"tag_value": "restricted",
		},
	}
	vars["table_tag_assignments"] = map[string]interface{}{
		"payments.transactions.classification": map[string]interface{}{
			"schema":    "payments",
			"table":     "transactions",
			"tag_key":   "classification",
			"tag_value": "confidential",
		},
	}
	vars["abac_policies"] = map[string]interface{}{
		"mask_ssn_enterprise": map[string]interface{}{
			"type":       "POLICY_TYPE_COLUMN_MASK",
			"principals": []string{"account users"},
			"match_columns": []map[string]interface{}{
				{"condition": "has_tag_value('data_classification', 'restricted')", "alias": "c"},
			},
			"column_mask": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.mask_ssn", defaults.CatalogName),
				"on_column":     "c",
			},
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)

	assert.NotContains(t, plan, "databricks_entity_tag_assignment.column[", "no column tag assignments when disabled")
	assert.NotContains(t, plan, "databricks_entity_tag_assignment.table[", "no table tag assignments when disabled")
	assert.NotContains(t, plan, "databricks_policy_info.this[", "no policies when disabled")
}

func TestCatalogAbacPreserveTagsOnDisable(t *testing.T) {
	common.SkipIfShortMode(t, "catalog-abac preserve tags on disable (plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := baseVars(defaults.CatalogName)
	vars["enable_abac"] = false
	vars["preserve_tags_on_disable"] = true
	vars["column_tag_assignments"] = map[string]interface{}{
		"payments.transactions.ssn": map[string]interface{}{
			"schema":    "payments",
			"table":     "transactions",
			"column":    "ssn",
			"tag_key":   "data_classification",
			"tag_value": "restricted",
		},
	}
	vars["table_tag_assignments"] = map[string]interface{}{
		"payments.transactions.classification": map[string]interface{}{
			"schema":    "payments",
			"table":     "transactions",
			"tag_key":   "classification",
			"tag_value": "confidential",
		},
	}
	vars["abac_policies"] = map[string]interface{}{
		"mask_ssn_enterprise": map[string]interface{}{
			"type":       "POLICY_TYPE_COLUMN_MASK",
			"principals": []string{"account users"},
			"match_columns": []map[string]interface{}{
				{"condition": "has_tag_value('data_classification', 'restricted')", "alias": "c"},
			},
			"column_mask": map[string]interface{}{
				"function_name": fmt.Sprintf("%s.security_functions.mask_ssn", defaults.CatalogName),
				"on_column":     "c",
			},
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, `databricks_entity_tag_assignment.column["payments.transactions.ssn"]`, "column tags must be preserved when preserve_tags_on_disable = true")
	assert.Contains(t, plan, `databricks_entity_tag_assignment.table["payments.transactions.classification"]`, "table tags must be preserved on the same switch as column tags")
	assert.NotContains(t, plan, "databricks_policy_info.this[", "no policies when enable_abac = false")
}
