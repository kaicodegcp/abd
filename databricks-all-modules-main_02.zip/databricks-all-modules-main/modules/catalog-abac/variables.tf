# =============================================================================
# Catalog ABAC - Variables
# =============================================================================
# Inputs for governed-tag assignments and ABAC policies at catalog scope.
# =============================================================================

variable "catalog_name" {
  description = "Name of the catalog. Must already exist."
  type        = string

  validation {
    condition     = length(trimspace(var.catalog_name)) > 0
    error_message = "catalog_name must not be empty."
  }
}

variable "enable_abac" {
  description = "Master switch. When false, all ABAC policies and (unless preserve_tags_on_disable = true) all column tag assignments are destroyed. WARNING: destroying column tags makes previously-tagged columns fail-open (unmasked) until tags are reapplied."
  type        = bool
  default     = true
}

variable "preserve_tags_on_disable" {
  description = "When enable_abac = false, preserves column tag assignments while destroying all ABAC policies. Default false."
  type        = bool
  default     = false
}

# -----------------------------------------------------------------------------
# Column tag assignments
# -----------------------------------------------------------------------------
variable "column_tag_assignments" {
  description = "Governed-tag assignments to apply to columns across the catalog. Map keyed by a stable identifier (e.g. \"<schema>.<table>.<column>\") for clean plan diffs. Tag keys must already exist as governed tags at the account level (created via databricks_tag_policy or the UC account console) before apply. Omit tag_value for presence-only tags; do not pass an empty string."
  type = map(object({
    schema    = string
    table     = string
    column    = string
    tag_key   = string
    tag_value = optional(string)
  }))
  default = {}

  validation {
    condition = alltrue([
      for k, a in var.column_tag_assignments :
      length(trimspace(a.schema)) > 0 && length(trimspace(a.table)) > 0 && length(trimspace(a.column)) > 0 && length(trimspace(a.tag_key)) > 0
    ])
    error_message = "column_tag_assignments: schema, table, column, and tag_key must not be empty strings."
  }

  validation {
    condition = alltrue([
      for k, a in var.column_tag_assignments :
      a.tag_value == null || try(length(trimspace(a.tag_value)) > 0, false)
    ])
    error_message = "column_tag_assignments: tag_value must not be an empty string. Omit the field entirely for presence-only tags."
  }
}

# -----------------------------------------------------------------------------
# Table tag assignments
# -----------------------------------------------------------------------------
variable "table_tag_assignments" {
  description = "Governed-tag assignments to apply to tables across the catalog. These are the tags a policy's when_condition and get_tag_value() read, and they inherit down from the parent schema and catalog. Column tags do not inherit, so a tag set here is not visible to match_columns. Map keyed by a stable identifier (e.g. \"<schema>.<table>.<tag_key>\") for clean plan diffs. Tag keys must already exist as governed tags at the account level before apply. Omit tag_value for presence-only tags; do not pass an empty string."
  type = map(object({
    schema    = string
    table     = string
    tag_key   = string
    tag_value = optional(string)
  }))
  default = {}

  validation {
    condition = alltrue([
      for k, a in var.table_tag_assignments :
      length(trimspace(a.schema)) > 0 && length(trimspace(a.table)) > 0 && length(trimspace(a.tag_key)) > 0
    ])
    error_message = "table_tag_assignments: schema, table, and tag_key must not be empty strings."
  }

  validation {
    condition = alltrue([
      for k, a in var.table_tag_assignments :
      a.tag_value == null || try(length(trimspace(a.tag_value)) > 0, false)
    ])
    error_message = "table_tag_assignments: tag_value must not be an empty string. Omit the field entirely for presence-only tags."
  }
}

# -----------------------------------------------------------------------------
# ABAC policies
# -----------------------------------------------------------------------------
variable "abac_policies" {
  description = "Map of ABAC policies attached at catalog scope. Key is the policy name (unique within the catalog). At catalog scope, policies cover all current and future tables across all schemas in the catalog. UDFs are BYO and referenced by fully qualified name."
  type = map(object({
    type              = string
    principals        = list(string)
    except_principals = optional(list(string))
    comment           = optional(string)
    when_condition    = optional(string)
    match_columns = optional(list(object({
      condition = string
      alias     = string
    })))
    row_filter = optional(object({
      function_name = string
      using = optional(list(object({
        alias    = optional(string)
        constant = optional(string)
      })))
    }))
    column_mask = optional(object({
      function_name = string
      on_column     = string
      using = optional(list(object({
        alias    = optional(string)
        constant = optional(string)
      })))
    }))
  }))
  default = {}

  validation {
    condition = alltrue([
      for p in var.abac_policies : contains(["POLICY_TYPE_ROW_FILTER", "POLICY_TYPE_COLUMN_MASK"], p.type)
    ])
    error_message = "Each abac_policies entry's type must be POLICY_TYPE_ROW_FILTER or POLICY_TYPE_COLUMN_MASK."
  }

  validation {
    condition = alltrue([
      for k, p in var.abac_policies : length(p.principals) > 0
    ])
    error_message = "abac_policies: principals must not be empty. Every policy must target at least one group."
  }

  validation {
    condition = alltrue([
      for k, p in var.abac_policies :
      p.type == "POLICY_TYPE_COLUMN_MASK"
        ? (p.column_mask != null && p.match_columns != null && length(p.match_columns) > 0)
        : true
    ])
    error_message = "POLICY_TYPE_COLUMN_MASK requires both column_mask and a non-empty match_columns list."
  }

  validation {
    condition = alltrue([
      for k, p in var.abac_policies :
      p.type == "POLICY_TYPE_ROW_FILTER" ? p.row_filter != null : true
    ])
    error_message = "POLICY_TYPE_ROW_FILTER requires row_filter."
  }

  validation {
    condition = alltrue([
      for k, p in var.abac_policies : !(p.column_mask != null && p.row_filter != null)
    ])
    error_message = "A policy cannot have both column_mask and row_filter set. Use type to declare exactly one action."
  }

  # try() around the alias list, not a null test on match_columns: Terraform does not
  # reliably short-circuit && and ||, so a length(null) in a guarded operand still
  # raises. Testing it that way made a row filter with no match_columns - the shape
  # filter_deny_all() needs - fail validation instead of the intended skip.
  validation {
    condition = alltrue([
      for k, p in var.abac_policies :
      (p.type == "POLICY_TYPE_COLUMN_MASK" && p.column_mask != null)
        ? contains(try([for mc in p.match_columns : mc.alias], []), p.column_mask.on_column)
        : true
    ])
    error_message = "column_mask.on_column must match an alias defined in match_columns."
  }

  # The "if" filter drops constant-only entries before the body runs. Guarding with
  # "u.alias == null || ..." instead does not work, for the same non-short-circuit
  # reason: contains(list, null) still raises.
  validation {
    condition = alltrue([
      for k, p in var.abac_policies :
      try(alltrue([
        for u in p.row_filter.using :
        contains(try([for mc in p.match_columns : mc.alias], []), u.alias)
        if u.alias != null
      ]), true)
    ])
    error_message = "row_filter.using[].alias must match an alias defined in match_columns."
  }

  # "" is not the same as no condition at the API, so reject it rather than send it.
  validation {
    condition = alltrue([
      for k, p in var.abac_policies :
      p.when_condition == null || try(length(trimspace(p.when_condition)) > 0, false)
    ])
    error_message = "abac_policies: when_condition must not be an empty string. Omit the field to apply the policy to every table in scope."
  }
}
