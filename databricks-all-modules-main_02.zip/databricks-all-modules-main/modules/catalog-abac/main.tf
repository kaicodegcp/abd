# =============================================================================
# Catalog ABAC
# =============================================================================
# UC ABAC policies at CATALOG scope. Covers every table in every schema in the
# catalog. Does NOT create the catalog, governed tag vocabulary, UDFs, or groups.
# =============================================================================

locals {
  # enable_abac gates policies; preserve_tags_on_disable keeps tags alive when policies are off.
  abac_policies          = var.enable_abac ? var.abac_policies : {}
  column_tag_assignments = (var.enable_abac || var.preserve_tags_on_disable) ? var.column_tag_assignments : {}
  table_tag_assignments  = (var.enable_abac || var.preserve_tags_on_disable) ? var.table_tag_assignments : {}
}

# -----------------------------------------------------------------------------
# Table tag assignments. These are what a policy's when_condition reads, and
# unlike column tags they inherit down from the parent schema and catalog.
# entity_name is fully qualified: <catalog>.<schema>.<table>
# -----------------------------------------------------------------------------
resource "databricks_entity_tag_assignment" "table" {
  for_each = local.table_tag_assignments

  entity_type = "tables"
  entity_name = "${var.catalog_name}.${each.value.schema}.${each.value.table}"
  tag_key     = each.value.tag_key
  tag_value   = try(each.value.tag_value, null)
}

# -----------------------------------------------------------------------------
# Column tag assignments. Tag keys must already exist at account scope.
# entity_name is fully qualified: <catalog>.<schema>.<table>.<column>
# -----------------------------------------------------------------------------
resource "databricks_entity_tag_assignment" "column" {
  for_each = local.column_tag_assignments

  entity_type = "columns"
  entity_name = "${var.catalog_name}.${each.value.schema}.${each.value.table}.${each.value.column}"
  tag_key     = each.value.tag_key
  tag_value   = try(each.value.tag_value, null)
}

# -----------------------------------------------------------------------------
# ABAC policies at catalog scope. Cover every current and future table in
# every schema in the catalog; cannot be bypassed by schema or table owners.
# -----------------------------------------------------------------------------
resource "databricks_policy_info" "this" {
  for_each = local.abac_policies

  name                  = each.key
  on_securable_type     = "CATALOG"
  on_securable_fullname = var.catalog_name
  for_securable_type    = "TABLE"

  policy_type       = each.value.type
  to_principals     = each.value.principals
  except_principals = try(each.value.except_principals, null)
  comment           = each.value.comment != null ? each.value.comment : ""
  when_condition    = try(each.value.when_condition, null)
  match_columns     = try(each.value.match_columns, null)
  row_filter        = try(each.value.row_filter, null)
  column_mask       = try(each.value.column_mask, null)

  # Ordering only, not a guarantee: a tag assignment takes a few minutes to become
  # visible to policy evaluation, so verify with a query rather than assuming the
  # first apply is live. Until it is, the policy does not apply - it fails open.
  depends_on = [
    databricks_entity_tag_assignment.column,
    databricks_entity_tag_assignment.table,
  ]
}
