output "catalog_name" {
  value = module.catalog_abac.catalog_name
}

output "abac_enabled" {
  value = module.catalog_abac.abac_enabled
}

output "policy_ids" {
  value = module.catalog_abac.policy_ids
}

output "tag_assignment_ids" {
  value = module.catalog_abac.tag_assignment_ids
}
