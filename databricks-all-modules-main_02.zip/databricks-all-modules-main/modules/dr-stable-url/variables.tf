variable "parent" {
  description = "Parent resource for the stable URL. Format: accounts/{account_id}. Note this is the ACCOUNT, not a failover group."
  type        = string

  validation {
    condition     = can(regex("^accounts/[0-9a-fA-F-]{36}$", var.parent))
    error_message = "parent must be of the form accounts/{account_id}, where account_id is a 36-character UUID."
  }
}

variable "stable_url_id" {
  description = "Client-provided identifier for the stable URL. Becomes part of the immutable resource name {parent}/stable-urls/{stable_url_id}; changing it destroys and recreates."
  type        = string

  validation {
    condition     = can(regex("^[a-z0-9][a-z0-9-]{1,62}[a-z0-9]$", var.stable_url_id))
    error_message = "stable_url_id must be 3-64 characters, lowercase alphanumeric or hyphen, and must not start or end with a hyphen."
  }
}

variable "initial_workspace_id" {
  description = "Numeric ID of the workspace this stable URL is initially bound to, as a string. Used only on create and never returned by the API; after a failover the current binding is reported by the effective_workspace_id output."
  type        = string

  validation {
    condition     = can(regex("^[0-9]+$", var.initial_workspace_id))
    error_message = "initial_workspace_id must be a numeric workspace ID expressed as a string, e.g. \"1234567890123456\"."
  }
}
