output "name" {
  description = "Fully qualified resource name, accounts/{account_id}/stable-urls/{stable_url_id}. This is the value to pass to a failover group's workspace_sets[].stable_url_names."
  value       = databricks_disaster_recovery_stable_url.this.name
}

output "url" {
  description = "The stable hostname, e.g. conn-{stable_workspace_id}.cloud.databricks.com. Point CI/CD and Terraform providers at this instead of a workspace-specific URL."
  value       = databricks_disaster_recovery_stable_url.this.url
}

output "stable_workspace_id" {
  description = "Stable workspace identifier. This is a UUID, not the numeric workspace ID - consumers that assume a numeric ID must be updated."
  value       = databricks_disaster_recovery_stable_url.this.stable_workspace_id
}

output "effective_workspace_id" {
  description = "Numeric ID of the workspace the stable URL currently resolves to. Changes after a failover."
  value       = databricks_disaster_recovery_stable_url.this.effective_workspace_id
}

output "failover_group_name" {
  description = "Fully qualified name of the failover group this stable URL is bound to, once a group references it. Empty until then."
  value       = databricks_disaster_recovery_stable_url.this.failover_group_name
}
