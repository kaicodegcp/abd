# =============================================================================
# dr-stable-url - basic example: register a stable URL on the account's
# Custom URL domain. Attach its name to a failover group workspace set via
# stable_url_names (see the ../dr wrapper). Requires an account with the
# Custom URL capability enabled by the Databricks account team.
# =============================================================================

terraform {
  required_version = ">= 1.5"
  required_providers {
    databricks = {
      source  = "databricks/databricks"
      version = ">= 1.125.0, < 2.0.0"
    }
  }
}

variable "databricks_account_id" {
  type    = string
  default = "00000000-0000-0000-0000-000000000000"
}

provider "databricks" {
  host       = "https://accounts.cloud.databricks.com"
  account_id = var.databricks_account_id
}

module "stable_url" {
  source = "../.."

  parent        = "accounts/${var.databricks_account_id}"
  stable_url_id = "acme-drg-url"

  # Write-only: the workspace it starts pointing at; after a failover the
  # live value is effective_workspace_id. Never edited to match.
  initial_workspace_id = "1111111111111111"
}

output "url" {
  value = module.stable_url.url
}
