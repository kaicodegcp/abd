package test

import (
	"fmt"
	"testing"

	common "github.com/sandbox45/databricks-all-modules/common"
)

// These tests are plan-only. The stable URL is an account-level resource, so
// DATABRICKS_HOST must point at the ACCOUNT host
// (https://accounts.cloud.databricks.com), not a workspace URL.
//
// No workspace is required: initial_workspace_id is an opaque string at plan
// time, so a placeholder ID plans cleanly.

func TestDRStableURLModule(t *testing.T) {
	defaults := common.GetTestDefaults()

	config := common.ModuleTestConfig{
		ModuleName:      "dr-stable-url",
		TestDescription: "Tests the Managed DR stable URL module",
		RequiredVars: map[string]interface{}{
			"parent":               fmt.Sprintf("accounts/%s", defaults.AccountID),
			"stable_url_id":        "plan-only-stable-url",
			"initial_workspace_id": "1234567890123456",
		},
		ExpectedOutputs: []string{
			"name",
			"url",
			"stable_workspace_id",
			"effective_workspace_id",
		},
	}

	common.TestModuleWithConfig(t, config)
}
