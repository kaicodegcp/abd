# =============================================================================
# Databricks Managed DR - Stable URL
# =============================================================================
# A stable URL is an account-level resource that provides a hostname which
# follows the workspace that is currently primary for a failover group. CI/CD
# targets this hostname so pipelines survive a failover without repointing.
#
# Ordering: create the stable URL first, then reference it from a failover
# group's workspace_sets[].stable_url_names. The failover_group_name attribute
# below is populated by that binding, so there is no dependency cycle.
#
# Requires the ACCOUNT-level provider (host = accounts.cloud.databricks.com).
# =============================================================================

resource "databricks_disaster_recovery_stable_url" "this" {
  parent        = var.parent
  stable_url_id = var.stable_url_id

  # Write-only: consumed on create, never returned by the API. After a failover
  # the binding is reflected in effective_workspace_id, not here. Do not
  # "correct" this value to match reality - see the module README.
  initial_workspace_id = var.initial_workspace_id

  lifecycle {
    ignore_changes = [initial_workspace_id]
  }
}
