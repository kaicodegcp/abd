terraform {
  required_version = ">= 1.0"

  required_providers {
    databricks = {
      source = "databricks/databricks"
      # Managed DR resources require a recent provider.
      version = ">= 1.125.0, < 2.0.0"
    }
  }
}
