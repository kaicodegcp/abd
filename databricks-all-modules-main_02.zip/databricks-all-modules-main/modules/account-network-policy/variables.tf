variable "network_policy_id" {
  description = "Unique identifier for the new network policy (max 32 characters). Ignored when existing_network_policy_id is set."
  type        = string
  default     = null
}

variable "workspace_id" {
  description = "Databricks workspace ID to bind the network policy to."
  type        = number
}

variable "existing_network_policy_id" {
  description = "ID of an existing account network policy to reuse. When set, no new policy is created — the existing policy is bound to the workspace directly."
  type        = string
  default     = null
}

variable "egress" {
  description = "Egress network access configuration."
  type = object({
    network_access = object({
      restriction_mode = string
      allowed_internet_destinations = optional(list(object({
        destination               = string
        internet_destination_type = string
      })), [])
      allowed_storage_destinations = optional(list(object({
        bucket_name              = optional(string)
        region                   = optional(string)
        storage_destination_type = string
        azure_storage_account    = optional(string)
        azure_storage_service    = optional(string)
      })), [])
      policy_enforcement = optional(object({
        enforcement_mode = string
      }))
    })
  })
  default = null
}

variable "ingress_public_access" {
  description = "Context-based ingress policy for public internet traffic. restriction_mode: FULL_ACCESS or RESTRICTED_ACCESS."
  type = object({
    restriction_mode = string
    allow_rules = optional(list(object({
      label = optional(string)
      authentication = optional(object({
        identity_type = optional(string)
        identities = optional(list(object({
          principal_id   = optional(number)
          principal_type = optional(string)
        })), [])
      }))
      destination = optional(object({
        all_destinations = optional(bool)
        workspace_ui     = optional(object({ all_destinations = optional(bool) }))
        workspace_api    = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        apps_runtime     = optional(object({ all_destinations = optional(bool) }))
        lakebase_runtime = optional(object({ all_destinations = optional(bool) }))
        account_api      = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        account_ui       = optional(object({ all_destinations = optional(bool) }))
      }))
      origin = optional(object({
        all_ip_ranges      = optional(bool)
        included_ip_ranges = optional(object({ ip_ranges = optional(list(string), []) }))
        excluded_ip_ranges = optional(object({ ip_ranges = optional(list(string), []) }))
      }))
    })), [])
    deny_rules = optional(list(object({
      label = optional(string)
      authentication = optional(object({
        identity_type = optional(string)
        identities = optional(list(object({
          principal_id   = optional(number)
          principal_type = optional(string)
        })), [])
      }))
      destination = optional(object({
        all_destinations = optional(bool)
        workspace_ui     = optional(object({ all_destinations = optional(bool) }))
        workspace_api    = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        apps_runtime     = optional(object({ all_destinations = optional(bool) }))
        lakebase_runtime = optional(object({ all_destinations = optional(bool) }))
        account_api      = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        account_ui       = optional(object({ all_destinations = optional(bool) }))
      }))
      origin = optional(object({
        all_ip_ranges      = optional(bool)
        included_ip_ranges = optional(object({ ip_ranges = optional(list(string), []) }))
        excluded_ip_ranges = optional(object({ ip_ranges = optional(list(string), []) }))
      }))
    })), [])
  })
  default = null
}

variable "ingress_private_access" {
  description = "Context-based ingress policy for private connectivity (PrivateLink/registered endpoints). restriction_mode: ALLOW_ALL_REGISTERED_ENDPOINTS or RESTRICTED_ACCESS."
  type = object({
    restriction_mode = string
    allow_rules = optional(list(object({
      label = optional(string)
      authentication = optional(object({
        identity_type = optional(string)
        identities = optional(list(object({
          principal_id   = optional(number)
          principal_type = optional(string)
        })), [])
      }))
      destination = optional(object({
        all_destinations = optional(bool)
        workspace_ui     = optional(object({ all_destinations = optional(bool) }))
        workspace_api    = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        apps_runtime     = optional(object({ all_destinations = optional(bool) }))
        lakebase_runtime = optional(object({ all_destinations = optional(bool) }))
        account_api      = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        account_ui       = optional(object({ all_destinations = optional(bool) }))
      }))
      origin = optional(object({
        all_registered_endpoints     = optional(bool)
        all_private_access           = optional(bool)
        azure_workspace_private_link = optional(bool)
        endpoints                    = optional(object({ endpoint_ids = optional(list(string), []) }))
      }))
    })), [])
    deny_rules = optional(list(object({
      label = optional(string)
      authentication = optional(object({
        identity_type = optional(string)
        identities = optional(list(object({
          principal_id   = optional(number)
          principal_type = optional(string)
        })), [])
      }))
      destination = optional(object({
        all_destinations = optional(bool)
        workspace_ui     = optional(object({ all_destinations = optional(bool) }))
        workspace_api    = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        apps_runtime     = optional(object({ all_destinations = optional(bool) }))
        lakebase_runtime = optional(object({ all_destinations = optional(bool) }))
        account_api      = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        account_ui       = optional(object({ all_destinations = optional(bool) }))
      }))
      origin = optional(object({
        all_registered_endpoints     = optional(bool)
        all_private_access           = optional(bool)
        azure_workspace_private_link = optional(bool)
        endpoints                    = optional(object({ endpoint_ids = optional(list(string), []) }))
      }))
    })), [])
  })
  default = null
}

variable "ingress_cross_workspace_access" {
  description = "Context-based ingress policy for cross-workspace traffic within the same account. restriction_mode: FULL_ACCESS or RESTRICTED_ACCESS."
  type = object({
    restriction_mode = string
    allow_rules = optional(list(object({
      label = optional(string)
      authentication = optional(object({
        identity_type = optional(string)
        identities = optional(list(object({
          principal_id   = optional(number)
          principal_type = optional(string)
        })), [])
      }))
      destination = optional(object({
        all_destinations = optional(bool)
        workspace_ui     = optional(object({ all_destinations = optional(bool) }))
        workspace_api    = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        apps_runtime     = optional(object({ all_destinations = optional(bool) }))
        lakebase_runtime = optional(object({ all_destinations = optional(bool) }))
        account_api      = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        account_ui       = optional(object({ all_destinations = optional(bool) }))
      }))
      origin = optional(object({
        all_source_workspaces = optional(bool)
        selected_workspaces   = optional(object({ workspace_ids = optional(list(number), []) }))
      }))
    })), [])
    deny_rules = optional(list(object({
      label = optional(string)
      authentication = optional(object({
        identity_type = optional(string)
        identities = optional(list(object({
          principal_id   = optional(number)
          principal_type = optional(string)
        })), [])
      }))
      destination = optional(object({
        all_destinations = optional(bool)
        workspace_ui     = optional(object({ all_destinations = optional(bool) }))
        workspace_api    = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        apps_runtime     = optional(object({ all_destinations = optional(bool) }))
        lakebase_runtime = optional(object({ all_destinations = optional(bool) }))
        account_api      = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        account_ui       = optional(object({ all_destinations = optional(bool) }))
      }))
      origin = optional(object({
        all_source_workspaces = optional(bool)
        selected_workspaces   = optional(object({ workspace_ids = optional(list(number), []) }))
      }))
    })), [])
  })
  default = null
}
