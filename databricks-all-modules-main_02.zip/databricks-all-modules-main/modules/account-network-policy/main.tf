locals {
  ingress = (
    var.ingress_public_access != null || var.ingress_private_access != null || var.ingress_cross_workspace_access != null
    ) ? {
    public_access          = var.ingress_public_access
    private_access         = var.ingress_private_access
    cross_workspace_access = var.ingress_cross_workspace_access
  } : null

  effective_network_policy_id = var.existing_network_policy_id != null ? var.existing_network_policy_id : one(databricks_account_network_policy.this[*].network_policy_id)
}

resource "databricks_account_network_policy" "this" {
  count = var.existing_network_policy_id == null ? 1 : 0

  network_policy_id = var.network_policy_id

  egress  = var.egress
  ingress = local.ingress

  lifecycle {
    precondition {
      condition     = var.existing_network_policy_id != null || var.network_policy_id != null
      error_message = "network_policy_id must be set when existing_network_policy_id is not provided."
    }
  }
}

resource "databricks_workspace_network_option" "this" {
  network_policy_id = local.effective_network_policy_id
  workspace_id      = var.workspace_id
}
