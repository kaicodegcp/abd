output "network_policy_id" {
  description = "The bound network policy ID (newly created or existing)."
  value       = local.effective_network_policy_id
}
