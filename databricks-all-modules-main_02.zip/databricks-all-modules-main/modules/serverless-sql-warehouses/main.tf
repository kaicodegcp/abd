locals {
  workspace_admin_group_name = "dbx-${lower(trimspace(var.environment))}-${lower(trimspace(var.program_name))}-wksadmin-grp"

  warehouses = {
    small = {
      name         = "Serverless Small Warehouse"
      cluster_size = "Small"
    }
    medium = {
      name         = "Serverless Medium Warehouse"
      cluster_size = "Medium"
    }
    large = {
      name         = "Serverless Large Warehouse"
      cluster_size = "Large"
    }
  }
}

module "sql_warehouse" {
  source = "../sql-warehouse"

  for_each = local.warehouses

  name                      = each.value.name
  cluster_size              = each.value.cluster_size
  min_num_clusters          = 1
  max_num_clusters          = 1
  auto_stop_mins            = 20
  enable_photon             = true
  enable_serverless_compute = true
  warehouse_type            = "PRO"
}

module "permissions" {
  source = "../permissions"

  for_each = local.warehouses

  sql_endpoint_id = module.sql_warehouse[each.key].id

  access_control_list = [
    {
      group_name       = "users"
      permission_level = "CAN_USE"
    },
    {
      group_name       = local.workspace_admin_group_name
      permission_level = "CAN_MANAGE"
    }
  ]
}
