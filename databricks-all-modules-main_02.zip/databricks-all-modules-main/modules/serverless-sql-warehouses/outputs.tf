output "warehouse_ids" {
  description = "Map of SQL warehouse identifiers, keyed by size."
  value = {
    for key, warehouse in module.sql_warehouse : key => warehouse.id
  }
}

output "warehouse_names" {
  description = "Map of SQL warehouse names, keyed by size."
  value = {
    for key, warehouse in module.sql_warehouse : key => warehouse.name
  }
}

output "jdbc_urls" {
  description = "Map of JDBC URLs for the SQL warehouses, keyed by size."
  value = {
    for key, warehouse in module.sql_warehouse : key => warehouse.jdbc_url
  }
}

output "permission_ids" {
  description = "Map of permission resource identifiers, keyed by warehouse size."
  value = {
    for key, permissions in module.permissions : key => permissions.id
  }
}

output "workspace_admin_group_name" {
  description = "Workspace administrator group granted CAN_MANAGE on all three SQL warehouses."
  value       = local.workspace_admin_group_name
}
