variable "environment" {
  description = "Deployment environment used to construct the workspace administrator group name."
  type        = string

  validation {
    condition     = contains(["dev", "uat", "prod"], lower(trimspace(var.environment)))
    error_message = "environment must be one of: dev, uat, prod."
  }
}

variable "program_name" {
  description = "Program identifier used to construct the workspace administrator group name: dbx-<environment>-<program_name>-wksadmin-grp."
  type        = string

  validation {
    condition     = can(regex("^[A-Za-z0-9]+(-[A-Za-z0-9]+)*$", trimspace(var.program_name)))
    error_message = "program_name must contain only letters, numbers, or single hyphens between values."
  }
}
