package test

import (
	"testing"

	common "github.com/sandbox45/databricks-all-modules/common"
)

func TestRecipientModule(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("recipient")
	// Placeholder global metastore ID for data recipient (format: cloud:region:guid)
	metastoreGlobalID := common.GetEnvOrDefault("TEST_RECIPIENT_METASTORE_GLOBAL_ID", "aws:us-west-2:00000000-0000-0000-0000-000000000000")

	config := common.ModuleTestConfig{
		ModuleName:      "recipient",
		ModulePath:      "..",
		TestDescription: "Tests Databricks Delta Sharing recipient module (DATABRICKS auth type)",
		RequiredVars: map[string]interface{}{
			"recipient_name":         uniqueID,
			"metastore_global_id": metastoreGlobalID,
		},
		ExpectedOutputs: []string{
			"id",
			"name",
		},
	}

	common.TestModuleWithConfig(t, config)
}

func TestRecipientModuleInputValidation(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("recipient-inputs")
	metastoreGlobalID := common.GetEnvOrDefault("TEST_RECIPIENT_METASTORE_GLOBAL_ID", "aws:us-west-2:00000000-0000-0000-0000-000000000000")

	config := common.ModuleTestConfig{
		ModuleName:      "recipient",
		ModulePath:      "..",
		TestDescription: "Validates recipient module required inputs",
		RequiredVars: map[string]interface{}{
			"recipient_name":         uniqueID,
			"metastore_global_id": metastoreGlobalID,
		},
	}

	opts := common.GetTestTerraformOptions(t, config)

	t.Run("ValidateRequiredInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})
}
