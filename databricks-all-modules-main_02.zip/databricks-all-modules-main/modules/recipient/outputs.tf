output "id" {
  description = "The unique identifier for the recipient"
  value       = databricks_recipient.recipient.id
}

output "name" {
  description = "The name of the recipient"
  value       = databricks_recipient.recipient.name
}
