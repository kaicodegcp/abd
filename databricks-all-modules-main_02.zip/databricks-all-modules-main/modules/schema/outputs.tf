output "id" {
  description = "The ID of the schema."
  value       = databricks_schema.this.id
}

output "name" {
  description = "The name of the schema."
  value       = databricks_schema.this.name
}

output "full_name" {
  description = "Full name in catalog.schema format."
  value       = "${databricks_schema.this.catalog_name}.${databricks_schema.this.name}"
}

output "grant_ids" {
  description = "Map of UC grant resource IDs for audit traceability."
  value = {
    schema_read  = databricks_grant.schema_read.id
    schema_write = databricks_grant.schema_write.id
    schema_owner = databricks_grant.schema_owner.id
  }
}
