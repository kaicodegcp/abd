package test

import (
	"path/filepath"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	common "github.com/sandbox45/databricks-all-modules/common"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func planSchemaModule(t *testing.T, vars map[string]interface{}) string {
	t.Helper()
	common.SkipIfShortMode(t, "schema module (plan)")
	common.RequireDatabricksEnv(t)

	opts := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: filepath.Join(".."),
		Vars:         vars,
		NoColor:      true,
	})
	terraform.Init(t, opts)
	plan := terraform.Plan(t, opts)
	require.NotEmpty(t, plan, "terraform plan should produce output")
	return plan
}

// Schema grants must target exactly the schema-read/write/owner personas, derived from app_id/app_acronym/schema name.
func TestSchemaModuleDerivedGroupNames(t *testing.T) {
	defaults := common.GetTestDefaults()

	plan := planSchemaModule(t, map[string]interface{}{
		"name":          "transactions",
		"catalog_name":  defaults.CatalogName,
		"environment":   "dev",
		"app_acronym":   "dms",
		"app_id":        "179392",
		"force_destroy": true,
	})

	assert.Contains(t, plan, "dbx-dev-179392-dms-schema-transactions-read-grp")
	assert.Contains(t, plan, "dbx-dev-179392-dms-schema-transactions-write-grp")
	assert.Contains(t, plan, "dbx-dev-179392-dms-schema-transactions-owner-grp")
}

// Additional caller-defined grants are created alongside — not instead of — the default persona grants.
func TestSchemaModuleAdditionalGrants(t *testing.T) {
	defaults := common.GetTestDefaults()

	plan := planSchemaModule(t, map[string]interface{}{
		"name":          "transactions",
		"catalog_name":  defaults.CatalogName,
		"environment":   "dev",
		"app_acronym":   "dms",
		"app_id":        "179392",
		"force_destroy": true,
		"additional_schema_grants": map[string]interface{}{
			"dbx-dev-179392-dms-auditor-grp": []string{"USE_SCHEMA", "SELECT"},
			"legacy-custom-group":            []string{"USE_SCHEMA", "SELECT", "EXECUTE"},
		},
	})

	// Default persona grants remain unchanged.
	assert.Contains(t, plan, "dbx-dev-179392-dms-schema-transactions-read-grp")
	assert.Contains(t, plan, "dbx-dev-179392-dms-schema-transactions-write-grp")
	assert.Contains(t, plan, "dbx-dev-179392-dms-schema-transactions-owner-grp")
	// Caller-defined grants are also planned, using the full group names supplied.
	assert.Contains(t, plan, "dbx-dev-179392-dms-auditor-grp")
	assert.Contains(t, plan, "legacy-custom-group")
}

func TestSchemaModule(t *testing.T) {
	defaults := common.GetTestDefaults()
	catalogName := defaults.CatalogName

	uniqueID := common.GenerateUniqueTestID("schema")

	config := common.ModuleTestConfig{
		ModuleName:      "schema",
		TestDescription: "Tests Databricks Unity Catalog schema module",
		RequiredVars: map[string]interface{}{
			"name":         uniqueID,
			"catalog_name": catalogName,
			"environment":  "dev",
			"app_acronym":  "dms",
			"app_id":       "179392",
		},
		OptionalVars: map[string]interface{}{
			"comment": "Test schema created by terratest",
			"properties": map[string]string{
				"environment": "test",
			},
			"force_destroy": true,
		},
		ExpectedOutputs: []string{
			"id",
			"name",
			"full_name",
			"grant_ids",
		},
	}

	common.TestModuleWithConfig(t, config)
}

func TestSchemaModuleWithStorageRoot(t *testing.T) {
	defaults := common.GetTestDefaults()
	catalogName := defaults.CatalogName

	uniqueID := common.GenerateUniqueTestID("schema-storage")

	config := common.ModuleTestConfig{
		ModuleName:      "schema",
		TestDescription: "Tests Databricks schema module with storage root",
		RequiredVars: map[string]interface{}{
			"name":         uniqueID,
			"catalog_name": catalogName,
			"environment":  "dev",
			"app_acronym":  "dms",
			"app_id":       "179392",
		},
		OptionalVars: map[string]interface{}{
			"comment":       "Schema with custom storage root",
			"force_destroy": true,
		},
		ExpectedOutputs: []string{
			"id",
			"name",
			"full_name",
			"grant_ids",
		},
	}

	common.TestModuleWithConfig(t, config)
}
