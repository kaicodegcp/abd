variable "environment" {
  description = "Deployment environment used in group name construction (dev, uat, prod)."
  type        = string
  validation {
    condition     = contains(["dev", "uat", "prod"], var.environment)
    error_message = "environment must be one of: dev, uat, prod."
  }
}

variable "app_acronym" {
  description = "CSI application acronym used in group name construction (e.g. dms)."
  type        = string
  validation {
    condition     = length(trimspace(var.app_acronym)) > 0
    error_message = "app_acronym must not be empty."
  }
}

variable "app_id" {
  description = "Application identifier (CSI) used in group name construction (e.g. 179392)."
  type        = string
  validation {
    condition     = length(trimspace(var.app_id)) > 0
    error_message = "app_id must not be empty."
  }
}

variable "catalog_name" {
  description = <<-EOT
    Name of the parent catalog. PREREQUISITE: the schema-read/write/owner groups must
    already hold USE_CATALOG on this catalog (normally via catalog-creation.permissions).
    This module grants schema scope only; without USE_CATALOG the grants apply but data
    access will not work.
  EOT
  type        = string

  validation {
    condition     = length(trimspace(var.catalog_name)) > 0
    error_message = "catalog_name must not be empty."
  }
}

variable "name" {
  description = "Name of the schema."
  type        = string

  validation {
    condition     = length(trimspace(var.name)) > 0
    error_message = "name must not be empty."
  }
}

variable "comment" {
  description = "Comment/description for the schema"
  type        = string
  default     = null
}

variable "properties" {
  description = "Schema properties"
  type        = map(string)
  default     = {}
}

variable "storage_root" {
  description = "Storage root location for managed tables"
  type        = string
  default     = null
}

variable "owner" {
  description = "Schema owner. Defaults to the Terraform identity."
  type        = string
  default     = null
}

variable "force_destroy" {
  description = "Force destroy even if schema contains tables"
  type        = bool
  default     = false
}

variable "additional_schema_grants" {
  description = "Optional map of full group name to schema privileges, granted in addition to the default personas. Caller supplies the exact group name."
  type        = map(list(string))
  default     = {}

  validation {
    condition = alltrue([
      for principal in keys(var.additional_schema_grants) : length(trimspace(principal)) > 0
    ])
    error_message = "Each additional_schema_grants key (principal group name) must be a non-empty string."
  }

  validation {
    condition = alltrue([
      for privs in values(var.additional_schema_grants) : length(privs) > 0
    ])
    error_message = "Each additional_schema_grants entry must define at least one privilege."
  }
}
