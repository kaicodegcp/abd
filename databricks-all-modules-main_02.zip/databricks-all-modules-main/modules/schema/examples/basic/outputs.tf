output "id" {
  description = "The ID of the schema."
  value       = module.schema.id
}

output "full_name" {
  description = "Full name in catalog.schema format."
  value       = module.schema.full_name
}

output "grant_ids" {
  description = "Map of UC grant resource IDs for audit traceability."
  value       = module.schema.grant_ids
}
