# Example: schema — creates a Unity Catalog schema with schema-scope grants.
# Copy terraform.tfvars.example to terraform.tfvars; auth via env (DATABRICKS_HOST/CLIENT_ID/CLIENT_SECRET).
# PREREQUISITE: schema-read/write/owner groups must already hold USE_CATALOG on the parent catalog
# (normally via catalog-creation.permissions); this module grants schema scope only.

provider "databricks" {}

module "schema" {
  source = "../.."

  catalog_name = var.catalog_name
  name         = var.name
  comment      = var.comment

  environment = var.environment
  app_acronym = var.app_acronym
  app_id      = var.app_id

  additional_schema_grants = var.additional_schema_grants
}
