variable "catalog_name" {
  description = "Name of the parent catalog. Must already exist."
  type        = string
}

variable "name" {
  description = "Name of the schema to create."
  type        = string
}

variable "comment" {
  description = "Optional description for the schema."
  type        = string
  default     = null
}

variable "environment" {
  description = "Deployment environment (dev, uat, prod)."
  type        = string
}

variable "app_acronym" {
  description = "CSI application acronym used in group name construction (e.g. dms)."
  type        = string
}

variable "app_id" {
  description = "Application identifier (CSI) used in group name construction."
  type        = string
}

variable "additional_schema_grants" {
  description = "Optional map of full group name to schema privileges, in addition to the default persona grants."
  type        = map(list(string))
  default     = {}
}
