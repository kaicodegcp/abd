resource "databricks_schema" "this" {
  catalog_name  = var.catalog_name
  name          = var.name
  comment       = var.comment
  properties    = var.properties
  storage_root  = var.storage_root
  owner         = var.owner
  force_destroy = var.force_destroy
}

# USE_CATALOG on the parent catalog is managed by catalog-creation; schema_owner_group requires it to exercise MANAGE.
# Groups follow: dbx-{environment}-{app_id}-{app_acronym}-schema-{schema_name}-{role}-grp
locals {
  schema_read_group  = "dbx-${var.environment}-${var.app_id}-${var.app_acronym}-schema-${var.name}-read-grp"
  schema_write_group = "dbx-${var.environment}-${var.app_id}-${var.app_acronym}-schema-${var.name}-write-grp"
  schema_owner_group = "dbx-${var.environment}-${var.app_id}-${var.app_acronym}-schema-${var.name}-owner-grp"

  schema_full_name = "${var.catalog_name}.${var.name}"
}

# CREATE_MODEL_VERSION is a model-level privilege; it cannot be inherited from schema scope and must be
# granted on individual registered models by the ML workflow that provisions them. Not managed here.

# Schema-scope: depends_on required — provider does not infer dependency on databricks_schema.
resource "databricks_grant" "schema_read" {
  schema     = local.schema_full_name
  principal  = local.schema_read_group
  privileges = ["USE_SCHEMA", "SELECT", "READ_VOLUME", "EXECUTE"]

  depends_on = [databricks_schema.this]
}

resource "databricks_grant" "schema_write" {
  schema    = local.schema_full_name
  principal = local.schema_write_group
  privileges = [
    "USE_SCHEMA",
    "SELECT",
    "MODIFY",
    "EXECUTE",
    "READ_VOLUME",
    "REFRESH",
    "WRITE_VOLUME",
  ]

  depends_on = [databricks_schema.this]
}

resource "databricks_grant" "schema_owner" {
  schema     = local.schema_full_name
  principal  = local.schema_owner_group
  privileges = ["ALL_PRIVILEGES", "MANAGE"]

  depends_on = [databricks_schema.this]
}

resource "databricks_grant" "schema_additional" {
  for_each = var.additional_schema_grants

  schema     = local.schema_full_name
  principal  = each.key
  privileges = each.value

  depends_on = [databricks_schema.this]

  lifecycle {
    precondition {
      condition     = !contains([local.schema_read_group, local.schema_write_group, local.schema_owner_group], each.key)
      error_message = "additional_schema_grants must not target the derived schema-read/write/owner persona groups; those are managed by the module's default grants."
    }
  }
}
