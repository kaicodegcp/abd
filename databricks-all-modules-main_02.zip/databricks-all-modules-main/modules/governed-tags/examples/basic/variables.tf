variable "account_id" {
  description = "Databricks account ID (governed tags + their permissions are account-level)."
  type        = string
}
