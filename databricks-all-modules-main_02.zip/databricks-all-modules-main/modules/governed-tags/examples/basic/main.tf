# =============================================================================
# governed-tags — basic example
# =============================================================================
# Creates the governed tag vocabulary an ABAC program needs, grants who may manage
# and assign each tag, and tags one column. Governed tags are account-level, so the
# provider is configured for account access.
# =============================================================================

# WORKSPACE-scoped provider: creates the governed tags + assignments. Point it at a
# workspace bound to the target metastore.
provider "databricks" {
  # host = "https://<workspace>.cloud.databricks.com", plus your auth.
}

# ACCOUNT-scoped provider: manages tag-policy permissions (rule sets).
provider "databricks" {
  alias      = "account"
  account_id = var.account_id
  # host = "https://accounts.cloud.databricks.com" (or azure/gcp accounts host), plus auth.
}

module "governed_tags" {
  source = "../../"
  providers = {
    databricks         = databricks
    databricks.account = databricks.account
  }
  account_id = var.account_id

  # 1) The governed tag vocabulary + allowed values. Editing a list edits the tag.
  tag_policies = {
    sensitivity = {
      description    = "Business sensitivity classification (drives ABAC column masks)."
      allowed_values = ["PUBLIC", "INTERNAL", "INTERNAL_PII", "CONFIDENTIAL", "CONFIDENTIAL_PII", "SENSITIVE_PII", "RESTRICTED"]
    }
    pii_type = {
      description    = "Type of PII a column holds."
      allowed_values = ["NONE", "SSN", "EMAIL", "PHONE", "DOB", "NAME"]
    }
    domain = {
      description    = "Business domain that owns the data."
      allowed_values = ["PAYMENTS", "LENDING", "DEPOSITS", "FRAUD"]
    }
    sub_category = {
      description    = "Finer-grained category within a domain."
      allowed_values = ["TRANSACTION", "ACCOUNT", "CUSTOMER"]
    }
  }

  # 2) Who may manage (edit the tag + its permissions) and assign (apply the tag).
  tag_policy_permissions = {
    sensitivity = [
      { principals = ["groups/data-stewards"], role = "roles/tagPolicy.manager" },
      { principals = ["groups/data-engineers"], role = "roles/tagPolicy.assigner" },
    ]
    pii_type = [
      { principals = ["groups/data-stewards"], role = "roles/tagPolicy.manager" },
    ]
  }

  # 3) Optional — tag a Unity Catalog column as soon as the vocabulary exists.
  entity_tag_assignments = {
    "sales.orders.customer_email" = {
      entity_type = "columns"
      entity_name = "main.sales.orders.customer_email"
      tag_key     = "sensitivity"
      tag_value   = "CONFIDENTIAL_PII"
    }
  }
}
