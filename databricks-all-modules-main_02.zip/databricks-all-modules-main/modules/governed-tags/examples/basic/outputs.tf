output "tag_keys" {
  description = "The governed tag keys created."
  value       = module.governed_tags.tag_keys
}

output "tag_policy_ids" {
  description = "tag_key => governed tag policy id."
  value       = module.governed_tags.tag_policy_ids
}

output "tag_policy_rule_set_names" {
  description = "tag_key => permissions rule set name."
  value       = module.governed_tags.tag_policy_rule_set_names
}
