terraform {
  required_version = ">= 1.5.0"

  required_providers {
    databricks = {
      source  = "databricks/databricks"
      version = ">= 1.100.0"
      # Governed tags and tag assignments are served by the WORKSPACE endpoint
      # (default provider); tag-policy permissions (access_control_rule_set) are an
      # ACCOUNT resource and use the databricks.account aliased provider.
      configuration_aliases = [databricks, databricks.account]
    }
  }
}
