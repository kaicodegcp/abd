output "tag_policy_ids" {
  description = "Map of tag_key => governed tag policy id (as created)."
  value       = { for k, p in databricks_tag_policy.this : k => p.id }
}

output "tag_keys" {
  description = "The governed tag keys managed by this module."
  value       = sort(keys(databricks_tag_policy.this))
}

output "tag_policy_rule_set_names" {
  description = "Map of tag_key => the access control rule set name managing its permissions."
  value       = { for k, r in databricks_access_control_rule_set.tag_policy : k => r.name }
}

output "entity_tag_assignments" {
  description = "Map of assignment key => \"entity_type|entity_name|tag_key\" for each UC entity tag assignment."
  value       = { for k, a in databricks_entity_tag_assignment.this : k => "${a.entity_type}|${a.entity_name}|${a.tag_key}" }
}

output "workspace_entity_tag_assignments" {
  description = "Map of assignment key => \"entity_type|entity_id|tag_key\" for each workspace entity tag assignment."
  value       = { for k, a in databricks_workspace_entity_tag_assignment.this : k => "${a.entity_type}|${a.entity_id}|${a.tag_key}" }
}
