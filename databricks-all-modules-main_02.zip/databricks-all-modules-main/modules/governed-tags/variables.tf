# =============================================================================
# governed-tags — variables
# =============================================================================

# -----------------------------------------------------------------------------
# 1) The governed tag vocabulary (databricks_tag_policy)
# -----------------------------------------------------------------------------
variable "tag_policies" {
  description = <<-EOT
    Governed tags to create or edit, keyed by tag_key. Each governed tag is a
    databricks_tag_policy: an allowed-value vocabulary that ABAC's hasTag/hasTagValue
    can match (a plain SET TAGS on an ungoverned key is invisible to ABAC).

    - description : optional human-readable description.
    - allowed_values : the governed value set. Editing this list edits the tag in
      place. Leave empty for a presence-only tag (matched with hasTag), if your
      workspace permits it. Removing a value that is already assigned may be
      rejected at apply time by the platform.

    Tag key rules: the characters , . : / - = and leading/trailing spaces are not
    allowed in a tag key.
  EOT
  type = map(object({
    description    = optional(string)
    allowed_values = optional(list(string), [])
  }))
  default = {}

  validation {
    condition     = alltrue([for k, _ in var.tag_policies : length(trimspace(k)) > 0])
    error_message = "tag_policies: every tag_key must be a non-empty string."
  }

  # Characters reserved by the tag engine, validated live: . = > < % & ? \
  # (Commas, colons and slashes are allowed — do not block them.)
  validation {
    condition = alltrue([
      for k, _ in var.tag_policies :
      !anytrue([for c in [".", "=", ">", "<", "%", "&", "?", "\\"] : strcontains(k, c)])
    ])
    error_message = "tag_policies: a tag_key may not contain any of the reserved characters . = > < % & ? \\"
  }

  validation {
    condition = alltrue([
      for k, p in var.tag_policies :
      length(p.allowed_values) == length(distinct(p.allowed_values))
    ])
    error_message = "tag_policies: allowed_values must not contain duplicates within a tag."
  }
}

# -----------------------------------------------------------------------------
# 2) Per-tag-policy permissions (databricks_access_control_rule_set)
# -----------------------------------------------------------------------------
variable "tag_policy_permissions" {
  description = <<-EOT
    Optional permissions on individual governed tags, keyed by tag_key (each key
    MUST also appear in tag_policies). Sets the rule set on
    accounts/<account_id>/tagPolicies/<tag_policy_id>/ruleSets/default.

    Each entry is the FULL list of grants for that tag (the rule set is
    authoritative — grants not listed here are removed). A grant is:
      - principals : ["groups/<name>", "users/<email>", "servicePrincipals/<app_id>"]
      - role       : "roles/tagPolicy.manager"  (edit the tag + its permissions)
                   or "roles/tagPolicy.assigner" (assign the tag to entities)

    Account-level "who may CREATE governed tags" (roles/tagPolicy.creator) is
    intentionally out of scope: it lives on the single account-wide rule set
    (accounts/<account_id>/ruleSets/default), which also carries unrelated account
    roles, so managing it here would risk clobbering them. Manage that separately.
  EOT
  type = map(list(object({
    principals = list(string)
    role       = string
  })))
  default = {}

  validation {
    condition = alltrue(flatten([
      for tk, rules in var.tag_policy_permissions : [
        for r in rules : contains(["roles/tagPolicy.manager", "roles/tagPolicy.assigner"], r.role)
      ]
    ]))
    error_message = "tag_policy_permissions: role must be roles/tagPolicy.manager or roles/tagPolicy.assigner."
  }

  validation {
    condition = alltrue(flatten([
      for tk, rules in var.tag_policy_permissions : [
        for r in rules : length(r.principals) > 0
      ]
    ]))
    error_message = "tag_policy_permissions: every grant must list at least one principal."
  }
}

variable "account_id" {
  description = "Databricks account ID. Required only when tag_policy_permissions is non-empty (it forms the rule set name)."
  type        = string
  default     = null

  validation {
    condition     = var.account_id == null || can(regex("^[0-9a-fA-F-]{10,}$", var.account_id))
    error_message = "account_id must be a Databricks account UUID."
  }
}

# -----------------------------------------------------------------------------
# 3) Assign governed tags to Unity Catalog entities (databricks_entity_tag_assignment)
# -----------------------------------------------------------------------------
variable "entity_tag_assignments" {
  description = <<-EOT
    Optional governed-tag assignments to Unity Catalog entities, keyed by a stable
    id for clean plan diffs (e.g. "sales.orders.customer_email").

    - entity_type : catalogs | schemas | tables | columns | volumes | ...
    - entity_name : the fully qualified name for the type
                    (columns: <catalog>.<schema>.<table>.<column>).
    - tag_key     : the governed tag (create it in tag_policies, or it must already exist).
    - tag_value   : omit for a presence-only tag; do not pass an empty string.

    NOTE: for ABAC roll-outs, the catalog-abac / schema-abac / table-abac modules are
    the richer home for assignments + policies. Use this block for standalone tagging.
  EOT
  type = map(object({
    entity_type = string
    entity_name = string
    tag_key     = string
    tag_value   = optional(string)
  }))
  default = {}

  validation {
    condition = alltrue([
      for k, a in var.entity_tag_assignments :
      length(trimspace(a.entity_type)) > 0 && length(trimspace(a.entity_name)) > 0 && length(trimspace(a.tag_key)) > 0
    ])
    error_message = "entity_tag_assignments: entity_type, entity_name, and tag_key must not be empty."
  }

  validation {
    condition = alltrue([
      for k, a in var.entity_tag_assignments :
      a.tag_value == null || try(length(trimspace(a.tag_value)) > 0, false)
    ])
    error_message = "entity_tag_assignments: tag_value must not be an empty string. Omit it for presence-only tags."
  }
}

# -----------------------------------------------------------------------------
# 4) Assign governed tags to workspace entities (databricks_workspace_entity_tag_assignment)
# -----------------------------------------------------------------------------
variable "workspace_entity_tag_assignments" {
  description = <<-EOT
    Optional governed-tag assignments to WORKSPACE entities, keyed by a stable id.

    - entity_type : apps | dashboards | geniespaces | notebooks
    - entity_id   : the entity's identifier (for apps, the app name; otherwise the object id).
    - tag_key     : the governed tag.
    - tag_value   : omit for a presence-only tag; do not pass an empty string.
  EOT
  type = map(object({
    entity_type = string
    entity_id   = string
    tag_key     = string
    tag_value   = optional(string)
  }))
  default = {}

  validation {
    condition = alltrue([
      for k, a in var.workspace_entity_tag_assignments :
      contains(["apps", "dashboards", "geniespaces", "notebooks"], a.entity_type)
    ])
    error_message = "workspace_entity_tag_assignments: entity_type must be one of apps, dashboards, geniespaces, notebooks."
  }

  validation {
    condition = alltrue([
      for k, a in var.workspace_entity_tag_assignments :
      length(trimspace(a.entity_id)) > 0 && length(trimspace(a.tag_key)) > 0
    ])
    error_message = "workspace_entity_tag_assignments: entity_id and tag_key must not be empty."
  }

  validation {
    condition = alltrue([
      for k, a in var.workspace_entity_tag_assignments :
      a.tag_value == null || try(length(trimspace(a.tag_value)) > 0, false)
    ])
    error_message = "workspace_entity_tag_assignments: tag_value must not be an empty string. Omit it for presence-only tags."
  }
}
