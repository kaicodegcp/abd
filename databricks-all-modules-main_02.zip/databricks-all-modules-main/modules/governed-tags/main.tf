# =============================================================================
# governed-tags
# =============================================================================
# Owns the governed-tag layer of ABAC:
#   1. the tag vocabulary + allowed values      (databricks_tag_policy)
#   2. who may manage / assign each governed tag (databricks_access_control_rule_set)
#   3. optional tag assignment to UC entities    (databricks_entity_tag_assignment)
#   4. optional tag assignment to WS entities     (databricks_workspace_entity_tag_assignment)
#
# It does NOT define ABAC enforcement policies (databricks_policy_info) — those are
# owned by the catalog-abac / schema-abac / table-abac modules, which read the
# governed tags this module creates.
#
# PROVIDERS (two):
#   databricks         -> WORKSPACE endpoint: tag policies + tag assignments.
#   databricks.account -> ACCOUNT endpoint:   tag-policy permissions (rule sets).
# Pass both from the caller (see examples/basic). The tag-policy API is served by a
# workspace bound to the metastore even though a governed tag is metastore-wide.
# =============================================================================

# 1) The governed tag vocabulary. Editing a tag's allowed_values edits it in place.
resource "databricks_tag_policy" "this" {
  for_each = var.tag_policies

  tag_key     = each.key
  description = each.value.description
  values      = [for v in each.value.allowed_values : { name = v }]
}

# 2) Per-tag-policy permissions. One authoritative rule set per governed tag; each
#    grant_rules block binds a role (manager/assigner) to a set of principals.
resource "databricks_access_control_rule_set" "tag_policy" {
  provider = databricks.account
  for_each = var.tag_policy_permissions

  name = "accounts/${var.account_id}/tagPolicies/${databricks_tag_policy.this[each.key].id}/ruleSets/default"

  dynamic "grant_rules" {
    for_each = each.value
    content {
      principals = grant_rules.value.principals
      role       = grant_rules.value.role
    }
  }

  lifecycle {
    precondition {
      condition     = var.account_id != null
      error_message = "account_id is required when tag_policy_permissions is set (it forms the rule set name)."
    }
    precondition {
      condition     = contains(keys(var.tag_policies), each.key)
      error_message = "tag_policy_permissions key '${each.key}' must also be defined in tag_policies."
    }
  }
}

# 3) Assign governed tags to Unity Catalog entities (columns, tables, schemas, ...).
resource "databricks_entity_tag_assignment" "this" {
  for_each = var.entity_tag_assignments

  entity_type = each.value.entity_type
  entity_name = each.value.entity_name
  tag_key     = each.value.tag_key
  tag_value   = each.value.tag_value

  # The governed tag should exist first when this module also creates it.
  depends_on = [databricks_tag_policy.this]
}

# 4) Assign governed tags to workspace entities (apps, dashboards, geniespaces, notebooks).
resource "databricks_workspace_entity_tag_assignment" "this" {
  for_each = var.workspace_entity_tag_assignments

  entity_type = each.value.entity_type
  entity_id   = each.value.entity_id
  tag_key     = each.value.tag_key
  tag_value   = each.value.tag_value

  depends_on = [databricks_tag_policy.this]
}
