variable "name" {
  description = "Job name"
  type        = string

  validation {
    condition     = length(trimspace(var.name)) > 0
    error_message = "Job name must not be empty."
  }
}

variable "description" {
  description = "Job description"
  type        = string
  default     = null
}

variable "timeout_seconds" {
  description = "Job timeout in seconds. 0 means no timeout."
  type        = number
  default     = 0
}

variable "max_concurrent_runs" {
  description = "Maximum number of concurrent runs"
  type        = number
  default     = 1
}

variable "tags" {
  description = "Job tags"
  type        = map(string)
  default     = {}
}

variable "control_run_state" {
  description = "When true, Databricks manages the job's paused/running state based on schedule or trigger configuration."
  type        = bool
  default     = false
}

variable "tasks" {
  description = "List of job tasks. Each task must specify exactly one task-type block."
  default     = []
  type = list(object({
    task_key                  = string
    description               = optional(string)
    timeout_seconds           = optional(number)
    max_retries               = optional(number)
    min_retry_interval_millis = optional(number)
    retry_on_timeout          = optional(bool)
    run_if                    = optional(string)
    environment_key           = optional(string)
    existing_cluster_id       = optional(string)
    job_cluster_key           = optional(string)
    depends_on                = optional(list(object({ task_key = string })))
    libraries                 = optional(list(any))

    notebook_task = optional(object({
      notebook_path   = string
      base_parameters = optional(map(string))
      source          = optional(string)
    }))

    spark_jar_task = optional(object({
      main_class_name = string
      parameters      = optional(list(string))
    }))

    spark_python_task = optional(object({
      python_file = string
      parameters  = optional(list(string))
      source      = optional(string)
    }))

    spark_submit_task = optional(object({
      parameters = optional(list(string))
    }))

    pipeline_task = optional(object({
      pipeline_id  = string
      full_refresh = optional(bool)
    }))

    python_wheel_task = optional(object({
      package_name = string
      entry_point  = string
      parameters   = optional(list(string))
    }))

    sql_task = optional(object({
      warehouse_id = string
      query        = optional(object({ query_id = string }))
      dashboard = optional(object({
        dashboard_id        = string
        custom_subject      = optional(string)
        pause_subscriptions = optional(bool)
      }))
      alert = optional(object({
        alert_id            = string
        pause_subscriptions = optional(bool)
      }))
      file = optional(object({
        path   = string
        source = optional(string)
      }))
    }))

    dbt_task = optional(object({
      commands           = list(string)
      project_directory  = optional(string)
      profiles_directory = optional(string)
      schema             = optional(string)
      warehouse_id       = optional(string)
    }))

    new_cluster = optional(any)
  }))

  validation {
    condition = alltrue([
      for task in var.tasks :
      length(compact([
        task.notebook_task != null ? "notebook" : "",
        task.spark_jar_task != null ? "jar" : "",
        task.spark_python_task != null ? "python" : "",
        task.spark_submit_task != null ? "submit" : "",
        task.pipeline_task != null ? "pipeline" : "",
        task.python_wheel_task != null ? "wheel" : "",
        task.sql_task != null ? "sql" : "",
        task.dbt_task != null ? "dbt" : ""
      ])) == 1
    ])
    error_message = "Each task must define exactly one task-type block (notebook_task, spark_jar_task, spark_python_task, spark_submit_task, pipeline_task, python_wheel_task, sql_task, or dbt_task)."
  }
}

variable "schedule" {
  description = "Job schedule configuration. pause_status must be PAUSED or UNPAUSED."
  type = object({
    quartz_cron_expression = string
    timezone_id            = string
    pause_status           = optional(string)
  })
  default = null

  validation {
    condition = var.schedule == null || try(
      contains(["PAUSED", "UNPAUSED"], var.schedule.pause_status) || var.schedule.pause_status == null,
      true
    )
    error_message = "schedule.pause_status must be PAUSED or UNPAUSED."
  }
}

variable "trigger" {
  description = "Job trigger configuration. pause_status must be PAUSED or UNPAUSED."
  type = object({
    pause_status = optional(string)
    file_arrival = optional(object({
      url                               = string
      min_time_between_triggers_seconds = optional(number)
      wait_after_last_change_seconds    = optional(number)
    }))
  })
  default = null

  validation {
    condition = var.trigger == null || try(
      contains(["PAUSED", "UNPAUSED"], var.trigger.pause_status) || var.trigger.pause_status == null,
      true
    )
    error_message = "trigger.pause_status must be PAUSED or UNPAUSED."
  }
}

variable "continuous" {
  description = "Continuous job configuration. pause_status must be PAUSED or UNPAUSED."
  type = object({
    pause_status = optional(string)
  })
  default = null

  validation {
    condition = var.continuous == null || try(
      contains(["PAUSED", "UNPAUSED"], var.continuous.pause_status) || var.continuous.pause_status == null,
      true
    )
    error_message = "continuous.pause_status must be PAUSED or UNPAUSED."
  }
}

variable "git_source" {
  description = "Git source configuration. Exactly one of branch, tag, or commit must be specified."
  type = object({
    url      = string
    provider = string
    branch   = optional(string)
    tag      = optional(string)
    commit   = optional(string)
  })
  default = null

  validation {
    condition = var.git_source == null || length(compact([
      try(var.git_source.branch, null),
      try(var.git_source.tag, null),
      try(var.git_source.commit, null)
    ])) == 1
    error_message = "git_source must specify exactly one of branch, tag, or commit."
  }
}

variable "job_clusters" {
  description = "List of job-level cluster definitions. Each entry must specify job_cluster_key and new_cluster."
  type = list(object({
    job_cluster_key = string
    new_cluster     = any
  }))
  default = []
}

variable "email_notifications" {
  description = "Email notification settings"
  type = object({
    on_start                               = optional(list(string))
    on_success                             = optional(list(string))
    on_failure                             = optional(list(string))
    on_duration_warning_threshold_exceeded = optional(list(string))
    no_alert_for_skipped_runs              = optional(bool)
  })
  default = null
}

variable "webhook_notifications" {
  description = "Webhook notification settings"
  type = object({
    on_start                               = optional(list(object({ id = string })))
    on_success                             = optional(list(object({ id = string })))
    on_failure                             = optional(list(object({ id = string })))
    on_duration_warning_threshold_exceeded = optional(list(object({ id = string })))
  })
  default = null
}

variable "notification_settings" {
  description = "Notification settings"
  type = object({
    no_alert_for_skipped_runs  = optional(bool)
    no_alert_for_canceled_runs = optional(bool)
  })
  default = null
}

variable "health" {
  description = "Job health configuration"
  type = object({
    rules = optional(list(object({
      metric = string
      op     = string
      value  = number
    })))
  })
  default = null
}

variable "parameters" {
  description = "Job parameters"
  type = list(object({
    name    = string
    default = string
  }))
  default = []
}

variable "format" {
  description = "Job format (SINGLE_TASK or MULTI_TASK)"
  type        = string
  default     = "MULTI_TASK"

  validation {
    condition     = contains(["SINGLE_TASK", "MULTI_TASK"], var.format)
    error_message = "format must be SINGLE_TASK or MULTI_TASK."
  }
}

variable "environments" {
  description = "Job environments (e.g. serverless). Tasks set environment_key to match environment_key here."
  type = list(object({
    environment_key = string
    client          = optional(string, "1")
  }))
  default = []
}

variable "app_acronym" {
  description = "CSI application acronym used in group name construction (e.g. dms)."
  type        = string

  validation {
    condition     = length(trimspace(var.app_acronym)) > 0
    error_message = "app_acronym must not be empty."
  }
}

variable "environment" {
  description = "Deployment environment (dev, uat, prod). Controls group names and engineer permission level."
  type        = string

  validation {
    condition     = contains(["dev", "uat", "prod"], var.environment)
    error_message = "environment must be one of: dev, uat, prod."
  }
}

variable "app_id" {
  description = "Application identifier / CSI used in group name construction (e.g. 179392)."
  type        = string

  validation {
    condition     = length(trimspace(var.app_id)) > 0
    error_message = "app_id must not be empty."
  }
}

variable "run_as_service_principal_application_id" {
  description = "Deployer service principal application (client) ID for run_as. Must be a GUID; provisioned upstream, not created by this module."
  type        = string

  validation {
    condition     = can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.run_as_service_principal_application_id))
    error_message = "run_as_service_principal_application_id must be the service principal's application (client) ID in GUID form, not a display name."
  }
}

variable "access_controls" {
  description = "Additional user or service principal ACL entries. Exactly one of group_name, user_name, or service_principal_name must be set per entry."
  type = list(object({
    group_name             = optional(string)
    user_name              = optional(string)
    service_principal_name = optional(string)
    permission_level       = string
  }))
  default = []

  validation {
    condition = alltrue([
      for acl in var.access_controls :
      length([for v in [acl.group_name, acl.user_name, acl.service_principal_name] : v if v != null && length(trimspace(v)) > 0]) == 1
    ])
    error_message = "Each access_controls entry must specify exactly one non-empty value among group_name, user_name, or service_principal_name."
  }

  validation {
    condition = alltrue([
      for acl in var.access_controls :
      contains(["CAN_VIEW", "CAN_MANAGE_RUN", "CAN_MANAGE"], acl.permission_level)
    ])
    error_message = "permission_level must be one of: CAN_VIEW, CAN_MANAGE_RUN, CAN_MANAGE."
  }
}
