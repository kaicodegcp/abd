output "id" {
  description = "The Databricks job ID."
  value       = databricks_job.this.id
}

output "job_id" {
  description = "The job ID. Alias for id."
  value       = databricks_job.this.id
}

output "name" {
  description = "The name of the job."
  value       = databricks_job.this.name
}

output "url" {
  description = "The URL to access the job."
  value       = databricks_job.this.url
}

output "permissions_id" {
  description = "The ID of the applied job permissions resource."
  value       = databricks_permissions.job.id
}
