output "job_id" {
  description = "The created job ID."
  value       = module.job.id
}

output "job_url" {
  description = "URL to the created job."
  value       = module.job.url
}
