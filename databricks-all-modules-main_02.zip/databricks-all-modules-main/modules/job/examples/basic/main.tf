# Example: job — creates a Databricks job with embedded permissions.
# Copy terraform.tfvars.example to terraform.tfvars; auth via env (DATABRICKS_HOST/CLIENT_ID/CLIENT_SECRET).

provider "databricks" {}

module "job" {
  source = "../.."

  name        = var.name
  app_acronym = var.app_acronym
  environment = var.environment
  app_id      = var.app_id

  run_as_service_principal_application_id = var.run_as_service_principal_application_id

  tasks = var.tasks
}
