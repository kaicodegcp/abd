variable "name" {
  description = "Job name."
  type        = string
}

variable "app_acronym" {
  description = "CSI application acronym used in group name construction (e.g. dms)."
  type        = string
}

variable "environment" {
  description = "Deployment environment (dev, uat, prod)."
  type        = string
}

variable "app_id" {
  description = "Application identifier used in group and service principal name construction."
  type        = string
}

variable "run_as_service_principal_application_id" {
  description = "Application (client) ID of the deployer service principal, provisioned upstream and used for run_as."
  type        = string
}

variable "tasks" {
  description = "List of job tasks."
  type        = list(any)
  default     = []
}
