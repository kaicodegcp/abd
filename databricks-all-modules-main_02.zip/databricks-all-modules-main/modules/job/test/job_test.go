package test

import (
	"path/filepath"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	common "github.com/sandbox45/databricks-all-modules/common"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func planJobModule(t *testing.T, vars map[string]interface{}) string {
	t.Helper()
	common.SkipIfShortMode(t, "job module (plan)")
	common.RequireDatabricksEnv(t)

	opts := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: filepath.Join(".."),
		Vars:         vars,
		NoColor:      true,
	})
	terraform.Init(t, opts)
	plan := terraform.Plan(t, opts)
	require.NotEmpty(t, plan, "terraform plan should produce output")
	return plan
}

func minimalNewCluster(defaults common.TestDefaults) map[string]interface{} {
	return map[string]interface{}{
		"spark_version": defaults.SparkVersion,
		"node_type_id":  defaults.NodeTypeID,
		"num_workers":   1,
	}
}

func baseJobVars(name string) map[string]interface{} {
	return map[string]interface{}{
		"name":        name,
		"app_acronym": "dms",
		"environment": "dev",
		"app_id":      "179392",
		"run_as_service_principal_application_id": "11111111-1111-1111-1111-111111111111",
	}
}

func TestJobModule(t *testing.T) {
	defaults := common.GetTestDefaults()
	uniqueID := common.GenerateUniqueTestID("job")

	config := common.ModuleTestConfig{
		ModuleName:      "job",
		TestDescription: "Tests Databricks job module",
		RequiredVars: map[string]interface{}{
			"name":        uniqueID,
			"app_acronym": "dms",
			"environment": "dev",
			"app_id":      "179392",
			"run_as_service_principal_application_id": "11111111-1111-1111-1111-111111111111",
			"tasks": []map[string]interface{}{
				{
					"task_key": "main",
					"notebook_task": map[string]interface{}{
						"notebook_path": "/ci-cd/notebook",
					},
					"new_cluster": map[string]interface{}{
						"spark_version": defaults.SparkVersion,
						"node_type_id":  defaults.NodeTypeID,
						"num_workers":   1,
					},
				},
			},
		},
		OptionalVars: map[string]interface{}{
			"max_concurrent_runs": 1,
			"timeout_seconds":     3600,
		},
		ExpectedOutputs: []string{
			"id",
			"job_id",
			"name",
			"url",
		},
	}

	common.TestModuleWithConfig(t, config)
}

func TestJobModuleWithSchedule(t *testing.T) {
	defaults := common.GetTestDefaults()
	uniqueID := common.GenerateUniqueTestID("job-sched")

	config := common.ModuleTestConfig{
		ModuleName:      "job",
		TestDescription: "Tests Databricks job with schedule",
		RequiredVars: map[string]interface{}{
			"name":        uniqueID,
			"app_acronym": "dms",
			"environment": "dev",
			"app_id":      "179392",
			"run_as_service_principal_application_id": "11111111-1111-1111-1111-111111111111",
			"tasks": []map[string]interface{}{
				{
					"task_key": "scheduled-task",
					"spark_python_task": map[string]interface{}{
						"python_file": "dbfs:/FileStore/scripts/test.py",
						"parameters":  []string{},
						"source":      "WORKSPACE",
					},
					"new_cluster": map[string]interface{}{
						"spark_version": defaults.SparkVersion,
						"node_type_id":  defaults.NodeTypeID,
						"num_workers":   1,
					},
				},
			},
		},
		OptionalVars: map[string]interface{}{
			"schedule": map[string]interface{}{
				"quartz_cron_expression": "0 0 * * * ?",
				"timezone_id":            "UTC",
			},
		},
		ExpectedOutputs: []string{
			"id",
			"job_id",
			"name",
			"url",
		},
	}

	common.TestModuleWithConfig(t, config)
}

func TestJobModuleWithEmailNotifications(t *testing.T) {
	defaults := common.GetTestDefaults()
	uniqueID := common.GenerateUniqueTestID("job-email")

	config := common.ModuleTestConfig{
		ModuleName:      "job",
		TestDescription: "Tests Databricks job with email notifications",
		RequiredVars: map[string]interface{}{
			"name":        uniqueID,
			"app_acronym": "dms",
			"environment": "dev",
			"app_id":      "179392",
			"run_as_service_principal_application_id": "11111111-1111-1111-1111-111111111111",
			"tasks": []map[string]interface{}{
				{
					"task_key": "notif-task",
					"notebook_task": map[string]interface{}{
						"notebook_path": "/ci-cd/notebook",
					},
					"new_cluster": map[string]interface{}{
						"spark_version": defaults.SparkVersion,
						"node_type_id":  defaults.NodeTypeID,
						"num_workers":   1,
					},
				},
			},
		},
		OptionalVars: map[string]interface{}{
			"email_notifications": map[string]interface{}{
				"on_failure": []string{"test@example.com"},
				"on_success": []string{"test@example.com"},
			},
		},
		ExpectedOutputs: []string{
			"id",
			"job_id",
			"name",
			"url",
		},
	}

	common.TestModuleWithConfig(t, config)
}

func TestJobModuleClusterLogConf(t *testing.T) {
	defaults := common.GetTestDefaults()
	name := common.GenerateUniqueTestID("job-logconf")

	cluster := minimalNewCluster(defaults)
	cluster["cluster_log_conf"] = map[string]interface{}{
		"volumes": map[string]interface{}{
			"destination": "/Volumes/plan_only_catalog/default/cluster_logs",
		},
	}

	vars := baseJobVars(name)
	vars["tasks"] = []map[string]interface{}{
		{
			"task_key": "logconf-task",
			"notebook_task": map[string]interface{}{
				"notebook_path": "/ci-cd/notebook",
			},
			"new_cluster": cluster,
		},
	}

	plan := planJobModule(t, vars)
	assert.Contains(t, plan, "cluster_log_conf")
	assert.Contains(t, plan, "volumes")
}

func TestJobModuleRunAsUsesProvidedServicePrincipal(t *testing.T) {
	common.SkipIfShortMode(t, "job module run_as (plan)")
	common.RequireDatabricksEnv(t)

	name := common.GenerateUniqueTestID("job-prod-sp")
	deployerAppID := "22222222-2222-2222-2222-222222222222"

	plan := planJobModule(t, map[string]interface{}{
		"name":        name,
		"app_acronym": "dms",
		"environment": "prod",
		"app_id":      "179392",
		"run_as_service_principal_application_id": deployerAppID,
	})

	assert.Contains(t, plan, "run_as")
	assert.Contains(t, plan, deployerAppID)
	assert.Contains(t, plan, "dbx-prod-179392-dms-deployer-grp")
}

func TestJobModuleJobClusterClusterLogConf(t *testing.T) {
	defaults := common.GetTestDefaults()
	name := common.GenerateUniqueTestID("job-jc-logconf")

	cluster := minimalNewCluster(defaults)
	cluster["cluster_log_conf"] = map[string]interface{}{
		"volumes": map[string]interface{}{
			"destination": "/Volumes/plan_only_catalog/default/cluster_logs",
		},
	}

	vars := baseJobVars(name)
	vars["job_clusters"] = []map[string]interface{}{
		{
			"job_cluster_key": "shared-logs",
			"new_cluster":     cluster,
		},
	}
	vars["tasks"] = []map[string]interface{}{
		{
			"task_key":        "shared-log-task",
			"job_cluster_key": "shared-logs",
			"notebook_task": map[string]interface{}{
				"notebook_path": "/ci-cd/notebook",
			},
		},
	}

	plan := planJobModule(t, vars)
	assert.Contains(t, plan, "cluster_log_conf")
	assert.Contains(t, plan, "volumes")
}

func planJobModuleExpectError(t *testing.T, vars map[string]interface{}) error {
	t.Helper()
	common.SkipIfShortMode(t, "job module (plan-expect-error)")
	common.RequireDatabricksEnv(t)

	opts := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: filepath.Join(".."),
		Vars:         vars,
		NoColor:      true,
	})
	terraform.Init(t, opts)
	_, err := terraform.PlanE(t, opts)
	return err
}

// Prod engineers may only view jobs; job changes go through CI/CD.
func TestJobModuleProdEngineerCanView(t *testing.T) {
	common.SkipIfShortMode(t, "job module prod engineer ACL (plan)")
	common.RequireDatabricksEnv(t)

	plan := planJobModule(t, map[string]interface{}{
		"name":        common.GenerateUniqueTestID("job-prod-eng"),
		"app_acronym": "dms",
		"environment": "prod",
		"app_id":      "179392",
		"run_as_service_principal_application_id": "11111111-1111-1111-1111-111111111111",
	})

	assert.Contains(t, plan, "dbx-prod-179392-dms-engineer-grp")
	assert.Contains(t, plan, "CAN_VIEW")
}

func TestJobModuleTaskRetryFields(t *testing.T) {
	common.SkipIfShortMode(t, "job module task retry fields (plan)")
	common.RequireDatabricksEnv(t)

	vars := baseJobVars(common.GenerateUniqueTestID("job-retry"))
	vars["tasks"] = []map[string]interface{}{
		{
			"task_key": "main",
			"notebook_task": map[string]interface{}{
				"notebook_path": "/ci-cd/notebook",
			},
			"max_retries":               3,
			"min_retry_interval_millis": 10000,
			"retry_on_timeout":          true,
		},
	}

	plan := planJobModule(t, vars)
	assert.Contains(t, plan, "max_retries")
	assert.Contains(t, plan, "min_retry_interval_millis")
	assert.Contains(t, plan, "retry_on_timeout")
}

func TestJobModuleMultipleTaskTypesFails(t *testing.T) {
	common.SkipIfShortMode(t, "job module multiple task types (plan fail)")
	common.RequireDatabricksEnv(t)

	vars := baseJobVars(common.GenerateUniqueTestID("job-multi-task"))
	vars["tasks"] = []map[string]interface{}{
		{
			"task_key": "main",
			"notebook_task": map[string]interface{}{
				"notebook_path": "/ci-cd/notebook",
			},
			"spark_python_task": map[string]interface{}{
				"python_file": "/ci-cd/script.py",
			},
		},
	}

	err := planJobModuleExpectError(t, vars)
	require.Error(t, err, "plan must fail when a task defines more than one task-type block")
}

func TestJobModuleMultipleSchedulesFails(t *testing.T) {
	common.SkipIfShortMode(t, "job module multiple schedules (plan fail)")
	common.RequireDatabricksEnv(t)

	vars := baseJobVars(common.GenerateUniqueTestID("job-multi-sched"))
	vars["schedule"] = map[string]interface{}{
		"quartz_cron_expression": "0 0 * * * ?",
		"timezone_id":            "UTC",
	}
	vars["continuous"] = map[string]interface{}{
		"pause_status": "UNPAUSED",
	}

	err := planJobModuleExpectError(t, vars)
	require.Error(t, err, "plan must fail when more than one of schedule, trigger, or continuous is set")
}

func TestJobModuleGitSourceMultipleRevisionsFails(t *testing.T) {
	common.SkipIfShortMode(t, "job module git multiple revisions (plan fail)")
	common.RequireDatabricksEnv(t)

	vars := baseJobVars(common.GenerateUniqueTestID("job-git-multi"))
	vars["git_source"] = map[string]interface{}{
		"url":      "https://github.com/example/repo",
		"provider": "gitHub",
		"branch":   "main",
		"tag":      "v1.0.0",
	}

	err := planJobModuleExpectError(t, vars)
	require.Error(t, err, "plan must fail when git_source specifies both branch and tag")
}

func TestJobModuleGitSourceNoRevisionFails(t *testing.T) {
	common.SkipIfShortMode(t, "job module git no revision (plan fail)")
	common.RequireDatabricksEnv(t)

	vars := baseJobVars(common.GenerateUniqueTestID("job-git-none"))
	vars["git_source"] = map[string]interface{}{
		"url":      "https://github.com/example/repo",
		"provider": "gitHub",
	}

	err := planJobModuleExpectError(t, vars)
	require.Error(t, err, "plan must fail when git_source specifies no revision selector")
}

// run_as expects the SP application (client) ID (GUID); a display name must fail validation.
func TestJobModuleInvalidRunAsApplicationIDFails(t *testing.T) {
	common.SkipIfShortMode(t, "job module invalid run_as app id (plan fail)")
	common.RequireDatabricksEnv(t)

	err := planJobModuleExpectError(t, map[string]interface{}{
		"name":        common.GenerateUniqueTestID("job-bad-sp"),
		"app_acronym": "dms",
		"environment": "dev",
		"app_id":      "179392",
		"run_as_service_principal_application_id": "dbx-dev-179392-dms-deployer-grp",
	})

	require.Error(t, err, "plan must fail when run_as_service_principal_application_id is not a GUID")
}
