variable "databricks_account_id" {
  description = "Databricks account ID (36-character UUID)."
  type        = string
}

variable "name" {
  description = "DR group key: names the failover group, stable URL (<name>-url) and workspace set (<name>-ws). Immutable once created; must not contain a region name (it outlives any particular primary region)."
  type        = string

  validation {
    condition     = can(regex("^[a-z0-9][a-z0-9-]{1,58}[a-z0-9]$", var.name))
    error_message = "name must be 3-60 characters, lowercase alphanumeric or hyphen, and must not start or end with a hyphen."
  }
}

variable "primary_workspace_id" {
  description = "Numeric workspace ID (as string) of the workspace that starts as primary."
  type        = string
}

variable "secondary_workspace_id" {
  description = "Numeric workspace ID (as string) of the dark replica workspace."
  type        = string
}

variable "primary_region" {
  description = "Region of the primary workspace."
  type        = string
}

variable "secondary_region" {
  description = "Region of the secondary workspace. Must differ from primary_region."
  type        = string
}

variable "catalogs" {
  description = "Catalogs to replicate, each with its storage-root URI in both regions (a location mapping is built per catalog). RBAC-only catalogs; at most 10. Empty list = workspace-asset-only DR."
  type = list(object({
    name          = string
    primary_uri   = string
    secondary_uri = string
  }))
  default = []
}

variable "extra_location_mappings" {
  description = "Additional exact-path location mappings (external table paths, external volume paths, per-schema buckets). Every external storage path used by a replicated catalog needs one."
  type = list(object({
    name          = string
    primary_uri   = string
    secondary_uri = string
  }))
  default = []
}

variable "replicate_workspace_assets" {
  description = "Replicate workspace assets (notebooks, jobs, ...). WARNING: deletes pre-existing in-scope assets in the secondary when replication starts."
  type        = bool
  default     = true
}

variable "create_stable_url" {
  description = "Create a stable URL that follows the current primary, so clients survive a failover without repointing."
  type        = bool
  default     = true
}
