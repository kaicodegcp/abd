# =============================================================================
# dr - basic example: turn an existing workspace pair into a Managed DR pair
# (failover group + optional stable URL) with one catalog in scope.
# =============================================================================

terraform {
  required_version = ">= 1.5"
  required_providers {
    databricks = {
      source  = "databricks/databricks"
      version = ">= 1.125.0, < 2.0.0"
    }
  }
}

variable "databricks_account_id" {
  type    = string
  default = "00000000-0000-0000-0000-000000000000"
}

provider "databricks" {
  alias      = "account"
  host       = "https://accounts.cloud.databricks.com"
  account_id = var.databricks_account_id
}

module "dr" {
  source    = "../.."
  providers = { databricks = databricks.account }

  databricks_account_id = var.databricks_account_id
  name                  = "acme-drg"

  primary_workspace_id   = "1111111111111111"
  secondary_workspace_id = "2222222222222222"
  primary_region         = "us-east-1"
  secondary_region       = "us-east-2"

  replicate_workspace_assets = true
  create_stable_url          = false # requires a Custom-URL-enabled account

  # One entry per catalog: bucket-root to bucket-root, exact path.
  catalogs = [{
    name          = "acme_catalog"
    primary_uri   = "s3://acme-catalog/"
    secondary_uri = "s3://acme-catalog-dr/"
  }]

  # One entry per schema bucket (sub-paths never resolve through a parent).
  extra_location_mappings = [{
    name          = "acme-schema1-location"
    primary_uri   = "s3://acme-catalog-schema1/"
    secondary_uri = "s3://acme-catalog-schema1-dr/"
  }]
}

output "failover_group_name" {
  value = module.dr.failover_group_name
}

output "replication_state" {
  value = module.dr.replication_state
}
