output "failover_group_name" {
  description = "Full resource name of the failover group."
  value       = module.failover_group.name
}

output "failover_group_id" {
  description = "Client-provided failover group ID."
  value       = var.name
}

output "stable_url" {
  description = "Stable URL hostname that follows the current primary; null when create_stable_url is false."
  value       = var.create_stable_url ? module.stable_url[0].url : null
}

output "replication_state" {
  description = "Replication state of the group, e.g. INITIAL_REPLICATION or ACTIVE."
  value       = module.failover_group.state
}

output "etag" {
  description = "Opaque version string; the failover API call needs a FRESH etag (re-read before failing over)."
  value       = module.failover_group.etag
}

output "stable_url_name" {
  description = "Full resource name of the stable URL; null when create_stable_url is false."
  value       = var.create_stable_url ? module.stable_url[0].name : null
}
