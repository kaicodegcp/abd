# =============================================================================
# Resilience DR - account-level orchestrator
# =============================================================================
# One module call turns a primary/secondary workspace pair into a replicating
# Managed DR pair: stable URL + failover group, with location mappings built
# automatically from simple {name, primary_uri, secondary_uri} inputs instead
# of the raw uri_by_region structures.
#
# Wraps the unchanged dr-stable-url and dr-failover-group modules (copied
# verbatim from the old repo). Requires the ACCOUNT-level provider.
#
# CONSOLE GATE (no API/CLI/provider path exists): Mission Critical must be
# enabled on BOTH workspaces in the Account Console before the failover group
# can be created. On a fresh enablement the first apply fails at the failover
# group with that error; enable Mission Critical, then apply again - nothing
# else is affected.
#
# Failover itself is an API/CLI call against a fresh etag, never Terraform:
#   databricks account disaster-recovery failover-failover-group \
#     accounts/{account_id}/failover-groups/{id} {target_region} FORCED --etag {etag}
# =============================================================================

locals {
  parent             = "accounts/${var.databricks_account_id}"
  workspace_set_name = "${var.name}-ws"

  all_mappings = concat(
    [for c in var.catalogs : {
      name          = "${var.name}-${replace(c.name, "_", "-")}-location"
      primary_uri   = c.primary_uri
      secondary_uri = c.secondary_uri
    }],
    var.extra_location_mappings
  )
}

module "stable_url" {
  source = "../dr-stable-url"
  count  = var.create_stable_url ? 1 : 0

  parent        = local.parent
  stable_url_id = "${var.name}-url"

  # Write-only: never returned by the API; after a failover it will not match
  # effective_workspace_id. Expected - must not be "corrected".
  initial_workspace_id = var.primary_workspace_id
}

module "failover_group" {
  source = "../dr-failover-group"

  parent            = local.parent
  failover_group_id = var.name
  regions           = [var.primary_region, var.secondary_region]

  # Write-only, same trap as initial_workspace_id above.
  initial_primary_region = var.primary_region

  workspace_sets = [{
    name                       = local.workspace_set_name
    workspace_ids              = [var.primary_workspace_id, var.secondary_workspace_id]
    replicate_workspace_assets = var.replicate_workspace_assets
    stable_url_names           = var.create_stable_url ? [module.stable_url[0].name] : null
  }]

  # Omitted entirely when no catalogs are declared (workspace-asset-only DR).
  unity_catalog_assets = length(var.catalogs) == 0 ? null : {
    catalogs                       = [for c in var.catalogs : { name = c.name }]
    data_replication_workspace_set = local.workspace_set_name

    # One mapping per storage root, matched EXACTLY: a path that is a sub-path
    # of a mapped URI does not resolve through it.
    location_mappings = [for m in local.all_mappings : {
      name = m.name
      uri_by_region = [
        { region = var.primary_region, uri = m.primary_uri },
        { region = var.secondary_region, uri = m.secondary_uri },
      ]
    }]
  }
}
