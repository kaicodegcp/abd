# Resilience DR samples

Working samples for the layered DR approach, taken from a verified live build
(two serverless workspaces, one failover group, one catalog, two schemas built
two different ways). Nothing here modifies existing modules; DR is composed
from the `dr*` modules plus the original workspace, schema, external-location
and group modules.

Operating model:

- **Ops** own the workspaces, the metastores, the default catalog all schemas
  go into, the replica-side registration on the secondary metastore, and the
  failover group with every location mapping. The group is ONE resource in ONE
  state; teams cannot register mappings independently (the API takes the full
  mapping list and validates it for completeness).
- **Domain/functional teams** own their schemas and their storage (bucket,
  KMS, IAM), created in their own state, and hand the mapping entry to Ops.

Layers, in apply order:

1. Two independent workspaces (primary + secondary), each with its own
   dedicated metastore and default catalog
2. Failover group pairing them (workspace assets only)
3. Schemas with their own storage (either method below)
4. Secondary (DR) storage: twin buckets, replica registration, mappings

---

## 1. Workspace pair

Two calls of the ORIGINAL `complete-workspace-serverless`, one per region.
No DR flags exist in the module; the pairing happens in layer 2.

```hcl
provider "aws" { region = var.aws_region }            # us-east-1
provider "aws" { alias = "dr", region = var.dr_region } # us-east-2

provider "databricks" {
  alias      = "account"
  host       = "https://accounts.cloud.databricks.com"
  account_id = var.databricks_account_id
}

provider "databricks" {
  alias = "workspace_primary"
  host  = module.workspace_primary.workspace_url
}

provider "databricks" {
  alias = "workspace_secondary"
  host  = module.workspace_secondary.workspace_url
}

module "metastore_secondary" {
  source    = "../modules/metastore"
  providers = { databricks = databricks.account }

  name          = "${var.prefix}-metastore-${var.dr_region}"
  region        = var.dr_region
  storage_root  = null
  force_destroy = true
}

module "workspace_primary" {
  source = "../modules/complete-workspace-serverless"

  providers = {
    aws                  = aws
    databricks.mws       = databricks.account
    databricks.workspace = databricks.workspace_primary
  }

  databricks_account_id      = var.databricks_account_id
  databricks_aws_account_id  = "414351767826"
  name_prefix                = var.prefix
  workspace_name             = var.prefix
  aws_region                 = var.aws_region
  workspace_root_bucket_name = "${var.prefix}-root-${data.aws_caller_identity.current.account_id}"
  existing_metastore_name    = var.primary_metastore_name

  create_default_catalog             = true
  default_catalog_enable_file_events = true
}

module "workspace_secondary" {
  source = "../modules/complete-workspace-serverless"

  providers = {
    aws                  = aws.dr
    databricks.mws       = databricks.account
    databricks.workspace = databricks.workspace_secondary
  }

  databricks_account_id      = var.databricks_account_id
  databricks_aws_account_id  = "414351767826"
  name_prefix                = "${var.prefix}-dr"
  workspace_name             = "${var.prefix}-dr"
  aws_region                 = var.dr_region
  workspace_root_bucket_name = "${var.prefix}-dr-root-${data.aws_caller_identity.current.account_id}"
  existing_metastore_name    = module.metastore_secondary.name

  create_default_catalog             = true
  default_catalog_enable_file_events = true
}
```

Notes:

- Dedicated metastore per region, never shared between deployments. The
  secondary metastore must not contain catalog names that overlap the
  replicated catalogs (default catalog names embed the workspace ID, so they
  never overlap).
- The default catalog external location can hit a one-time file-events
  validation race on a fresh create (an S3 TestEvent lands in the new queue
  and validation cannot parse it). Retry the apply; if it persists, purge the
  SQS queue and apply again.

## 2. Failover group (workspace pair first, catalogs later)

The `dr` module wraps the stable URL and failover group. Start with
workspace-asset-only replication; catalogs and mappings can be added later as
an IN-PLACE update.

```hcl
module "dr" {
  source    = "../modules/dr"
  providers = { databricks = databricks.account }

  databricks_account_id = var.databricks_account_id
  name                  = "${var.prefix}-drg"

  primary_workspace_id   = tostring(module.workspace_primary.workspace_id)
  secondary_workspace_id = tostring(module.workspace_secondary.workspace_id)
  primary_region         = var.aws_region
  secondary_region       = var.dr_region

  replicate_workspace_assets = true
  create_stable_url          = false

  catalogs = [] # workspace-asset-only to start; see layer 4 for UC scope
}
```

Notes:

- CONSOLE GATE: Mission Critical must be enabled on BOTH workspaces in the
  Account Console before the group can be created. There is no API for it.
  The first apply fails at the group with that exact error; enable the add-on
  on both workspaces (verify the workspace IDs on their console pages), then
  apply again. Enablement is per workspace and easy to click on the wrong row.
- Failover is never Terraform. It is a CLI/API call against a fresh etag.

## 3. Schema with its own storage

Both methods are verified and can coexist under the same catalog and the same
failover group.

### Method A: direct modules, reusing the catalog's credential

The schema uses the CATALOG's storage credential. The catalog's IAM role only
covers the catalog bucket, so the schema bucket carries a BUCKET POLICY
granting that role (resource policies take effect immediately, so there is no
IAM propagation wait). The role ARN is read from the credential because the
original catalog-creation role name carries a random suffix.

```hcl
data "databricks_storage_credential" "default_catalog" {
  provider = databricks.workspace_primary
  name     = module.workspace_primary.default_catalog_storage_credential_id
}

locals {
  schema_bucket = "${module.workspace_primary.default_catalog_s3_bucket_name}-${var.schema_name}"
}

resource "aws_s3_bucket" "schema" {
  bucket        = local.schema_bucket
  force_destroy = true
}

# + aws_s3_bucket_public_access_block / _server_side_encryption_configuration

data "aws_iam_policy_document" "schema_bucket" {
  statement {
    sid = "UnityCatalogRoleAccess"
    principals {
      type        = "AWS"
      identifiers = [data.databricks_storage_credential.default_catalog.storage_credential_info[0].aws_iam_role[0].role_arn]
    }
    actions   = ["s3:GetObject", "s3:PutObject", "s3:DeleteObject", "s3:ListBucket", "s3:GetBucketLocation"]
    resources = [aws_s3_bucket.schema.arn, "${aws_s3_bucket.schema.arn}/*"]
  }
}

resource "aws_s3_bucket_policy" "schema" {
  bucket = aws_s3_bucket.schema.id
  policy = data.aws_iam_policy_document.schema_bucket.json
}

module "schema_location" {
  source    = "../modules/external-location"
  providers = { databricks = databricks.workspace_primary }

  name            = "${local.schema_bucket}-external-location"
  url             = "s3://${local.schema_bucket}/"
  credential_name = module.workspace_primary.default_catalog_storage_credential_id
  force_destroy   = true

  depends_on = [aws_s3_bucket_policy.schema]
}

module "schema" {
  source    = "../modules/schema"
  providers = { databricks = databricks.workspace_primary }

  catalog_name  = module.workspace_primary.default_catalog_name
  name          = var.schema_name
  storage_root  = "s3://${local.schema_bucket}/"
  force_destroy = true
  environment   = var.environment
  app_id        = var.app_id
  app_acronym   = var.app_acronym

  depends_on = [module.schema_location, module.schema_persona_groups]
}
```

### Method B: the dr-schema module, one call

Fully self-contained, client-wrapper style: own credential, own KMS (both
regions), own IAM role scoped to exactly this schema's buckets and keys, own
bucket plus its "-dr" twin, external location, schema with persona grants.
Everything create-or-pass: `create_bucket`, `create_kms_key`,
`create_iam_role` each default true, or pass `bucket_name`, `kms_key_arn` /
`dr_kms_key_arn`, `iam_role_arn` instead.

```hcl
module "domain_schema" {
  source = "../modules/dr-schema"

  providers = {
    databricks = databricks.workspace_primary
    aws        = aws
  }

  catalog_name = module.workspace_primary.default_catalog_name
  name         = "domainschema"

  environment = var.environment
  app_id      = var.app_id
  app_acronym = var.app_acronym

  dr_enable = true
  dr_region = var.dr_region

  # Fresh IAM roles can take hours before Unity Catalog's S3 access sees them
  # (STS accepts the role while S3 still denies). The role here is correct by
  # construction; skip the synchronous validation instead of stalling.
  skip_validation = true

  force_destroy = true

  depends_on = [module.domain_schema_persona_groups]
}
```

Both methods require the three account-level persona groups to exist:
`dbx-<env>-<app_id>-<acronym>-schema-<name>-{read,write,owner}-grp`
(create them with `modules/group`, `force = true`, account provider).

## 4. Secondary (DR) storage and mappings

Every replicated storage root needs a twin bucket in the secondary region, a
replica-side registration on the SECONDARY metastore, and an EXACT-PATH
mapping on the failover group (a sub-path never resolves through a parent
mapping, which is why every catalog and every schema has its own bucket and
twin).

The `dr-schema` module creates its own twin; the catalog twin (and any
Method A schema twin) is created in the Ops root. Replica registration is one
`dr-replica-storage` chain per catalog family; its role covers
`<catalog-bucket>*` in both regions, so every schema twin is included.

```hcl
module "replica_storage" {
  source = "../modules/dr-replica-storage"

  providers = {
    aws        = aws
    databricks = databricks.workspace_secondary
  }

  bucket_name = local.catalog_dr_bucket # "<catalog-bucket>-dr"
  extra_buckets = {
    appschema    = local.schema_dr_bucket             # Method A twin
    domainschema = module.domain_schema.dr_bucket_name # Method B twin
  }
  kms_key_arns = concat(
    [data.aws_kms_alias.s3_primary.target_key_arn, data.aws_kms_alias.s3_dr.target_key_arn],
    module.domain_schema.dr_replica_kms_arns,                   # Method B CMKs
  )
  force_destroy = true

  # name outputs alone do not order the twin bucket creation
  depends_on = [module.domain_schema]
}
```

Then the group's UC scope, updated IN-PLACE on the existing group:

```hcl
module "dr" {
  # ... unchanged from layer 2 ...

  catalogs = [{
    name          = module.workspace_primary.default_catalog_name
    primary_uri   = "s3://${module.workspace_primary.default_catalog_s3_bucket_name}/"
    secondary_uri = "s3://${local.catalog_dr_bucket}/"
  }]

  extra_location_mappings = [
    {
      name          = "${var.schema_name}-location"               # Method A
      primary_uri   = "s3://${local.schema_bucket}/"
      secondary_uri = "s3://${local.schema_dr_bucket}/"
    },
    module.domain_schema.dr_location_mapping,                     # Method B
  ]

  depends_on = [module.replica_storage]
}
```

## 5. Attaching EXISTING workspaces, catalogs and schemas (brownfield)

Verified: enabling DR on an already-running deployment arrives as PURE
ADDITIONS. Nothing existing is modified, destroyed or replaced; the failover
group only needs the workspace IDs, and the storage layer is built next to
what exists. A team that already runs the mirrored two-region pattern (a
workspace per region, catalogs, schemas) attaches like this:

```hcl
# The EXISTING workspaces are referenced, not managed, by this root.
variable "primary_workspace_id" {}   # e.g. from the team's workspace state/console
variable "secondary_workspace_id" {}
variable "catalog_name" {}           # existing catalog to replicate
variable "catalog_bucket" {}         # its existing bucket
variable "schema_buckets" {          # existing per-schema buckets
  type = list(string)
}

locals {
  catalog_dr_bucket = "${var.catalog_bucket}-dr"
  schema_dr_buckets = [for b in var.schema_buckets : "${b}-dr"]
}

# Twin bucket per existing storage root (catalog + each schema), secondary
# region. Same shape as layer 4; count over the list, per-resource region.

# Replica registration, one chain for the whole catalog family:
module "replica_storage" {
  source    = "../modules/dr-replica-storage"
  providers = { aws = aws, databricks = databricks.workspace_secondary }

  bucket_name        = local.catalog_dr_bucket
  extra_bucket_names = local.schema_dr_buckets
  kms_key_arns       = var.storage_kms_key_arns # keys of the existing buckets + twins
  force_destroy      = true
}

# The group: existing workspace IDs in, existing storage mapped.
module "dr" {
  source    = "../modules/dr"
  providers = { databricks = databricks.account }

  databricks_account_id = var.databricks_account_id
  name                  = "${var.prefix}-drg"

  primary_workspace_id   = var.primary_workspace_id
  secondary_workspace_id = var.secondary_workspace_id
  primary_region         = var.aws_region
  secondary_region       = var.dr_region

  replicate_workspace_assets = true # see the deletion caveat below
  create_stable_url          = false

  catalogs = [{
    name          = var.catalog_name
    primary_uri   = "s3://${var.catalog_bucket}/"
    secondary_uri = "s3://${local.catalog_dr_bucket}/"
  }]

  extra_location_mappings = [for i, b in var.schema_buckets : {
    name          = "${b}-location"
    primary_uri   = "s3://${b}/"
    secondary_uri = "s3://${local.schema_dr_buckets[i]}/"
  }]

  depends_on = [module.replica_storage]
}
```

What must be true before attaching (the brownfield checklist):

- **Mission Critical and serverless enabled on BOTH existing workspaces**,
  same Databricks account, same cloud, separate regions.
- **The secondary workspace loses its own workspace assets.** With
  `replicate_workspace_assets = true`, Managed DR DELETES existing assets of
  the replicated types (notebooks, jobs, warehouses, dashboards, files) in the
  secondary and holds it read-only with compute disabled. A team whose
  mirrored secondary carries real workspace content must either accept that
  deletion, migrate the content to the primary first, or attach with
  `replicate_workspace_assets = false` (catalog-only DR), which leaves the
  secondary workspace's own assets alone.
- **Secondary catalog names must not overlap the replicated catalogs.** The
  mirror convention (region-suffixed or workspace-ID-suffixed names) already
  guarantees this; the secondary's OWN catalogs are untouched and keep
  working, only overlapping names block enrollment.
- **Every replicated storage root needs its own mapping.** One per catalog
  bucket and one per schema bucket, exact path. A shared bucket with
  per-schema prefixes maps per prefix instead.
- **ALL PRIVILEGES** for the enrolling admin on every external location used
  by the catalogs being attached, and the secondary-side IAM (the replica
  chain above) on the twins.
- **Initial replication of an attached catalog copies everything it already
  contains.** Expect the group's replication point to be gated on that first
  full copy; existing schemas and tables appear read-only in the secondary as
  the copy completes.

## Operational notes (all observed on real applies)

- **Additions are in-place and non-breaking.** Adding a catalog or a mapping
  updates the failover group in place; existing mappings and running
  replication are untouched.
- **Removals are guarded.** The service validates the FULL mapping list
  against every source location it knows. A mapping cannot be removed while
  the source schema exists, and after the schema is deleted the removal stays
  blocked until replication observes the deletion. During INITIAL_REPLICATION
  the inventory does not refresh at all, so offboarding queues behind the
  initial copy. The orphaned mapping is harmless in the meantime.
- **Fresh IAM roles propagate slowly to Unity Catalog's S3 access.** The
  60-second waits cover the normal case, but a brand-new role has been
  observed to need a few HOURS before validation passes, with STS accepting
  the role the whole time. Diagnose with
  `POST /api/2.1/unity-catalog/validate-storage-credentials`
  (`{"storage_credential_name": "...", "url": "s3://..."}`): it separates
  ASSUME_ROLE / SELF_ASSUME_ROLE / EXTERNAL_ID_CONDITION from READ / LIST /
  WRITE / DELETE and pinpoints the failing layer. Retry, do not rebuild.
- **Updating an existing replica role's policy also races validation** (new
  KMS key added for a new schema twin): the module's wait only runs on role
  creation. One retry clears it; policy updates propagate in about a minute.
- **Mission Critical** is a one-time console step per workspace; the failover
  group errors name the exact workspace ID that is missing it.
- **Replication states:** the group reports INITIAL_REPLICATION until the
  first full copy completes, then ACTIVE. Replicated catalogs and schemas
  appear read-only in the secondary workspace only after the cycle that
  copies them.
