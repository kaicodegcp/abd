# CMK for catalog-creation when create_test_catalog is true.

data "aws_partition" "current" {}

data "aws_caller_identity" "current" {}

module "test_catalog_storage_kms" {
  count   = var.create_test_catalog ? 1 : 0
  source  = "terraform-aws-modules/kms/aws"
  version = "~> 3.0"

  description = "Integration test CMK for catalog-creation root storage"
  key_usage   = "ENCRYPT_DECRYPT"

  computed_aliases = {
    "catalog-storage" = {
      name = "${local.prefix}-catalog-storage-${var.workspace_id}-test"
    }
  }

  key_statements = [
    {
      sid    = "Enable IAM User Permissions"
      effect = "Allow"
      principals = [{
        type        = "AWS"
        identifiers = ["arn:${data.aws_partition.current.partition}:iam::${data.aws_caller_identity.current.account_id}:root"]
      }]
      actions   = ["kms:*"]
      resources = ["*"]
    },
    {
      sid    = "Allow IAM Role to use the key"
      effect = "Allow"
      principals = [{
        type        = "AWS"
        identifiers = ["arn:${data.aws_partition.current.partition}:iam::${data.aws_caller_identity.current.account_id}:role/${local.prefix}-catalog-${var.workspace_id}"]
      }]
      actions   = ["kms:Decrypt", "kms:Encrypt", "kms:GenerateDataKey*"]
      resources = ["*"]
    }
  ]

  tags = {
    Purpose     = "all-modules-test"
    environment = "integration-test"
  }
}
