# custom-udfs

Deploy a team's **own** SQL UDFs through Terraform, governed exactly like the
standard `security-udf-pack` — a schema, a Terraform-managed setup notebook, a
setup job, grants, and optional ownership transfer. Use it for the cases the
standard pack does not cover.

> Prefer the standard `security-udf-pack` wherever it fits: it is centrally
> governed, tested, and versioned. Reach for `custom-udfs` only when a team has a
> genuine requirement the standard functions can't meet.

## How it works

You supply a map of function definitions; you write **only the SQL body**. For
each entry the module assembles and deploys:

```sql
CREATE OR REPLACE FUNCTION <catalog>.<schema>.<name>(<parameters>)
RETURNS <returns>
LANGUAGE SQL
[DETERMINISTIC]
COMMENT '<comment>'
RETURN <definition>
```

The module owns the fully-qualified name, deployment, ownership, and grants, so a
custom function is governed the same way as a standard one.

`terraform apply` creates the schema, the setup notebook, and the setup job — it
does **not** run the job. Run the job (or wire it into CI) to actually create or
refresh the functions, exactly like `security-udf-pack`.

## Usage

```hcl
module "custom_udfs" {
  source       = "../../modules/custom-udfs"
  catalog_name = "cts_200100_catalog"
  schema_name  = "custom_functions"

  functions = {
    "mask_keep_first2_last2" = {
      parameters = "value STRING"
      returns    = "STRING"
      comment    = "Keep first 2 and last 2 chars."
      definition = <<-SQL
        CASE WHEN value IS NULL THEN NULL
             WHEN length(value) <= 4 THEN repeat('*', length(value))
             ELSE concat(left(value,2), repeat('*', length(value)-4), right(value,2)) END
      SQL
    }
  }

  grants = [
    { principal = "dbx-prod-olympus-200100-payments-analyst-role", privileges = ["USE_SCHEMA", "EXECUTE"] },
  ]
}
```

See `examples/basic/terraform.tfvars.example` for a mask, a scoped row-filter, and
a no-argument function.

## Function definition fields

| Field | Required | Notes |
|-------|----------|-------|
| `parameters` | yes | Parameter list as it appears in the DDL, e.g. `"value STRING, keep INT"`. Use `""` for a no-argument function. |
| `returns` | yes | Return type, e.g. `STRING`, `BOOLEAN`, `VARIANT`. |
| `definition` | yes | The `RETURN` expression / body. **No trailing semicolon.** |
| `comment` | no | Surfaced by `DESCRIBE FUNCTION`. Single quotes are escaped automatically. |
| `deterministic` | no (default `true`) | Set `false` if the body calls a non-deterministic builtin (e.g. `rand()`, `current_timestamp()`). |

## Safety / design notes

- **Arbitrary bodies are safe to pass.** Function specs reach the setup notebook as
  base64-encoded JSON and the `CREATE` statements are built by string
  concatenation, so a body containing quotes, `%`, `{`, or `}` cannot break the
  generated notebook.
- **Bind like any UDF.** Reference a deployed function by its FQN
  (`<catalog>.<schema>.<name>`) in `SET MASK` / `SET ROW FILTER` or in an
  `abac_policies` map (see the `catalog-abac` starter-policies example). Grant
  `USE_SCHEMA` + `EXECUTE` to the groups that need it.
- **Follow the group-naming contract** if your function resolves entitlement:
  `dbx-<sdlc>-<workspace>-<csi>-<value>-access`. Pass the scope constants as
  arguments (as the standard pack does) rather than hard-coding them.
- **One effective row filter per table (A-007)** and **one mask per column** apply
  to custom functions too.
- **Ownership / redeploy.** With `function_owner_principal` set, the run-as identity
  must remain owner or be a member of that group, or a redeploy fails — same
  contract as the standard pack.

## Inputs (summary)

`catalog_name` (req), `functions` (the map above), `schema_name`
(`custom_functions`), `version_label`, `comment`, `owner`, `force_destroy`,
`notebook_base_path`, `existing_cluster_id`,
`run_as_service_principal_application_id`, `function_owner_principal`, `grants`,
`tags`. See `variables.tf` for full descriptions and validations.

## Outputs

`schema_fqn`, `function_names` (FQNs), `setup_job_id`, `setup_notebook_path`,
`version_label`.
