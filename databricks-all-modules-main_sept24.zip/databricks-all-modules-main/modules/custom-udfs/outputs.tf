output "schema_fqn" {
  description = "Fully qualified name of the custom-functions schema."
  value       = local.schema_fqn
}

output "function_names" {
  description = "Fully qualified names of the custom UDFs this module deploys."
  value       = [for f in local.functions_list : "${local.schema_fqn}.${f.name}"]
}

output "setup_job_id" {
  description = "ID of the setup job. Run it (or trigger via CI) to create/refresh the functions; terraform apply creates the job but does not run it."
  value       = databricks_job.custom_udf_setup.id
}

output "setup_notebook_path" {
  description = "Workspace path of the Terraform-managed setup notebook."
  value       = databricks_notebook.custom_udf_setup.path
}

output "version_label" {
  description = "Version label applied to this set of custom functions."
  value       = var.version_label
}
