variable "catalog_name" {
  description = "Unity Catalog catalog where the custom-function schema will be created."
  type        = string

  validation {
    condition     = can(regex("^[A-Za-z][A-Za-z0-9_]*$", var.catalog_name))
    error_message = "catalog_name must start with a letter and contain only letters, numbers, and underscores."
  }
}

variable "schema_name" {
  description = "Schema for the team's custom UDFs. Defaults to 'custom_functions'. Keep it separate from the standard security_functions schema."
  type        = string
  default     = "custom_functions"

  validation {
    condition     = can(regex("^[A-Za-z0-9][A-Za-z0-9_]*$", var.schema_name))
    error_message = "schema_name must start with a letter or digit and contain only letters, numbers, and underscores."
  }
}

# -----------------------------------------------------------------------------
# The custom functions. Key = function name; value = a SQL UDF definition. The
# module assembles, per entry:
#
#   CREATE OR REPLACE FUNCTION <catalog>.<schema>.<name>(<parameters>)
#   RETURNS <returns>
#   LANGUAGE SQL
#   [DETERMINISTIC]
#   COMMENT '<comment>'
#   RETURN <definition>
#
# Only the SQL body is yours to write; the module owns the FQN, ownership, and
# deployment so custom functions are governed exactly like the standard pack.
# -----------------------------------------------------------------------------
variable "functions" {
  description = "Map of custom SQL UDFs to deploy. Key is the function name."
  type = map(object({
    parameters    = string               # e.g. "value STRING, keep INT"
    returns       = string               # e.g. "STRING" or "BOOLEAN"
    definition    = string               # the RETURN expression / body (no trailing semicolon)
    comment       = optional(string, "") # surfaced in DESCRIBE FUNCTION
    deterministic = optional(bool, true) # SQL UDFs are deterministic unless they call non-deterministic builtins
  }))
  default = {}

  validation {
    condition     = alltrue([for k in keys(var.functions) : can(regex("^[A-Za-z][A-Za-z0-9_]*$", k))])
    error_message = "Each function name (map key) must start with a letter and contain only letters, numbers, and underscores."
  }

  validation {
    condition     = alltrue([for f in values(var.functions) : length(trimspace(f.parameters == null ? "" : f.parameters)) >= 0])
    error_message = "parameters must be a string (use \"\" for a no-argument function)."
  }

  validation {
    condition     = alltrue([for f in values(var.functions) : length(trimspace(f.returns)) > 0])
    error_message = "Each function must specify a non-empty returns type, e.g. STRING or BOOLEAN."
  }

  validation {
    condition     = alltrue([for f in values(var.functions) : length(trimspace(f.definition)) > 0])
    error_message = "Each function must specify a non-empty definition (the RETURN expression / body)."
  }

  validation {
    condition     = alltrue([for f in values(var.functions) : !can(regex(";\\s*$", f.definition))])
    error_message = "definition must not end with a semicolon; provide only the RETURN expression / body."
  }
}

variable "comment" {
  description = "Free-text description for the custom-functions schema."
  type        = string
  default     = "Team-owned custom ABAC UDFs (supplement to the standard security-udf-pack)."
}

variable "version_label" {
  description = "Version label for this set of custom functions. Applied as a job tag and printed in the setup notebook output."
  type        = string
  default     = "0.1.0"

  validation {
    condition     = can(regex("^[0-9]+\\.[0-9]+\\.[0-9]+(?:[-+][A-Za-z0-9.-]+)?$", var.version_label))
    error_message = "version_label must use semantic version format, such as 0.1.0."
  }
}

variable "force_destroy" {
  description = "If true, allows Terraform to delete the schema even when it contains functions. Set true in dev/test; keep false in production."
  type        = bool
  default     = false
}

variable "owner" {
  description = "Schema owner. Defaults to the Terraform caller identity. Use function_owner_principal to own the functions themselves."
  type        = string
  default     = null
}

variable "notebook_base_path" {
  description = "Workspace folder for the setup notebook. Notebook path is '<base>/<catalog>-<schema>-custom-udf-setup'."
  type        = string
  default     = "/custom-udfs"
}

variable "existing_cluster_id" {
  description = "Cluster ID for the setup job. When null, the task runs on serverless compute (must be enabled). Any cluster supplied must support Unity Catalog."
  type        = string
  default     = null
}

variable "run_as_service_principal_application_id" {
  description = "Application (client) ID of the service principal that runs the setup job (GUID, not a display name). Recommended for production."
  type        = string
  default     = null

  validation {
    condition = var.run_as_service_principal_application_id == null || can(
      regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$",
      var.run_as_service_principal_application_id)
    )
    error_message = "run_as_service_principal_application_id must be a GUID, not a display name."
  }
}

variable "function_owner_principal" {
  description = "Principal to own every deployed custom UDF, applied via ALTER FUNCTION after creation. The run-as identity must remain owner or be a member, or redeployment fails. Null keeps ownership on the run-as identity."
  type        = string
  default     = null

  validation {
    condition     = var.function_owner_principal == null || length(trimspace(var.function_owner_principal != null ? var.function_owner_principal : "")) > 0
    error_message = "function_owner_principal must not be blank when set."
  }

  validation {
    condition     = var.function_owner_principal == null || !can(regex("`", var.function_owner_principal))
    error_message = "function_owner_principal must not contain backtick characters."
  }
}

variable "tags" {
  description = "Tags applied to the setup job."
  type        = map(string)
  default     = {}
}

variable "grants" {
  description = "Schema-level grants for the custom-functions schema. Principals must already hold USE_CATALOG on the parent catalog. This module is the sole Terraform owner of each listed principal's grants on this schema."
  type = list(object({
    principal  = string
    privileges = list(string)
  }))
  default = []

  validation {
    condition     = length(var.grants) == length(distinct([for g in var.grants : trimspace(g.principal)]))
    error_message = "Each principal must appear at most once in var.grants."
  }

  validation {
    condition     = alltrue([for g in var.grants : length(trimspace(g.principal)) > 0])
    error_message = "Each grant entry must have a non-empty principal."
  }

  validation {
    condition     = alltrue([for g in var.grants : length(g.privileges) > 0])
    error_message = "Each grant entry must specify at least one privilege."
  }

  validation {
    condition = alltrue([
      for g in var.grants : alltrue([
        for p in g.privileges : contains(["USE_SCHEMA", "EXECUTE", "CREATE_FUNCTION", "ALL_PRIVILEGES"], p)
      ])
    ])
    error_message = "Valid schema-level privileges are: USE_SCHEMA, EXECUTE, CREATE_FUNCTION, ALL_PRIVILEGES."
  }

  validation {
    condition = alltrue([
      for g in var.grants :
      contains(g.privileges, "ALL_PRIVILEGES") ? length(g.privileges) == 1 : true
    ])
    error_message = "ALL_PRIVILEGES cannot be combined with other privileges."
  }
}
