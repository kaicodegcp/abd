# =============================================================================
# Custom UDFs
# =============================================================================
# Lets a team deploy its OWN SQL UDFs through Terraform, governed exactly like
# the standard security-udf-pack (schema + Terraform-managed setup notebook +
# job + grants + optional ownership transfer), for cases the standard pack does
# not cover. Teams write only the SQL body; the module owns the FQN, deployment,
# and governance.
#
# The function specs are passed to the notebook as base64(json) and the CREATE
# statements are assembled by string concatenation (not f-strings), so arbitrary
# SQL bodies -- quotes, %, {, } and all -- cannot break the generated notebook.
# =============================================================================

locals {
  schema_fqn    = "${var.catalog_name}.${var.schema_name}"
  notebook_path = "${var.notebook_base_path}/${var.catalog_name}-${var.schema_name}-custom-udf-setup"

  grants_map = {
    for g in var.grants : trimspace(g.principal) => { privileges = g.privileges }
  }

  # Stable, ordered list of function specs (sorted by name for a deterministic notebook).
  functions_list = [
    for name in sort(keys(var.functions)) : {
      name          = name
      parameters    = var.functions[name].parameters
      returns       = var.functions[name].returns
      definition    = var.functions[name].definition
      comment       = var.functions[name].comment
      deterministic = var.functions[name].deterministic
    }
  ]

  # Function specs, base64(json)-encoded so the notebook can decode them safely
  # regardless of what characters the SQL bodies contain.
  functions_spec_b64 = base64encode(jsonencode(local.functions_list))

  function_owner = var.function_owner_principal != null ? var.function_owner_principal : ""

  notebook_content = <<-PYTHON
    # Managed by Terraform. Re-run after apply to refresh the custom functions.
    import base64
    import json

    catalog = "${var.catalog_name}"
    schema  = "${var.schema_name}"
    fqn     = catalog + "." + schema

    # Function specs arrive base64(json)-encoded; decode without any string interpolation.
    functions = json.loads(base64.b64decode("${local.functions_spec_b64}").decode("utf-8"))

    created = []
    for f in functions:
        name       = f["name"]
        parameters = f.get("parameters") or ""
        returns    = f["returns"]
        definition = f["definition"]
        comment    = (f.get("comment") or "").replace("'", "''")
        det        = "DETERMINISTIC" if f.get("deterministic", True) else ""

        # Build the DDL by concatenation so the arbitrary SQL body is never treated
        # as an f-string / format template.
        ddl = (
            "CREATE OR REPLACE FUNCTION " + fqn + "." + name + "(" + parameters + ")\n"
            + "RETURNS " + returns + "\n"
            + "LANGUAGE SQL\n"
            + (det + "\n" if det else "")
            + "COMMENT '" + comment + "'\n"
            + "RETURN " + definition
        )
        spark.sql(ddl)
        created.append(name)

    # Optional: transfer ownership of every created function to a group.
    function_owner = "${local.function_owner}"
    if function_owner:
        escaped_owner = function_owner.replace("`", "``")
        for name in created:
            try:
                spark.sql("ALTER FUNCTION " + fqn + "." + name + " OWNER TO `" + escaped_owner + "`")
            except Exception as e:
                raise RuntimeError("Failed to transfer ownership of " + fqn + "." + name + ": " + str(e)) from e
        print("Ownership of " + str(len(created)) + " custom UDFs transferred to: " + function_owner)

    print("Custom UDFs ${var.version_label}: " + str(len(created)) + " function(s) deployed to " + fqn + ".")
    if created:
        print("Functions: " + ", ".join(created))
  PYTHON
}

resource "databricks_schema" "this" {
  catalog_name  = var.catalog_name
  name          = var.schema_name
  comment       = var.comment
  owner         = var.owner
  force_destroy = var.force_destroy
}

resource "databricks_notebook" "custom_udf_setup" {
  path           = local.notebook_path
  language       = "PYTHON"
  content_base64 = base64encode(local.notebook_content)

  depends_on = [databricks_schema.this]
}

resource "databricks_job" "custom_udf_setup" {
  name                = "custom-udfs-${var.catalog_name}-${var.schema_name}"
  tags                = merge(var.tags, { custom_udfs_version = var.version_label })
  max_concurrent_runs = 1

  dynamic "run_as" {
    for_each = var.run_as_service_principal_application_id != null ? [1] : []
    content {
      service_principal_name = var.run_as_service_principal_application_id
    }
  }

  task {
    task_key            = "create-custom-udfs"
    existing_cluster_id = var.existing_cluster_id

    notebook_task {
      notebook_path = databricks_notebook.custom_udf_setup.path
    }
  }
}

resource "databricks_grant" "this" {
  for_each = local.grants_map

  schema     = local.schema_fqn
  principal  = each.key
  privileges = each.value.privileges

  depends_on = [databricks_schema.this]
}
