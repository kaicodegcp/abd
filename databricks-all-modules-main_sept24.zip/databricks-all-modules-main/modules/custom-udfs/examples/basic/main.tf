// Example: deploy a team's custom SQL UDFs via the custom-udfs module.
// Copy terraform.tfvars.example to terraform.tfvars and adapt. terraform apply
// creates the schema, notebook, and job; run the job to create the functions.

provider "databricks" {}

module "custom_udfs" {
  source = "../.."

  catalog_name                            = var.catalog_name
  schema_name                             = var.schema_name
  functions                               = var.functions
  comment                                 = var.comment
  version_label                           = var.version_label
  owner                                   = var.owner
  force_destroy                           = var.force_destroy
  notebook_base_path                      = var.notebook_base_path
  existing_cluster_id                     = var.existing_cluster_id
  run_as_service_principal_application_id = var.run_as_service_principal_application_id
  function_owner_principal                = var.function_owner_principal
  grants                                  = var.grants
  tags                                    = var.tags
}
