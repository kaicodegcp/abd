output "schema_fqn" { value = module.custom_udfs.schema_fqn }
output "function_names" { value = module.custom_udfs.function_names }
output "setup_job_id" { value = module.custom_udfs.setup_job_id }
output "setup_notebook_path" { value = module.custom_udfs.setup_notebook_path }
