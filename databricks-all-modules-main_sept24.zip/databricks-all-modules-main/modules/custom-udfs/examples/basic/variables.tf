variable "catalog_name" { type = string }
variable "schema_name" {
  type    = string
  default = "custom_functions"
}
variable "functions" {
  type = map(object({
    parameters    = string
    returns       = string
    definition    = string
    comment       = optional(string, "")
    deterministic = optional(bool, true)
  }))
  default = {}
}
variable "comment" {
  type    = string
  default = "Team-owned custom ABAC UDFs (supplement to the standard security-udf-pack)."
}
variable "version_label" {
  type    = string
  default = "0.1.0"
}
variable "owner" {
  type    = string
  default = null
}
variable "force_destroy" {
  type    = bool
  default = false
}
variable "notebook_base_path" {
  type    = string
  default = "/custom-udfs"
}
variable "existing_cluster_id" {
  type    = string
  default = null
}
variable "run_as_service_principal_application_id" {
  type    = string
  default = null
}
variable "function_owner_principal" {
  type    = string
  default = null
}
variable "grants" {
  type = list(object({
    principal  = string
    privileges = list(string)
  }))
  default = []
}
variable "tags" {
  type    = map(string)
  default = {}
}
