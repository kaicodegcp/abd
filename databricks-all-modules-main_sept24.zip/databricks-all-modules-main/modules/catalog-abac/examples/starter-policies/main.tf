// Starter ABAC policies — a curated catalog of common policy patterns that plugs
// straight into the catalog-abac module. Copy terraform.tfvars.example to
// terraform.tfvars, adjust the catalog, scope constants, group names, and UDF
// catalog to your deployment, then trim to the policies you actually need.
//
// The same abac_policies map works with the schema-abac and table-abac modules —
// only the module source and the securable it attaches to change. See INDEX.md.

provider "databricks" {}

module "catalog_abac" {
  source = "../.."

  catalog_name = var.catalog_name

  enable_abac              = var.enable_abac
  preserve_tags_on_disable = var.preserve_tags_on_disable
  column_tag_assignments   = var.column_tag_assignments
  table_tag_assignments    = var.table_tag_assignments
  abac_policies            = var.abac_policies
}
