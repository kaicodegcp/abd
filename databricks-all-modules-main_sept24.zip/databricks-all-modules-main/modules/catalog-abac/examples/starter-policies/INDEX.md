# Starter ABAC Policies

A curated, copy-and-adapt menu of the ABAC policy patterns most teams need on day
one, keyed to the Day-1 governed-tag vocabulary from the ABAC Terminology Glossary.
It plugs into the `catalog-abac` module (and, unchanged, into `schema-abac` /
`table-abac`). It is a **menu** — trim to what each object needs.

Each policy is a `databricks_policy_info` created by the module from the
`abac_policies` map; you never write the resource yourself.

## What's included

### Column masks (coexist safely — one mask per column)

| Policy | Tag it keys on | UDF | Effect |
|--------|----------------|-----|--------|
| `mask_ssn_format` | `pii_type=SSN` | `mask_ssn` | last 4 (`***-**-6789`) |
| `mask_email_format` | `pii_type=EMAIL` | `mask_email` | initial + domain |
| `mask_phone_format` | `pii_type=PHONE` | `mask_phone` | last 4 |
| `mask_dob_format` | `pii_type=DOB` | `mask_dob` | year only |
| `mask_name_format` | `pii_type=NAME` | `mask_name` | initials |
| `mask_account_last4` | `pii_type=ACCOUNT` | `mask_keep_last4` | last 4 (`********1234`) |
| `mask_restricted_any_type` | `sensitivity=RESTRICTED` | `mask_any_type` | type-preserving sentinel, for all |
| `reveal_internal_pii_unless_entitled` | `sensitivity=INTERNAL_PII` | `mask_unless_entitled` | shown only to `internal-pii` group |
| `reveal_confidential_pii_unless_entitled` | `sensitivity=CONFIDENTIAL_PII` | `mask_unless_entitled` | shown only to `confidential-pii` group |
| `reveal_sensitive_pii_unless_entitled` | `sensitivity=SENSITIVE_PII` | `mask_unless_entitled` | shown only to `sensitive-pii` group |
| `reveal_confidential_pii_to_us_uk_direct` | `sensitivity=CONFIDENTIAL_PII` | `mask_any_type` | direct members of `us-access`/`uk-access` see raw; all others masked |

### Tag introspection (pass a tag value as a function argument)

With provider ≥ ~1.13x, a `using` entry can be a `function_arg_expression`
`tag_introspection` instead of a `constant`/`alias`:

- `column_tag_value` (`{ column_alias, tag_key }`) — the matched column's own tag value.
- `tag_value` (`{ tag_key }`) — a governed tag on the securable (table/schema/catalog).

This collapses per-value fan-out: one `mask_by_classification` policy reads each
column's `sensitivity` tag and reveals/masks accordingly, and the `sdlc`/`workspace`/
`csi` scope constants can be sourced from the deployment-context tags so a policy is
portable DEV→PROD. See the commented `mask_by_sensitivity_tag` block and the
deployment-context note in `terraform.tfvars.example`. Live-verified end-to-end.

### Direct attribute-group membership (flat model)

The `reveal_*_unless_entitled` masks resolve entitlement *inside* the UDF, so they
work whether a caller arrives via a nested functional role **or** directly in the
atomic group. `reveal_confidential_pii_to_us_uk_direct` instead names the atomic
groups (`us-access`, `uk-access`) **directly** in `except_principals` — the flat
model, for when a policy should target specific groups rather than a dimension
generically.

> **Why this matters (verified):** `policy_info` targeting applies **only** to the
> principals you list. If a table's policies name only role ("upper") groups,
> someone placed directly in an atomic attribute group **bypasses** them. When you
> use direct membership, list the atomic groups explicitly. Row filters need no
> special handling — `rowfilter_attribute` calls `is_account_group_member`, which
> resolves direct and nested membership alike.

### Row filters (a table may have only ONE — these are alternatives)

| Policy | Pattern | UDF | Effect |
|--------|---------|-----|--------|
| `rowfilter_by_country` *(active)* | 1 / 10 | `rowfilter_attribute` | rows scoped to caller's `origin_country_code`; only on transactional tables |
| `rowfilter_by_domain` *(commented)* | 1 / 10 | `rowfilter_attribute` | rows scoped to caller's `domain` |
| `rowfilter_product_hierarchy` *(commented)* | 11 | `rowfilter_hierarchy` | rows scoped to caller's product within portfolio + scope |
| `default_deny_onboarding` *(commented)* | — | `rowfilter_deny_all` | break-glass deny-all while onboarding |

## Tag & group convention (from the glossary)

- **Governed tag keys** are `snake_case`: `sensitivity`, `pii_type`,
  `origin_country_code`, `origin_legal_vehicle`, `domain`, `team`, `cost_center`,
  `sub_category`, `portfolio`, `product`. (The `sensitivity` tag *is* the data
  classification — Day-1 uses one tag for both.)
- **Governed tag values** keep underscores: `CONFIDENTIAL_PII`, `SENSITIVE_PII`, `SSN`.
- **ABAC group value segments use dashes**, lower-cased. The group is
  `dbx-<sdlc>-<workspace>-<csi>-<value-with-dashes>-access`, so `CONFIDENTIAL_PII`
  → `dbx-prod-olympus-200100-confidential-pii-access`. That is why the
  `mask_unless_entitled` classification constant is passed **with dashes**
  (`confidential-pii`), while the tag it matches on carries the underscore value
  (`CONFIDENTIAL_PII`).

> **Country / legal-vehicle key discrepancy.** The Terminology Glossary uses
> `origin_country_code` / `origin_legal_vehicle`; the Appendix-D UDF doc uses
> `cbat_country_code` / `cbat_legal_vehicle`. This starter uses `origin_*` (the
> glossary is declared authoritative). Change it to match your governed-tag
> vocabulary if your platform uses the `cbat_*` spelling.

## Prerequisites (Platform team owns these)

- **UDFs**: `security-udf-pack` deployed to `<catalog>.security_functions`.
- **Governed tags**: the keys above exist at account scope (`governed-tags` module).
- **Groups + nesting**: atomic ABAC groups and functional-role nesting provisioned
  for the scope constants used. ABAC decides *what you see*; RBAC (workspace /
  catalog / schema / compute) is separate and unchanged.

## How to use

```bash
cp terraform.tfvars.example terraform.tfvars
# edit terraform.tfvars — the 5 adaptation points are listed at the top of the file
terraform init
terraform plan     # review the policies + tag assignments to be created
terraform apply
```

### Using these at schema or table scope

The `abac_policies` map is scope-agnostic. Point `source` at `schema-abac` /
`table-abac` and pass the same map. **Row filters are usually best at table scope**
(you control exactly one per table); column masks work well catalog-wide. Prefer the
narrowest scope that covers the requirement.

## Critical constraints & gotchas

- **One row filter per table (A-007).** Unity Catalog allows a single effective row
  filter per table; two matching row-filter policies are a platform error at apply.
  The row-filter entries here are **alternatives** — keep one per table shape, or
  apply row filters at table scope. `rowfilter_by_country` is scoped to
  `sub_category=TRANSACTION` tables so reference tables stay broadly visible
  (Pattern 12).
- **One mask per column.** A column matched by two column-mask policies is a
  conflict. Keep tag assignments non-overlapping — don't tag one column both
  `sensitivity=RESTRICTED` and `pii_type=SSN`, or the blanket and format masks will
  contend.
- **Wide AND filters (Pattern 10) don't fit `policy_info`.** Its `using` list caps at
  10 args and `match_columns` at ~3, so an AND over many dimensions
  (`country AND legal_vehicle AND domain AND team AND cost_center AND sensitivity AND
  pii_type`) must be composed into a **single native** `ALTER TABLE … SET ROW FILTER
  … ON (cols)` (verified to 12 columns), not a `policy_info` policy. PUMA composes
  this single expression in the target design.
- **`on_column` vs `using`.** For a column mask, `on_column` is the masked column
  (the UDF's first arg); `using` supplies the rest. Row filters have no `on_column`.
- **Tag propagation lag.** A newly assigned governed tag can take a few minutes to
  become visible to policy evaluation; until then a tag-gated policy fails **open**.
  Verify with a test-persona query, not by assuming the first apply is live.
- **Column vs table tags.** `match_columns` reads column tags (no inheritance);
  `when_condition` reads table tags (which inherit from schema/catalog).
- **Verify, don't assume.** Certify a policy by querying as an entitled *and* an
  unentitled test user and confirming the rows/masks — not by a green apply.

## Staged rollout / rollback

`enable_abac = false` disables all policies at once (`preserve_tags_on_disable = true`
keeps the tag assignments), then `true` re-enables. Useful for phased onboarding or
an emergency stop.

## Pattern coverage

| Appendix D pattern | Covered by |
|--------------------|-----------|
| 1 — single attribute row filter | `rowfilter_by_country` / `_by_domain` |
| 9 — column mask | the `mask_*` family |
| 10 — full enterprise (wide AND) | documented above — native `SET ROW FILTER` (not `policy_info`) |
| 11 — product hierarchy | `rowfilter_product_hierarchy` |
| 12 — reference vs transactional | `sub_category` gating: transactional tables get the row filter, reference tables stay broad |
