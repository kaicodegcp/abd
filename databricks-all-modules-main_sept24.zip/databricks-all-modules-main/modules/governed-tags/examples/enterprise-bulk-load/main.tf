# =============================================================================
# governed-tags — enterprise bulk load
# =============================================================================
# Loads the FULL enterprise governed-tag vocabulary at account scope via the
# governed-tags module. Governed tags are account-level, so this single apply
# makes every dimension available to all workspaces bound to the metastore
# ("bulk load all governed tags to all workspaces at the account level").
#
# The vocabulary is assembled in dimensions.tf from:
#   - static business + deployment-context dimensions (from code)
#   - origin_country_code (ISO list)
#   - origin_legal_vehicle (parsed from the CLEMS CSV extract; re-apply to refresh)
#
# Deploy against a workspace bound to the target metastore. It manages the tag
# VOCABULARY only (no per-tag permissions here) — layer tag_policy_permissions on
# top when you decide the manager/assigner groups.
# =============================================================================

# WORKSPACE-scoped provider: serves the tag-policies API (account-global effect).
provider "databricks" {
  # host = "https://<workspace>.cloud.databricks.com", plus your auth.
}

# ACCOUNT-scoped provider: required by the module's configuration_aliases even
# when no tag_policy_permissions are set (it is otherwise unused here).
provider "databricks" {
  alias      = "account"
  account_id = var.account_id
  # host = "https://accounts.cloud.databricks.com" (or azure/gcp accounts host), plus auth.
}

# Enforce platform ownership of the auto-derived context tags (sdlc/workspace/csi):
# grant ONLY platform ops the manager + assigner roles. The rule set is
# authoritative, so application teams cannot create or assign these tags — the Ops
# standard's "Prohibited Tags" rule. Empty platform_ops_principals => no lockdown.
locals {
  tag_policy_permissions = length(var.platform_ops_principals) == 0 ? {} : {
    for tag_key in local.platform_owned_tags : tag_key => [
      { principals = var.platform_ops_principals, role = "roles/tagPolicy.manager" },
      { principals = var.platform_ops_principals, role = "roles/tagPolicy.assigner" },
    ]
  }
}

module "governed_tags" {
  source = "../../"
  providers = {
    databricks         = databricks
    databricks.account = databricks.account
  }

  account_id             = var.account_id
  tag_policies           = local.tag_policies
  tag_policy_permissions = local.tag_policy_permissions
}
