output "tag_keys_loaded" {
  description = "All governed tag keys created/updated by this bulk load."
  value       = sort(keys(local.tag_policies))
}

output "tag_value_counts" {
  description = "Number of allowed values loaded per governed tag."
  value       = { for k, v in local.all_dimensions : k => length(v) }
}

output "origin_legal_vehicle_values" {
  description = "Legal-vehicle values resolved from the CLEMS CSV extract."
  value       = local.legal_vehicle_values
}
