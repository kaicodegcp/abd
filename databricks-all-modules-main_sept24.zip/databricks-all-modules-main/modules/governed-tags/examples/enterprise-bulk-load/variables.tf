variable "account_id" {
  description = "Databricks account ID. Passed to the module for the (aliased) account provider; only strictly required if you later add tag_policy_permissions."
  type        = string
  default     = null
}

variable "legal_vehicle_csv" {
  description = <<-EOT
    Path to the CLEMS legal-vehicle master extract. Columns:
    LEGAL_VEHICLE_ID,LEGAL_VEHICLE_NAME,ACTIVE_IND. Only ACTIVE_IND=Y rows are
    loaded; LEGAL_VEHICLE_ID is left-zero-padded to 5 chars, de-duplicated, sorted.
    Refresh origin_legal_vehicle by dropping a new CSV here and re-applying
    (Terraform-only bulk load — no separate sync job).
  EOT
  type        = string
  default     = "reference/legal_vehicle_master.csv"
}

variable "csi_values" {
  description = <<-EOT
    Allowed values for the platform-owned `csi` deployment-context tag. CSI is an
    open, enterprise-maintained set (valid 5/6-digit Client System Identifiers), so
    it is a variable rather than a hard-coded list: extend it as CSIs are onboarded.
  EOT
  type        = list(string)
  default     = ["23456", "56789", "200100", "200200"]
}

variable "workspace_values" {
  description = "Allowed values for the platform-owned `workspace` deployment-context tag (logical workspace identifiers)."
  type        = list(string)
  default     = ["OLYMPUS", "PAYMENTS", "TREASURY", "DRIFT"]
}

variable "platform_ops_principals" {
  description = <<-EOT
    Principals that own the auto-derived deployment-context tags (sdlc, workspace,
    csi). They receive BOTH the manager (edit the tag + its permissions) and
    assigner (apply the tag) roles; because each tag's rule set is authoritative,
    everyone else is locked out — enforcing the Ops standard's rule that
    application teams MUST NOT create or manually assign these tags.

    Set to your real platform-operations group(s), e.g.
    ["groups/dbx-platform-operations"]. Format: "groups/<name>", "users/<email>",
    or "servicePrincipals/<app_id>". Requires var.account_id.
    Set to [] to skip the lockdown (vocabulary only).
  EOT
  type        = list(string)
  default     = ["groups/dbx-platform-operations"]
}
