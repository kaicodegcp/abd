# Enterprise governed-tag bulk load

Loads the **full enterprise governed-tag vocabulary** at **account scope** in one
`terraform apply`, via the [`governed-tags`](../../) module. Governed tags are
account-level objects, so this single config makes every dimension available to
**all workspaces** bound to the metastore — "bulk load all governed tags to all
workspaces at the account level."

Source of truth: *DBX ABAC Initial Bulk Load* and *DBX Operations Guide:
Deployment Context Tagging Standard*.

## What it loads

### Prohibited / platform-owned tags (auto-derived context)

`sdlc`, `workspace`, and `csi` are **auto-derived deployment context** — resolved by
the platform from the deployment pipeline and the `<CSI>-bronze/silver/gold` schema
naming convention. Per the Ops standard, **application teams MUST NOT create or
manually tag these**. This example enforces that: `var.platform_ops_principals`
receives the manager + assigner roles on those three tags, and because each tag's
rule set is authoritative, everyone else is locked out. Point it at your real
platform-ops group and set `var.account_id`. (Set `platform_ops_principals = []` to
load the vocabulary without the lockdown.)

**Deployment-context tags (platform-owned — `sdlc` / `workspace` / `csi`)** drive
policy composition and entitlement-group construction
(`dbx-<sdlc>-<workspace>-<csi>-<attribute>-access`):

| Tag | Values |
|-----|--------|
| `sdlc` | DEV, INT, UAT, PROD |
| `workspace` | var `workspace_values` (default OLYMPUS, PAYMENTS, TREASURY, DRIFT) |
| `csi` | var `csi_values` (open, enterprise-maintained set) |

**Business-classification tags (data-owner-owned)** drive ABAC authorization:
`sensitivity`, `pii_type`, `masking_rule`, `field_visibility`, `domain`,
`sub_category`, `team`, `workload_type`, `cost_center`, `medallion_layer`,
`portfolio`, `product` (static value sets in `dimensions.tf`), plus two **dynamic**
dimensions:

- `origin_country_code` — ISO 3166-1 alpha-2 list.
- `origin_legal_vehicle` — parsed from the CLEMS CSV (`var.legal_vehicle_csv`):
  ACTIVE_IND=Y rows only, id zero-padded to 5, de-duped, sorted. **Terraform-only
  refresh:** drop a new CSV and re-apply (no separate sync job).

## Usage

```hcl
# provider auth via env: DATABRICKS_HOST + DATABRICKS_CONFIG_PROFILE (or host/token)
terraform init
terraform plan                    # review the vocabulary before applying
terraform apply -parallelism=2    # see note below
```

> **Apply with reduced parallelism.** The tag-policies API serializes writes and
> rejects a burst of concurrent creates with `Operation aborted due to concurrent
> modification`. Loading ~17 tags at Terraform's default parallelism (10) trips
> this. Use `-parallelism=2` (a re-apply is safe/idempotent and also clears it).
> Verified live: full apply of all 17 tags + the 3 platform-ownership rule sets,
> then destroy, all clean.

Adjust values in `dimensions.tf` (static dims) or via `terraform.tfvars`
(`csi_values`, `workspace_values`, `legal_vehicle_csv`) to match your enterprise
reference data.

## ⚠️ Governed tags are account-global — mind existing keys

A `databricks_tag_policy` for a given key is **one object per account**. If a key
here (`pii_type`, `sensitivity`, `domain`, `team`, …) already exists in the target
account owned by another team, applying this **overwrites their allowed values**.
Before applying to a shared account:

1. `terraform plan` and diff against `databricks tag-policies list-tag-policies`.
2. Reconcile any key another team owns (align on one value set, or namespace your
   keys, e.g. `abac_pii_type`) — do **not** silently clobber another team's tag.
3. This example manages the **vocabulary only**. Layer `tag_policy_permissions`
   (manager/assigner rule sets) on the module once the owning groups are decided —
   the Ops standard mandates platform-only write access to `sdlc`/`workspace`/`csi`.
