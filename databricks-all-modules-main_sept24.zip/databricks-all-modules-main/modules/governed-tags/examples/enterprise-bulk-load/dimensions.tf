# =============================================================================
# The enterprise governed-tag vocabulary (bulk load).
# Source of truth: "DBX ABAC Initial Bulk Load" + "DBX Operations Guide:
# Deployment Context Tagging Standard". All values here are governed at the
# ACCOUNT level, so this one config makes the vocabulary available to every
# workspace bound to the metastore.
# =============================================================================

locals {
  # ---------------------------------------------------------------------------
  # Deployment-context tags (PLATFORM-OWNED: sdlc / workspace / csi).
  # Used for policy composition + entitlement group construction, e.g.
  #   dbx-<sdlc>-<workspace>-<csi>-<attribute>-access
  # ---------------------------------------------------------------------------
  deployment_context = {
    sdlc      = ["DEV", "INT", "UAT", "PROD"]
    workspace = var.workspace_values
    csi       = var.csi_values
  }

  # ---------------------------------------------------------------------------
  # Business-classification tags (DATA-OWNER-OWNED), static value sets.
  # ---------------------------------------------------------------------------
  static_dimensions = {
    sensitivity = ["PUBLIC", "INTERNAL", "INTERNAL_PII", "CONFIDENTIAL", "CONFIDENTIAL_PII", "SENSITIVE_PII", "RESTRICTED"]
    pii_type    = ["none", "basic", "sensitive", "financial", "health"]

    masking_rule     = ["none", "partial_mask", "full_mask", "redact", "tokenize"]
    field_visibility = ["full", "restricted", "hidden"]

    domain = [
      "CUSTOMER_PLATFORMS_INTERACTIONS", "INSTITUTIONAL_DEPOSITS_CORE_ACCOUNTS",
      "INVESTOR_SERVICES", "ISSUER_SERVICES", "OPERATIONS", "PARTNERSHIPS_INNOVATION",
      "PAYMENTS", "PRODUCT_SALES_CLIENT_EXPERIENCE", "SERVICES_REFERENCE_DATA",
      "TRADE_WORKING_CAPITAL_SOLUTIONS", "APPLICATION_DEVELOPMENT", "DATA_EXECUTION",
      "ENTERPRISE_RESILIENCY", "FOUNDATIONAL_SERVICES",
    ]
    sub_category    = ["GENERAL", "REFERENCE", "TRANSACTION", "MASTER", "EVENT"]
    team            = ["CPI", "AML", "RISK", "TREASURY", "PAYMENTS"]
    workload_type   = ["INGESTION_BATCH", "INGESTION_REAL_TIME", "SELF_SERVICE", "ANALYTICS", "TRANSFORM", "ML_ANALYTICS"]
    cost_center     = ["FINANCE", "TECHNOLOGY", "OPERATIONS", "UNKNOWN"]
    medallion_layer = ["RAW", "STAGING", "CANONICAL", "PRESENTATION"]

    # Enterprise-maintained example sets (adapt to your reference data). The Ops
    # doc lists portfolio/product as business tags without enumerating values.
    portfolio = ["OLYMPUS", "TREASURY", "MARKETS"]
    product   = ["CARDS", "LOANS", "DEPOSITS", "WIRES"]
  }

  # ---------------------------------------------------------------------------
  # Dynamic dimension 1 — origin_country_code (ISO 3166-1 alpha-2).
  # ---------------------------------------------------------------------------
  iso_country_codes = [
    "AD", "AE", "AF", "AG", "AI", "AL", "AM", "AO", "AR", "AT",
    "AU", "AW", "AZ", "BA", "BB", "BD", "BE", "BF", "BG", "BH",
    "BI", "BJ", "BN", "BO", "BR", "BS", "BT", "BW", "BY", "BZ",
    "CA", "CD", "CF", "CG", "CH", "CI", "CL", "CM", "CN", "CO",
    "CR", "CU", "CY", "CZ", "DE", "DJ", "DK", "DM", "DO", "DZ",
    "EC", "EE", "EG", "ER", "ES", "ET", "FI", "FJ", "FK", "FM",
    "FR", "GA", "GB", "GD", "GE", "GH", "GI", "GL", "GM", "GN",
    "GQ", "GR", "GT", "GU", "GW", "GY", "HK", "HN", "HR", "HT",
    "HU", "ID", "IE", "IL", "IN", "IQ", "IR", "IS", "IT", "JM",
    "JO", "JP", "KE", "KG", "KH", "KI", "KM", "KR", "KW", "KZ",
    "LA", "LB", "LC", "LI", "LK", "LR", "LS", "LT", "LU", "LV",
    "LY", "MA", "MC", "MD", "ME", "MG", "MH", "MK", "ML", "MM",
    "MN", "MO", "MR", "MT", "MU", "MV", "MW", "MX", "MY", "MZ",
    "NA", "NE", "NG", "NI", "NL", "NO", "NP", "NR", "NZ", "OM",
    "PA", "PE", "PG", "PH", "PK", "PL", "PT", "PW", "PY", "QA",
    "RO", "RS", "RU", "RW", "SA", "SB", "SC", "SD", "SE", "SG",
    "SI", "SK", "SL", "SM", "SN", "SO", "SR", "ST", "SV", "SY",
    "SZ", "TD", "TG", "TH", "TJ", "TL", "TM", "TN", "TO", "TR",
    "TT", "TV", "TW", "TZ", "UA", "UG", "US", "UY", "UZ", "VA",
    "VC", "VE", "VN", "VU", "WS", "YE", "ZA", "ZM", "ZW",
  ]

  # ---------------------------------------------------------------------------
  # Dynamic dimension 2 — origin_legal_vehicle (from the CLEMS CSV extract).
  # Filter ACTIVE_IND=Y, zero-pad the id to 5 chars, de-dupe, sort.
  # ---------------------------------------------------------------------------
  legal_vehicle_rows = csvdecode(file("${path.module}/${var.legal_vehicle_csv}"))
  legal_vehicle_values = sort(distinct([
    for r in local.legal_vehicle_rows :
    try(format("%05d", tonumber(trimspace(r.LEGAL_VEHICLE_ID))), trimspace(r.LEGAL_VEHICLE_ID))
    if upper(trimspace(try(r.ACTIVE_IND, "Y"))) == "Y"
  ]))

  # ---------------------------------------------------------------------------
  # Merge everything into the module's tag_policies shape.
  # ---------------------------------------------------------------------------
  all_dimensions = merge(
    local.deployment_context,
    local.static_dimensions,
    {
      origin_country_code  = local.iso_country_codes
      origin_legal_vehicle = local.legal_vehicle_values
    },
  )

  # PLATFORM-OWNED (auto-derived) deployment-context tags. Per the Ops standard's
  # "Prohibited Tags & Columns", application teams MUST NOT create or manually
  # assign these — they are resolved by the platform deployment context and the
  # <CSI>-bronze/silver/gold schema naming convention. The prohibition is ENFORCED
  # by tag_policy_permissions in main.tf (only platform ops get manager/assigner).
  platform_owned_tags = ["sdlc", "workspace", "csi"]

  tag_descriptions = {
    sdlc      = "PLATFORM-OWNED, auto-derived deployment-context tag (environment stage). Application teams MUST NOT create or manually assign it."
    workspace = "PLATFORM-OWNED, auto-derived deployment-context tag (logical workspace identifier). Application teams MUST NOT create or manually assign it."
    csi       = "PLATFORM-OWNED, auto-derived deployment-context tag (Client System Identifier, from the <CSI>-bronze/silver/gold schema naming convention). Application teams MUST NOT create or manually assign it."
  }

  tag_policies = {
    for tag_key, values in local.all_dimensions :
    tag_key => {
      description    = lookup(local.tag_descriptions, tag_key, "${tag_key} governed tag (enterprise bulk load).")
      allowed_values = values
    }
  }
}
