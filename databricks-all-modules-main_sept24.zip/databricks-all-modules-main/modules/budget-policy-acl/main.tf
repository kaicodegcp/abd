# Serverless usage policy ACL (Terraform: databricks_access_control_rule_set).
#
# modules/budget-policy calls this module to create a new policy and its ACL in one
# deployment.
# Use it directly (attach-only) for policies that already exist.
#
# Authoritative permissions on accounts/{account_id}/budgetPolicies/{policy_id}/ruleSets/default.
# Does not create the policy or identities. Pass policy_id from modules/budget-policy and
# acl_principal_id from existing users, groups, and service principals.
#
# Account-level API. The root module must configure the Databricks provider with
# the account console host and account_id (not a workspace URL).
# OAuth still comes from DATABRICKS_CLIENT_ID / DATABRICKS_CLIENT_SECRET.
# https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/access_control_rule_set

locals {
  user_acl_principal_ids    = distinct(var.user_acl_principal_ids)
  manager_acl_principal_ids = distinct(var.manager_acl_principal_ids)
}

resource "databricks_access_control_rule_set" "this" {
  name = "accounts/${trimspace(var.account_id)}/budgetPolicies/${trimspace(var.policy_id)}/ruleSets/default"

  dynamic "grant_rules" {
    for_each = length(local.user_acl_principal_ids) > 0 ? [local.user_acl_principal_ids] : []
    content {
      role       = "roles/budgetPolicy.user"
      principals = grant_rules.value
    }
  }

  dynamic "grant_rules" {
    for_each = length(local.manager_acl_principal_ids) > 0 ? [local.manager_acl_principal_ids] : []
    content {
      role       = "roles/budgetPolicy.manager"
      principals = grant_rules.value
    }
  }

  lifecycle {
    precondition {
      condition     = length(local.user_acl_principal_ids) + length(local.manager_acl_principal_ids) > 0
      error_message = "At least one of user_acl_principal_ids or manager_acl_principal_ids must be non-empty."
    }

    precondition {
      condition     = length(setintersection(toset(local.user_acl_principal_ids), toset(local.manager_acl_principal_ids))) == 0
      error_message = "A principal cannot be both roles/budgetPolicy.user and roles/budgetPolicy.manager. Grant manager only."
    }
  }
}
