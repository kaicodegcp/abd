package test

import (
	"fmt"
	"path/filepath"
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	common "github.com/sandbox45/databricks-all-modules/common"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

const planPlaceholderPolicyID = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"

// flattenErr collapses Terraform's 80-column line wrapping so substring
// assertions on error messages are not split across a line break.
func flattenErr(err error) string {
	return strings.Join(strings.Fields(err.Error()), " ")
}

func planModule(t *testing.T, vars map[string]interface{}) string {
	t.Helper()
	opts := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: filepath.Join(".."),
		Vars:         vars,
		NoColor:      true,
	})
	terraform.Init(t, opts)
	return terraform.Plan(t, opts)
}

func planModuleExpectError(t *testing.T, vars map[string]interface{}) error {
	t.Helper()
	opts := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: filepath.Join(".."),
		Vars:         vars,
		NoColor:      true,
	})
	terraform.Init(t, opts)
	_, err := terraform.PlanE(t, opts)
	return err
}

func accountID() string {
	return common.GetTestDefaults().AccountID
}

func baseVars() map[string]interface{} {
	return map[string]interface{}{
		"account_id": accountID(),
		"policy_id":  planPlaceholderPolicyID,
		"user_acl_principal_ids": []string{
			"groups/payments-dev",
			"servicePrincipals/11111111-2222-3333-4444-555555555555",
		},
		"manager_acl_principal_ids": []string{
			"users/platform-admin@example.com",
		},
	}
}

func expectedRuleSetName() string {
	return fmt.Sprintf("accounts/%s/budgetPolicies/%s/ruleSets/default", accountID(), planPlaceholderPolicyID)
}

func TestBudgetPolicyAclUsersAndManagers(t *testing.T) {
	common.SkipIfShortMode(t, "budget-policy-acl users and managers (plan)")
	common.RequireDatabricksEnv(t)

	plan := planModule(t, baseVars())
	require.NotEmpty(t, plan, "terraform plan should produce output")

	assert.Contains(t, plan, "databricks_access_control_rule_set.this", "rule set resource must be planned")
	assert.Contains(t, plan, expectedRuleSetName(), "rule set name must use accounts/{account_id}/budgetPolicies/{policy_id}/ruleSets/default")
	assert.Contains(t, plan, "roles/budgetPolicy.user", "user role must appear in plan")
	assert.Contains(t, plan, "roles/budgetPolicy.manager", "manager role must appear in plan")
	assert.Contains(t, plan, "groups/payments-dev", "group acl_principal_id must appear in plan")
	assert.Contains(t, plan, "servicePrincipals/11111111-2222-3333-4444-555555555555", "service principal acl_principal_id must appear in plan")
	assert.Contains(t, plan, "users/platform-admin@example.com", "user acl_principal_id must appear in plan")
}

func TestBudgetPolicyAclUsersOnly(t *testing.T) {
	common.SkipIfShortMode(t, "budget-policy-acl users only (plan)")
	common.RequireDatabricksEnv(t)

	vars := map[string]interface{}{
		"account_id": accountID(),
		"policy_id":  planPlaceholderPolicyID,
		"user_acl_principal_ids": []string{
			"groups/payments-dev",
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, "databricks_access_control_rule_set.this")
	assert.Contains(t, plan, "roles/budgetPolicy.user")
	assert.NotContains(t, plan, "roles/budgetPolicy.manager")
}

func TestBudgetPolicyAclManagersOnly(t *testing.T) {
	common.SkipIfShortMode(t, "budget-policy-acl managers only (plan)")
	common.RequireDatabricksEnv(t)

	vars := map[string]interface{}{
		"account_id": accountID(),
		"policy_id":  planPlaceholderPolicyID,
		"manager_acl_principal_ids": []string{
			"users/platform-admin@example.com",
		},
	}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, "databricks_access_control_rule_set.this")
	assert.Contains(t, plan, "roles/budgetPolicy.manager")
	assert.NotContains(t, plan, "roles/budgetPolicy.user")
}

func TestBudgetPolicyAclEmptyPrincipalsRejected(t *testing.T) {
	common.SkipIfShortMode(t, "budget-policy-acl empty principals (plan)")
	common.RequireDatabricksEnv(t)

	vars := map[string]interface{}{
		"account_id": accountID(),
		"policy_id":  planPlaceholderPolicyID,
	}

	err := planModuleExpectError(t, vars)
	require.Error(t, err, "empty principal lists must fail validation")
	assert.Contains(t, flattenErr(err), "must be non-empty")
}

func TestBudgetPolicyAclOverlapRejected(t *testing.T) {
	common.SkipIfShortMode(t, "budget-policy-acl overlapping principals (plan)")
	common.RequireDatabricksEnv(t)

	vars := map[string]interface{}{
		"account_id":                accountID(),
		"policy_id":                 planPlaceholderPolicyID,
		"user_acl_principal_ids":    []string{"groups/payments-dev"},
		"manager_acl_principal_ids": []string{"groups/payments-dev"},
	}

	err := planModuleExpectError(t, vars)
	require.Error(t, err, "overlapping user and manager principals must fail validation")
	assert.Contains(t, err.Error(), "manager")
}

func TestBudgetPolicyAclInvalidPrincipalRejected(t *testing.T) {
	common.SkipIfShortMode(t, "budget-policy-acl invalid principal (plan)")
	common.RequireDatabricksEnv(t)

	vars := map[string]interface{}{
		"account_id":             accountID(),
		"policy_id":              planPlaceholderPolicyID,
		"user_acl_principal_ids": []string{"payments-dev"},
	}

	err := planModuleExpectError(t, vars)
	require.Error(t, err, "principals without users/groups/servicePrincipals prefix must fail validation")
	assert.Contains(t, err.Error(), "users/")
}

func TestBudgetPolicyAclEmptyPolicyIDRejected(t *testing.T) {
	common.SkipIfShortMode(t, "budget-policy-acl empty policy_id (plan)")
	common.RequireDatabricksEnv(t)

	vars := map[string]interface{}{
		"account_id":             accountID(),
		"policy_id":              "   ",
		"user_acl_principal_ids": []string{"groups/payments-dev"},
	}

	err := planModuleExpectError(t, vars)
	require.Error(t, err, "empty policy_id must fail validation")
}

func TestBudgetPolicyAclInvalidAccountIDRejected(t *testing.T) {
	common.SkipIfShortMode(t, "budget-policy-acl invalid account_id (plan)")
	common.RequireDatabricksEnv(t)

	vars := map[string]interface{}{
		"account_id":             "not-a-uuid",
		"policy_id":              planPlaceholderPolicyID,
		"user_acl_principal_ids": []string{"groups/payments-dev"},
	}

	err := planModuleExpectError(t, vars)
	require.Error(t, err, "non-UUID account_id must fail validation")
}

func TestBudgetPolicyAclModuleInputs(t *testing.T) {
	config := common.ModuleTestConfig{
		ModuleName:      "budget-policy-acl",
		TestDescription: "Tests Databricks usage policy ACL module inputs (plan)",
		RequiredVars: map[string]interface{}{
			"account_id": accountID(),
			"policy_id":  planPlaceholderPolicyID,
			"user_acl_principal_ids": []string{
				"groups/payments-dev",
			},
		},
		ExpectedOutputs: []string{
			"id",
			"name",
			"account_id",
			"policy_id",
			"user_acl_principal_ids",
			"manager_acl_principal_ids",
		},
	}

	common.TestModuleWithConfig(t, config)
}
