# Example: attach-only usage-policy ACL on an existing budget policy.
# For a new policy and ACL in one deployment, use modules/budget-policy.
# Copy terraform.tfvars.example to terraform.tfvars. Set databricks_account_id
# and policy_id (terraform output -raw policy_id from the budget-policy example).
# Pass acl_principal_id from existing users, groups, and service principals —
# this module does not create identities.
#
# This resource is an account API. A workspace URL in DATABRICKS_HOST produces
# HTTP 404 ("Not Found") on apply. The provider host is set explicitly so a leftover
# workspace DATABRICKS_HOST does not override it.
#
# OAuth (account-level service principal with the account admin role):
#   export DATABRICKS_CLIENT_ID="<application-id: UUID, not the secret>"
#   export DATABRICKS_CLIENT_SECRET="<oauth-secret>"
# https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/access_control_rule_set

provider "databricks" {
  host       = var.databricks_account_host
  account_id = var.databricks_account_id
}

module "budget_policy_acl" {
  source = "../.."

  account_id                = var.databricks_account_id
  policy_id                 = var.policy_id
  user_acl_principal_ids    = var.user_acl_principal_ids
  manager_acl_principal_ids = var.manager_acl_principal_ids
}
