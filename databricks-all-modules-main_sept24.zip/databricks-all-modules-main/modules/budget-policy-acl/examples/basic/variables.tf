variable "databricks_account_id" {
  description = "Databricks account UUID. Required by the budget-policy rule set name."
  type        = string
}

variable "databricks_account_host" {
  description = "Databricks account console URL, e.g. https://accounts.cloud.databricks.com (AWS) or https://accounts.azuredatabricks.net (Azure)."
  type        = string
}

variable "policy_id" {
  description = "Usage policy ID from modules/budget-policy (policy_id output)."
  type        = string
}

variable "user_acl_principal_ids" {
  description = "acl_principal_id values granted roles/budgetPolicy.user."
  type        = list(string)
  default     = []
}

variable "manager_acl_principal_ids" {
  description = "acl_principal_id values granted roles/budgetPolicy.manager."
  type        = list(string)
  default     = []
}
