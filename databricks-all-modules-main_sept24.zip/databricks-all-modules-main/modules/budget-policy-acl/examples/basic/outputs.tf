output "id" {
  description = "Rule set ID (same as name)."
  value       = module.budget_policy_acl.id
}

output "name" {
  description = "Rule set name."
  value       = module.budget_policy_acl.name
}

output "policy_id" {
  description = "Usage policy ID this rule set is bound to."
  value       = module.budget_policy_acl.policy_id
}

output "user_acl_principal_ids" {
  description = "Principals granted roles/budgetPolicy.user."
  value       = module.budget_policy_acl.user_acl_principal_ids
}

output "manager_acl_principal_ids" {
  description = "Principals granted roles/budgetPolicy.manager."
  value       = module.budget_policy_acl.manager_acl_principal_ids
}
