variable "account_id" {
  description = "Databricks account UUID. Used in the rule set name accounts/{account_id}/budgetPolicies/{policy_id}/ruleSets/default."
  type        = string

  validation {
    condition     = can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", trimspace(var.account_id)))
    error_message = "account_id must be a UUID."
  }
}

variable "policy_id" {
  description = "Server-generated usage (budget) policy ID from modules/budget-policy (databricks_budget_policy.policy_id)."
  type        = string

  validation {
    condition     = length(trimspace(var.policy_id)) > 0
    error_message = "policy_id must not be empty."
  }
}

variable "user_acl_principal_ids" {
  description = "Existing user, group, and service principal ACL IDs granted roles/budgetPolicy.user (can apply the usage policy). Pass acl_principal_id from databricks_user, databricks_group, or databricks_service_principal (users/{username}, groups/{groupname}, servicePrincipals/{applicationId})."
  type        = list(string)
  default     = []

  validation {
    condition     = length(var.user_acl_principal_ids) == length(distinct(var.user_acl_principal_ids))
    error_message = "user_acl_principal_ids must be unique."
  }

  validation {
    condition = alltrue([
      for p in var.user_acl_principal_ids :
      can(regex("^(users|groups|servicePrincipals)/.+$", p))
    ])
    error_message = "user_acl_principal_ids must use users/{username}, groups/{groupname}, or servicePrincipals/{applicationId}."
  }
}

variable "manager_acl_principal_ids" {
  description = "Existing user, group, and service principal ACL IDs granted roles/budgetPolicy.manager (can edit the policy and its permissions). Pass acl_principal_id from databricks_user, databricks_group, or databricks_service_principal."
  type        = list(string)
  default     = []

  validation {
    condition     = length(var.manager_acl_principal_ids) == length(distinct(var.manager_acl_principal_ids))
    error_message = "manager_acl_principal_ids must be unique."
  }

  validation {
    condition = alltrue([
      for p in var.manager_acl_principal_ids :
      can(regex("^(users|groups|servicePrincipals)/.+$", p))
    ])
    error_message = "manager_acl_principal_ids must use users/{username}, groups/{groupname}, or servicePrincipals/{applicationId}."
  }
}
