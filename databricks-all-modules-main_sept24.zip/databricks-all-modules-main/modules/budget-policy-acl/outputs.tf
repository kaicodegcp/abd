output "id" {
  description = "Rule set ID (same as name)."
  value       = databricks_access_control_rule_set.this.id
}

output "name" {
  description = "Rule set name: accounts/{account_id}/budgetPolicies/{policy_id}/ruleSets/default."
  value       = databricks_access_control_rule_set.this.name
}

output "account_id" {
  description = "Account UUID used in the rule set name."
  value       = trimspace(var.account_id)
}

output "policy_id" {
  description = "Usage policy ID this rule set is bound to."
  value       = trimspace(var.policy_id)
}

output "user_acl_principal_ids" {
  description = "Principals granted roles/budgetPolicy.user."
  value       = local.user_acl_principal_ids
}

output "manager_acl_principal_ids" {
  description = "Principals granted roles/budgetPolicy.manager."
  value       = local.manager_acl_principal_ids
}
