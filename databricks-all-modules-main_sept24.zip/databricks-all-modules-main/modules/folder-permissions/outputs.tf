output "directory_acl" {
  description = "Summary of the managed Databricks workspace directory ACL."

  value = {
    directory_path = databricks_directory.application_root.path
    group_permissions = {
      for group_name, permission in var.group_permissions :
      group_name => upper(permission)
    }
  }
}

output "subdirectory_acls" {
  description = "Summary of the created child directories and their explicit ACLs. Parent permissions are inherited in Databricks and are not repeated here."

  value = {
    for directory_name, directory in databricks_directory.subdirectories :
    directory_name => {
      directory_path = directory.path
      group_permissions = {
        for group_name, permission in var.subdirectory_permissions[directory_name] :
        group_name => upper(permission)
      }
    }
  }
}
