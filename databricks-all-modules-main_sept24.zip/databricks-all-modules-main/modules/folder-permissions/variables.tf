variable "directory_path" {
  description = "Absolute application root path Terraform will create beneath /Applications using the /Applications/<CSI-ID>-<acronym> naming convention."
  type        = string

  validation {
    condition = (
      startswith(var.directory_path, "/") &&
      var.directory_path != "/" &&
      !endswith(var.directory_path, "/")
    )

    error_message = "directory_path must be an absolute, non-root path that begins with / and does not end with /."
  }

  validation {
    condition     = can(regex("^/Applications/[^/]+-[^/]+$", var.directory_path))
    error_message = "directory_path must match /Applications/<CSI-ID>-<acronym> and identify one direct child of /Applications."
  }
}

variable "group_permissions" {
  description = "Map of Databricks group names to permissions for the directory."
  type        = map(string)

  validation {
    condition     = length(var.group_permissions) == 5
    error_message = "group_permissions must contain five distinct groups: workspace admin, support, engineer, analyst, and deployer."
  }

  validation {
    condition = alltrue([
      for group_name in keys(var.group_permissions) :
      length(trimspace(group_name)) > 0
    ])

    error_message = "Every group_permissions key must be a non-empty group name."
  }

  validation {
    condition = alltrue([
      for permission in values(var.group_permissions) :
      contains(
        ["CAN_READ", "CAN_RUN", "CAN_EDIT", "CAN_MANAGE"],
        upper(permission)
      )
    ])

    error_message = "Every folder permission must be CAN_READ, CAN_RUN, CAN_EDIT, or CAN_MANAGE."
  }

}

variable "subdirectory_permissions" {
  description = "Map of child directory names to their explicit Databricks group permissions. The module creates these directories beneath directory_path."
  type        = map(map(string))
  default     = {}

  validation {
    condition = alltrue([
      for directory_name in keys(var.subdirectory_permissions) :
      length(trimspace(directory_name)) > 0 &&
      !contains([".", ".."], trimspace(directory_name)) &&
      !strcontains(directory_name, "/") &&
      !strcontains(directory_name, "\\")
    ])

    error_message = "Every subdirectory name must be a non-empty direct child name without path separators."
  }

  validation {
    condition = alltrue([
      for permissions in values(var.subdirectory_permissions) :
      length(permissions) > 0
    ])

    error_message = "Every configured subdirectory must contain at least one explicit group permission."
  }

  validation {
    condition = alltrue(flatten([
      for permissions in values(var.subdirectory_permissions) : [
        for group_name in keys(permissions) :
        length(trimspace(group_name)) > 0
      ]
    ]))

    error_message = "Every subdirectory permission key must be a non-empty group name."
  }

  validation {
    condition = alltrue(flatten([
      for permissions in values(var.subdirectory_permissions) : [
        for permission in values(permissions) :
        contains(
          ["CAN_READ", "CAN_RUN", "CAN_EDIT", "CAN_MANAGE"],
          upper(permission)
        )
      ]
    ]))

    error_message = "Every subdirectory permission must be CAN_READ, CAN_RUN, CAN_EDIT, or CAN_MANAGE."
  }
}
