resource "databricks_directory" "application_root" {
  provider = databricks.workspace

  path             = var.directory_path
  delete_recursive = false
}

resource "databricks_permissions" "this" {
  provider = databricks.workspace

  directory_path = databricks_directory.application_root.path

  dynamic "access_control" {
    for_each = var.group_permissions

    content {
      group_name       = access_control.key
      permission_level = upper(access_control.value)
    }
  }
}

resource "databricks_directory" "subdirectories" {
  provider = databricks.workspace

  for_each = var.subdirectory_permissions

  path             = "${databricks_directory.application_root.path}/${each.key}"
  delete_recursive = false
}

resource "databricks_permissions" "subdirectories" {
  provider = databricks.workspace

  for_each = var.subdirectory_permissions

  directory_path = databricks_directory.subdirectories[each.key].path

  dynamic "access_control" {
    for_each = each.value

    content {
      group_name       = access_control.key
      permission_level = upper(access_control.value)
    }
  }
}
