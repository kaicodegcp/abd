terraform {
  required_version = ">= 1.5.0"

  required_providers {
    databricks = {
      source  = "databricks/databricks"
      version = ">= 1.57.0, < 2.0.0"

      configuration_aliases = [
        databricks.workspace
      ]
    }
  }
}
