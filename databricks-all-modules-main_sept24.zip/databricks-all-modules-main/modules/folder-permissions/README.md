# Databricks application folder permissions

This module creates one Databricks application root beneath `/Applications`,
manages its authoritative ACL, and creates direct child directories with their
own explicit ACLs.

Use one module instance for each application team. The supplied path must follow
`/Applications/<CSI-ID>-<acronym>`. Files placed inside the directory receive the
applicable inherited directory permissions.

The module manages workspace folders and folder ACLs only. The referenced groups
must already exist and be assigned to the target workspace by the separate
workspace-entitlements stack before this module is applied.

## Resulting hierarchy

For application `179392-dms`, the root configuration creates:

```text
/Applications/179392-dms/
  dbx-dev-179392-dms-engineer-grp/
  dbx-dev-179392-dms-analyst-grp/
```

The child-folder names come directly from `engineer_group_name` and
`analyst_group_name`. No CSI ID or application acronym is hardcoded, so the same
configuration applies to every future application entry.

## Group naming model

Each workspace belongs to one program. The platform-owned workspace administrator
and support groups are shared by every application in that workspace:

```text
dbx-{environment}-{program-name}-wksadmin-grp
dbx-{environment}-{program-name}-support-grp
```

For example, a development workspace for the `datahub` program uses:

```text
dbx-dev-datahub-wksadmin-grp
dbx-dev-datahub-support-grp
```

Each application has separate engineer, analyst, and deployer groups:

```text
dbx-{environment}-{CSI-ID}-{CSI-acronym-app}-engineer-grp
dbx-{environment}-{CSI-ID}-{CSI-acronym-app}-analyst-grp
dbx-{environment}-{CSI-ID}-{CSI-acronym-app}-deployer-grp
```

Values such as `datahub`, `{CSI-ID}`, and `{CSI-acronym-app}` are examples or
placeholders only. The module does not hardcode a program, CSI ID, or application
acronym.

## Expected permissions

The root configuration supplies the complete group names and grants:

| Principal | Scope | Permission |
| --- | --- | --- |
| Workspace administrator group | Shared by the program workspace | `CAN_MANAGE` |
| Platform support group | Shared by the program workspace | `CAN_RUN` |
| Engineer group | Unique to the application | `CAN_READ` (`CAN_VIEW` in the UI) |
| Analyst group | Unique to the application | `CAN_READ` (`CAN_VIEW` in the UI) |
| Deployer group | Unique to the application | `CAN_MANAGE` |

The root configuration also creates these application-specific child folders:

| Child folder | Explicit permission |
| --- | --- |
| `dbx-dev-<CSI-ID>-<acronym>-engineer-grp/` | Matching engineer group: `CAN_MANAGE` |
| `dbx-dev-<CSI-ID>-<acronym>-analyst-grp/` | Matching analyst group: `CAN_MANAGE` |

Root ACLs continue to be inherited by both child folders. In particular, the
workspace administrator and deployer retain `CAN_MANAGE`, support retains
`CAN_RUN`, and both application persona groups retain root-level `CAN_READ`.

## Usage

```hcl
module "application_folder_permissions" {
  source = "./modules/folder-permissions"

  providers = {
    databricks.workspace = databricks.workspace
  }

  directory_path = "/Applications/179392-dms"

  group_permissions = {
    "dbx-dev-datahub-wksadmin-grp"    = "CAN_MANAGE"
    "dbx-dev-datahub-support-grp"     = "CAN_RUN"
    "dbx-dev-179392-dms-engineer-grp" = "CAN_READ"
    "dbx-dev-179392-dms-analyst-grp"  = "CAN_READ"
    "dbx-dev-179392-dms-deployer-grp" = "CAN_MANAGE"
  }

  subdirectory_permissions = {
    "dbx-dev-179392-dms-engineer-grp" = {
      "dbx-dev-179392-dms-engineer-grp" = "CAN_MANAGE"
    }
    "dbx-dev-179392-dms-analyst-grp" = {
      "dbx-dev-179392-dms-analyst-grp" = "CAN_MANAGE"
    }
  }
}
```

## Onboarding sequence

1. Create and assign the required Databricks groups to the workspace.
2. Add the application path and group names to `application_folder_acls`.
3. Review `terraform plan`, including the application root, child directories,
   and their permissions.
4. Apply the configuration.

The module creates the application root plus its configured direct child
directories. Keep future applications as documentation examples rather than fake
paths in live variables.
