output "id" {
  description = "Alias for policy_id (consistent with other modules)."
  value       = databricks_budget_policy.this.policy_id
}

output "policy_id" {
  description = "Server-generated usage (budget) policy ID."
  value       = databricks_budget_policy.this.policy_id
}

output "policy_name" {
  description = "Usage policy name."
  value       = var.policy_name
}

output "custom_tags" {
  description = "Tags configured on the usage policy."
  value       = var.custom_tags
}

output "binding_workspace_ids" {
  description = "Workspace IDs this policy is bound to, if any."
  value       = var.binding_workspace_ids
}

output "account_id" {
  description = "Trimmed Databricks account UUID supplied by the caller, or null when omitted."
  value       = var.account_id == null ? null : trimspace(var.account_id)
}

output "rule_set_id" {
  description = "Usage-policy rule set ID, or null when ACL management is disabled."
  value       = try(module.acl[0].id, null)
}

output "rule_set_name" {
  description = "Usage-policy rule set name, or null when ACL management is disabled."
  value       = try(module.acl[0].name, null)
}

output "user_acl_principal_ids" {
  description = "Users, groups, and service principals granted roles/budgetPolicy.user."
  value       = try(module.acl[0].user_acl_principal_ids, [])
}

output "manager_acl_principal_ids" {
  description = "Users, groups, and service principals granted roles/budgetPolicy.manager."
  value       = try(module.acl[0].manager_acl_principal_ids, [])
}
