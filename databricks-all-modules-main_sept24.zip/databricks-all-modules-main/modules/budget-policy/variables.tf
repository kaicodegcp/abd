variable "policy_name" {
  description = "Usage policy name (unique among active policies; latin1; cannot start with reserved prefixes such as databricks:default-policy)."
  type        = string

  validation {
    condition     = length(trimspace(var.policy_name)) > 0
    error_message = "policy_name must not be empty."
  }

  validation {
    condition     = !startswith(trimspace(var.policy_name), "databricks:default-policy")
    error_message = "policy_name cannot start with the reserved prefix databricks:default-policy."
  }
}

variable "custom_tags" {
  description = "Tags applied to serverless compute for chargeback. Callers choose keys and values (for example BU, AppName, Env, CostCenter). Keys cannot be budget-policy-name, budget-policy-id, or budget-policy-resolution-result. May be empty; at most 20 entries; keys must be unique."
  type = list(object({
    key   = string
    value = optional(string)
  }))

  validation {
    condition     = length(var.custom_tags) <= 20
    error_message = "custom_tags must contain at most 20 entries."
  }

  validation {
    condition     = length(var.custom_tags) == length(distinct([for t in var.custom_tags : t.key]))
    error_message = "custom_tags keys must be unique within a policy."
  }

  validation {
    condition = alltrue([
      for t in var.custom_tags :
      length(trimspace(t.key)) > 0
    ])
    error_message = "custom_tags key must not be empty."
  }

  validation {
    condition = alltrue([
      for t in var.custom_tags :
      !contains(["budget-policy-name", "budget-policy-id", "budget-policy-resolution-result"], t.key)
    ])
    error_message = "custom_tags keys cannot be budget-policy-name, budget-policy-id, or budget-policy-resolution-result."
  }
}

variable "binding_workspace_ids" {
  description = "Optional workspace numeric IDs that this usage policy is bound to. Omit or null for account-wide availability (subject to provider/API behavior)."
  type        = list(number)
  default     = null

  validation {
    condition     = var.binding_workspace_ids == null || alltrue([for id in var.binding_workspace_ids : id > 0])
    error_message = "binding_workspace_ids values must be positive workspace IDs."
  }
}

variable "account_id" {
  description = "Databricks account UUID. Required when usage-policy ACL principals are configured."
  type        = string
  default     = null

  validation {
    condition     = var.account_id == null || can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", trimspace(var.account_id)))
    error_message = "account_id must be null or a UUID."
  }
}

variable "user_acl_principal_ids" {
  description = "Existing users, groups, and service principals granted roles/budgetPolicy.user (users/{username}, groups/{groupname}, servicePrincipals/{applicationId}). Format and uniqueness are validated by modules/budget-policy-acl."
  type        = list(string)
  default     = []
}

variable "manager_acl_principal_ids" {
  description = "Existing users, groups, and service principals granted roles/budgetPolicy.manager (users/{username}, groups/{groupname}, servicePrincipals/{applicationId}). Format and uniqueness are validated by modules/budget-policy-acl."
  type        = list(string)
  default     = []
}
