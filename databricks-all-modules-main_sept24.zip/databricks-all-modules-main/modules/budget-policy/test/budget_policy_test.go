package test

import (
	"os"
	"path/filepath"
	"strconv"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	common "github.com/sandbox45/databricks-all-modules/common"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

const planPlaceholderWorkspaceID = 1111111111111111
const planServicePrincipalID = "servicePrincipals/11111111-2222-3333-4444-555555555555"

func planModule(t *testing.T, vars map[string]interface{}) string {
	t.Helper()
	opts := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: filepath.Join(".."),
		Vars:         vars,
		NoColor:      true,
	})
	terraform.Init(t, opts)
	return terraform.Plan(t, opts)
}

func planModuleExpectError(t *testing.T, vars map[string]interface{}) error {
	t.Helper()
	opts := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: filepath.Join(".."),
		Vars:         vars,
		NoColor:      true,
	})
	terraform.Init(t, opts)
	_, err := terraform.PlanE(t, opts)
	return err
}

func sampleTags() []map[string]interface{} {
	return []map[string]interface{}{
		{"key": "BU", "value": "Finance"},
		{"key": "AppName", "value": "Payments"},
		{"key": "Env", "value": "dev"},
		{"key": "CostCenter", "value": "CC-100"},
	}
}

func baseVars(policyName string) map[string]interface{} {
	return map[string]interface{}{
		"policy_name": policyName,
		"custom_tags": sampleTags(),
	}
}

func accountID() string {
	return common.GetTestDefaults().AccountID
}

func aclVars(policyName string) map[string]interface{} {
	vars := baseVars(policyName)
	vars["account_id"] = accountID()
	return vars
}

func workspaceIDForPlan() int {
	for _, key := range []string{"TEST_BUDGET_POLICY_WORKSPACE_ID", "DATABRICKS_WORKSPACE_ID"} {
		raw := os.Getenv(key)
		if raw == "" {
			continue
		}
		id, err := strconv.Atoi(raw)
		if err == nil && id > 0 {
			return id
		}
	}
	return planPlaceholderWorkspaceID
}

func TestBudgetPolicyCreateWithTags(t *testing.T) {
	common.SkipIfShortMode(t, "budget-policy create with tags (plan)")
	common.RequireDatabricksEnv(t)

	policyName := common.GenerateUniqueTestID("usage-policy")
	plan := planModule(t, baseVars(policyName))
	require.NotEmpty(t, plan, "terraform plan should produce output")

	assert.Contains(t, plan, "databricks_budget_policy.this", "usage policy resource must be planned")
	assert.Contains(t, plan, policyName, "policy_name must appear in plan")
	assert.Contains(t, plan, "BU", "tag key BU must appear in plan")
	assert.Contains(t, plan, "Finance", "tag value Finance must appear in plan")
	assert.Contains(t, plan, "AppName", "tag key AppName must appear in plan")
	assert.Contains(t, plan, "Payments", "tag value Payments must appear in plan")
	assert.Contains(t, plan, "Env", "tag key Env must appear in plan")
	assert.Contains(t, plan, "CostCenter", "tag key CostCenter must appear in plan")
	assert.Contains(t, plan, "CC-100", "tag value CC-100 must appear in plan")
	assert.NotContains(t, plan, "databricks_access_control_rule_set.this", "rule set must not be managed when ACL principals are omitted")
}

func TestBudgetPolicyWorkspaceBinding(t *testing.T) {
	common.SkipIfShortMode(t, "budget-policy workspace binding (plan)")
	common.RequireDatabricksEnv(t)

	wsID := workspaceIDForPlan()
	policyName := common.GenerateUniqueTestID("usage-policy-bound")
	vars := baseVars(policyName)
	vars["binding_workspace_ids"] = []int{wsID}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, "databricks_budget_policy.this", "usage policy resource must be planned")
	assert.Contains(t, plan, "binding_workspace_ids", "workspace binding must appear in plan")
	assert.Contains(t, plan, strconv.Itoa(wsID), "bound workspace ID must appear in plan")
}

func TestBudgetPolicyNoWorkspaceBinding(t *testing.T) {
	common.SkipIfShortMode(t, "budget-policy without workspace binding (plan)")
	common.RequireDatabricksEnv(t)

	policyName := common.GenerateUniqueTestID("usage-policy-unbound")
	plan := planModule(t, baseVars(policyName))
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, "databricks_budget_policy.this", "usage policy resource must be planned")
	assert.NotContains(t, plan, strconv.Itoa(planPlaceholderWorkspaceID), "placeholder workspace ID must not appear when binding is omitted")
	assert.NotContains(t, plan, "databricks_access_control_rule_set.this", "rule set must not be managed when ACL principals are omitted")
}

func TestBudgetPolicyAclUserPrincipal(t *testing.T) {
	common.SkipIfShortMode(t, "budget-policy user ACL principal (plan)")
	common.RequireDatabricksEnv(t)

	vars := aclVars(common.GenerateUniqueTestID("usage-policy-user-acl"))
	vars["user_acl_principal_ids"] = []string{"users/analyst@example.com"}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, "databricks_access_control_rule_set.this")
	assert.Contains(t, plan, "roles/budgetPolicy.user")
	assert.Contains(t, plan, "users/analyst@example.com")
	assert.NotContains(t, plan, "roles/budgetPolicy.manager")
}

func TestBudgetPolicyAclGroupPrincipal(t *testing.T) {
	common.SkipIfShortMode(t, "budget-policy group ACL principal (plan)")
	common.RequireDatabricksEnv(t)

	vars := aclVars(common.GenerateUniqueTestID("usage-policy-group-acl"))
	vars["manager_acl_principal_ids"] = []string{"groups/platform-admins"}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, "databricks_access_control_rule_set.this")
	assert.Contains(t, plan, "roles/budgetPolicy.manager")
	assert.Contains(t, plan, "groups/platform-admins")
	assert.NotContains(t, plan, "roles/budgetPolicy.user")
}

func TestBudgetPolicyAclServicePrincipal(t *testing.T) {
	common.SkipIfShortMode(t, "budget-policy service principal ACL (plan)")
	common.RequireDatabricksEnv(t)

	vars := aclVars(common.GenerateUniqueTestID("usage-policy-sp-acl"))
	vars["user_acl_principal_ids"] = []string{planServicePrincipalID}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, "databricks_access_control_rule_set.this")
	assert.Contains(t, plan, "roles/budgetPolicy.user")
	assert.Contains(t, plan, planServicePrincipalID)
}

func TestBudgetPolicyAclMixedPrincipals(t *testing.T) {
	common.SkipIfShortMode(t, "budget-policy mixed ACL principals (plan)")
	common.RequireDatabricksEnv(t)

	vars := aclVars(common.GenerateUniqueTestID("usage-policy-mixed-acl"))
	vars["user_acl_principal_ids"] = []string{
		"users/analyst@example.com",
		"groups/payments-dev",
		planServicePrincipalID,
	}
	vars["manager_acl_principal_ids"] = []string{"groups/platform-admins"}

	plan := planModule(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, "databricks_budget_policy.this")
	assert.Contains(t, plan, "databricks_access_control_rule_set.this")
	assert.Contains(t, plan, "roles/budgetPolicy.user")
	assert.Contains(t, plan, "roles/budgetPolicy.manager")
	assert.Contains(t, plan, "users/analyst@example.com")
	assert.Contains(t, plan, "groups/payments-dev")
	assert.Contains(t, plan, planServicePrincipalID)
	assert.Contains(t, plan, "groups/platform-admins")
}

func TestBudgetPolicyAclOverlapRejected(t *testing.T) {
	common.SkipIfShortMode(t, "budget-policy overlapping ACL principals (plan)")
	common.RequireDatabricksEnv(t)

	vars := aclVars(common.GenerateUniqueTestID("usage-policy-overlap"))
	vars["user_acl_principal_ids"] = []string{planServicePrincipalID}
	vars["manager_acl_principal_ids"] = []string{planServicePrincipalID}

	err := planModuleExpectError(t, vars)
	require.Error(t, err, "a service principal cannot be in both ACL roles")
	assert.Contains(t, err.Error(), "cannot be both")
}

func TestBudgetPolicyAclInvalidPrincipalRejected(t *testing.T) {
	common.SkipIfShortMode(t, "budget-policy invalid ACL principal (plan)")
	common.RequireDatabricksEnv(t)

	vars := aclVars(common.GenerateUniqueTestID("usage-policy-bad-principal"))
	vars["user_acl_principal_ids"] = []string{"payments-dev"}

	err := planModuleExpectError(t, vars)
	require.Error(t, err, "principal without a supported ACL prefix must fail validation")
	assert.Contains(t, err.Error(), "servicePrincipals")
}

func TestBudgetPolicyAclAccountIDRequired(t *testing.T) {
	common.SkipIfShortMode(t, "budget-policy ACL account id required (plan)")
	common.RequireDatabricksEnv(t)

	vars := baseVars(common.GenerateUniqueTestID("usage-policy-no-account"))
	vars["user_acl_principal_ids"] = []string{"groups/payments-dev"}

	err := planModuleExpectError(t, vars)
	require.Error(t, err, "account_id must be required when ACL principals are configured")
	assert.Contains(t, err.Error(), "account_id is required")
}

func TestBudgetPolicyAclInvalidAccountIDRejected(t *testing.T) {
	common.SkipIfShortMode(t, "budget-policy invalid ACL account id (plan)")
	common.RequireDatabricksEnv(t)

	vars := baseVars(common.GenerateUniqueTestID("usage-policy-bad-account"))
	vars["account_id"] = "not-a-uuid"
	vars["user_acl_principal_ids"] = []string{"groups/payments-dev"}

	err := planModuleExpectError(t, vars)
	require.Error(t, err, "non-UUID account_id must fail validation")
	assert.Contains(t, err.Error(), "UUID")
}

func TestBudgetPolicyReservedTagKeyRejected(t *testing.T) {
	common.SkipIfShortMode(t, "budget-policy reserved tag key (plan)")
	common.RequireDatabricksEnv(t)

	vars := map[string]interface{}{
		"policy_name": common.GenerateUniqueTestID("usage-policy-reserved"),
		"custom_tags": []map[string]interface{}{
			{"key": "budget-policy-id", "value": "should-fail"},
		},
	}

	err := planModuleExpectError(t, vars)
	require.Error(t, err, "reserved tag keys must fail validation")
	assert.Contains(t, err.Error(), "budget-policy-id")
}

func TestBudgetPolicyDuplicateTagKeyRejected(t *testing.T) {
	common.SkipIfShortMode(t, "budget-policy duplicate tag key (plan)")
	common.RequireDatabricksEnv(t)

	vars := map[string]interface{}{
		"policy_name": common.GenerateUniqueTestID("usage-policy-dup"),
		"custom_tags": []map[string]interface{}{
			{"key": "BU", "value": "Finance"},
			{"key": "BU", "value": "Engineering"},
		},
	}

	err := planModuleExpectError(t, vars)
	require.Error(t, err, "duplicate tag keys must fail validation")
	assert.Contains(t, err.Error(), "unique")
}

func TestBudgetPolicyEmptyNameRejected(t *testing.T) {
	common.SkipIfShortMode(t, "budget-policy empty name (plan)")
	common.RequireDatabricksEnv(t)

	vars := map[string]interface{}{
		"policy_name": "   ",
		"custom_tags": sampleTags(),
	}

	err := planModuleExpectError(t, vars)
	require.Error(t, err, "empty policy_name must fail validation")
}

func TestBudgetPolicyInvalidWorkspaceIDRejected(t *testing.T) {
	common.SkipIfShortMode(t, "budget-policy invalid workspace id (plan)")
	common.RequireDatabricksEnv(t)

	vars := baseVars(common.GenerateUniqueTestID("usage-policy-bad-ws"))
	vars["binding_workspace_ids"] = []int{0}

	err := planModuleExpectError(t, vars)
	require.Error(t, err, "non-positive workspace IDs must fail validation")
}

func TestBudgetPolicyModuleInputs(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("budget-policy")

	config := common.ModuleTestConfig{
		ModuleName:      "budget-policy",
		TestDescription: "Tests Databricks serverless usage policy module inputs (plan)",
		RequiredVars: map[string]interface{}{
			"policy_name": uniqueID,
			"custom_tags": []interface{}{
				map[string]interface{}{
					"key":   "terraform-module-test",
					"value": "budget-policy",
				},
			},
		},
		ExpectedOutputs: []string{
			"id",
			"policy_id",
			"policy_name",
			"custom_tags",
			"binding_workspace_ids",
			"account_id",
			"rule_set_id",
			"rule_set_name",
			"user_acl_principal_ids",
			"manager_acl_principal_ids",
		},
	}

	common.TestModuleWithConfig(t, config)
}

func TestBudgetPolicyModuleWithWorkspaceBinding(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("budget-policy-ws")
	wsID := workspaceIDForPlan()

	config := common.ModuleTestConfig{
		ModuleName:      "budget-policy",
		TestDescription: "Tests usage policy with binding_workspace_ids (plan)",
		RequiredVars: map[string]interface{}{
			"policy_name": uniqueID,
			"custom_tags": []interface{}{
				map[string]interface{}{
					"key":   "terraform-module-test",
					"value": "budget-policy-bound",
				},
			},
			"binding_workspace_ids": []interface{}{wsID},
		},
		ExpectedOutputs: []string{
			"id",
			"policy_id",
			"policy_name",
			"custom_tags",
			"binding_workspace_ids",
			"account_id",
			"rule_set_id",
			"rule_set_name",
			"user_acl_principal_ids",
			"manager_acl_principal_ids",
		},
	}

	common.TestModuleWithConfig(t, config)
}
