#!/bin/bash
# Run budget-policy plan tests. databricks_budget_policy is an account API:
#   export DATABRICKS_HOST="https://accounts.cloud.databricks.com"
#   export DATABRICKS_ACCOUNT_ID="<account-uuid>"
#   export DATABRICKS_CLIENT_ID="<application-id>"
#   export DATABRICKS_CLIENT_SECRET="<oauth-secret>"
# Optional: TEST_BUDGET_POLICY_WORKSPACE_ID=<numeric workspace id> for bind assertions.
#
# Usage: from repo root: ./modules/budget-policy/test/run_tests.sh
#        or from this dir: ./run_tests.sh
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../../.." && pwd)"
SECRETS="$REPO_ROOT/secrets"

if [ -f "$SECRETS" ]; then
  echo "Sourcing secrets from $SECRETS"
  # shellcheck source=/dev/null
  source "$SECRETS"
else
  echo "Note: secrets file not found at $SECRETS"
  echo "Tests need DATABRICKS_HOST (account console), DATABRICKS_CLIENT_ID, DATABRICKS_CLIENT_SECRET."
fi

cd "$SCRIPT_DIR"
go test -v -run 'TestBudgetPolicy' -timeout 10m -count=1 .
