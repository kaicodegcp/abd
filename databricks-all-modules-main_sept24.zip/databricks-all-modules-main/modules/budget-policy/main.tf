# Serverless usage policy with optional authoritative ACL.
#
# Creates databricks_budget_policy and, when ACL principals are supplied,
# delegates the rule set to modules/budget-policy-acl so the grant logic and
# its preconditions are defined in exactly one place.
#
# Account-level API. The root module must configure the Databricks provider with
# the account console host and account_id (not a workspace URL). Workspace hosts
# return HTTP 404 Not Found on create. Client ID/secret still come from env.
#
# Permissions: the service principal needs roles/billing.admin on the account.
# Account admin alone returns PERMISSION_DENIED "missing CreateBudgetPolicyPermission".
# https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/budget_policy

locals {
  manage_acl = length(var.user_acl_principal_ids) + length(var.manager_acl_principal_ids) > 0
}

resource "databricks_budget_policy" "this" {
  policy_name           = var.policy_name
  custom_tags           = var.custom_tags
  binding_workspace_ids = var.binding_workspace_ids

  lifecycle {
    precondition {
      condition     = !local.manage_acl || try(length(trimspace(var.account_id)) > 0, false)
      error_message = "account_id is required when user_acl_principal_ids or manager_acl_principal_ids is non-empty."
    }
  }
}

module "acl" {
  source = "../budget-policy-acl"
  count  = local.manage_acl ? 1 : 0

  account_id                = var.account_id
  policy_id                 = databricks_budget_policy.this.policy_id
  user_acl_principal_ids    = var.user_acl_principal_ids
  manager_acl_principal_ids = var.manager_acl_principal_ids
}
