output "id" {
  description = "Alias for policy_id."
  value       = module.budget_policy.id
}

output "policy_id" {
  description = "Server-generated usage policy ID."
  value       = module.budget_policy.policy_id
}

output "policy_name" {
  description = "Usage policy name."
  value       = module.budget_policy.policy_name
}

output "custom_tags" {
  description = "Tags configured on the usage policy."
  value       = module.budget_policy.custom_tags
}

output "binding_workspace_ids" {
  description = "Workspace IDs this policy is bound to, if any."
  value       = module.budget_policy.binding_workspace_ids
}

output "account_id" {
  description = "Databricks account UUID supplied to the module."
  value       = module.budget_policy.account_id
}

output "rule_set_id" {
  description = "Usage-policy rule set ID."
  value       = module.budget_policy.rule_set_id
}

output "rule_set_name" {
  description = "Usage-policy rule set name."
  value       = module.budget_policy.rule_set_name
}

output "user_acl_principal_ids" {
  description = "Principals granted roles/budgetPolicy.user."
  value       = module.budget_policy.user_acl_principal_ids
}

output "manager_acl_principal_ids" {
  description = "Principals granted roles/budgetPolicy.manager."
  value       = module.budget_policy.manager_acl_principal_ids
}
