variable "databricks_account_id" {
  description = "Databricks account UUID. Required by databricks_budget_policy (account-level API)."
  type        = string
}

variable "databricks_account_host" {
  description = "Databricks account console URL"
  type        = string
  default     = "https://accounts.cloud.databricks.com"
}

variable "policy_name" {
  description = "Usage policy name (unique among active policies)."
  type        = string
}

variable "custom_tags" {
  description = "Tags applied to serverless compute usage. Callers choose keys and values."
  type = list(object({
    key   = string
    value = optional(string)
  }))
}

variable "binding_workspace_ids" {
  description = "Optional workspace numeric IDs to bind the policy to. Null = not bound to a subset of workspaces."
  type        = list(number)
  default     = null
}

variable "user_acl_principal_ids" {
  description = "Existing users, groups, and service principals granted roles/budgetPolicy.user."
  type        = list(string)
  default     = []
}

variable "manager_acl_principal_ids" {
  description = "Existing users, groups, and service principals granted roles/budgetPolicy.manager."
  type        = list(string)
  default     = []
}
