# Example: serverless usage policy and ACL in one deployment.
# The module creates databricks_budget_policy and, when principals are supplied,
# its authoritative databricks_access_control_rule_set (via modules/budget-policy-acl).
# Use modules/budget-policy-acl directly only to attach ACLs to an existing policy_id.
# Copy terraform.tfvars.example to terraform.tfvars and set databricks_account_id.
#
# This resource is an account API. A workspace URL in DATABRICKS_HOST produces
# HTTP 404 ("Not Found") on apply. The provider host is set explicitly so a leftover
# workspace DATABRICKS_HOST does not override it.
#
# OAuth (account-level service principal with the account admin role):
#   export DATABRICKS_CLIENT_ID="<application-id: UUID, not the secret>"
#   export DATABRICKS_CLIENT_SECRET="<oauth-secret>"
# https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/budget_policy

provider "databricks" {
  host       = var.databricks_account_host
  account_id = var.databricks_account_id
}

module "budget_policy" {
  source = "../.."

  account_id                = var.databricks_account_id
  policy_name               = var.policy_name
  custom_tags               = var.custom_tags
  binding_workspace_ids     = var.binding_workspace_ids
  user_acl_principal_ids    = var.user_acl_principal_ids
  manager_acl_principal_ids = var.manager_acl_principal_ids
}
