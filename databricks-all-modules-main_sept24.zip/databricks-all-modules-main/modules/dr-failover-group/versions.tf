terraform {
  # >= 1.2 for lifecycle preconditions; >= 1.5 matches the repo baseline.
  required_version = ">= 1.5"

  required_providers {
    databricks = {
      source = "databricks/databricks"
      # Managed DR resources require a recent provider.
      version = ">= 1.125.0, < 2.0.0"
    }
  }
}
