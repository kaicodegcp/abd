# =============================================================================
# Network Connectivity Configuration (NCC) Module - Variables
# =============================================================================
# Creates one Databricks MWS Network Connectivity Config for serverless egress
# control, any number of private endpoint rules on it, and (optionally) binds it
# to one or more workspaces.
# =============================================================================

variable "name" {
  description = "Name of the Network Connectivity Config in the Databricks account (unique among active NCCs)."
  type        = string

  validation {
    condition     = length(trimspace(var.name)) > 0
    error_message = "name must not be empty."
  }
}

variable "region" {
  description = "AWS region for the NCC. An NCC can only be bound to workspaces in the same region."
  type        = string

  validation {
    condition     = length(trimspace(var.region)) > 0
    error_message = "region must not be empty."
  }
}

# -----------------------------------------------------------------------------
# Private endpoint rules (AWS)
# -----------------------------------------------------------------------------
# One entry per resource you want serverless compute to reach privately. The map
# is keyed by a caller-chosen name so many rules live on a single NCC; keys must
# be known at plan time (values, e.g. an NLB endpoint_service, may be known after
# apply). Two shapes are supported — set exactly one of aws_service / endpoint_service:
#
#   private_endpoint_rules = {
#     # AWS-managed resource: aws_service builds com.amazonaws.<region>.<service>.
#     bedrock  = { aws_service = "bedrock-runtime" }
#     dynamodb = { aws_service = "dynamodb" }
#     kms      = { aws_service = "kms" }
#
#     # Customer VPC endpoint service (internal NLB): endpoint_service + domain_names.
#     nlb-payments = {
#       endpoint_service = aws_vpc_endpoint_service.payments.service_name
#       domain_names     = ["api.payments.internal"]
#     }
#   }
#
# S3 is intentionally NOT supported here: reach S3 over a VPC gateway endpoint,
# not an NCC interface endpoint.
# -----------------------------------------------------------------------------

variable "private_endpoint_rules" {
  description = <<-EOT
    Map of AWS private endpoint rules to create on this NCC, keyed by a
    caller-chosen name (the key is stable and must be known at plan time).

    Set exactly one of aws_service or endpoint_service per rule:

    1. AWS-managed resource (Bedrock, DynamoDB, KMS, Lambda, RDS, Redshift,
       Secrets Manager, STS, SNS, SQS, EMR, Glue, ...):
         aws_service - service token, e.g. "bedrock-runtime", "dynamodb", "kms".
                       The rule endpoint_service becomes com.amazonaws.<region>.<aws_service>.
       Any lowercase AWS service token is accepted (the token is only shape-checked),
       so services Databricks adds later work without a module change; the account
       API rejects a genuinely unsupported service at apply. S3 is excluded on
       purpose — use a VPC gateway endpoint for S3.

    2. Customer VPC endpoint service (an internal NLB behind a VPC endpoint service):
         endpoint_service - full service name, e.g.
                            com.amazonaws.vpce.us-west-2.vpce-svc-xxxx
                            (may be known after apply).
         domain_names     - FQDNs that resolve to resources behind the service.

    enabled (optional) - whether the rule is enabled (provider default when null).

    Current AWS-managed services supported by Databricks are listed here:
    https://docs.databricks.com/aws/en/security/network/serverless-network-security/pl-aws-resources#supported-resources
  EOT
  type = map(object({
    aws_service      = optional(string)
    endpoint_service = optional(string)
    domain_names     = optional(list(string))
    enabled          = optional(bool)
  }))
  default = {}

  validation {
    condition     = alltrue([for k in keys(var.private_endpoint_rules) : length(trimspace(k)) > 0])
    error_message = "private_endpoint_rules keys must not be empty."
  }

  validation {
    condition = alltrue([
      for r in var.private_endpoint_rules :
      !(r.aws_service != null && r.endpoint_service != null)
    ])
    error_message = "Each private endpoint rule must set either aws_service (managed resource) or endpoint_service (VPC endpoint service), not both."
  }

  validation {
    condition = alltrue([
      for r in var.private_endpoint_rules :
      r.aws_service != null || r.endpoint_service != null
    ])
    error_message = "Each private endpoint rule must set one of aws_service or endpoint_service."
  }

  # S3 is reached via a VPC gateway endpoint, not an NCC interface endpoint.
  validation {
    condition = alltrue([
      for r in var.private_endpoint_rules :
      coalesce(r.aws_service, "unset") != "s3"
    ])
    error_message = "aws_service \"s3\" is not supported: reach S3 over a VPC gateway endpoint, not an NCC private endpoint rule."
  }

  # Validate the SHAPE of aws_service, not membership in a fixed list: the token
  # is interpolated into com.amazonaws.<region>.<service>, so it must be a lowercase
  # AWS service name (letters/digits, hyphen-separated). The Databricks account API
  # is the authority on which services are actually supported, so a service Databricks
  # adds later (e.g. a new endpoint) works here with no module change; an unsupported
  # token surfaces as a clear API error at apply. See the supported-resources docs:
  # https://docs.databricks.com/aws/en/security/network/serverless-network-security/pl-aws-resources#supported-resources
  validation {
    condition = alltrue([
      for r in var.private_endpoint_rules :
      r.aws_service == null || can(regex("^[a-z0-9]+(-[a-z0-9]+)*$", coalesce(r.aws_service, "unset")))
    ])
    error_message = "aws_service must be a lowercase AWS service name using letters, digits, and hyphens (e.g. bedrock-runtime, dynamodb, kms) — the <service> in com.amazonaws.<region>.<service>."
  }
}

# -----------------------------------------------------------------------------
# Workspace bindings (optional)
# -----------------------------------------------------------------------------
# Numeric workspace IDs to bind this NCC to. One databricks_mws_ncc_binding is
# created per ID. IDs must be known at plan time (existing workspaces, or a var);
# to bind a workspace created in the same apply, keep a databricks_mws_ncc_binding
# in the root module with a static count/for_each gate instead (see README).
# -----------------------------------------------------------------------------

variable "workspace_ids" {
  description = "Numeric workspace IDs to bind this NCC to. Must be known at plan time. Empty = create no bindings."
  type        = list(number)
  default     = []

  validation {
    condition     = length(var.workspace_ids) == length(distinct(var.workspace_ids))
    error_message = "workspace_ids must be unique."
  }

  validation {
    condition     = alltrue([for id in var.workspace_ids : id > 0])
    error_message = "workspace_ids values must be positive workspace IDs."
  }
}
