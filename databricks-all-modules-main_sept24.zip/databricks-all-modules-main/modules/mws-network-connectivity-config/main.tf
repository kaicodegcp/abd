# =============================================================================
# Databricks Network Connectivity Configuration (NCC)
# =============================================================================
# Creates one NCC, any number of AWS private endpoint rules on it (for_each over
# var.private_endpoint_rules), and optional bindings to workspaces.
#
# https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/mws_network_connectivity_config
#
# Account-level API. Configure the databricks provider with the account console
# host and account_id (not a workspace URL). Egress rules (stable IPs) are
# computed by Databricks and exported as the egress_config attribute (see outputs).
# =============================================================================

resource "databricks_mws_network_connectivity_config" "this" {
  name   = var.name
  region = var.region
}

# =============================================================================
# Private endpoint rules
# =============================================================================
# One databricks_mws_ncc_private_endpoint_rule per entry in
# var.private_endpoint_rules. Two shapes are supported (see variables.tf):
#   - AWS-managed resource: aws_service builds endpoint_service as
#     com.amazonaws.<region>.<service> (Bedrock, DynamoDB, KMS, ...). S3 is not
#     supported here (use a VPC gateway endpoint for S3).
#   - Customer VPC endpoint service (NLB): endpoint_service + domain_names.
# Map keys must be known at plan time; a raw endpoint_service value may be
# (known after apply) from aws_vpc_endpoint_service. connection_state, rule_id,
# etc. are provider-computed (read-only), so Databricks transitions the rule
# CREATING -> ESTABLISHED without producing a Terraform diff.
# https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/mws_ncc_private_endpoint_rule
# =============================================================================

locals {
  # Resolve each rule to the provider's fields. aws_service is a convenience that
  # builds the AWS-managed service endpoint name com.amazonaws.<region>.<service>;
  # a raw endpoint_service (e.g. an NLB VPC endpoint service) is passed through as-is.
  private_endpoint_rules = {
    for k, r in var.private_endpoint_rules : k => {
      endpoint_service = r.aws_service != null ? format("com.amazonaws.%s.%s", var.region, r.aws_service) : r.endpoint_service
      domain_names     = r.domain_names
      enabled          = r.enabled
    }
  }
}

resource "databricks_mws_ncc_private_endpoint_rule" "this" {
  for_each = local.private_endpoint_rules

  network_connectivity_config_id = databricks_mws_network_connectivity_config.this.network_connectivity_config_id
  endpoint_service               = each.value.endpoint_service
  domain_names                   = each.value.domain_names
  enabled                        = each.value.enabled
}

# =============================================================================
# Workspace bindings
# =============================================================================
# One databricks_mws_ncc_binding per workspace ID. Keyed by the stringified
# workspace ID so IDs must be known at plan time (see variables.tf).
# https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/mws_ncc_binding
# =============================================================================

resource "databricks_mws_ncc_binding" "this" {
  for_each = { for id in var.workspace_ids : tostring(id) => id }

  network_connectivity_config_id = databricks_mws_network_connectivity_config.this.network_connectivity_config_id
  workspace_id                   = each.value
}
