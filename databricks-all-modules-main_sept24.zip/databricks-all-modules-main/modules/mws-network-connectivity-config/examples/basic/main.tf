# Example: one NCC with many private endpoint rules, bound to workspaces.
# The module creates databricks_mws_network_connectivity_config, one
# databricks_mws_ncc_private_endpoint_rule per entry in private_endpoint_rules,
# and one databricks_mws_ncc_binding per entry in workspace_ids.
# Copy terraform.tfvars.example to terraform.tfvars and set databricks_account_id.
#
# NCC is an account API. A workspace URL in DATABRICKS_HOST produces HTTP 404 on
# apply. The provider host is set explicitly so a leftover workspace
# DATABRICKS_HOST does not override it.
#
# OAuth (account-level service principal with the account admin role):
#   export DATABRICKS_CLIENT_ID="<application-id: UUID, not the secret>"
#   export DATABRICKS_CLIENT_SECRET="<oauth-secret>"
# https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/mws_network_connectivity_config

provider "databricks" {
  host       = var.databricks_account_host
  account_id = var.databricks_account_id
}

module "ncc" {
  source = "../.."

  name                   = var.name
  region                 = var.region
  private_endpoint_rules = var.private_endpoint_rules
  workspace_ids          = var.workspace_ids
}
