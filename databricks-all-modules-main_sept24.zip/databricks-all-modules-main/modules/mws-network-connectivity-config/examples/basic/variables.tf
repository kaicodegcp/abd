variable "databricks_account_id" {
  description = "Databricks account UUID (account-level NCC API)."
  type        = string
}

variable "databricks_account_host" {
  description = "Databricks account console URL."
  type        = string
  default     = "https://accounts.cloud.databricks.com"
}

variable "name" {
  description = "NCC name."
  type        = string
}

variable "region" {
  description = "AWS region for the NCC."
  type        = string
}

variable "private_endpoint_rules" {
  description = "AWS private endpoint rules keyed by name. See the root module's variables.tf."
  type = map(object({
    aws_service      = optional(string)
    endpoint_service = optional(string)
    domain_names     = optional(list(string))
    enabled          = optional(bool)
  }))
  default = {}
}

variable "workspace_ids" {
  description = "Numeric workspace IDs to bind the NCC to (must be known at plan time)."
  type        = list(number)
  default     = []
}
