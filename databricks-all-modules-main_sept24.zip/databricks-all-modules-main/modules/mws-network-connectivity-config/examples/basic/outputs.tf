output "network_connectivity_config_id" {
  description = "NCC ID."
  value       = module.ncc.network_connectivity_config_id
}

output "egress_config" {
  description = "Computed egress rules (stable IPs) for firewall allowlisting."
  value       = module.ncc.egress_config
}

output "private_endpoint_rules" {
  description = "Created private endpoint rules keyed by input key."
  value       = module.ncc.private_endpoint_rules
}

output "private_endpoint_rule_ids" {
  description = "Input key => private endpoint rule_id."
  value       = module.ncc.private_endpoint_rule_ids
}

output "bound_workspace_ids" {
  description = "Workspace IDs the NCC is bound to."
  value       = module.ncc.bound_workspace_ids
}
