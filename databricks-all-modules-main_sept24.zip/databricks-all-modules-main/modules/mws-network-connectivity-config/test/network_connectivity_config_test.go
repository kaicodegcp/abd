package test

import (
	"path/filepath"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	common "github.com/sandbox45/databricks-all-modules/common"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// planModule runs terraform init + plan against the module root and returns the
// plan output. planModuleExpectError returns the plan error (for validation tests).
func planModule(t *testing.T, vars map[string]interface{}) string {
	t.Helper()
	opts := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: filepath.Join(".."),
		Vars:         vars,
		NoColor:      true,
	})
	terraform.Init(t, opts)
	return terraform.Plan(t, opts)
}

func planModuleExpectError(t *testing.T, vars map[string]interface{}) error {
	t.Helper()
	opts := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: filepath.Join(".."),
		Vars:         vars,
		NoColor:      true,
	})
	terraform.Init(t, opts)
	_, err := terraform.PlanE(t, opts)
	return err
}

func region() string {
	return common.GetTestDefaults().AWSRegion
}

// -----------------------------------------------------------------------------
// Baseline: NCC only, no rules, no bindings.
// -----------------------------------------------------------------------------

func TestNetworkConnectivityConfigMinimal(t *testing.T) {
	common.SkipIfShortMode(t, "ncc minimal (plan)")
	common.RequireDatabricksEnv(t)

	vars := map[string]interface{}{
		"name":   common.GenerateUniqueTestID("ncc"),
		"region": region(),
	}
	plan := planModule(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, "databricks_mws_network_connectivity_config.this")
	assert.NotContains(t, plan, "databricks_mws_ncc_private_endpoint_rule.this", "no rule should be planned with an empty rule map")
	assert.NotContains(t, plan, "databricks_mws_ncc_binding.this", "no binding should be planned with empty workspace_ids")
}

// -----------------------------------------------------------------------------
// Many private endpoint rules on a single NCC.
// -----------------------------------------------------------------------------

func TestNetworkConnectivityConfigManyRules(t *testing.T) {
	common.SkipIfShortMode(t, "ncc many private endpoint rules (plan)")
	common.RequireDatabricksEnv(t)

	vars := map[string]interface{}{
		"name":   common.GenerateUniqueTestID("ncc-multi"),
		"region": region(),
		"private_endpoint_rules": map[string]interface{}{
			"payments": map[string]interface{}{
				"endpoint_service": "com.amazonaws.vpce.us-west-2.vpce-svc-0aaaaaaaaaaaaaaaa",
				"domain_names":     []string{"api.payments.internal"},
			},
			"risk": map[string]interface{}{
				"endpoint_service": "com.amazonaws.vpce.us-west-2.vpce-svc-0bbbbbbbbbbbbbbbb",
				"domain_names":     []string{"api.risk.internal", "data.risk.internal"},
			},
			"market-data": map[string]interface{}{
				"endpoint_service": "com.amazonaws.vpce.us-west-2.vpce-svc-0cccccccccccccccc",
				"domain_names":     []string{"feed.marketdata.internal"},
			},
		},
	}
	plan := planModule(t, vars)
	require.NotEmpty(t, plan)

	// Each rule is a distinct for_each instance keyed by its map key.
	assert.Contains(t, plan, `databricks_mws_ncc_private_endpoint_rule.this["payments"]`)
	assert.Contains(t, plan, `databricks_mws_ncc_private_endpoint_rule.this["risk"]`)
	assert.Contains(t, plan, `databricks_mws_ncc_private_endpoint_rule.this["market-data"]`)
	assert.Contains(t, plan, "api.payments.internal")
	assert.Contains(t, plan, "data.risk.internal")
	assert.Contains(t, plan, "vpce-svc-0cccccccccccccccc")
}

// -----------------------------------------------------------------------------
// AWS-managed resources (S3, Bedrock, DynamoDB, ...) alongside a VPC endpoint service.
// -----------------------------------------------------------------------------

func TestNetworkConnectivityConfigAwsManagedRules(t *testing.T) {
	common.SkipIfShortMode(t, "ncc aws-managed resource rules (plan)")
	common.RequireDatabricksEnv(t)

	r := region()
	vars := map[string]interface{}{
		"name":   common.GenerateUniqueTestID("ncc-managed"),
		"region": r,
		"private_endpoint_rules": map[string]interface{}{
			// Bedrock: service endpoint only.
			"bedrock": map[string]interface{}{
				"aws_service": "bedrock-runtime",
			},
			// DynamoDB: service endpoint only.
			"dynamodb": map[string]interface{}{
				"aws_service": "dynamodb",
			},
			// KMS: service endpoint only.
			"kms": map[string]interface{}{
				"aws_service": "kms",
			},
			// Customer VPC endpoint service (NLB).
			"payments": map[string]interface{}{
				"endpoint_service": "com.amazonaws.vpce." + r + ".vpce-svc-0aaaaaaaaaaaaaaaa",
				"domain_names":     []string{"api.payments.internal"},
			},
		},
	}
	plan := planModule(t, vars)
	require.NotEmpty(t, plan)

	// aws_service is resolved to com.amazonaws.<region>.<service>.
	assert.Contains(t, plan, "com.amazonaws."+r+".bedrock-runtime")
	assert.Contains(t, plan, "com.amazonaws."+r+".dynamodb")
	assert.Contains(t, plan, "com.amazonaws."+r+".kms")
	// Raw endpoint_service (NLB) passes through unchanged.
	assert.Contains(t, plan, "com.amazonaws.vpce."+r+".vpce-svc-0aaaaaaaaaaaaaaaa")
}

func TestNetworkConnectivityConfigS3Rejected(t *testing.T) {
	common.SkipIfShortMode(t, "ncc s3 aws_service rejected (plan)")
	common.RequireDatabricksEnv(t)

	vars := map[string]interface{}{
		"name":   common.GenerateUniqueTestID("ncc-s3"),
		"region": region(),
		"private_endpoint_rules": map[string]interface{}{
			"data-lake": map[string]interface{}{
				"aws_service": "s3",
			},
		},
	}
	err := planModuleExpectError(t, vars)
	require.Error(t, err, "S3 must be rejected (use a VPC gateway endpoint)")
	assert.Contains(t, err.Error(), "gateway endpoint")
}

func TestNetworkConnectivityConfigBothServicesRejected(t *testing.T) {
	common.SkipIfShortMode(t, "ncc rule with both aws_service and endpoint_service (plan)")
	common.RequireDatabricksEnv(t)

	vars := map[string]interface{}{
		"name":   common.GenerateUniqueTestID("ncc-both"),
		"region": region(),
		"private_endpoint_rules": map[string]interface{}{
			"conflict": map[string]interface{}{
				"aws_service":      "kms",
				"endpoint_service": "com.amazonaws.vpce.us-west-2.vpce-svc-0aaaaaaaaaaaaaaaa",
			},
		},
	}
	err := planModuleExpectError(t, vars)
	require.Error(t, err, "a rule must not set both aws_service and endpoint_service")
	assert.Contains(t, err.Error(), "not both")
}

func TestNetworkConnectivityConfigNeitherServiceRejected(t *testing.T) {
	common.SkipIfShortMode(t, "ncc rule with neither service (plan)")
	common.RequireDatabricksEnv(t)

	vars := map[string]interface{}{
		"name":   common.GenerateUniqueTestID("ncc-neither"),
		"region": region(),
		"private_endpoint_rules": map[string]interface{}{
			"empty": map[string]interface{}{
				"domain_names": []string{"api.internal"},
			},
		},
	}
	err := planModuleExpectError(t, vars)
	require.Error(t, err, "a rule must set aws_service or endpoint_service")
	assert.Contains(t, err.Error(), "one of")
}

func TestNetworkConnectivityConfigMalformedServiceRejected(t *testing.T) {
	common.SkipIfShortMode(t, "ncc malformed aws_service (plan)")
	common.RequireDatabricksEnv(t)

	// Only the SHAPE is validated, not membership in a fixed list, so a well-formed
	// token the module has never heard of is accepted (the API is the authority).
	// A malformed token (uppercase / underscore / dots) is rejected at plan time.
	vars := map[string]interface{}{
		"name":   common.GenerateUniqueTestID("ncc-badsvc"),
		"region": region(),
		"private_endpoint_rules": map[string]interface{}{
			"typo": map[string]interface{}{
				"aws_service": "Bedrock_Runtime",
			},
		},
	}
	err := planModuleExpectError(t, vars)
	require.Error(t, err, "a malformed aws_service token must fail validation")
	assert.Contains(t, err.Error(), "lowercase")
}

func TestNetworkConnectivityConfigUnknownServiceAccepted(t *testing.T) {
	common.SkipIfShortMode(t, "ncc future/unknown aws_service accepted (plan)")
	common.RequireDatabricksEnv(t)

	// A service the module does not enumerate (e.g. one Databricks adds later) must
	// pass validation and resolve to com.amazonaws.<region>.<service> with no module
	// change. It would only fail later if the account API rejects it at apply.
	r := region()
	vars := map[string]interface{}{
		"name":   common.GenerateUniqueTestID("ncc-future"),
		"region": r,
		"private_endpoint_rules": map[string]interface{}{
			"future": map[string]interface{}{
				"aws_service": "some-new-service",
			},
		},
	}
	plan := planModule(t, vars)
	require.NotEmpty(t, plan)
	assert.Contains(t, plan, "com.amazonaws."+r+".some-new-service")
}

// -----------------------------------------------------------------------------
// Workspace bindings.
// -----------------------------------------------------------------------------

func TestNetworkConnectivityConfigWorkspaceBindings(t *testing.T) {
	common.SkipIfShortMode(t, "ncc workspace bindings (plan)")
	common.RequireDatabricksEnv(t)

	vars := map[string]interface{}{
		"name":          common.GenerateUniqueTestID("ncc-bind"),
		"region":        region(),
		"workspace_ids": []int64{1234567890123456, 2345678901234567},
	}
	plan := planModule(t, vars)
	require.NotEmpty(t, plan)

	assert.Contains(t, plan, `databricks_mws_ncc_binding.this["1234567890123456"]`)
	assert.Contains(t, plan, `databricks_mws_ncc_binding.this["2345678901234567"]`)
}

// -----------------------------------------------------------------------------
// Validation rejections.
// -----------------------------------------------------------------------------

func TestNetworkConnectivityConfigDuplicateWorkspaceRejected(t *testing.T) {
	common.SkipIfShortMode(t, "ncc duplicate workspace_ids (plan)")
	common.RequireDatabricksEnv(t)

	vars := map[string]interface{}{
		"name":          common.GenerateUniqueTestID("ncc-dup-ws"),
		"region":        region(),
		"workspace_ids": []int64{1234567890123456, 1234567890123456},
	}
	err := planModuleExpectError(t, vars)
	require.Error(t, err, "duplicate workspace IDs must fail validation")
	assert.Contains(t, err.Error(), "unique")
}

func TestNetworkConnectivityConfigInvalidWorkspaceRejected(t *testing.T) {
	common.SkipIfShortMode(t, "ncc non-positive workspace_id (plan)")
	common.RequireDatabricksEnv(t)

	vars := map[string]interface{}{
		"name":          common.GenerateUniqueTestID("ncc-bad-ws"),
		"region":        region(),
		"workspace_ids": []int64{0},
	}
	err := planModuleExpectError(t, vars)
	require.Error(t, err, "non-positive workspace IDs must fail validation")
	assert.Contains(t, err.Error(), "positive")
}

func TestNetworkConnectivityConfigEmptyNameRejected(t *testing.T) {
	common.SkipIfShortMode(t, "ncc empty name (plan)")
	common.RequireDatabricksEnv(t)

	vars := map[string]interface{}{
		"name":   "   ",
		"region": region(),
	}
	err := planModuleExpectError(t, vars)
	require.Error(t, err, "empty name must fail validation")
}

// -----------------------------------------------------------------------------
// Config-driven input/output smoke test (plan-only, via common helper).
// -----------------------------------------------------------------------------

func TestNetworkConnectivityConfigModuleInputs(t *testing.T) {
	config := common.ModuleTestConfig{
		ModuleName:      "mws-network-connectivity-config",
		TestDescription: "Tests Databricks NCC module inputs (plan)",
		RequiredVars: map[string]interface{}{
			"name":   common.GenerateUniqueTestID("ncc-inputs"),
			"region": region(),
		},
		ExpectedOutputs: []string{
			"network_connectivity_config_id",
			"id",
			"region",
			"egress_config",
			"private_endpoint_rules",
			"private_endpoint_rule_ids",
			"bound_workspace_ids",
		},
	}
	common.TestModuleWithConfig(t, config)
}
