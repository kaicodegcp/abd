# =============================================================================
# Network Connectivity Configuration - Outputs
# =============================================================================

output "network_connectivity_config_id" {
  description = "Canonical unique identifier of the Network Connectivity Config in the Databricks account."
  value       = databricks_mws_network_connectivity_config.this.network_connectivity_config_id
}

output "id" {
  description = "Same as network_connectivity_config_id (convenience alias)."
  value       = databricks_mws_network_connectivity_config.this.network_connectivity_config_id
}

output "region" {
  description = "Region the NCC was created in. Workspaces bound to it must be in this region."
  value       = databricks_mws_network_connectivity_config.this.region
}

# Computed egress info (read-only; cannot be set via this resource).
output "egress_config" {
  description = "Computed egress rules from Databricks (e.g. aws_stable_ip_rule.cidr_blocks). Use for firewall allowlisting; cannot be set via Terraform."
  value       = databricks_mws_network_connectivity_config.this.egress_config
}

# Private endpoint rules, keyed by the same key used in var.private_endpoint_rules.
output "private_endpoint_rules" {
  description = "Map of created private endpoint rules keyed by input key: rule_id, connection_state (effective when ESTABLISHED), resolved endpoint_service, domain_names, enabled."
  value = {
    for k, r in databricks_mws_ncc_private_endpoint_rule.this : k => {
      rule_id          = r.rule_id
      connection_state = r.connection_state
      endpoint_service = r.endpoint_service
      domain_names     = r.domain_names
      enabled          = r.enabled
    }
  }
}

output "private_endpoint_rule_ids" {
  description = "Convenience map of input key => private endpoint rule_id."
  value       = { for k, r in databricks_mws_ncc_private_endpoint_rule.this : k => r.rule_id }
}

output "bound_workspace_ids" {
  description = "Workspace IDs this NCC is bound to (empty when no bindings were requested)."
  value       = [for b in databricks_mws_ncc_binding.this : b.workspace_id]
}
