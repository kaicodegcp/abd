# =============================================================================
# Classic Databricks Workspace - Databricks-only, standalone module
#
# Brings a Classic (customer-managed VPC) workspace up and running using ONLY
# databricks_* resources. Every AWS object (VPC, subnets, security groups,
# S3 root bucket, cross-account IAM role, KMS keys, PrivateLink VPC endpoints)
# is created by the infra team and arrives here as an input variable.
#
# This module is self-contained: no AWS provider, no external module sources,
# no relative module paths. Copy the folder anywhere and it works.
#
# Providers expected from the caller:
#   databricks.account   - account-level (accounts.cloud.databricks.com)
#   databricks.workspace - workspace-level (host = workspace URL, for the
#                          post-creation security settings)
#
# Out of scope by design: groups/users, cluster policies, IP access lists,
# catalogs/schemas, audit-log delivery, DR (map the per-region workspaces
# from this module's outputs in the separate DR layer).
# =============================================================================

locals {
  prefix = var.workspace_name
  suffix = random_string.suffix.result

  effective_private_access_settings_id = (
    var.enable_private_link
    ? coalesce(var.private_access_settings_id, try(databricks_mws_private_access_settings.this[0].private_access_settings_id, null))
    : null
  )

  network_policy_ingress = (
    var.network_policy_public_access != null || var.network_policy_private_access != null || var.network_policy_cross_workspace_access != null
    ) ? {
    public_access          = var.network_policy_public_access
    private_access         = var.network_policy_private_access
    cross_workspace_access = var.network_policy_cross_workspace_access
  } : null

  effective_network_policy_id = var.network_policy_id != null ? var.network_policy_id : one(databricks_account_network_policy.this[*].network_policy_id)
}

resource "random_string" "suffix" {
  length  = 6
  special = false
  upper   = false
}

# =============================================================================
# CREDENTIALS - registers the infra-team cross-account IAM role
# =============================================================================

# Existing states created this without count - keep the object in place.
moved {
  from = databricks_mws_credentials.this
  to   = databricks_mws_credentials.this[0]
}

resource "databricks_mws_credentials" "this" {
  provider = databricks.account
  count    = var.credentials_id == null ? 1 : 0

  # account_id comes from the provider config (deprecated on the resource)
  credentials_name = "${local.prefix}-credentials-${local.suffix}"
  role_arn         = var.cross_account_role_arn

  lifecycle {
    precondition {
      condition     = var.cross_account_role_arn != null
      error_message = "Set cross_account_role_arn, or pass credentials_id to reference a pre-registered credentials configuration."
    }
  }
}

locals {
  effective_credentials_id = coalesce(var.credentials_id, try(databricks_mws_credentials.this[0].credentials_id, null))
}

# =============================================================================
# STORAGE CONFIGURATION - registers the infra-team S3 root bucket
# =============================================================================

moved {
  from = databricks_mws_storage_configurations.this
  to   = databricks_mws_storage_configurations.this[0]
}

resource "databricks_mws_storage_configurations" "this" {
  provider = databricks.account
  count    = var.storage_configurations_id == null ? 1 : 0

  account_id                 = var.databricks_account_id
  storage_configuration_name = "${local.prefix}-storage-${local.suffix}"
  bucket_name                = var.root_bucket_name

  lifecycle {
    precondition {
      condition     = var.root_bucket_name != null
      error_message = "Set root_bucket_name, or pass storage_configurations_id to reference a pre-registered storage configuration."
    }
  }
}

locals {
  effective_storage_configuration_id = coalesce(var.storage_configurations_id, try(databricks_mws_storage_configurations.this[0].storage_configuration_id, null))
}

# =============================================================================
# PRIVATELINK - registers the infra-team AWS VPC endpoints and creates the
# private access settings (unless an existing PAS ID is supplied)
# =============================================================================

resource "databricks_mws_vpc_endpoint" "backend_rest" {
  provider = databricks.account
  count    = var.enable_private_link && var.networks_id == null ? 1 : 0

  account_id          = var.databricks_account_id
  aws_vpc_endpoint_id = var.rest_api_aws_vpc_endpoint_id
  vpc_endpoint_name   = "${local.prefix}-vpce-backend-${var.vpc_id}"
  region              = var.aws_region

  lifecycle {
    precondition {
      condition     = var.rest_api_aws_vpc_endpoint_id != null
      error_message = "rest_api_aws_vpc_endpoint_id must be set when enable_private_link is true."
    }
  }
}

resource "databricks_mws_vpc_endpoint" "backend_relay" {
  provider = databricks.account
  count    = var.enable_private_link && var.networks_id == null ? 1 : 0

  account_id          = var.databricks_account_id
  aws_vpc_endpoint_id = var.dataplane_relay_aws_vpc_endpoint_id
  vpc_endpoint_name   = "${local.prefix}-vpce-relay-${var.vpc_id}"
  region              = var.aws_region

  lifecycle {
    precondition {
      condition     = var.dataplane_relay_aws_vpc_endpoint_id != null
      error_message = "dataplane_relay_aws_vpc_endpoint_id must be set when enable_private_link is true."
    }
  }
}

resource "databricks_mws_private_access_settings" "this" {
  provider = databricks.account
  count    = var.enable_private_link && var.private_access_settings_id == null ? 1 : 0

  private_access_settings_name = "${local.prefix}-pas-${local.suffix}"
  region                       = var.aws_region
  public_access_enabled        = var.public_access_enabled
  private_access_level         = var.private_access_level
}

# =============================================================================
# NETWORK CONFIGURATION - registers the infra-team VPC/subnets/SGs
# =============================================================================

moved {
  from = databricks_mws_networks.this
  to   = databricks_mws_networks.this[0]
}

resource "databricks_mws_networks" "this" {
  provider = databricks.account
  count    = var.networks_id == null ? 1 : 0

  account_id         = var.databricks_account_id
  network_name       = "${local.prefix}-network-${local.suffix}"
  vpc_id             = var.vpc_id
  subnet_ids         = var.private_subnet_ids
  security_group_ids = var.workspace_security_group_ids

  vpc_endpoints {
    dataplane_relay = var.enable_private_link ? [databricks_mws_vpc_endpoint.backend_relay[0].vpc_endpoint_id] : []
    rest_api        = var.enable_private_link ? [databricks_mws_vpc_endpoint.backend_rest[0].vpc_endpoint_id] : []
  }

  lifecycle {
    precondition {
      condition     = var.vpc_id != null && var.private_subnet_ids != null && var.workspace_security_group_ids != null
      error_message = "Set vpc_id, private_subnet_ids, and workspace_security_group_ids, or pass networks_id to reference a network configuration pre-registered for this workspace."
    }
  }
}

locals {
  effective_network_id = coalesce(var.networks_id, try(databricks_mws_networks.this[0].network_id, null))
}

# =============================================================================
# CUSTOMER-MANAGED KEYS - registers the infra-team KMS keys
# =============================================================================

resource "databricks_mws_customer_managed_keys" "managed_services" {
  provider = databricks.account
  count    = var.enable_cmk && var.managed_services_customer_managed_key_id == null ? 1 : 0

  account_id = var.databricks_account_id

  aws_key_info {
    key_arn   = var.managed_services_kms_key_arn
    key_alias = var.managed_services_kms_key_alias
  }

  use_cases = ["MANAGED_SERVICES"]

  lifecycle {
    precondition {
      condition     = var.managed_services_kms_key_arn != null && var.managed_services_kms_key_alias != null
      error_message = "When enable_cmk is true, managed_services_kms_key_arn and managed_services_kms_key_alias must be set."
    }
  }
}

resource "databricks_mws_customer_managed_keys" "workspace_storage" {
  provider = databricks.account
  count    = var.enable_cmk && var.storage_customer_managed_key_id == null ? 1 : 0

  account_id = var.databricks_account_id

  aws_key_info {
    key_arn   = var.workspace_storage_kms_key_arn
    key_alias = var.workspace_storage_kms_key_alias
  }

  use_cases = ["STORAGE"]

  lifecycle {
    precondition {
      condition     = var.workspace_storage_kms_key_arn != null && var.workspace_storage_kms_key_alias != null
      error_message = "When enable_cmk is true, workspace_storage_kms_key_arn and workspace_storage_kms_key_alias must be set."
    }
  }
}

# =============================================================================
# WORKSPACE
# =============================================================================

resource "databricks_mws_workspaces" "this" {
  provider = databricks.account

  account_id               = var.databricks_account_id
  workspace_name           = "${local.prefix}-${local.suffix}"
  aws_region               = var.aws_region
  deployment_name          = var.deployment_name
  credentials_id           = local.effective_credentials_id
  storage_configuration_id = local.effective_storage_configuration_id
  network_id               = local.effective_network_id

  managed_services_customer_managed_key_id = var.enable_cmk ? coalesce(var.managed_services_customer_managed_key_id, try(databricks_mws_customer_managed_keys.managed_services[0].customer_managed_key_id, null)) : null
  storage_customer_managed_key_id          = var.enable_cmk ? coalesce(var.storage_customer_managed_key_id, try(databricks_mws_customer_managed_keys.workspace_storage[0].customer_managed_key_id, null)) : null

  private_access_settings_id = local.effective_private_access_settings_id

  pricing_tier = var.pricing_tier
  custom_tags  = var.tags

  # Destroy ordering: remove the workspace before the NCC resources.
  depends_on = [databricks_mws_network_connectivity_config.this]
}

# =============================================================================
# NETWORK CONNECTIVITY CONFIG (optional) + binding
# =============================================================================

resource "databricks_mws_network_connectivity_config" "this" {
  provider = databricks.account
  count    = var.enable_network_connectivity_config && var.network_connectivity_config_id == null ? 1 : 0

  name   = "${local.prefix}-ncc-${local.suffix}"
  region = var.aws_region
}

locals {
  effective_ncc_id = (
    var.enable_network_connectivity_config
    ? coalesce(var.network_connectivity_config_id, try(databricks_mws_network_connectivity_config.this[0].network_connectivity_config_id, null))
    : null
  )
}

resource "databricks_mws_ncc_private_endpoint_rule" "nlb" {
  provider = databricks.account
  count    = var.enable_network_connectivity_config && length(var.ncc_nlb_domain_names) > 0 ? 1 : 0

  network_connectivity_config_id = local.effective_ncc_id
  endpoint_service               = var.ncc_nlb_vpc_endpoint_service_name
  domain_names                   = var.ncc_nlb_domain_names
}

resource "databricks_mws_ncc_binding" "this" {
  provider = databricks.account
  count    = var.enable_network_connectivity_config ? 1 : 0

  network_connectivity_config_id = local.effective_ncc_id
  workspace_id                   = databricks_mws_workspaces.this.workspace_id
}

# =============================================================================
# UNITY CATALOG - assign the workspace to the existing regional metastore
# =============================================================================

data "databricks_metastore" "existing" {
  provider = databricks.account

  name = var.metastore_name

  depends_on = [databricks_mws_workspaces.this]
}

resource "databricks_metastore_assignment" "this" {
  provider = databricks.account

  workspace_id = databricks_mws_workspaces.this.workspace_id
  metastore_id = data.databricks_metastore.existing.metastore_id
}

# =============================================================================
# WORKSPACE SECURITY HARDENING (optional, workspace provider)
# =============================================================================

# A freshly provisioned workspace returns "temporarily unavailable" from its
# settings APIs for the first minutes; wait before touching them.
resource "time_sleep" "workspace_api_warmup" {
  count = var.configure_workspace_security || length(coalesce(var.compliance_standards, [])) > 0 ? 1 : 0

  create_duration = var.workspace_api_warmup_duration

  depends_on = [databricks_metastore_assignment.this]
}

resource "databricks_workspace_setting_v2" "disable_legacy_access" {
  provider = databricks.workspace
  count    = var.configure_workspace_security ? 1 : 0

  name = "disable_legacy_access"
  boolean_val = {
    value = true
  }

  depends_on = [time_sleep.workspace_api_warmup]
}

resource "databricks_workspace_setting_v2" "disable_legacy_dbfs" {
  provider = databricks.workspace
  count    = var.configure_workspace_security ? 1 : 0

  name = "disable_legacy_dbfs"
  boolean_val = {
    value = true
  }

  # v2 settings share one storage entity per workspace; parallel writes hit
  # OCC conflicts, so the chain below applies them strictly one at a time.
  depends_on = [databricks_workspace_setting_v2.disable_legacy_access]
}

resource "databricks_workspace_setting_v2" "sql_results_download" {
  provider = databricks.workspace
  count    = var.configure_workspace_security ? 1 : 0

  name = "sql_results_download"
  boolean_val = {
    value = false
  }

  depends_on = [databricks_workspace_setting_v2.disable_legacy_dbfs]
}

resource "databricks_workspace_setting_v2" "notebook_table_clipboard" {
  provider = databricks.workspace
  count    = var.configure_workspace_security ? 1 : 0

  name = "enableNotebookTableClipboard"
  boolean_val = {
    value = false
  }

  depends_on = [databricks_workspace_setting_v2.sql_results_download]
}

resource "databricks_workspace_setting_v2" "export_notebook" {
  provider = databricks.workspace
  count    = var.configure_workspace_security ? 1 : 0

  name = "enableExportNotebook"
  boolean_val = {
    value = false
  }

  depends_on = [databricks_workspace_setting_v2.notebook_table_clipboard]
}

resource "databricks_workspace_setting_v2" "notebook_results_download" {
  provider = databricks.workspace
  count    = var.configure_workspace_security ? 1 : 0

  name = "enableResultsDownloading"
  boolean_val = {
    value = false
  }

  depends_on = [databricks_workspace_setting_v2.export_notebook]
}

resource "databricks_workspace_setting_v2" "uc_volumes_download_ui" {
  provider = databricks.workspace
  count    = var.configure_workspace_security ? 1 : 0

  name = "uc_volumes_download_ui"
  boolean_val = {
    value = false
  }

  depends_on = [databricks_workspace_setting_v2.notebook_results_download]
}

resource "databricks_restrict_workspace_admins_setting" "this" {
  provider = databricks.workspace
  count    = var.configure_workspace_security ? 1 : 0

  restrict_workspace_admins {
    status = var.restrict_workspace_admins_status
  }

  depends_on = [databricks_workspace_setting_v2.uc_volumes_download_ui]
}

resource "databricks_workspace_conf" "security_settings" {
  provider = databricks.workspace
  count    = var.configure_workspace_security ? 1 : 0

  custom_config = merge(
    {
      "enableVerboseAuditLogs"                           = tostring(var.enable_verbose_audit_logs)
      "enableDbfsFileBrowser"                            = "false"
      "enforceUserIsolation"                             = "true"
      "storeInteractiveNotebookResultsInCustomerAccount" = "true"
      "enableUploadDataUis"                              = "false"
      "enableIpAccessLists"                              = tostring(var.enable_ip_access_lists)
      "maxTokenLifetimeDays"                             = tostring(var.max_token_lifetime_days)
      "enableTokensConfig"                               = "false"
    },
    # enableWebTerminal: the API accepts "true" but returns 400 on "false" for
    # newer workspaces (verified), so the key is sent only on explicit enable.
    # Disabling the web terminal is governed in the admin console.
    var.enable_web_terminal ? { "enableWebTerminal" = "true" } : {},
    var.additional_workspace_config
  )

  depends_on = [time_sleep.workspace_api_warmup]
}

# =============================================================================
# COMPLIANCE SECURITY PROFILE (optional, workspace provider)
# =============================================================================

resource "databricks_compliance_security_profile_workspace_setting" "this" {
  provider = databricks.workspace
  count    = length(coalesce(var.compliance_standards, [])) > 0 ? 1 : 0

  compliance_security_profile_workspace {
    is_enabled           = true
    compliance_standards = var.compliance_standards
  }

  depends_on = [time_sleep.workspace_api_warmup]
}

# =============================================================================
# AUDIT LOG DELIVERY (optional, account-level singleton) - registers the
# infra-team delivery bucket + role and creates the AUDIT_LOGS delivery.
# =============================================================================

resource "databricks_mws_credentials" "audit_log_delivery" {
  provider = databricks.account
  count    = var.enable_audit_log_delivery ? 1 : 0

  credentials_name = "${local.prefix}-audit-log-credentials-${local.suffix}"
  role_arn         = var.audit_log_delivery_role_arn

  lifecycle {
    precondition {
      condition     = var.audit_log_delivery_role_arn != null && var.audit_log_delivery_bucket_name != null
      error_message = "When enable_audit_log_delivery is true, set audit_log_delivery_role_arn and audit_log_delivery_bucket_name."
    }
  }
}

resource "databricks_mws_storage_configurations" "audit_log_delivery" {
  provider = databricks.account
  count    = var.enable_audit_log_delivery ? 1 : 0

  account_id                 = var.databricks_account_id
  storage_configuration_name = "${local.prefix}-audit-log-storage-${local.suffix}"
  bucket_name                = var.audit_log_delivery_bucket_name
}

resource "databricks_mws_log_delivery" "audit_logs" {
  provider = databricks.account
  count    = var.enable_audit_log_delivery ? 1 : 0

  account_id               = var.databricks_account_id
  credentials_id           = databricks_mws_credentials.audit_log_delivery[0].credentials_id
  storage_configuration_id = databricks_mws_storage_configurations.audit_log_delivery[0].storage_configuration_id
  delivery_path_prefix     = "audit-logs"
  config_name              = "${local.prefix}-audit-logs"
  log_type                 = "AUDIT_LOGS"
  output_format            = "JSON"
}

# =============================================================================
# ACCOUNT NETWORK POLICY (optional) - egress + context-based ingress
# =============================================================================

locals {
  # Policy changes REPLACE the policy (provider behavior), and a policy cannot
  # be deleted while attached to a running workspace. Terraform-native fix:
  # the policy ID carries a short hash of its content, and create_before_destroy
  # orders every change as create-new -> re-point binding (detaches old) ->
  # delete old. Max ID length is 32 chars.
  network_policy_content_hash = substr(md5(jsonencode({
    egress  = var.network_policy_egress
    ingress = local.network_policy_ingress
  })), 0, 6)
}

resource "databricks_account_network_policy" "this" {
  provider = databricks.account
  count    = var.enable_account_network_policy && var.network_policy_id == null ? 1 : 0

  network_policy_id = "${substr(local.prefix, 0, 14)}-np-${local.suffix}-${local.network_policy_content_hash}"

  egress  = var.network_policy_egress
  ingress = local.network_policy_ingress

  lifecycle {
    create_before_destroy = true

    # FAIL CLOSED: an armed policy with no egress rules is a no-op that reads
    # as "egress control on" - refuse to create one.
    precondition {
      condition     = var.network_policy_egress != null
      error_message = "enable_account_network_policy is on (the default) but network_policy_egress is not set - that would create an EMPTY, fail-open policy. Set network_policy_egress (restriction_mode + policy_enforcement), pass network_policy_id to bind an existing policy, or opt out explicitly with enable_account_network_policy = false."
    }
  }
}

# Detach propagation buffer: sits between the policy and its binding, with the
# wait on DESTROY. Replacement order becomes: create new policy -> create sleep
# (instant) -> re-point binding (detaches old policy) -> destroy old sleep
# (waits 60s) -> destroy old policy. Gives the server-side detach a minute to
# propagate before the delete.
resource "time_sleep" "network_policy_detach_wait" {
  count = var.enable_account_network_policy && var.network_policy_id == null ? 1 : 0

  triggers = {
    policy_id = databricks_account_network_policy.this[0].network_policy_id
  }

  create_duration  = "0s"
  destroy_duration = "60s"

  lifecycle {
    create_before_destroy = true
  }
}

resource "databricks_workspace_network_option" "this" {
  provider = databricks.account
  count    = var.enable_account_network_policy ? 1 : 0

  network_policy_id = local.effective_network_policy_id
  workspace_id      = databricks_mws_workspaces.this.workspace_id

  depends_on = [time_sleep.network_policy_detach_wait]

  lifecycle {
    create_before_destroy = true
  }
}
