# =============================================================================
# Outputs - Classic Workspace (Databricks-only, standalone)
# =============================================================================

output "workspace_id" {
  description = "Databricks workspace ID. Feed this to the separate DR mapping and any downstream wrappers."
  value       = databricks_mws_workspaces.this.workspace_id
}

output "workspace_url" {
  description = "Databricks workspace URL (use as the host for the workspace provider in downstream stacks)."
  value       = databricks_mws_workspaces.this.workspace_url
}

output "deployment_name" {
  description = "Workspace deployment name."
  value       = databricks_mws_workspaces.this.deployment_name
}

output "workspace_status" {
  description = "Provisioning status of the workspace."
  value       = databricks_mws_workspaces.this.workspace_status
}

output "credentials_id" {
  description = "MWS credentials configuration ID in use (created here or passed in)."
  value       = local.effective_credentials_id
}

output "storage_configuration_id" {
  description = "MWS storage configuration ID in use (created here or passed in)."
  value       = local.effective_storage_configuration_id
}

output "network_id" {
  description = "MWS network configuration ID in use (created here or passed in)."
  value       = local.effective_network_id
}

output "private_access_settings_id" {
  description = "Private access settings ID attached to the workspace (created here or passed in); null when PrivateLink is disabled."
  value       = local.effective_private_access_settings_id
}

output "rest_api_databricks_vpc_endpoint_id" {
  description = "Databricks-side registration ID of the REST API VPC endpoint; null when PL is off or the network config is referenced."
  value       = try(databricks_mws_vpc_endpoint.backend_rest[0].vpc_endpoint_id, null)
}

output "dataplane_relay_databricks_vpc_endpoint_id" {
  description = "Databricks-side registration ID of the SCC relay VPC endpoint; null when PL is off or the network config is referenced."
  value       = try(databricks_mws_vpc_endpoint.backend_relay[0].vpc_endpoint_id, null)
}

output "managed_services_cmk_id" {
  description = "Databricks CMK registration ID for managed services in use (created here or passed in); null when enable_cmk is false."
  value       = var.enable_cmk ? coalesce(var.managed_services_customer_managed_key_id, try(databricks_mws_customer_managed_keys.managed_services[0].customer_managed_key_id, null)) : null
}

output "storage_cmk_id" {
  description = "Databricks CMK registration ID for workspace storage in use (created here or passed in); null when enable_cmk is false."
  value       = var.enable_cmk ? coalesce(var.storage_customer_managed_key_id, try(databricks_mws_customer_managed_keys.workspace_storage[0].customer_managed_key_id, null)) : null
}

output "metastore_id" {
  description = "Unity Catalog metastore ID assigned to the workspace."
  value       = data.databricks_metastore.existing.metastore_id
}

output "ncc_id" {
  description = "Network Connectivity Config ID bound to the workspace (created here or passed in); null when disabled."
  value       = local.effective_ncc_id
}

output "account_network_policy_id" {
  description = "Account network policy ID bound to the workspace; null when disabled."
  value       = var.enable_account_network_policy ? local.effective_network_policy_id : null
}

output "csp_enabled" {
  description = "Whether the Compliance Security Profile is enabled (driven solely by compliance_standards being non-empty)."
  value       = length(coalesce(var.compliance_standards, [])) > 0
}

# -----------------------------------------------------------------------------
# Evidence / handover: every AWS reference this module consumed, echoed back.
# Nothing in this map was created by this module.
# -----------------------------------------------------------------------------

output "consumed_aws_resources" {
  description = "Echo of all infra-team AWS inputs registered with Databricks, for handover and evidence capture."
  value = {
    aws_region                          = var.aws_region
    vpc_id                              = var.vpc_id
    private_subnet_ids                  = var.private_subnet_ids
    workspace_security_group_ids        = var.workspace_security_group_ids
    root_bucket_name                    = var.root_bucket_name
    cross_account_role_arn              = var.cross_account_role_arn
    rest_api_aws_vpc_endpoint_id        = var.rest_api_aws_vpc_endpoint_id
    dataplane_relay_aws_vpc_endpoint_id = var.dataplane_relay_aws_vpc_endpoint_id
    managed_services_kms_key_arn        = var.managed_services_kms_key_arn
    workspace_storage_kms_key_arn       = var.workspace_storage_kms_key_arn
  }
}

output "workspace_info" {
  description = "Summary of the deployed workspace."
  value = {
    workspace_id   = databricks_mws_workspaces.this.workspace_id
    workspace_url  = databricks_mws_workspaces.this.workspace_url
    aws_region     = var.aws_region
    private_link   = var.enable_private_link
    cmk_enabled    = var.enable_cmk
    ncc_enabled    = var.enable_network_connectivity_config
    csp_enabled    = length(coalesce(var.compliance_standards, [])) > 0
    network_policy = var.enable_account_network_policy
    metastore_name = var.metastore_name
  }
}
