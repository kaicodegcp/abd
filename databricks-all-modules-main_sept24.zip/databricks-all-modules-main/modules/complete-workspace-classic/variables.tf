# =============================================================================
# Variables - Classic Workspace (Databricks-only, standalone)
#
# Every AWS object is created by the infra team and passed here as a pure
# reference parameter. This module never creates, reads, or modifies any AWS
# resource - the AWS provider is not required.
# =============================================================================

# -----------------------------------------------------------------------------
# Identity / common
# -----------------------------------------------------------------------------

variable "databricks_account_id" {
  description = "Databricks account ID (from the account console)."
  type        = string
}

variable "workspace_name" {
  description = "Base name for the workspace and the Databricks-side configuration objects. A random 6-character suffix is appended for uniqueness."
  type        = string
}

variable "deployment_name" {
  description = "Deployment name for the workspace URL (<deployment_name>.cloud.databricks.com). Must be enabled on the Databricks account. Keep it deterministic per region so DR mapping and stable URLs work. Null lets Databricks generate one."
  type        = string
  default     = null
}

variable "aws_region" {
  description = "AWS region of the infra-team-provided network and storage (e.g. us-east-1, us-east-2)."
  type        = string
}

variable "pricing_tier" {
  description = "Workspace pricing tier."
  type        = string
  default     = "ENTERPRISE"

  validation {
    condition     = contains(["STANDARD", "PREMIUM", "ENTERPRISE"], var.pricing_tier)
    error_message = "pricing_tier must be STANDARD, PREMIUM, or ENTERPRISE."
  }
}

variable "tags" {
  description = "Custom tags applied to the workspace."
  type        = map(string)
  default     = {}
}

# -----------------------------------------------------------------------------
# Network (infra team) - registered as the workspace network configuration
# -----------------------------------------------------------------------------

variable "networks_id" {
  description = "ID of an existing MWS network configuration pre-registered for THIS workspace (network configs are single-use, one workspace each). When set, this module creates no network config and no backend VPCe registrations, and vpc_id / private_subnet_ids / workspace_security_group_ids / the two VPCe IDs are not needed."
  type        = string
  default     = null
}

variable "vpc_id" {
  description = "ID of the infra-team VPC hosting the Classic compute plane. Required unless networks_id is set."
  type        = string
  default     = null

  validation {
    condition     = var.vpc_id == null ? true : can(regex("^vpc-[a-f0-9]{8,}$", var.vpc_id))
    error_message = "vpc_id must look like vpc-xxxxxxxx."
  }
}

variable "private_subnet_ids" {
  description = "Private subnet IDs for cluster nodes. At least 2, in different AZs (AZ separation is an infra-team contract; it cannot be verified here without the AWS provider). Required unless networks_id is set."
  type        = list(string)
  default     = null

  validation {
    condition     = var.private_subnet_ids == null ? true : length(var.private_subnet_ids) >= 2
    error_message = "Databricks requires at least 2 private subnets in different AZs."
  }

  validation {
    condition     = var.private_subnet_ids == null ? true : alltrue([for s in var.private_subnet_ids : can(regex("^subnet-[a-f0-9]{8,}$", s))])
    error_message = "Every entry must look like subnet-xxxxxxxx."
  }
}

variable "workspace_security_group_ids" {
  description = "Security group IDs for the workspace data plane (with the Databricks-required internode and egress rules already applied by the infra team). Required unless networks_id is set."
  type        = list(string)
  default     = null

  validation {
    condition     = var.workspace_security_group_ids == null ? true : length(var.workspace_security_group_ids) >= 1
    error_message = "At least one workspace security group ID is required."
  }

  validation {
    condition     = var.workspace_security_group_ids == null ? true : alltrue([for sg in var.workspace_security_group_ids : can(regex("^sg-[a-f0-9]{8,}$", sg))])
    error_message = "Every entry must look like sg-xxxxxxxx."
  }
}

# -----------------------------------------------------------------------------
# Storage (infra team)
# -----------------------------------------------------------------------------

variable "storage_configurations_id" {
  description = "ID of an existing MWS storage configuration to use. When set, no storage configuration is created and root_bucket_name is not needed."
  type        = string
  default     = null
}

variable "root_bucket_name" {
  description = "Name of the S3 root (DBFS) bucket. The infra team must have attached the Databricks bucket policy (Grant Databricks Access with the DatabricksAccountId principal-tag condition) before this module runs. Required unless storage_configurations_id is set."
  type        = string
  default     = null

  validation {
    condition     = var.root_bucket_name == null ? true : can(regex("^[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]$", var.root_bucket_name))
    error_message = "root_bucket_name must be a valid S3 bucket name."
  }
}

# -----------------------------------------------------------------------------
# IAM (infra team)
# -----------------------------------------------------------------------------

variable "credentials_id" {
  description = "ID of an existing MWS credentials configuration to use (credentials configs are reusable across workspaces). When set, no credentials configuration is created and cross_account_role_arn is not needed."
  type        = string
  default     = null
}

variable "cross_account_role_arn" {
  description = "ARN of the cross-account IAM role the infra team created for Databricks (trusts the Databricks account with external ID = databricks_account_id and carries the Databricks cross-account policy). The role must already exist and have propagated. Required unless credentials_id is set."
  type        = string
  default     = null

  validation {
    condition     = var.cross_account_role_arn == null ? true : can(regex("^arn:aws[a-zA-Z-]*:iam::[0-9]{12}:role/.+$", var.cross_account_role_arn))
    error_message = "cross_account_role_arn must be a valid IAM role ARN."
  }
}

# -----------------------------------------------------------------------------
# PrivateLink (infra team creates the AWS VPC endpoints; this module registers them)
# -----------------------------------------------------------------------------

variable "enable_private_link" {
  description = "Register infra-team backend VPC endpoints and attach private access settings to the workspace. SECURE BY DEFAULT: on - set false explicitly to deploy without PrivateLink."
  type        = bool
  default     = true
}

variable "rest_api_aws_vpc_endpoint_id" {
  description = "AWS VPC endpoint ID for the Databricks workspace (REST API) backend service. Required when enable_private_link is true."
  type        = string
  default     = null

  validation {
    condition     = var.rest_api_aws_vpc_endpoint_id == null || can(regex("^vpce-[a-f0-9]{8,}$", var.rest_api_aws_vpc_endpoint_id))
    error_message = "rest_api_aws_vpc_endpoint_id must look like vpce-xxxxxxxx."
  }
}

variable "dataplane_relay_aws_vpc_endpoint_id" {
  description = "AWS VPC endpoint ID for the Databricks SCC relay backend service. Required when enable_private_link is true."
  type        = string
  default     = null

  validation {
    condition     = var.dataplane_relay_aws_vpc_endpoint_id == null || can(regex("^vpce-[a-f0-9]{8,}$", var.dataplane_relay_aws_vpc_endpoint_id))
    error_message = "dataplane_relay_aws_vpc_endpoint_id must look like vpce-xxxxxxxx."
  }
}

variable "private_access_settings_id" {
  description = "ID of an existing MWS private access settings object to attach. When null and enable_private_link is true, this module creates one."
  type        = string
  default     = null
}

variable "public_access_enabled" {
  description = "Whether the workspace front end stays reachable from the public internet when PrivateLink is enabled (used only when this module creates the private access settings). SECURE BY DEFAULT: false (VPCE-only) - set true explicitly for the hybrid posture."
  type        = bool
  default     = false
}

variable "private_access_level" {
  description = "Private access level for the private access settings created by this module: ACCOUNT or ENDPOINT."
  type        = string
  default     = "ACCOUNT"

  validation {
    condition     = contains(["ACCOUNT", "ENDPOINT"], var.private_access_level)
    error_message = "private_access_level must be ACCOUNT or ENDPOINT."
  }
}

# -----------------------------------------------------------------------------
# Customer-managed keys (infra team creates the KMS keys; this module registers them)
# -----------------------------------------------------------------------------

variable "enable_cmk" {
  description = "Use Databricks customer-managed keys for managed services and workspace storage (registered here from KMS ARNs/aliases, or referenced via the *_customer_managed_key_id variables). SECURE BY DEFAULT: on - set false explicitly to deploy without CMK."
  type        = bool
  default     = true
}

variable "managed_services_customer_managed_key_id" {
  description = "ID of an existing Databricks CMK registration for managed services (CMK registrations are reusable across workspaces). When set, no registration is created and the managed services KMS ARN/alias are not needed."
  type        = string
  default     = null
}

variable "storage_customer_managed_key_id" {
  description = "ID of an existing Databricks CMK registration for workspace storage. When set, no registration is created and the storage KMS ARN/alias are not needed."
  type        = string
  default     = null
}

variable "managed_services_kms_key_arn" {
  description = "KMS key ARN for managed services encryption (key policy must already allow the Databricks principals). Required when enable_cmk is true."
  type        = string
  default     = null

  validation {
    condition     = var.managed_services_kms_key_arn == null || can(regex("^arn:aws[a-zA-Z-]*:kms:", var.managed_services_kms_key_arn))
    error_message = "managed_services_kms_key_arn must be a KMS key ARN."
  }
}

variable "managed_services_kms_key_alias" {
  description = "KMS key alias for managed services encryption. Required when enable_cmk is true."
  type        = string
  default     = null
}

variable "workspace_storage_kms_key_arn" {
  description = "KMS key ARN for workspace storage (root bucket + EBS) encryption (key policy must already allow the Databricks principals and the cross-account role for EBS). Required when enable_cmk is true."
  type        = string
  default     = null

  validation {
    condition     = var.workspace_storage_kms_key_arn == null || can(regex("^arn:aws[a-zA-Z-]*:kms:", var.workspace_storage_kms_key_arn))
    error_message = "workspace_storage_kms_key_arn must be a KMS key ARN."
  }
}

variable "workspace_storage_kms_key_alias" {
  description = "KMS key alias for workspace storage encryption. Required when enable_cmk is true."
  type        = string
  default     = null
}

# -----------------------------------------------------------------------------
# Unity Catalog
# -----------------------------------------------------------------------------

variable "metastore_name" {
  description = "Name of the existing regional Unity Catalog metastore to assign the workspace to (one per region: us-east-1 / us-east-2)."
  type        = string
}

# -----------------------------------------------------------------------------
# Network Connectivity Config (optional, Databricks-side)
# -----------------------------------------------------------------------------

variable "enable_network_connectivity_config" {
  description = "Bind a Network Connectivity Config to the workspace (created here, or an existing one via network_connectivity_config_id). WARNING: the binding is IRREVERSIBLE (swap-only, no detach - recovery means rebuilding the workspace), and a freshly created NCC may carry empty egress default_rules; verify the NCC's rules before binding, and never bind another team's NCC. On DR-paired workspaces, NCC binding was observed to break table-data replication."
  type        = bool
  default     = false
}

variable "network_connectivity_config_id" {
  description = "ID of an existing NCC (same region) to bind instead of creating one - NCCs are shareable across workspaces and accounts have a per-region NCC quota. When null and NCC is enabled, this module creates one."
  type        = string
  default     = null
}

variable "ncc_nlb_vpc_endpoint_service_name" {
  description = "AWS VPC endpoint service name of an infra-team internal NLB (e.g. com.amazonaws.vpce.us-east-1.vpce-svc-xxxxxxxx). Required at apply when ncc_nlb_domain_names is non-empty."
  type        = string
  default     = null
}

variable "ncc_nlb_domain_names" {
  description = "FQDNs reachable via the NLB. When non-empty, creates the NCC private endpoint rule."
  type        = list(string)
  default     = []
}

# -----------------------------------------------------------------------------
# Workspace security hardening (optional, workspace provider)
# -----------------------------------------------------------------------------

variable "configure_workspace_security" {
  description = "Apply the hardened workspace security settings after the workspace is up."
  type        = bool
  default     = true
}

variable "workspace_api_warmup_duration" {
  description = "Wait after workspace creation before applying workspace-level settings - the settings APIs of a freshly provisioned workspace return 'temporarily unavailable' for the first minutes."
  type        = string
  default     = "180s"
}

variable "max_token_lifetime_days" {
  description = "Maximum personal access token lifetime in days. Must be >= 1: the platform treats 0 as UNLIMITED lifetime, which would silently disable the cap."
  type        = number
  default     = 90

  validation {
    condition     = var.max_token_lifetime_days >= 1
    error_message = "max_token_lifetime_days must be >= 1 - the platform interprets 0 as UNLIMITED token lifetime (fail-open)."
  }
}

variable "enable_ip_access_lists" {
  description = "Arm the IP access lists feature. NOTE: has no blocking effect until ALLOW lists are actually created (workspace admin or separate automation) - this only enables the enforcement framework."
  type        = bool
  default     = true
}

variable "enable_verbose_audit_logs" {
  description = "Verbose audit logs (notebook-command-level telemetry). OFF by default per client requirement (log volume); note the SRA recommends on - set true to restore the fuller telemetry."
  type        = bool
  default     = false
}

variable "enable_web_terminal" {
  description = "Allow the cluster web terminal."
  type        = bool
  default     = false
}

variable "restrict_workspace_admins_status" {
  description = "Restriction status for workspace admins: ALLOW_ALL or RESTRICT_TOKENS_AND_JOB_RUN_AS."
  type        = string
  default     = "RESTRICT_TOKENS_AND_JOB_RUN_AS"

  validation {
    condition     = contains(["ALLOW_ALL", "RESTRICT_TOKENS_AND_JOB_RUN_AS"], var.restrict_workspace_admins_status)
    error_message = "restrict_workspace_admins_status must be ALLOW_ALL or RESTRICT_TOKENS_AND_JOB_RUN_AS."
  }
}

variable "additional_workspace_config" {
  description = "Extra workspace_conf key/value pairs. May NOT override the module-managed hardening keys - overriding them here would silently defeat the hardened posture."
  type        = map(string)
  default     = {}

  validation {
    condition = length(setintersection(keys(var.additional_workspace_config), toset([
      "enableVerboseAuditLogs", "enableDbfsFileBrowser", "enforceUserIsolation",
      "storeInteractiveNotebookResultsInCustomerAccount", "enableUploadDataUis",
      "enableIpAccessLists", "enableWebTerminal", "maxTokenLifetimeDays",
      "enableTokensConfig"
    ]))) == 0
    error_message = "additional_workspace_config must not override module-managed hardening keys (enableVerboseAuditLogs, enableDbfsFileBrowser, enforceUserIsolation, storeInteractiveNotebookResultsInCustomerAccount, enableUploadDataUis, enableIpAccessLists, enableWebTerminal, maxTokenLifetimeDays, enableTokensConfig) - use the dedicated variables instead."
  }
}

# -----------------------------------------------------------------------------
# Compliance Security Profile (optional, workspace provider)
# -----------------------------------------------------------------------------

variable "compliance_standards" {
  description = "List of compliance standards. THE single CSP control: a non-empty list enables the Compliance Security Profile with these standards; null or [] leaves CSP off (no separate enable flag - nothing can sit armed-but-empty). WARNING: CSP is IRREVERSIBLE once applied to a workspace. Valid values: https://pkg.go.dev/github.com/databricks/databricks-sdk-go/service/settings#ComplianceStandard"
  type        = list(string)
  default     = null
  nullable    = true

  validation {
    condition     = alltrue([for standard in coalesce(var.compliance_standards, []) : can(regex("^[A-Z0-9_]+$", standard))])
    error_message = "compliance_standards entries must be uppercase standard identifiers such as HIPAA or PCI_DSS."
  }
}

# -----------------------------------------------------------------------------
# Account network policy (optional) - egress + context-based ingress
# -----------------------------------------------------------------------------

variable "enable_account_network_policy" {
  description = "Create (or reuse) an account network policy and bind it to the workspace. SECURE BY DEFAULT: on - set false explicitly to deploy without egress control."
  type        = bool
  default     = true
}

variable "network_policy_id" {
  description = "ID of an existing account network policy to reuse. When set, no new policy is created - the existing policy is bound to the workspace directly."
  type        = string
  default     = null
}

variable "network_policy_egress" {
  description = "Egress network access configuration for the account network policy."
  type = object({
    network_access = object({
      restriction_mode = string
      allowed_internet_destinations = optional(list(object({
        destination               = string
        internet_destination_type = string
      })), [])
      allowed_storage_destinations = optional(list(object({
        bucket_name              = optional(string)
        region                   = optional(string)
        storage_destination_type = string
      })), [])
      policy_enforcement = optional(object({
        enforcement_mode = string
      }))
    })
  })
  default = null
}

variable "network_policy_public_access" {
  description = "Context-based ingress policy for public internet traffic. restriction_mode: FULL_ACCESS or RESTRICTED_ACCESS."
  type = object({
    restriction_mode = string
    allow_rules = optional(list(object({
      label = optional(string)
      authentication = optional(object({
        identity_type = optional(string)
        identities = optional(list(object({
          principal_id   = optional(number)
          principal_type = optional(string)
        })), [])
      }))
      destination = optional(object({
        all_destinations = optional(bool)
        workspace_ui     = optional(object({ all_destinations = optional(bool) }))
        workspace_api    = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        apps_runtime     = optional(object({ all_destinations = optional(bool) }))
        lakebase_runtime = optional(object({ all_destinations = optional(bool) }))
        account_api      = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        account_ui       = optional(object({ all_destinations = optional(bool) }))
      }))
      origin = optional(object({
        all_ip_ranges      = optional(bool)
        included_ip_ranges = optional(object({ ip_ranges = optional(list(string), []) }))
        excluded_ip_ranges = optional(object({ ip_ranges = optional(list(string), []) }))
      }))
    })), [])
    deny_rules = optional(list(object({
      label = optional(string)
      authentication = optional(object({
        identity_type = optional(string)
        identities = optional(list(object({
          principal_id   = optional(number)
          principal_type = optional(string)
        })), [])
      }))
      destination = optional(object({
        all_destinations = optional(bool)
        workspace_ui     = optional(object({ all_destinations = optional(bool) }))
        workspace_api    = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        apps_runtime     = optional(object({ all_destinations = optional(bool) }))
        lakebase_runtime = optional(object({ all_destinations = optional(bool) }))
        account_api      = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        account_ui       = optional(object({ all_destinations = optional(bool) }))
      }))
      origin = optional(object({
        all_ip_ranges      = optional(bool)
        included_ip_ranges = optional(object({ ip_ranges = optional(list(string), []) }))
        excluded_ip_ranges = optional(object({ ip_ranges = optional(list(string), []) }))
      }))
    })), [])
  })
  default = null
}

variable "network_policy_private_access" {
  description = "Context-based ingress policy for private connectivity (PrivateLink/registered endpoints). restriction_mode: ALLOW_ALL_REGISTERED_ENDPOINTS or RESTRICTED_ACCESS."
  type = object({
    restriction_mode = string
    allow_rules = optional(list(object({
      label = optional(string)
      authentication = optional(object({
        identity_type = optional(string)
        identities = optional(list(object({
          principal_id   = optional(number)
          principal_type = optional(string)
        })), [])
      }))
      destination = optional(object({
        all_destinations = optional(bool)
        workspace_ui     = optional(object({ all_destinations = optional(bool) }))
        workspace_api    = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        apps_runtime     = optional(object({ all_destinations = optional(bool) }))
        lakebase_runtime = optional(object({ all_destinations = optional(bool) }))
        account_api      = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        account_ui       = optional(object({ all_destinations = optional(bool) }))
      }))
      origin = optional(object({
        all_registered_endpoints = optional(bool)
        all_private_access       = optional(bool)
        endpoints                = optional(object({ endpoint_ids = optional(list(string), []) }))
      }))
    })), [])
    deny_rules = optional(list(object({
      label = optional(string)
      authentication = optional(object({
        identity_type = optional(string)
        identities = optional(list(object({
          principal_id   = optional(number)
          principal_type = optional(string)
        })), [])
      }))
      destination = optional(object({
        all_destinations = optional(bool)
        workspace_ui     = optional(object({ all_destinations = optional(bool) }))
        workspace_api    = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        apps_runtime     = optional(object({ all_destinations = optional(bool) }))
        lakebase_runtime = optional(object({ all_destinations = optional(bool) }))
        account_api      = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        account_ui       = optional(object({ all_destinations = optional(bool) }))
      }))
      origin = optional(object({
        all_registered_endpoints = optional(bool)
        all_private_access       = optional(bool)
        endpoints                = optional(object({ endpoint_ids = optional(list(string), []) }))
      }))
    })), [])
  })
  default = null
}

variable "network_policy_cross_workspace_access" {
  description = "Context-based ingress policy for cross-workspace traffic within the same account. restriction_mode: FULL_ACCESS or RESTRICTED_ACCESS."
  type = object({
    restriction_mode = string
    allow_rules = optional(list(object({
      label = optional(string)
      authentication = optional(object({
        identity_type = optional(string)
        identities = optional(list(object({
          principal_id   = optional(number)
          principal_type = optional(string)
        })), [])
      }))
      destination = optional(object({
        all_destinations = optional(bool)
        workspace_ui     = optional(object({ all_destinations = optional(bool) }))
        workspace_api    = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        apps_runtime     = optional(object({ all_destinations = optional(bool) }))
        lakebase_runtime = optional(object({ all_destinations = optional(bool) }))
        account_api      = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        account_ui       = optional(object({ all_destinations = optional(bool) }))
      }))
      origin = optional(object({
        all_source_workspaces = optional(bool)
        selected_workspaces   = optional(object({ workspace_ids = optional(list(number), []) }))
      }))
    })), [])
    deny_rules = optional(list(object({
      label = optional(string)
      authentication = optional(object({
        identity_type = optional(string)
        identities = optional(list(object({
          principal_id   = optional(number)
          principal_type = optional(string)
        })), [])
      }))
      destination = optional(object({
        all_destinations = optional(bool)
        workspace_ui     = optional(object({ all_destinations = optional(bool) }))
        workspace_api    = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        apps_runtime     = optional(object({ all_destinations = optional(bool) }))
        lakebase_runtime = optional(object({ all_destinations = optional(bool) }))
        account_api      = optional(object({ scope_qualifier = optional(string), scopes = optional(list(string), []) }))
        account_ui       = optional(object({ all_destinations = optional(bool) }))
      }))
      origin = optional(object({
        all_source_workspaces = optional(bool)
        selected_workspaces   = optional(object({ workspace_ids = optional(list(number), []) }))
      }))
    })), [])
  })
  default = null
}

# -----------------------------------------------------------------------------
# Audit log delivery (optional) - ACCOUNT-LEVEL SINGLETON: log delivery
# configurations are account-wide, so enable this in exactly ONE wrapper
# instance per account (not per workspace), or duplicates are created.
# -----------------------------------------------------------------------------

variable "enable_audit_log_delivery" {
  description = "Create the account audit-log delivery configuration (credentials + storage config + log delivery). Account-level singleton: enable in exactly one wrapper instance per account."
  type        = bool
  default     = false
}

variable "audit_log_delivery_bucket_name" {
  description = "Infra-team S3 bucket for audit log delivery, with the Databricks log-delivery bucket policy attached. Required when enable_audit_log_delivery is true."
  type        = string
  default     = null
}

variable "audit_log_delivery_role_arn" {
  description = "Infra-team IAM role for audit log delivery (Databricks log-delivery trust with for_log_delivery external id). Required when enable_audit_log_delivery is true."
  type        = string
  default     = null

  validation {
    condition     = var.audit_log_delivery_role_arn == null ? true : can(regex("^arn:aws[a-zA-Z-]*:iam::[0-9]{12}:role/.+$", var.audit_log_delivery_role_arn))
    error_message = "audit_log_delivery_role_arn must be a valid IAM role ARN."
  }
}
