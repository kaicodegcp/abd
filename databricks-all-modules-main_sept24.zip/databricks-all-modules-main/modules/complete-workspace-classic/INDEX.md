# complete-workspace-classic

Standalone Terraform module that brings a **Classic (customer-managed VPC) Databricks
workspace on AWS** up and running using **only `databricks_*` resources**. Every AWS
object is created by the infra team and passed in as a pure input parameter - this
module never creates, reads, or modifies anything in AWS, and the AWS provider is not
required. There are no external or relative module sources: copy this folder anywhere
and it works.

## Security posture: secure by default

`enable_private_link`, `enable_cmk`, and `enable_account_network_policy` default
to **true**, and `public_access_enabled` defaults to **false** (VPCE-only front
end). A minimal apply therefore FAILS at plan until the caller either supplies
the security inputs or explicitly opts out with `= false` - every insecure
deployment is a visible, reviewable decision in tfvars. CSP has a SINGLE
control: a non-empty `compliance_standards` list enables it with those
standards; null/[] (the default) leaves it off - there is no separate enable
flag, so nothing can sit armed-but-empty. WARNING: CSP is IRREVERSIBLE per
workspace; provide standards only when the decision is final. One
deliberate exception: `enable_audit_log_delivery` stays false (account-level
singleton - enable in exactly one wrapper instance per account, not per
workspace).
The network policy is FAIL-CLOSED: with `enable_account_network_policy` on, a
plan-time precondition demands `network_policy_egress` (or a `network_policy_id`
reference, or an explicit opt-out) - an armed-but-empty policy cannot be
created. `enable_ip_access_lists` defaults true (note: it blocks nothing until
ALLOW lists are actually created); `enable_verbose_audit_logs` defaults FALSE per
client requirement (log volume) - the SRA recommends true.

## What it creates (all Databricks-side)

| Resource | Purpose | Condition |
|---|---|---|
| `databricks_mws_credentials` | Registers the infra-team cross-account IAM role | always |
| `databricks_mws_storage_configurations` | Registers the infra-team S3 root bucket | always |
| `databricks_mws_networks` | Registers the infra-team VPC / subnets / security groups | always |
| `databricks_mws_vpc_endpoint` x2 | Registers the infra-team backend REST + SCC relay AWS VPC endpoints | `enable_private_link` |
| `databricks_mws_private_access_settings` | Private access settings (or pass `private_access_settings_id`) | `enable_private_link` |
| `databricks_mws_customer_managed_keys` x2 | Registers the infra-team KMS keys (managed services + storage) | `enable_cmk` |
| `databricks_mws_workspaces` | The Classic workspace | always |
| `databricks_mws_network_connectivity_config` + `databricks_mws_ncc_binding` (+ optional NLB private endpoint rule) | Serverless egress control | `enable_network_connectivity_config` |
| `databricks_metastore_assignment` | Assigns the workspace to the existing regional metastore (looked up by name) | always |
| `databricks_workspace_setting_v2` / `databricks_workspace_conf` / `databricks_restrict_workspace_admins_setting` | Hardened workspace security settings | `configure_workspace_security` |
| `databricks_compliance_security_profile_workspace_setting` | Compliance Security Profile (irreversible) | non-empty `compliance_standards` |
| `databricks_account_network_policy` + `databricks_workspace_network_option` | Egress restrictions + **context-based ingress** (public / private / cross-workspace), or bind `network_policy_id` | `enable_account_network_policy` |

**Out of scope by design:** groups/users, cluster policies, IP access lists,
catalogs/schemas, audit-log delivery, DR. DR is managed separately by mapping the
per-region workspaces via this module's `workspace_id` / `workspace_url` /
`deployment_name` outputs.

## Dependencies - what must exist BEFORE using this module

The module creates nothing outside Databricks, so everything it consumes must
pre-exist. Three dependency classes:

### 1. Always required (any mode)

| Dependency | Owner | Requirement |
|---|---|---|
| Databricks account | platform | Account ID; the account must allow workspace creation in the target region |
| Account-admin service principal | platform | OAuth client ID/secret with account-admin, wired into the `databricks.account` provider (env `DATABRICKS_CLIENT_ID`/`DATABRICKS_CLIENT_SECRET`) |
| Unity Catalog **metastore** in the target region | platform | Referenced by `metastore_name` - the module NEVER creates it; one per region, must exist before the first apply |
| Cluster launch path (to actually run compute) | infra team | Either NAT egress or the full private set: backend PL endpoints + STS + Kinesis interface endpoints + S3 gateway endpoint on the private route tables. Workspace creation succeeds without this, cluster launch does not |

### 2. Per-object decision table: reference it, or let the module create it

Every MWS object follows one rule - **pass the reference ID and it must pre-exist;
omit it and the module creates it, which moves the dependency to the raw AWS
inputs behind it** (those must then pre-exist instead). The module never creates
anything on AWS: even in create mode it only *registers* infra-team AWS objects
with Databricks.

| Object | Reference ID passed → must pre-exist as | ID omitted → module creates it FROM (these must pre-exist) |
|---|---|---|
| Credentials config | `credentials_id` - MWS credentials config (reusable across workspaces) | `cross_account_role_arn` - IAM role trusting the Databricks principal with `sts:ExternalId` = account ID + the cross-account EC2 policy; propagated (fresh roles can fail one apply - rerun) |
| Storage config | `storage_configurations_id` - MWS storage config | `root_bucket_name` - S3 bucket **with the Databricks bucket policy attached** (`aws:PrincipalTag/DatabricksAccountId` condition) |
| Network config | `networks_id` - MWS network config **pre-registered for THIS workspace** (single-use; built from VPCe *registration* IDs - an AWS VPCe registers only once) | `vpc_id` + `private_subnet_ids` (>= 2, distinct AZs, DNS on) + `workspace_security_group_ids` (internode self rules + control-plane egress 443/2443/5432/6666/8443-8451 + 443 to S3 prefix list); with PL also the two raw VPCe IDs below - the module then registers them too |
| Backend VPCe registrations | (implicit in a referenced `networks_id`) | `rest_api_aws_vpc_endpoint_id` + `dataplane_relay_aws_vpc_endpoint_id` - interface endpoints to the **regional** workspace + SCC relay services, private DNS on, PL SG admitting the backend ports from the workspace SG (gated by `enable_private_link`) |
| PAS | `private_access_settings_id` - MWS PAS (shareable) | nothing external - created from `public_access_enabled` / `private_access_level` (gated by `enable_private_link`) |
| CMK registrations | `managed_services_customer_managed_key_id` + `storage_customer_managed_key_id` (shareable) | KMS ARN/alias pairs - key policies must allow the Databricks principals (Encrypt/Decrypt for managed services; data-key use + `kms:CreateGrant` via `kms:ViaService ec2` for the cross-account role on the storage key) (gated by `enable_cmk`) |
| NCC | `network_connectivity_config_id` - NCC in the same region (shareable; **quota 10/region** - referencing a shared NCC is the recommended pattern) | nothing external - created by name (gated by `enable_network_connectivity_config`; counts against the quota) |
| Account network policy | `network_policy_id` - account policy (shareable; its workspace binding does NOT detach on destroy - reset the workspace to `default-policy` before deleting a policy) | nothing external - created from `network_policy_egress` + the three context-based ingress objects (gated by `enable_account_network_policy`) |
| Audit log delivery | - (no reference form) | `audit_log_delivery_bucket_name` + `audit_log_delivery_role_arn` - infra-team bucket with the Databricks log-delivery policy and role with the log-delivery trust (gated by `enable_audit_log_delivery`; ACCOUNT-LEVEL SINGLETON - one instance per account) |
| Metastore | `metastore_name` - **always referenced, never created**; the one object with no create path | - |

Rule of thumb: shareable objects (credentials, PAS, CMK registrations, NCC,
network policy) are usually *referenced* in a multi-workspace setup and
*created* only by the first/owning stack; the network config is always
per-workspace either way; storage config is usually created (one root bucket
per workspace).

## Providers

The caller passes two aliased Databricks providers:

```hcl
provider "databricks" {
  alias      = "account"
  host       = "https://accounts.cloud.databricks.com"
  account_id = var.databricks_account_id
  # auth: DATABRICKS_CLIENT_ID / DATABRICKS_CLIENT_SECRET env vars
}

provider "databricks" {
  alias = "workspace"
  host  = module.classic_workspace.workspace_url
}
```

## Usage

See `examples/two-region/` - one stack, applied once per region with
`us-east-1.tfvars` / `us-east-2.tfvars` (separate state per region, matching the
standard two-region pipeline orchestration). All region differences live in tfvars.

## Notes

- `workspace_name` gets a random 6-character suffix for uniqueness; pass
  `deployment_name` when you need deterministic workspace URLs (stable-URL / DR
  mapping).
- CSP (non-empty `compliance_standards`) is irreversible on a workspace - enable deliberately.
- Toggling `configure_workspace_security` from true to false removes the managed
  security settings resources from state (settings themselves keep their last value
  server-side, except `databricks_workspace_conf` keys which are best-effort reset by
  the provider).
- Context-based ingress: set the three `network_policy_*_access` objects
  (restriction mode + allow/deny rules on authentication / destination / origin)
  together with `network_policy_egress`, and `enable_account_network_policy = true`.
