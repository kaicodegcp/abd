terraform {
  required_version = ">= 1.6.0"

  required_providers {
    databricks = {
      source                = "databricks/databricks"
      version               = ">= 1.106.0"
      configuration_aliases = [databricks.account, databricks.workspace]
    }
    random = {
      source  = "hashicorp/random"
      version = ">= 3.0"
    }
    time = {
      source  = "hashicorp/time"
      version = ">= 0.9"
    }
  }
}
