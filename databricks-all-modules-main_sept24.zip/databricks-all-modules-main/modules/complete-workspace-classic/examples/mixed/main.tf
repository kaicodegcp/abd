# =============================================================================
# Example - MIXED mode: the common real-world split.
#
# REFERENCED (shared platform objects, exist already):
#   - credentials config (one cross-account role registration for the account)
#   - NCC (shared per region - per-region quota makes creating one per
#     workspace a bad idea)
#   - PAS (shared PrivateLink posture)
#   - account network policy (one shared policy bound to many workspaces)
#   - metastore (always)
#
# CREATED by the module (per-workspace objects, from raw infra-team values):
#   - storage config (this workspace's own root bucket)
#   - network config + backend VPCe registrations (network configs are
#     single-use anyway)
#   - CMK registrations (this workspace's KMS keys)
# =============================================================================

terraform {
  required_version = ">= 1.6.0"

  required_providers {
    databricks = {
      source  = "databricks/databricks"
      version = ">= 1.106.0"
    }
  }
}

variable "databricks_account_id" { type = string }

provider "databricks" {
  alias      = "account"
  host       = "https://accounts.cloud.databricks.com"
  account_id = var.databricks_account_id
}

provider "databricks" {
  alias = "workspace"
  host  = module.classic_workspace.workspace_url
}

module "classic_workspace" {
  source = "../.."

  providers = {
    databricks.account   = databricks.account
    databricks.workspace = databricks.workspace
  }

  databricks_account_id = var.databricks_account_id
  workspace_name        = "acme-analytics-use1"
  aws_region            = "us-east-1"
  tags                  = { Environment = "prod" }

  # --- REFERENCED: shared platform objects ---
  credentials_id = "11111111-2222-3333-4444-555555555555"

  enable_network_connectivity_config = true
  network_connectivity_config_id     = "11111111-2222-3333-4444-bbbbbbbbbbbb"

  enable_private_link        = true
  private_access_settings_id = "11111111-2222-3333-4444-888888888888"

  enable_account_network_policy = true
  network_policy_id             = "acme-shared-np"

  metastore_name = "acme-metastore-us-east-1"

  # --- CREATED: per-workspace objects from raw infra-team values ---

  # Storage config from this workspace's root bucket
  root_bucket_name = "acme-analytics-root-123456789012"

  # Network config + backend VPCe registrations from the raw network values
  vpc_id                              = "vpc-0aaaabbbbccccdddd"
  private_subnet_ids                  = ["subnet-0aaaabbbbccccdddd", "subnet-0eeeeffff00001111"]
  workspace_security_group_ids        = ["sg-0aaaabbbbccccdddd"]
  rest_api_aws_vpc_endpoint_id        = "vpce-0aaaabbbbccccdddd"
  dataplane_relay_aws_vpc_endpoint_id = "vpce-0eeeeffff00001111"

  # CMK registrations from this workspace's KMS keys
  enable_cmk                      = true
  managed_services_kms_key_arn    = "arn:aws:kms:us-east-1:123456789012:key/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
  managed_services_kms_key_alias  = "alias/acme-analytics-managed-services"
  workspace_storage_kms_key_arn   = "arn:aws:kms:us-east-1:123456789012:key/ffffffff-0000-1111-2222-333333333333"
  workspace_storage_kms_key_alias = "alias/acme-analytics-workspace-storage"

  configure_workspace_security = true
}

output "workspace_url" {
  value = module.classic_workspace.workspace_url
}
