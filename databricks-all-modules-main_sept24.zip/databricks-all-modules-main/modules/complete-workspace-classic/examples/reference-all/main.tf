# =============================================================================
# Example - REFERENCE mode: every MWS object already exists and is passed as
# an ID. The module creates ONLY the workspace, its bindings/assignment, and
# the hardening settings.
#
# Where the IDs come from in this model:
#   - a central platform/registration layer owns credentials, storage, PAS,
#     CMK registrations, NCC, and the network policy (all shareable), and
#     pre-registers ONE network config per workspace (single-use)
#   - the metastore is the regional one (always referenced by name)
# =============================================================================

terraform {
  required_version = ">= 1.6.0"

  required_providers {
    databricks = {
      source  = "databricks/databricks"
      version = ">= 1.106.0"
    }
  }
}

variable "databricks_account_id" { type = string }

provider "databricks" {
  alias      = "account"
  host       = "https://accounts.cloud.databricks.com"
  account_id = var.databricks_account_id
}

provider "databricks" {
  alias = "workspace"
  host  = module.classic_workspace.workspace_url
}

module "classic_workspace" {
  source = "../.."

  providers = {
    databricks.account   = databricks.account
    databricks.workspace = databricks.workspace
  }

  databricks_account_id = var.databricks_account_id
  workspace_name        = "acme-prod-use1"
  aws_region            = "us-east-1"
  tags                  = { Environment = "prod" }

  # --- Everything below is a REFERENCE; the module creates none of it. ---

  # Reusable MWS configs (owned by the platform layer)
  credentials_id            = "11111111-2222-3333-4444-555555555555"
  storage_configurations_id = "11111111-2222-3333-4444-666666666666"

  # Network config: single-use - pre-registered specifically FOR this
  # workspace by the platform layer (raw VPC/subnet/SG/VPCe inputs not needed)
  networks_id = "11111111-2222-3333-4444-777777777777"

  # PrivateLink: shared PAS
  enable_private_link        = true
  private_access_settings_id = "11111111-2222-3333-4444-888888888888"

  # CMK: shared registrations (KMS ARNs/aliases not needed)
  enable_cmk                               = true
  managed_services_customer_managed_key_id = "11111111-2222-3333-4444-999999999999"
  storage_customer_managed_key_id          = "11111111-2222-3333-4444-aaaaaaaaaaaa"

  # NCC: shared regional NCC (per-region quota - referencing is preferred)
  enable_network_connectivity_config = true
  network_connectivity_config_id     = "11111111-2222-3333-4444-bbbbbbbbbbbb"

  # Account network policy: shared policy, bound to this workspace
  # (egress/ingress objects not needed when referencing)
  enable_account_network_policy = true
  network_policy_id             = "acme-shared-np"

  # Metastore: always referenced
  metastore_name = "acme-metastore-us-east-1"

  # Workspace hardening still applies in reference mode
  configure_workspace_security = true
}

output "workspace_url" {
  value = module.classic_workspace.workspace_url
}
