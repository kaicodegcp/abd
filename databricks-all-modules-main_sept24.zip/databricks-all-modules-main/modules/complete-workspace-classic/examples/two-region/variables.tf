# Passthrough variables for the two-region example. Values live in
# us-east-1.tfvars / us-east-2.tfvars.

variable "databricks_account_id" { type = string }
variable "workspace_name" { type = string }
variable "deployment_name" {
  type    = string
  default = null
}
variable "aws_region" { type = string }
variable "tags" {
  type    = map(string)
  default = {}
}

variable "vpc_id" { type = string }
variable "private_subnet_ids" { type = list(string) }
variable "workspace_security_group_ids" { type = list(string) }
variable "root_bucket_name" { type = string }
variable "cross_account_role_arn" { type = string }

variable "enable_private_link" {
  type    = bool
  default = true
}
variable "rest_api_aws_vpc_endpoint_id" {
  type    = string
  default = null
}
variable "dataplane_relay_aws_vpc_endpoint_id" {
  type    = string
  default = null
}
variable "public_access_enabled" {
  type    = bool
  default = false
}

variable "enable_cmk" {
  type    = bool
  default = true
}
variable "managed_services_kms_key_arn" {
  type    = string
  default = null
}
variable "managed_services_kms_key_alias" {
  type    = string
  default = null
}
variable "workspace_storage_kms_key_arn" {
  type    = string
  default = null
}
variable "workspace_storage_kms_key_alias" {
  type    = string
  default = null
}

variable "metastore_name" { type = string }

variable "configure_workspace_security" {
  type    = bool
  default = true
}
