# =============================================================================
# Example caller - CREATE mode: the module creates every MWS object from raw
# infra-team AWS values. See ../INDEX.md for the create-vs-reference matrix
# and ../reference-all / ../mixed for the other modes.
#
# Classic workspace, Databricks-only, one region per run.
#
# Deploy the same stack twice with different tfvars (us-east-1 / us-east-2),
# matching the standard two-region pipeline orchestration:
#   terraform apply -var-file=us-east-1.tfvars.example   (state: us-east-1)
#   terraform apply -var-file=us-east-2.tfvars.example   (state: us-east-2)
#
# Authentication (service principal, injected by the pipeline as env vars):
#   DATABRICKS_CLIENT_ID / DATABRICKS_CLIENT_SECRET
# =============================================================================

terraform {
  required_version = ">= 1.6.0"

  required_providers {
    databricks = {
      source  = "databricks/databricks"
      version = ">= 1.106.0"
    }
  }
}

provider "databricks" {
  alias      = "account"
  host       = "https://accounts.cloud.databricks.com"
  account_id = var.databricks_account_id
}

# Workspace-level provider for the post-creation security settings.
# The host comes straight from the module output.
provider "databricks" {
  alias = "workspace"
  host  = module.classic_workspace.workspace_url
}

module "classic_workspace" {
  source = "../.."

  providers = {
    databricks.account   = databricks.account
    databricks.workspace = databricks.workspace
  }

  # Identity / common
  databricks_account_id = var.databricks_account_id
  workspace_name        = var.workspace_name
  deployment_name       = var.deployment_name
  aws_region            = var.aws_region
  tags                  = var.tags

  # AWS references (all created by the infra team)
  vpc_id                       = var.vpc_id
  private_subnet_ids           = var.private_subnet_ids
  workspace_security_group_ids = var.workspace_security_group_ids
  root_bucket_name             = var.root_bucket_name
  cross_account_role_arn       = var.cross_account_role_arn

  # PrivateLink (AWS VPC endpoints created by the infra team)
  enable_private_link                 = var.enable_private_link
  rest_api_aws_vpc_endpoint_id        = var.rest_api_aws_vpc_endpoint_id
  dataplane_relay_aws_vpc_endpoint_id = var.dataplane_relay_aws_vpc_endpoint_id
  public_access_enabled               = var.public_access_enabled

  # CMK (KMS keys created by the infra team)
  enable_cmk                      = var.enable_cmk
  managed_services_kms_key_arn    = var.managed_services_kms_key_arn
  managed_services_kms_key_alias  = var.managed_services_kms_key_alias
  workspace_storage_kms_key_arn   = var.workspace_storage_kms_key_arn
  workspace_storage_kms_key_alias = var.workspace_storage_kms_key_alias

  # Unity Catalog
  metastore_name = var.metastore_name

  # Hardening
  configure_workspace_security = var.configure_workspace_security

  # Account network policy (on by default): restricted egress + explicit
  # context-based ingress. Add DR-mapped buckets to the storage allowlist
  # when this workspace joins a failover group.
  network_policy_egress = {
    network_access = {
      restriction_mode              = "RESTRICTED_ACCESS"
      allowed_internet_destinations = []
      allowed_storage_destinations  = []
      policy_enforcement            = { enforcement_mode = "ENFORCED" }
    }
  }

  network_policy_public_access = {
    restriction_mode = "FULL_ACCESS"
    # Lockdown shape:
    # restriction_mode = "RESTRICTED_ACCESS"
    # allow_rules = [{
    #   label       = "office-ips"
    #   destination = { all_destinations = true }
    #   origin      = { included_ip_ranges = { ip_ranges = ["x.x.x.x/32"] } }
    # }]
  }

  network_policy_private_access = {
    restriction_mode = "ALLOW_ALL_REGISTERED_ENDPOINTS"
  }

  network_policy_cross_workspace_access = {
    restriction_mode = "FULL_ACCESS"
  }
}

output "workspace_url" {
  value = module.classic_workspace.workspace_url
}

output "workspace_id" {
  value = module.classic_workspace.workspace_id
}

output "consumed_aws_resources" {
  value = module.classic_workspace.consumed_aws_resources
}
