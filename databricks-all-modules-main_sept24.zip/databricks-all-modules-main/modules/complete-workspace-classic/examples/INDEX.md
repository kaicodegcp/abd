# Examples - create vs. reference

Every MWS object this module needs follows one rule: **pass its ID to reference an
existing object, omit the ID to have the module create it** (the module then needs
the raw inputs for that object). The metastore is the exception - it must always
exist and is referenced by name.

| Object | Reference variable | Raw inputs when creating | Shareable across workspaces? |
|---|---|---|---|
| Credentials config | `credentials_id` | `cross_account_role_arn` | yes |
| Storage config | `storage_configurations_id` | `root_bucket_name` | yes (shared root bucket - allowed, usually one per workspace) |
| Network config (+ backend VPCe registrations) | `networks_id` | `vpc_id`, `private_subnet_ids`, `workspace_security_group_ids`, `rest_api_aws_vpc_endpoint_id`, `dataplane_relay_aws_vpc_endpoint_id` | NO - single-use, pre-register one per workspace |
| PAS | `private_access_settings_id` | `public_access_enabled`, `private_access_level` (gated by `enable_private_link`) | yes |
| CMK registrations | `managed_services_customer_managed_key_id`, `storage_customer_managed_key_id` | KMS ARN/alias pairs (gated by `enable_cmk`) | yes |
| NCC | `network_connectivity_config_id` | none (gated by `enable_network_connectivity_config`; per-region quota of NCCs - prefer referencing a shared one) | yes |
| Account network policy | `network_policy_id` | `network_policy_egress` + the three context-based ingress objects (gated by `enable_account_network_policy`) | yes |
| Metastore | `metastore_name` | - (always referenced, never created) | yes (one per region) |

## The three examples

- **`two-region/`** - CREATE mode: the module creates every MWS object from raw
  infra-team AWS values (bucket name, role ARN, VPC/subnets/SGs, VPCe IDs, KMS
  ARNs). The standard first-workspace-in-a-region shape, run once per region.
- **`reference-all/`** - REFERENCE mode: every object passed as an ID; the module
  creates only the workspace, its bindings/assignment, and the hardening settings.
  The shape for a platform-team model where a central registration layer owns all
  MWS objects.
- **`mixed/`** - the common real-world middle: shared platform objects referenced
  (credentials, NCC, PAS, network policy), per-workspace objects created (storage
  config, network config, CMK registrations).

Notes that apply to all modes:

- An AWS VPC endpoint can be registered with Databricks only once; a registration
  can back many network configs. When pre-registering network configs externally,
  reuse the registration IDs, not the raw `vpce-` IDs.
- Referencing leaves no trace in this state beyond the workspace attachment -
  destroying the workspace never touches referenced objects.
