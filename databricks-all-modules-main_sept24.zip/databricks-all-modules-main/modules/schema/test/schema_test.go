package test

import (
	"path/filepath"
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	common "github.com/sandbox45/databricks-all-modules/common"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func planSchemaModule(t *testing.T, vars map[string]interface{}) string {
	t.Helper()
	common.SkipIfShortMode(t, "schema module (plan)")
	common.RequireDatabricksEnv(t)

	opts := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: filepath.Join(".."),
		Vars:         vars,
		NoColor:      true,
	})
	terraform.Init(t, opts)
	plan := terraform.Plan(t, opts)
	require.NotEmpty(t, plan, "terraform plan should produce output")
	return plan
}

// Schema grants must target exactly the schema-read/write/owner personas, derived from app_id/app_acronym/schema name.
func TestSchemaModuleDerivedGroupNames(t *testing.T) {
	defaults := common.GetTestDefaults()

	plan := planSchemaModule(t, map[string]interface{}{
		"name":          "transactions",
		"catalog_name":  defaults.CatalogName,
		"environment":   "dev",
		"app_acronym":   "dms",
		"app_id":        "179392",
		"force_destroy": true,
	})

	assert.Contains(t, plan, "dbx-dev-179392-dms-schema-transactions-read-grp")
	assert.Contains(t, plan, "dbx-dev-179392-dms-schema-transactions-write-grp")
	assert.Contains(t, plan, "dbx-dev-179392-dms-schema-transactions-owner-grp")
}

// Additional caller-defined grants are created alongside — not instead of — the default persona grants.
func TestSchemaModuleAdditionalGrants(t *testing.T) {
	defaults := common.GetTestDefaults()

	plan := planSchemaModule(t, map[string]interface{}{
		"name":          "transactions",
		"catalog_name":  defaults.CatalogName,
		"environment":   "dev",
		"app_acronym":   "dms",
		"app_id":        "179392",
		"force_destroy": true,
		"additional_schema_grants": map[string]interface{}{
			"dbx-dev-179392-dms-auditor-grp": []string{"USE_SCHEMA", "SELECT"},
			"legacy-custom-group":            []string{"USE_SCHEMA", "SELECT", "EXECUTE"},
		},
	})

	// Default persona grants remain unchanged.
	assert.Contains(t, plan, "dbx-dev-179392-dms-schema-transactions-read-grp")
	assert.Contains(t, plan, "dbx-dev-179392-dms-schema-transactions-write-grp")
	assert.Contains(t, plan, "dbx-dev-179392-dms-schema-transactions-owner-grp")
	// Caller-defined grants are also planned, using the full group names supplied.
	assert.Contains(t, plan, "dbx-dev-179392-dms-auditor-grp")
	assert.Contains(t, plan, "legacy-custom-group")
}

func planSchemaModuleExpectError(t *testing.T, vars map[string]interface{}) string {
	t.Helper()
	common.SkipIfShortMode(t, "schema module (negative plan)")
	common.RequireDatabricksEnv(t)

	opts := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: filepath.Join(".."),
		Vars:         vars,
		NoColor:      true,
	})
	_, err := terraform.InitAndPlanE(t, opts)
	require.Error(t, err, "expected terraform plan to fail")
	// Terraform hard-wraps error messages across lines; collapse whitespace so
	// substring assertions do not depend on where the wrap falls.
	return strings.Join(strings.Fields(err.Error()), " ")
}

func externalUseVars(defaults common.TestDefaults) map[string]interface{} {
	return map[string]interface{}{
		"name":          "transactions",
		"catalog_name":  defaults.CatalogName,
		"environment":   "dev",
		"app_acronym":   "dms",
		"app_id":        "179392",
		"force_destroy": true,
	}
}

// The planned schema_external_use grant carries exactly USE_SCHEMA, SELECT, EXTERNAL_USE_SCHEMA
// (asserted on the resource's own privileges, order-independent — not on the overall plan text).
func TestSchemaModuleExternalUseSchemaGrant(t *testing.T) {
	common.SkipIfShortMode(t, "schema module (plan)")
	common.RequireDatabricksEnv(t)

	vars := externalUseVars(common.GetTestDefaults())
	vars["external_use_schema_principals"] = []string{"sp-starburst-external"}

	opts := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: filepath.Join(".."),
		Vars:         vars,
		NoColor:      true,
	})
	plan := terraform.InitAndPlanAndShowWithStructNoLogTempPlanFile(t, opts)

	addr := `databricks_grant.schema_external_use["sp-starburst-external"]`
	res, ok := plan.ResourcePlannedValuesMap[addr]
	require.True(t, ok, "expected planned resource %s", addr)

	rawPrivs, ok := res.AttributeValues["privileges"].([]interface{})
	require.True(t, ok, "privileges should be a list")
	got := make([]string, 0, len(rawPrivs))
	for _, p := range rawPrivs {
		got = append(got, p.(string))
	}
	assert.ElementsMatch(t, []string{"USE_SCHEMA", "SELECT", "EXTERNAL_USE_SCHEMA"}, got)
}

func TestSchemaModuleExternalUseBlankPrincipalRejected(t *testing.T) {
	vars := externalUseVars(common.GetTestDefaults())
	vars["external_use_schema_principals"] = []string{"  "}

	out := planSchemaModuleExpectError(t, vars)
	assert.Contains(t, out, "blank or whitespace-only")
}

func TestSchemaModuleExternalUseOverlapReadRejected(t *testing.T) {
	vars := externalUseVars(common.GetTestDefaults())
	vars["external_use_schema_principals"] = []string{"dbx-dev-179392-dms-schema-transactions-read-grp"}

	out := planSchemaModuleExpectError(t, vars)
	assert.Contains(t, out, "must not target the derived schema-read/write/owner persona groups")
}

func TestSchemaModuleExternalUseOverlapWriteRejected(t *testing.T) {
	vars := externalUseVars(common.GetTestDefaults())
	vars["external_use_schema_principals"] = []string{"dbx-dev-179392-dms-schema-transactions-write-grp"}

	out := planSchemaModuleExpectError(t, vars)
	assert.Contains(t, out, "must not target the derived schema-read/write/owner persona groups")
}

func TestSchemaModuleExternalUseOverlapOwnerRejected(t *testing.T) {
	vars := externalUseVars(common.GetTestDefaults())
	vars["external_use_schema_principals"] = []string{"dbx-dev-179392-dms-schema-transactions-owner-grp"}

	out := planSchemaModuleExpectError(t, vars)
	assert.Contains(t, out, "must not target the derived schema-read/write/owner persona groups")
}

func TestSchemaModuleExternalUseOverlapAdditionalRejected(t *testing.T) {
	vars := externalUseVars(common.GetTestDefaults())
	vars["additional_schema_grants"] = map[string]interface{}{
		"sp-shared": []string{"USE_SCHEMA", "SELECT"},
	}
	vars["external_use_schema_principals"] = []string{"sp-shared"}

	out := planSchemaModuleExpectError(t, vars)
	assert.Contains(t, out, "must not also be in additional_schema_grants")
}

func TestSchemaModule(t *testing.T) {
	defaults := common.GetTestDefaults()
	catalogName := defaults.CatalogName

	uniqueID := common.GenerateUniqueTestID("schema")

	config := common.ModuleTestConfig{
		ModuleName:      "schema",
		TestDescription: "Tests Databricks Unity Catalog schema module",
		RequiredVars: map[string]interface{}{
			"name":         uniqueID,
			"catalog_name": catalogName,
			"environment":  "dev",
			"app_acronym":  "dms",
			"app_id":       "179392",
		},
		OptionalVars: map[string]interface{}{
			"comment": "Test schema created by terratest",
			"properties": map[string]string{
				"environment": "test",
			},
			"force_destroy": true,
		},
		ExpectedOutputs: []string{
			"id",
			"name",
			"full_name",
			"grant_ids",
		},
	}

	common.TestModuleWithConfig(t, config)
}

func TestSchemaModuleWithStorageRoot(t *testing.T) {
	defaults := common.GetTestDefaults()
	catalogName := defaults.CatalogName

	uniqueID := common.GenerateUniqueTestID("schema-storage")

	config := common.ModuleTestConfig{
		ModuleName:      "schema",
		TestDescription: "Tests Databricks schema module with storage root",
		RequiredVars: map[string]interface{}{
			"name":         uniqueID,
			"catalog_name": catalogName,
			"environment":  "dev",
			"app_acronym":  "dms",
			"app_id":       "179392",
		},
		OptionalVars: map[string]interface{}{
			"comment":       "Schema with custom storage root",
			"force_destroy": true,
		},
		ExpectedOutputs: []string{
			"id",
			"name",
			"full_name",
			"grant_ids",
		},
	}

	common.TestModuleWithConfig(t, config)
}
