# =============================================================================
# Connection
# =============================================================================

variable "workspace_url" {
  description = "URL of the existing Databricks workspace (from deployment-v2 output)"
  type        = string
  default     = "https://dbc-4caaa24a-edaa.cloud.databricks.com"
}

variable "test_prefix" {
  description = "Prefix for all test resource names (enables parallel runs)"
  type        = string
  default     = "inttest"
}

# =============================================================================
# Compute Defaults
# =============================================================================

variable "node_type_id" {
  description = "EC2 instance type for clusters and instance pools"
  type        = string
  default     = "i3.xlarge"
}

variable "spark_version" {
  description = "Databricks Runtime version"
  type        = string
  default     = "14.3.x-scala2.12"
}

# =============================================================================
# Optional classic compute (global init script, cluster policy, pool, cluster)
# =============================================================================

variable "create_test_global_init_script" {
  description = "Create the global init script module"
  type        = bool
  default     = false
}

variable "create_test_cluster_policy" {
  description = "Create the cluster policy module"
  type        = bool
  default     = false
}

variable "create_test_instance_pool" {
  description = "Create the instance pool module"
  type        = bool
  default     = false
}

variable "create_test_cluster" {
  description = "Create the all-purpose cluster module (also enables library + cluster permissions)"
  type        = bool
  default     = false
}

# =============================================================================
# Identity
# =============================================================================

variable "test_sp_application_id" {
  description = "Application (client) ID for the test service principal"
  type        = string
  default     = "f41c5ff6-58ba-49b7-9524-20f6ee4b20b3"
}

variable "test_deployer_sp_application_id" {
  description = "Deployer service principal application (client) ID for the test job's run_as (GUID, not display name)."
  type        = string
}

# =============================================================================
# Secrets
# =============================================================================

variable "test_secret_value" {
  description = "Value for the test secret"
  type        = string
  default     = "integration-test-secret-value"
  sensitive   = true
}

variable "test_ip_allowlist_cidrs" {
  description = "CIDRs for the integration test IP allow list. Supply explicit ranges; do not use 0.0.0.0/0."
  type        = list(string)
  default     = ["10.0.0.0/8"]
}

# =============================================================================
# Repo (optional)
# =============================================================================

variable "test_repo_url" {
  description = "HTTPS URL of a git repo to import (empty to skip)"
  type        = string
  default     = ""
}

variable "test_repo_provider" {
  description = "Git provider (gitHub, bitbucketCloud, azureDevOpsServices, etc.)"
  type        = string
  default     = "gitHub"
}

variable "test_repo_branch" {
  description = "Branch to check out"
  type        = string
  default     = "main"
}

# =============================================================================
# Unity Catalog (optional - requires catalog from deployment-v2)
# =============================================================================

variable "catalog_name" {
  description = "Existing catalog name for schema tests (empty to skip when not creating test catalog)"
  type        = string
  default     = "terraform_workspace_catalog_7474656999765793"
}

variable "workspace_id" {
  description = "Databricks workspace numeric ID (used for catalog-creation naming when create_test_catalog = true)"
  type        = string
  default     = "7474656999765793"
}

# =============================================================================
# AWS (for creating new UC IAM role and S3 bucket when create_test_catalog = true)
# =============================================================================

variable "aws_region" {
  description = "AWS region for Unity Catalog S3 bucket and IAM role"
  type        = string
  default     = "us-east-1"
}

variable "databricks_aws_account_id" {
  description = "Databricks AWS account ID for IAM role trust policy (Unity Catalog assumes this role)"
  type        = string
  default     = "414351767826" # Databricks UC service account for standard AWS regions
}

variable "unity_catalog_iam_arn" {
  description = "Databricks Unity Catalog master role ARN for IAM trust policy (same as complete-workspace)"
  type        = string
  default     = "arn:aws:iam::414351767826:role/unity-catalog-prod-UCMasterRole-14S5ZJVKOTYTL"
}

# =============================================================================
# Storage Credential / External Location (optional)
# =============================================================================

variable "storage_credential_role_arn" {
  description = "IAM role ARN for storage credential test (empty to skip)"
  type        = string
  default     = "arn:aws:iam::332745928618:role/terraform-workspace-catalog-7474656999765793"
}

variable "external_location_url" {
  description = "S3 URL for external location test (empty to skip)"
  type        = string
  default     = "s3://terraform-workspace-catalog-7474656999765793/test_catalog/"
}

# =============================================================================
# Catalog (optional - creates a test catalog)
# =============================================================================

variable "create_test_catalog" {
  description = "Create a test catalog for catalog module testing"
  type        = bool
  default     = true
}

variable "create_test_table" {
  description = "Create a test table (requires catalog storage accessible by SQL warehouse). Disabled by default due to SQL API timeout; create in Databricks and import if needed."
  type        = bool
  default     = false
}

# Catalog-creation: Unity Catalog file events (optional SQS + external location file_event_queue)
variable "enable_catalog_file_events" {
  description = "When create_test_catalog is true, pass through to catalog-creation: SQS + S3 notifications and external location file events for Auto Loader-style ingestion"
  type        = bool
  default     = true
}

variable "catalog_file_events_sqs_message_retention_seconds" {
  description = "SQS retention for catalog file-events queue (60–1209600); only used when enable_catalog_file_events is true"
  type        = number
  default     = 345600
}

variable "catalog_file_events_sqs_kms_key_id" {
  description = "Optional KMS key for catalog file-events SQS; only used when enable_catalog_file_events is true"
  type        = string
  default     = null
}

variable "catalog_file_events_s3_events" {
  description = "S3 event types for catalog file-events notifications"
  type        = list(string)
  default     = ["s3:ObjectCreated:*"]
}

variable "catalog_file_events_s3_filter_prefix" {
  description = "Optional S3 key prefix filter for catalog file-events notifications"
  type        = string
  default     = ""
}

variable "catalog_file_events_s3_filter_suffix" {
  description = "Optional S3 key suffix filter for catalog file-events notifications"
  type        = string
  default     = ""
}

# =============================================================================
# Model Serving (optional - requires a registered model)
# =============================================================================

variable "model_serving_entity_name" {
  description = "Registered model name for model serving test (empty to skip)"
  type        = string
  default     = ""
}

variable "model_serving_entity_version" {
  description = "Model version for model serving test"
  type        = string
  default     = "1"
}

# =============================================================================
# Mount (optional/legacy - requires S3 bucket)
# =============================================================================

variable "mount_s3_bucket" {
  description = "S3 bucket name for mount test (empty to skip)"
  type        = string
  default     = ""
}

variable "mount_instance_profile" {
  description = "Instance profile ARN for mount test"
  type        = string
  default     = ""
}

# =============================================================================
# Permission framework (app_acronym/environment/app_id for group name construction)
# =============================================================================

variable "app_acronym" {
  description = "Application acronym for group name construction (e.g. dms)."
  type        = string
  default     = "dms"
}

variable "environment" {
  description = "Environment for group name construction (dev, uat, prod)."
  type        = string
  default     = "dev"
}

variable "app_id" {
  description = "Application ID for group name construction."
  type        = string
  default     = "179392"
}
